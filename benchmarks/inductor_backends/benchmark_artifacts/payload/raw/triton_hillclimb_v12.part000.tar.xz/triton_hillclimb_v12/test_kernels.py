import fcntl,json,math
from pathlib import Path
import torch
import triton
from torch.testing._internal.common_utils import TestCase,run_tests,parametrize
from torch.testing._internal.common_device_type import instantiate_device_type_tests,onlyCUDA
from kernels import softmax_backward,transpose_copy,norm_backward,broadcast_arithmetic
ROOT=Path(__file__).resolve().parent


class TestCategoryKernels(TestCase):
    @onlyCUDA
    @parametrize('special',[False,True])
    def test_softmax_backward_layouts_and_tails(self,device,special):
        for m,r in [(37,64),(65,128),(31,256)]:
            p=torch.softmax(torch.randn(m,r,device=device),-1);g=torch.randn_like(p);keep=torch.rand(m,r,device=device)>.3
            if special:p[1,0]=float('nan');g[2,0]=float('inf');keep[3]=False
            product=(g*(keep.float()*1.1111111111111112))*p
            ref=torch.addcmul(product,-p,product.sum(-1,keepdim=True))
            for rows,lanes,vec,warps in [(2,32,4,1),(4,16,4,1),(8,64,2,2)]:
                actual=p.clone();softmax_backward[(triton.cdiv(m,rows),)](actual,g,keep,m,r,rows,lanes,vec,warps,num_warps=warps)
                self.assertEqual(actual,ref,atol=2e-6,rtol=2e-5,equal_nan=True)

    @onlyCUDA
    def test_transpose_exact_tails(self,device):
        for b,h,s,d in [(2,3,37,64),(1,5,19,80),(2,12,577,64)]:
            x=torch.randn(b,h,s,d,device=device,dtype=torch.bfloat16);ref=x.permute(0,2,1,3).contiguous();out=torch.empty_like(ref)
            for block,vec,warps in [(512,1,1),(2048,4,4),(1024,8,2)]:
                for read_order in [0,1]:
                    transpose_copy[(triton.cdiv(x.numel(),block),)](x,out,x.numel(),h*d,s,d,block,warps,vec,read_order,num_warps=warps)
                    self.assertEqual(out,ref,atol=0,rtol=0)

    @onlyCUDA
    def test_norm_backward_layouts_and_tails(self,device):
        for m,r in [(37,128),(65,256),(19,1024),(17,1536)]:
            g=torch.randn(m,r,device=device,dtype=torch.bfloat16);w=torch.randn(r,device=device);h=torch.randn(m,r,device=device);scale=torch.rand(m,device=device)/r;keep=torch.rand(m,r,device=device)>.3
            v=g.float()*w;ref=scale[:,None]*((v*r-v.sum(-1,keepdim=True))-h*(v*h).sum(-1,keepdim=True));refout=(ref*(keep.float()*1.1111111111111112)).to(torch.bfloat16)
            for rows,lanes,vec,warps in [(4,16,4,1),(2,32,4,1),(8,64,2,2)]:
                actual=h.clone();out=torch.empty_like(g);norm_backward[(triton.cdiv(m,rows),)](actual,g,w,scale,keep,out,actual,m,triton.next_power_of_2(r),rows,lanes,vec,warps,RNUM=r,num_warps=warps)
                self.assertEqual(actual,ref,atol=2e-5,rtol=2e-5)
                self.assertEqual(out,refout,atol=.008,rtol=.01)

    @onlyCUDA
    def test_broadcast_exact_tails_and_specials(self,device):
        for n in [4099,65537]:
            for dtype in [torch.bfloat16,torch.float32]:
                x=torch.randn(n,device=device,dtype=dtype)
                x[:5]=torch.tensor([0.,-0.,float('inf'),-float('inf'),float('nan')],device=device,dtype=dtype)
                for scalar in [-.75,0.,1.25]:
                    scale=torch.tensor(scalar,device=device);ref=((scale*(1.0/n))*(x.float()*2.)).to(dtype)
                    for block,unroll,warps,vec in [(256,2,1,2),(1024,1,2,8)]:
                        out=torch.empty_like(x);broadcast_arithmetic[(triton.cdiv(n,block*unroll),)](scale,x,out,n,block,unroll,warps,vec,num_warps=warps)
                        self.assertEqual(out,ref,atol=0,rtol=0,equal_nan=True)

    @onlyCUDA
    @parametrize('index',[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14])
    def test_recorded_winners_against_torch(self,device,index):
        from search import ROWS,Case
        row=ROWS[index];path=Path(row['folder'])/'FINAL.json'
        if not path.exists():self.skipTest('search not complete')
        result=json.loads(path.read_text());best=min((r for r in result['rows'] if r['label'].startswith('candidate')),key=lambda r:r['runtime_us']);case=Case(row,4242);case.reset();a=case.args;k=row['category'];dims=row['dims']
        if k=='mean':
            x=a[0].flatten();r=dims['r0_numel'];n=x.numel();expected=torch.empty(dims['xnumel'],device=device)
            for start in range(0,dims['xnumel'],16):
                end=min(start+16,dims['xnumel']);segment=x[start*r:min(end*r,n)].float();segment=torch.nn.functional.pad(segment,(0,(end-start)*r-segment.numel()));expected[start:end]=(segment.view(end-start,r)**2).sum(-1)
            refs=[expected]
        elif k=='softmaxbw':
            p=case.originals[0].reshape(-1,dims['r0_numel']);product=(a[1].reshape_as(p)*(a[2].reshape_as(p).float()*1.1111111111111112))*p;refs=[torch.addcmul(product,-p,product.sum(-1,keepdim=True)).reshape(a[0].shape)]
        elif k=='transpose':
            shape=a[0].shape;s,d=shape[-2:];c=a[1].shape[-1];h=c//d;b=a[0].numel()//(h*s*d);refs=[a[0].reshape(b,h,s,d).permute(0,2,1,3).contiguous().reshape(a[1].shape)]
        elif k=='broadcast':
            n=dims['xnumel'];scalar=a[0].item();refs=[torch.empty_like(a[2])]
            factor=1./n
            for start in range(0,n,1<<24):refs[0].view(-1)[start:start+(1<<24)]=((a[0]*factor)*(a[1].view(-1)[start:start+(1<<24)].float()*2.)).to(a[2].dtype)
        elif index in [9,10]:
            if index==9:h=case.originals[0];g,w,scale,keep=a[1:5]
            else:g,w,h,scale,keep=a[:5]
            m=dims['xnumel'];r=dims['r0_numel'];v=g.reshape(m,r).float()*w;h=h.reshape(m,r);scale=scale.reshape(m,1);keep=keep.reshape(m,r)
            ref=scale*((v*r-v.sum(-1,keepdim=True))-h*(v*h).sum(-1,keepdim=True));refs=[ref.reshape(a[case.outputs[0]].shape),(ref*(keep.float()*1.1111111111111112)).to(torch.bfloat16).reshape(a[case.outputs[1]].shape)]
        else:
            v=a[0].reshape(32,256,128).float()*(a[1].reshape(32,256,128).float()*1.1111111111111112);refs=[(v*a[2].reshape(32,256,128)).sum(1).t(),v.sum(1).t()]
        case.validate(case.callable(best['config']))
        errors=[]
        for i,ref in zip(case.outputs,refs):
            exact=k in ['transpose','broadcast'];self.assertEqual(a[i],ref,atol=0 if exact else .02 if a[i].dtype==torch.bfloat16 else .003,rtol=0 if exact else .02 if a[i].dtype==torch.bfloat16 else 2e-4,equal_nan=True)
        del case
        torch.cuda.empty_cache()


instantiate_device_type_tests(TestCategoryKernels,globals(),only_for='cuda')
if __name__=='__main__':
    with open('/dev/shm/pytorch-simd-v2-entry.lock','a') as e,open('/dev/shm/pytorch-simd-v2-benchmark.lock','a') as b:
        fcntl.flock(e,fcntl.LOCK_EX);fcntl.flock(b,fcntl.LOCK_EX);run_tests()
