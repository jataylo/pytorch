import triton
from triton.experimental import gluon
from triton.experimental.gluon import language as gl


@gluon.jit
def softmax_backward(p,g,mask,M:gl.constexpr,R:gl.constexpr,ROWS:gl.constexpr,LANES:gl.constexpr,VEC:gl.constexpr,WARPS:gl.constexpr,RNUM:gl.constexpr=0):
    layout:gl.constexpr=gl.BlockedLayout([1,VEC],[64//LANES,LANES],[WARPS,1],[1,0])
    row=gl.program_id(0)*ROWS+gl.arange(0,ROWS,layout=gl.SliceLayout(1,layout))
    col=gl.arange(0,R,layout=gl.SliceLayout(0,layout))
    idx=row[:,None]*R+col[None,:]
    prob=gl.load(p+idx,row[:,None]<M,other=0)
    grad=gl.load(g+idx,row[:,None]<M,other=0)
    keep=gl.load(mask+idx,row[:,None]<M,other=0).to(gl.float32)
    product=(grad*(keep*1.1111111111111112))*prob
    total=gl.sum(product,1)
    value=gl.fma(-prob,total[:,None],product)
    gl.store(p+idx,value,row[:,None]<M)


@gluon.jit
def transpose_copy(x,y,N:gl.constexpr,C:gl.constexpr,S:gl.constexpr,D:gl.constexpr,BLOCK:gl.constexpr,WARPS:gl.constexpr,VEC:gl.constexpr,READ_ORDER:gl.constexpr=0):
    i=gl.program_id(0)*BLOCK+gl.arange(0,BLOCK,layout=gl.BlockedLayout([VEC],[64],[WARPS],[0]))
    x0=i%C
    x1=i//C
    offset=D*(x1%S)+(S*D)*(x0//D)+(S*C)*(x1//S)+(x0%D)
    if READ_ORDER == 0:
        v=gl.load(x+offset,i<N,other=0)
        gl.store(y+i,v,i<N)
    else:
        output=(i//(S*C))*(S*C)+((i//D)%S)*C+((i//(S*D))%(C//D))*D+(i%D)
        v=gl.load(x+i,i<N,other=0)
        gl.store(y+output,v,i<N)


@gluon.jit
def norm_backward(xhat,grad,weight,scale,mask,out,statout,M:gl.constexpr,R:gl.constexpr,ROWS:gl.constexpr,LANES:gl.constexpr,VEC:gl.constexpr,WARPS:gl.constexpr,RNUM:gl.constexpr=0):
    layout:gl.constexpr=gl.BlockedLayout([1,VEC],[64//LANES,LANES],[WARPS,1],[1,0])
    row=gl.program_id(0)*ROWS+gl.arange(0,ROWS,layout=gl.SliceLayout(1,layout))
    col=gl.arange(0,R,layout=gl.SliceLayout(0,layout))
    if RNUM == 0:
        RNUM=R
    valid=(row[:,None]<M)&(col[None,:]<RNUM)
    idx=row[:,None]*RNUM+col[None,:]
    g=gl.load(grad+idx,valid,other=0).to(gl.float32)
    w=gl.load(weight+col,col<RNUM,other=0)
    h=gl.load(xhat+idx,valid,other=0)
    s=gl.load(scale+row,row<M,other=0)
    keep=gl.load(mask+idx,valid,other=0).to(gl.float32)
    v=g*w[None,:]
    sum1=gl.sum(v,1)
    sum2=gl.sum(v*h,1)
    value=s[:,None]*((v*RNUM-sum1[:,None])-h*sum2[:,None])
    gl.store(statout+idx,value,valid)
    gl.store(out+idx,value*(keep*1.1111111111111112),valid)


@gluon.jit
def broadcast_arithmetic(scalar,x,y,N:gl.constexpr,BLOCK:gl.constexpr,UNROLL:gl.constexpr,WARPS:gl.constexpr,VEC:gl.constexpr):
    lane=gl.arange(0,BLOCK,layout=gl.BlockedLayout([VEC],[64],[WARPS],[0]))
    scale=gl.load(scalar)*(1.0/N)
    for u in gl.static_range(UNROLL):
        i=gl.program_id(0)*(BLOCK*UNROLL)+u*BLOCK+lane
        v=gl.load(x+i,i<N,other=0).to(gl.float32)
        gl.store(y+i,scale*(v*2.0),i<N)
