import argparse,ast,csv,fcntl,hashlib,importlib.util,json,math,random,statistics,sys,time,traceback
from pathlib import Path
import torch
import triton
from kernels import softmax_backward,transpose_copy,norm_backward,broadcast_arithmetic
ROOT=Path(__file__).resolve().parent
ROWS=json.loads((ROOT/'manifest.json').read_text())

def load(path):
    name='hc12_'+hashlib.sha256(str(path).encode()).hexdigest()[:16]
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m


def generated(row,cfg):
    folder=Path(row['folder'])/'candidates';folder.mkdir(exist_ok=True)
    path=folder/(hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest()[:16]+'.py')
    source=(Path(row['folder'])/'original_triton.py').read_text()
    if cfg.get('simplify'):
        import re
        source=re.sub(r'\(\(\(r0_1 \+ (\d+)\*x0\) % (\d+)\)\)',r'(r0_1 + \1*x0)',source)
    tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef))
    if cfg.get('unroll',1)>1:
        start=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='xindex' for t in n.targets))
        tail=fn.body[start:]
        for n in ast.walk(tail[0]):
            if isinstance(n,ast.Name) and n.id=='xoffset':n.id='unrolled_offset'
        setup=ast.parse(f'unrolled_offset = xoffset * {cfg["unroll"]} + u * XBLOCK').body
        fn.body=fn.body[:start]+[ast.For(target=ast.Name(id='u',ctx=ast.Store()),iter=ast.parse(f'tl.static_range({cfg["unroll"]})',mode='eval').body,body=setup+tail,orelse=[])]
    old=next(d for d in fn.decorator_list if isinstance(d,ast.Call));kw={k.arg:k.value for k in old.keywords}
    ckeys={k:v for k,v in cfg.items() if k in ['XBLOCK','R0_BLOCK','waves_per_eu']}
    cexpr=f'triton.Config({ckeys!r},num_warps={cfg["num_warps"]},num_stages={cfg.get("num_stages",1)})'
    kind='POINTWISE' if row['category'] in ['transpose','broadcast'] else 'PERSISTENT_REDUCTION' if 'R0_BLOCK' not in row['signature'] else 'REDUCTION'
    kw['inductor_meta']=ast.parse('dict('+ast.unparse(kw['inductor_meta'])+', )',mode='eval').body if False else kw['inductor_meta']
    kw['inductor_meta'].keys.extend([ast.Constant('force_disable_caches'),ast.Constant('autotune_local_cache')]);kw['inductor_meta'].values.extend([ast.Constant(True),ast.Constant(False)])
    fn.decorator_list=[ast.Call(func=ast.parse('triton_heuristics.cached_autotune',mode='eval').body,args=[],keywords=[ast.keyword(arg='size_hints',value=kw['size_hints']),ast.keyword(arg='configs',value=ast.List(elts=[ast.parse(cexpr,mode='eval').body],ctx=ast.Load())),ast.keyword(arg='triton_meta',value=kw['triton_meta']),ast.keyword(arg='inductor_meta',value=kw['inductor_meta']),ast.keyword(arg='heuristic_type',value=ast.parse('triton_heuristics.HeuristicType.'+kind,mode='eval').body),ast.keyword(arg='filename',value=ast.Name(id='__file__',ctx=ast.Load()))]),ast.parse('triton.jit',mode='eval').body]
    ast.fix_missing_locations(tree);path.write_text(ast.unparse(tree)+'\n');return getattr(load(path),row['triton_name'])


class Case:
    def __init__(self,row,seed=2026):
        self.row=row;self.name=row['category'];self.flush_mb=256
        self.args=[];self.pointer_names=[k for k,v in row['signature'].items() if v.startswith('*')]
        self.outputs=[i for i,k in enumerate(self.pointer_names) if k.startswith(('out_','in_out'))]
        self.mutated=row['mutated_indices']
        for name in row['actual_args']:
            b=row['buffers'][name];self.args.append(torch.empty_strided(tuple(map(int,b['shape'])),tuple(map(int,b['stride'])),device='cuda',dtype=getattr(torch,b['dtype'].split('.')[-1])))
        self.dimargs=[row['dims'][k] for k,v in row['signature'].items() if v=='i32']
        self.originals={i:torch.empty_like(self.args[i]) for i in self.mutated};self.refresh(seed)
        self.warm=[torch.empty(0,device='cuda',dtype=torch.uint8).set_(self.args[i].untyped_storage()) for i in row['warm_indices']]
        self.native=self.callable(self.baseconfig())
        fpath=Path(row['folder'])/'fly_replay.py';fsrc=(Path(row['folder'])/'original_flydsl.py').read_text()
        original_binary=ast.parse(row['fly_compile'],mode='eval').body.args[3].value
        original_py=Path(original_binary.split('.'+row['kernel_name'])[0]+'.py')
        fpath.write_text(fsrc.replace('__file__',repr(str(original_py))))
        self.fly=getattr(load(fpath),row['kernel_name']+f'_c{row["fly_candidate"]}_main')
        self.fly_fn=lambda:self.fly(*self.args,stream=torch.cuda.current_stream().cuda_stream)
        self.reset();self.native();torch.cuda.synchronize();self.expected=[self.args[i].clone() for i in self.outputs]

    def baseconfig(self):
        return {k:v for k,v in self.row['baseline_config'].items() if k in ['XBLOCK','R0_BLOCK','num_warps','num_stages','waves_per_eu']}

    def refresh(self,seed):
        torch.manual_seed(seed)
        for i,a in enumerate(self.args):
            if a.dtype==torch.bool:a.random_(0,2)
            else:a.normal_(0,.5)
        if self.name=='softmaxbw':self.args[0].copy_(torch.softmax(self.args[0],-1))
        if self.name=='normbw' and self.row['index']==9:self.args[3].abs_().add_(.1).div_(self.row['dims']['r0_numel'])
        for i in self.mutated:self.originals[i].copy_(self.args[i])

    def reset(self):
        for i in self.mutated:self.args[i].copy_(self.originals[i])

    def callable(self,cfg):
        r=self.row;dims=r['dims'];kind=cfg.get('kind','generated')
        if kind=='gl':
            if self.name=='broadcast':
                return lambda:broadcast_arithmetic[(triton.cdiv(dims['xnumel'],cfg['XBLOCK']*cfg['unroll']),)](*self.args,N=dims['xnumel'],BLOCK=cfg['XBLOCK'],UNROLL=cfg['unroll'],WARPS=cfg['num_warps'],VEC=cfg['VEC'],num_warps=cfg['num_warps'],enable_fp_fusion=True)
            if self.name=='softmaxbw':fn=softmax_backward;args=self.args;extra=dict(M=dims['xnumel'],R=dims['r0_numel'])
            elif self.name=='normbw':
                fn=norm_backward;args=[*self.args,self.args[0]] if r['index']==9 else [self.args[2],self.args[0],self.args[1],self.args[3],self.args[4],self.args[6],self.args[5]];extra=dict(M=dims['xnumel'],R=triton.next_power_of_2(dims['r0_numel']),RNUM=dims['r0_numel'])
            else:
                fn=transpose_copy;args=self.args;b=r['buffers'][r['actual_args'][0]]['shape'];s,d=map(int,b[-2:]);c=int(r['buffers'][r['actual_args'][1]]['shape'][-1]);extra=dict(N=dims['xnumel'],C=c,S=s,D=d,BLOCK=cfg['XBLOCK'],READ_ORDER=cfg.get('READ_ORDER',0))
            if self.name=='transpose':grid=(triton.cdiv(dims['xnumel'],cfg['XBLOCK']),)
            else:grid=(triton.cdiv(dims['xnumel'],cfg['ROWS']),);extra.update(ROWS=cfg['ROWS'],LANES=cfg['LANES'])
            return lambda:fn[grid](*args,**extra,WARPS=cfg['num_warps'],VEC=cfg['VEC'],num_warps=cfg['num_warps'],enable_fp_fusion=True)
        kernel=generated(r,cfg)
        if cfg.get('unroll',1)>1:
            # The generated grid helper still divides by XBLOCK; adjust its extent.
            dimargs=[self.dimargs[0]//cfg['unroll'],*self.dimargs[1:]]
        else:dimargs=self.dimargs
        return lambda:kernel.run(*self.args,*dimargs,stream=torch.cuda.current_stream().cuda_stream)

    def validate(self,fn):
        self.reset();compiled=fn();torch.cuda.synchronize();error=0
        for i,expected in zip(self.outputs,self.expected):
            actual=self.args[i]
            if self.name in ['transpose','broadcast']:torch.testing.assert_close(actual,expected,atol=0,rtol=0,equal_nan=True)
            else:torch.testing.assert_close(actual,expected,atol=1e-4 if actual.dtype==torch.float32 else .02,rtol=1e-4 if actual.dtype==torch.float32 else .02,equal_nan=True)
            # Avoid allocating a full FP32 difference for billion-element tensors.
            a=actual.flatten();b=expected.flatten()
            for start in range(0,a.numel(),1<<24):error=max(error,(a[start:start+(1<<24)].float()-b[start:start+(1<<24)].float()).abs().nan_to_num().max().item())
        return compiled,error


def measure(case,entries,rounds=3,reps=3):
    flush=torch.empty(case.flush_mb<<20,device='cuda',dtype=torch.uint8);samples=[[] for _ in entries]
    events=[[(torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)) for _ in range(reps)] for _ in entries]
    for rnd in range(rounds):
        torch.cuda._sleep(10_000_000)
        for j in range(len(entries)):
            i=(rnd+j)%len(entries)
            for a,b in events[i]:
                flush.zero_();case.reset()
                for value in case.warm:value.add_(0)
                a.record();entries[i]['fn']();b.record()
        torch.cuda.synchronize()
        for i,es in enumerate(events):samples[i].append(statistics.mean(a.elapsed_time(b)*1000 for a,b in es))
    return [dict(median_us=statistics.median(s),samples_us=s) for s in samples]


def neighbors(case,cfg):
    if cfg.get('kind')=='gl':
        opts={'num_warps':[1,2,4,8],'VEC':[1,2,4,8]}
        opts.update({'XBLOCK':[128,256,512,1024,2048,4096,8192],'unroll':[1,2,4,8,16]} if case.name=='broadcast' else {'XBLOCK':[256,512,1024,2048,4096,8192],'READ_ORDER':[0,1]} if case.name=='transpose' else {'ROWS':[1,2,4,8,16,32],'LANES':[8,16,32,64]})
    else:
        opts={'XBLOCK':[1,2,4,8,16,32,64] if case.name in ['mean','softmaxbw','normbw'] else [256,512,1024,2048,4096,8192,16384], 'num_warps':[1,2,4,8],'waves_per_eu':[0,1,2,4]}
        if 'R0_BLOCK' in cfg:opts['R0_BLOCK']=[64,128,256,512,1024,2048,4096,8192]
        if case.name=='mean':opts['simplify']=[False,True]
        if case.name in ['broadcast','transpose']:opts['unroll']=[1,2,4,8]
    for k,values in opts.items():
        old=cfg.get(k,False if k=='simplify' else 1 if k=='unroll' else 0)
        if old in values:
            ix=values.index(old);choices=values[max(0,ix-1):ix]+values[ix+1:ix+2]
        else:choices=values[:2]
        for v in choices:
            c=dict(cfg);c[k]=v
            if c.get('XBLOCK',1)*c.get('R0_BLOCK',1)>65536:continue
            if case.name in ['softmaxbw','normbw','transpose','broadcast'] and 'xmask = xindex < xnumel' not in (Path(case.row['folder'])/'original_triton.py').read_text() and case.row['dims']['xnumel']%(c.get('XBLOCK',c.get('ROWS',1))*c.get('unroll',1)):continue
            yield c


def conf(a,b):
    v=[100*(x-y)/x for x,y in zip(a,b)];rng=random.Random(2026);boot=sorted(statistics.median(rng.choices(v,k=len(v))) for _ in range(2000))
    return dict(paired_median_percent=statistics.median(v),bootstrap95_low=boot[int(.025*len(boot))],bootstrap95_high=boot[int(.975*len(boot))])


def search(row,limit):
    folder=Path(row['folder']);case=Case(row);seen={};valid=[]
    def evaluate(cfg):
        key=json.dumps(cfg,sort_keys=True)
        if key in seen:return seen[key]
        item=dict(config=cfg)
        try:
            fn=case.callable(cfg);compiled,error=case.validate(fn);item.update(measure(case,[dict(fn=fn)],2,2)[0],max_abs_error=error);valid.append(item)
        except Exception as exc:item['error']=str(exc)[-1500:]
        seen[key]=item;(folder/'search.json').write_text(json.dumps(list(seen.values()),indent=2));return item
    seeds=[case.baseconfig()]
    if case.name in ['mean','normbw']:seeds.append(dict(case.baseconfig(),num_warps=2,XBLOCK=1,R0_BLOCK=1024) if 'R0_BLOCK' in case.row['signature'] else dict(case.baseconfig(),num_warps=1,XBLOCK=4))
    if case.name in ['softmaxbw','normbw'] and row['index'] in [3,4,5,9,10]:seeds.append(dict(kind='gl',ROWS=4,LANES=16,VEC=4,num_warps=1))
    if case.name=='transpose':seeds.append(dict(kind='gl',XBLOCK=2048,VEC=4,num_warps=2))
    if case.name=='broadcast':
        seeds.extend([dict(case.baseconfig(),XBLOCK=1024,num_warps=2,unroll=4,waves_per_eu=0),dict(kind='gl',XBLOCK=256,num_warps=1,unroll=8,VEC=4),dict(kind='gl',XBLOCK=1024,num_warps=2,unroll=4,VEC=8)])
    for seed in seeds:evaluate(seed)
    for step in range(5):
        pool=[]
        for kind in ['generated','gl']:
            choices=[v for v in valid if v['config'].get('kind','generated')==kind]
            if choices:pool.extend(neighbors(case,min(choices,key=lambda v:v['median_us'])['config']))
        before=len(seen)
        for cfg in pool:
            if len(seen)>=limit:break
            evaluate(cfg)
        if len(seen)==before or len(seen)>=limit:break
    finalists=sorted(valid,key=lambda v:v['median_us'])[:3]
    entries=[dict(label='original',fn=case.native),dict(label='flydsl',fn=case.fly_fn)]
    entries +=[dict(label=f'candidate{i}',config=v['config'],fn=case.callable(v['config'])) for i,v in enumerate(finalists)]
    allsamples={e['label']:[] for e in entries};errors={e['label']:[] for e in entries};hashes=[]
    for seed in [999,1337]:
        case.refresh(seed);hashes.append(hashlib.sha256(case.args[0].flatten()[:1024].float().cpu().numpy().tobytes()).hexdigest());case.reset();case.native();torch.cuda.synchronize();case.expected=[case.args[i].clone() for i in case.outputs]
        for e in entries:
            compiled,error=case.validate(e['fn']);errors[e['label']].append(error)
            if compiled is not None and hasattr(compiled,'asm'):
                for ext in ['ttgir','amdgcn']:
                    if ext in compiled.asm:(folder/(e['label']+'.'+ext)).write_text(compiled.asm[ext])
        for e,m in zip(entries,measure(case,entries,10,4)):allsamples[e['label']]+=m['samples_us']
    rows=[];baseline=statistics.median(allsamples['original']);fly=statistics.median(allsamples['flydsl'])
    for e in entries:
        label=e['label'];us=statistics.median(allsamples[label]);rows.append(dict(index=row['index'],category=row['category'],model=row['model'],label=label,config=e.get('config'),runtime_us=us,original_triton_us=baseline,flydsl_us=fly,time_saved_vs_original_percent=100*(baseline-us)/baseline,time_saved_vs_flydsl_percent=100*(fly-us)/fly,max_abs_error=max(errors[label]),**conf(allsamples['original'],allsamples[label])))
    result=dict(rows=rows,samples=allsamples,validation_errors=errors,input_hashes=hashes,candidates_tested=len(seen),candidates_valid=len(valid),math_policy='unchanged math functions and arithmetic expressions; reductions may reorder',full_model_rerun=False)
    (folder/'FINAL.json').write_text(json.dumps(result,indent=2));print('RESULT',json.dumps(rows),flush=True)
    del case;torch.cuda.empty_cache();return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--limit',type=int,default=55);parser.add_argument('--indices',default='');args=parser.parse_args()
    with open('/dev/shm/pytorch-simd-v2-entry.lock','a') as e,open('/dev/shm/pytorch-simd-v2-benchmark.lock','a') as b:
        fcntl.flock(e,fcntl.LOCK_EX);fcntl.flock(b,fcntl.LOCK_EX)
        for row in ROWS:
            if args.indices and row['index'] not in list(map(int,args.indices.split(','))):continue
            if (Path(row['folder'])/'FINAL.json').exists():continue
            print('START',row['index'],row['model'],flush=True)
            try:search(row,args.limit)
            except Exception:
                (Path(row['folder'])/'ERROR.txt').write_text(traceback.format_exc());traceback.print_exc()
        results=[json.loads(p.read_text()) for p in ROOT.glob('*/FINAL.json')];(ROOT/'SUMMARY.json').write_text(json.dumps(results,indent=2))
