import ast,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
rows=json.loads((ROOT/'selected_cases.json').read_text())
allrows=__import__('csv').DictReader(open(ROOT.parent/'kernel_routes_v9/per_kernel_routes.csv'))
lookup={(r['model'],r['kernel_name'],r['tuning']):r for r in allrows if r['timing_available']=='True'}
manifest=[]
for i,row in enumerate(rows):
    record=Path(row['diagnostic_file']).parent.parent
    audit=json.loads((record/'codegen/flydsl_autotune1.world1.rank0.json').read_text())
    name=row['kernel_name']; found=None
    for graph in audit['graphs']:
        p=Path(graph['wrapper'])
        if not p.exists():continue
        text=p.read_text()
        if name+'_select_' not in text:continue
        tree=ast.parse(text)
        selector=next((n for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='fdp_rt.BackendSelector' and name in ast.unparse(n.targets[0])),None)
        if selector is not None:found=(p,text,tree,selector);break
    if found is None:raise RuntimeError(name)
    p,text,tree,selector=found
    sname=ast.unparse(selector.targets[0]); trun=selector.value.args[0].elts[1].body; tname=ast.unparse(trun.func).split('.')[0]
    assigns={ast.unparse(n.targets[0]):n for n in tree.body if isinstance(n,ast.Assign)}
    tsrc=assigns[tname].value.args[1].value
    fassign=assigns[name];fsrc=next(n.value for n in ast.walk(fassign.value) if isinstance(n,ast.Constant) and isinstance(n.value,str) and 'import flydsl.compiler' in n.value)
    run=next(n for n in ast.walk(tree) if isinstance(n,ast.Call) and ast.unparse(n.func)==sname+'.run')
    meta=lookup[row['model'],name,'expanded'];buffers=json.loads(meta['buffers_json'])
    folder=ROOT/f'{i:02d}_{row["category"]}';folder.mkdir(exist_ok=True)
    (folder/'original_triton.py').write_text(tsrc);(folder/'original_flydsl.py').write_text(fsrc)
    e=dict(row,index=i,folder=str(folder),wrapper=str(p),triton_name=tname,triton_run=ast.unparse(trun),actual_args=[ast.unparse(a) for a in run.args],buffers=buffers,warm_indices=ast.literal_eval(selector.value.args[1]),mutated_indices=ast.literal_eval(selector.value.args[2]),selector_source=ast.unparse(selector),fly_compile=ast.unparse(fassign.value))
    manifest.append(e)
    print(i,row['category'],row['model'],e['actual_args'],buffers, '\n',tsrc[tsrc.index('def '):][:500],flush=True)
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2))
