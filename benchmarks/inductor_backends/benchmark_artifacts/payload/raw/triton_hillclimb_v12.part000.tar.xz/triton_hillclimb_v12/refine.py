from pathlib import Path
p=Path(__file__).with_name('search.py');s=p.read_text();s=s.replace("if case.name in ['softmaxbw','normbw','transpose','broadcast'] and case.row['dims']['xnumel']%(c.get('XBLOCK',c.get('ROWS',1))*c.get('unroll',1)):continue", "if case.name in ['softmaxbw','normbw','transpose','broadcast'] and 'xmask = xindex < xnumel' not in (Path(case.row['folder'])/'original_triton.py').read_text() and case.row['dims']['xnumel']%(c.get('XBLOCK',c.get('ROWS',1))*c.get('unroll',1)):continue")
p.write_text(s)
