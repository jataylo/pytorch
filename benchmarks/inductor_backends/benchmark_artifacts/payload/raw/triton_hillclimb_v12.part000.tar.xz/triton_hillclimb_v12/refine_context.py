import ast,json,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
rows=json.loads((root/'manifest.json').read_text())
for row in rows:
    selector=ast.parse(row['selector_source']).body[0].value
    row['mutated_indices']=ast.literal_eval(selector.args[1]);row['warm_indices']=ast.literal_eval(selector.args[2])
    for name in ['FINAL.json','search.json']:
        p=Path(row['folder'])/name
        if p.exists():shutil.move(p,p.with_name('pilot_'+name))
(root/'manifest.json').write_text(json.dumps(rows,indent=2))
p=root/'search.py';s=p.read_text().replace("self.mutated=[i for i,k in enumerate(self.pointer_names) if k.startswith('in_out')]","self.mutated=row['mutated_indices']")
s=s.replace("self.warm=[self.args[i].view(torch.uint8) for i in row['warm_indices'] if self.args[i].is_contiguous()]","self.warm=[torch.empty(0,device='cuda',dtype=torch.uint8).set_(self.args[i].untyped_storage()) for i in row['warm_indices']]")
s=s.replace("if self.name=='normbw':fn=norm_backward;args=self.args;extra=dict(M=dims['xnumel'],R=dims['r0_numel'])","if self.name=='normbw':fn=norm_backward;args=self.args;extra=dict(M=dims['xnumel'],R=dims['r0_numel'])")
s=s.replace("elif self.name=='normbw':fn=norm_backward;args=self.args;extra=dict(M=dims['xnumel'],R=dims['r0_numel'])","elif self.name=='normbw':\n                fn=norm_backward;args=[*self.args,self.args[0]] if r['index']==9 else [self.args[2],self.args[0],self.args[1],self.args[3],self.args[4],self.args[6],self.args[5]];extra=dict(M=dims['xnumel'],R=triton.next_power_of_2(dims['r0_numel']),RNUM=dims['r0_numel'])")
s=s.replace("BLOCK=cfg['XBLOCK'])","BLOCK=cfg['XBLOCK'],READ_ORDER=cfg.get('READ_ORDER',0))")
s=s.replace("opts.update({'XBLOCK':[256,512,1024,2048,4096,8192]}","opts.update({'XBLOCK':[256,512,1024,2048,4096,8192],'READ_ORDER':[0,1]}")
s=s.replace("[3,4,5,9]","[3,4,5,9,10]")
s=s.replace("atol=2e-4 if actual.dtype==torch.float32 else .02,rtol=2e-4 if actual.dtype==torch.float32 else .02","atol=1e-4 if actual.dtype==torch.float32 else .02,rtol=1e-4 if actual.dtype==torch.float32 else .02")
p.write_text(s)
p=root/'kernels.py';s=p.read_text().replace('VEC:gl.constexpr):\n    i=','VEC:gl.constexpr,READ_ORDER:gl.constexpr=0):\n    i=')
s=s.replace('v=gl.load(x+offset,i<N,other=0)\n    gl.store(y+i,v,i<N)','if READ_ORDER == 0:\n        v=gl.load(x+offset,i<N,other=0)\n        gl.store(y+i,v,i<N)\n    else:\n        output=(i//(S*C))*(S*C)+((i//D)%S)*C+((i//(S*D))%(C//D))*D+(i%D)\n        v=gl.load(x+i,i<N,other=0)\n        gl.store(y+output,v,i<N)')
s=s.replace('mask,out,M:gl.constexpr,R:gl.constexpr,ROWS:', 'mask,out,statout,M:gl.constexpr,R:gl.constexpr,ROWS:')
s=s.replace('VEC:gl.constexpr,WARPS:gl.constexpr):\n    layout:', 'VEC:gl.constexpr,WARPS:gl.constexpr,RNUM:gl.constexpr=0):\n    layout:')
# Only norm uses a padded reduction extent.
s=s.replace('    idx=row[:,None]*R+col[None,:]\n    g=gl.load(grad+idx,row[:,None]<M,other=0)', '    if RNUM == 0:\n        RNUM=R\n    valid=(row[:,None]<M)&(col[None,:]<RNUM)\n    idx=row[:,None]*RNUM+col[None,:]\n    g=gl.load(grad+idx,valid,other=0)')
s=s.replace('w=gl.load(weight+col)','w=gl.load(weight+col,col<RNUM,other=0)').replace('h=gl.load(xhat+idx,row[:,None]<M,other=0)','h=gl.load(xhat+idx,valid,other=0)').replace('keep=gl.load(mask+idx,row[:,None]<M,other=0).to(gl.float32)\n    v=g*w','keep=gl.load(mask+idx,valid,other=0).to(gl.float32)\n    v=g*w')
s=s.replace('((v*R-sum1[:,None])','((v*RNUM-sum1[:,None])').replace('gl.store(xhat+idx,value,row[:,None]<M)','gl.store(statout+idx,value,valid)').replace('gl.store(out+idx,value*(keep*1.1111111111111112),row[:,None]<M)','gl.store(out+idx,value*(keep*1.1111111111111112),valid)')
p.write_text(s)
p=root/'test_kernels.py';s=p.read_text().replace('actual,g,w,scale,keep,out,m,r,rows,lanes,vec,warps','actual,g,w,scale,keep,out,actual,m,r,rows,lanes,vec,warps')
s=s.replace("p=case.originals[0];product=(a[1]*(a[2].float()*1.1111111111111112))*p;refs=[torch.addcmul(product,-p,product.sum(-1,keepdim=True))]","p=case.originals[0].reshape(-1,dims['r0_numel']);product=(a[1].reshape_as(p)*(a[2].reshape_as(p).float()*1.1111111111111112))*p;refs=[torch.addcmul(product,-p,product.sum(-1,keepdim=True)).reshape(a[0].shape)]")
s=s.replace("(v*a[2].reshape(32,256,128)).sum(1).flatten(),v.sum(1).flatten()","(v*a[2].reshape(32,256,128)).sum(1).t(),v.sum(1).t()")
p.write_text(s)
