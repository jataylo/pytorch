from pathlib import Path
root=Path(__file__).resolve().parent
p=root/'confirm.py';s=p.read_text().replace('import csv,fcntl,hashlib,json,statistics','import csv,fcntl,hashlib,json,statistics,sys')
s=s.replace('for row in ROWS:\n            final=',"for row in ROWS:\n            if len(sys.argv)>1 and row['index'] not in list(map(int,sys.argv[1].split(','))):continue\n            final=")
s=s.replace("        (OUT/'SUMMARY.json').write_text", "        rows=[json.loads(p.read_text())['result'] for p in sorted(OUT.glob('[0-9][0-9].json'))]\n        (OUT/'SUMMARY.json').write_text")
p.write_text(s)
p=root/'test_kernels.py';s=p.read_text().replace('from kernels import softmax_backward,transpose_copy,norm_backward','from kernels import softmax_backward,transpose_copy,norm_backward,broadcast_arithmetic')
s=s.replace('    @onlyCUDA\n    @parametrize(\'index\'', '''    @onlyCUDA
    def test_broadcast_exact_tails_and_specials(self,device):
        for n in [4099,65537]:
            for dtype in [torch.bfloat16,torch.float32]:
                x=torch.randn(n,device=device,dtype=dtype)
                x[:5]=torch.tensor([0.,-0.,float('inf'),-float('inf'),float('nan')],device=device,dtype=dtype)
                for scalar in [-.75,0.,1.25]:
                    scale=torch.tensor(scalar,device=device);ref=((scale*(1.0/n))*(x.float()*2.)).to(dtype)
                    for block,unroll,warps,vec in [(256,2,1,2),(1024,1,2,8)]:
                        out=torch.empty_like(x);broadcast_arithmetic[(triton.cdiv(n,block*unroll),)](scale,x,out,n,block,unroll,warps,vec,num_warps=warps)
                        self.assertEqual(out,ref,atol=0,rtol=0,equal_nan=True)

    @onlyCUDA
    @parametrize('index' ''')
# Preserve the decorator syntax after inserting the extra test.
s=s.replace("@parametrize('index' ,[", "@parametrize('index',[")
p.write_text(s)
