from pathlib import Path
import shutil
root=Path(__file__).resolve().parent
p=root/'search.py';s=p.read_text().replace('from kernels import softmax_backward,transpose_copy,norm_backward','from kernels import softmax_backward,transpose_copy,norm_backward,broadcast_arithmetic')
s=s.replace("if kind=='gl':\n            if self.name=='softmaxbw'", "if kind=='gl':\n            if self.name=='broadcast':\n                return lambda:broadcast_arithmetic[(triton.cdiv(dims['xnumel'],cfg['XBLOCK']*cfg['unroll']),)](*self.args,N=dims['xnumel'],BLOCK=cfg['XBLOCK'],UNROLL=cfg['unroll'],WARPS=cfg['num_warps'],VEC=cfg['VEC'],num_warps=cfg['num_warps'],enable_fp_fusion=True)\n            if self.name=='softmaxbw'")
s=s.replace("opts.update({'XBLOCK':[256,512,1024,2048,4096,8192],'READ_ORDER':[0,1]} if case.name=='transpose' else", "opts.update({'XBLOCK':[128,256,512,1024,2048,4096,8192],'unroll':[1,2,4,8,16]} if case.name=='broadcast' else {'XBLOCK':[256,512,1024,2048,4096,8192],'READ_ORDER':[0,1]} if case.name=='transpose' else")
s=s.replace("if case.name=='broadcast':seeds.append(dict(case.baseconfig(),XBLOCK=1024,num_warps=2,unroll=4,waves_per_eu=0))", "if case.name=='broadcast':\n        seeds.extend([dict(case.baseconfig(),XBLOCK=1024,num_warps=2,unroll=4,waves_per_eu=0),dict(kind='gl',XBLOCK=256,num_warps=1,unroll=8,VEC=4),dict(kind='gl',XBLOCK=1024,num_warps=2,unroll=4,VEC=8)])")
p.write_text(s)
for folder in root.glob('*_broadcast'):
    for name in ['FINAL.json','search.json']:
        p=folder/name
        if p.exists():shutil.move(p,p.with_name('pre_gluon_'+name))
