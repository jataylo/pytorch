Triton category hill climb v12

15 recorded kernel contexts across 5 categories on one MI355X. 543 unique case/config pairs explored across all attempts, 442 evaluations in the final matched searches.

Final category geomeans (3 kernel cases/category, unweighted):
  mean: 19.03% less time than original Triton; per-case range 1.45% to 30.27%.
  softmaxbw: 13.69% less time than original Triton; per-case range 4.70% to 19.88%.
  transpose: 34.30% less time than original Triton; per-case range 27.20% to 42.30%.
  normbw: 13.23% less time than original Triton; per-case range 3.84% to 28.90%.
  broadcast: 3.43% less time than original Triton; per-case range 0.58% to 4.90%.

Implementation:
  mean: preserve split reduction stages, tune block/warps/waves, remove redundant modulo only under the existing index<N and row masks. For these generated kernels the index is nonnegative and the load mask implies index<N, so index%N equals index on every active lane. Invalid lanes remain masked.
  softmax backward: tune rows/warps and explicit subwave layouts; same fused multiply/dropout/reduction/fma formula. The best final candidates here use ordinary generated Triton with improved configurations.
  transpose: choose input-linear or output-linear traversal, tune vector width/workgroup size; input-linear traversal won all three final cases. Exact output required.
  norm backward: tune reduction blocks and warps; test explicit persistent Gluon alternative including padded1536columns. Final winners use existing generated Triton with improved configurations.
  broadcast: explicit Gluon layouts with small workgroups and static unroll; same scalar factor and two multiplies; exact output required.

Validation and interpretation:
  20 CUDA tests passed. Every selected winner was also checked against an independent PyTorch formula on seed4242. Custom layouts cover tails, transpose read directions, non-power-of-two norms, softmax NaN/Inf, and broadcast NaN/Inf.
  Fixed winners were confirmed on two further seeds with30 rotating paired rounds and5 invocations/round. CSV bootstrap intervals summarize repeated rounds on this device, not performance across hardware or model distributions.
  Preserve original selected Triton configs and pointer metadata. Replay uses original selector output restore and raw-storage warm indices, with256MiBflush. Pilot cache-context mismatch is archived and excluded.
  These are isolated microkernel prototypes, not production Inductor changes. No approximate math functions were added. Reductions may have different rounding; passing these checks is not full training convergence validation.
  Inputs use recorded shapes/strides/dtypes with random data, not captured training tensors. The selected contexts favor known FlyDSL leads; category geomeans are not estimates for all workloads. No GEMM/conv work.
  All original training benchmark sources and results remain untouched. No model rerun with candidates was performed.

Files:
  hillclimb_results.csv: one row per kernel, configs, source paths, speedups, errors and paired intervals.
  category_summary.csv: unweighted3-case geometric means and ranges.
  manifest.json: original wrapper paths, source/config provenance, signatures, shapes and selector mappings.
  kernels.py: explicit-layout candidate kernels. search.py: generated-source transformations and hill climb.
  confirmation/*.json: raw repeated timings and fresh-input sample hashes. VALIDATION.json: protocol and source hashes.

Commands run (from /dockerx/pytorch-flex; with task environment and validated v4 overlay):
  CUDA_VISIBLE_DEVICES=0 TRITON_DEFAULT_FP_FUSION=1 TRITON_CACHE_DIR=/dockerx/pytorch-flex/agent_space/simd_bench/triton_hillclimb_v12/triton_cache bash agent_space/simd_bench/run_env.sh agent_space/simd_bench/fallback_fixes_v4/agent_space/run_overlay.py /dockerx/pytorch-flex/agent_space/simd_bench/triton_hillclimb_v12/search.py --limit 65
  Same prefix: /dockerx/pytorch-flex/agent_space/simd_bench/triton_hillclimb_v12/confirm.py (broadcast finalists subsequently reconfirmed with indices12,13,14)
  Same prefix: /dockerx/pytorch-flex/agent_space/simd_bench/triton_hillclimb_v12/test_kernels.py
  Completed searches are preserved; search.py skips folders with FINAL.json.
