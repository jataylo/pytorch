from pathlib import Path
p=Path(__file__).with_name('test_kernels.py');s=p.read_text()
s=s.replace("transpose_copy[(triton.cdiv(x.numel(),block),)](x,out,x.numel(),h*d,s,d,block,warps,vec,num_warps=warps)\n                self.assertEqual(out,ref,atol=0,rtol=0)","for read_order in [0,1]:\n                    transpose_copy[(triton.cdiv(x.numel(),block),)](x,out,x.numel(),h*d,s,d,block,warps,vec,read_order,num_warps=warps)\n                    self.assertEqual(out,ref,atol=0,rtol=0)")
s=s.replace('[(37,128),(65,256),(19,1024)]','[(37,128),(65,256),(19,1024),(17,1536)]')
s=s.replace('actual,g,w,scale,keep,out,actual,m,r,rows,lanes,vec,warps,num_warps=warps','actual,g,w,scale,keep,out,actual,m,triton.next_power_of_2(r),rows,lanes,vec,warps,RNUM=r,num_warps=warps')
p.write_text(s)
