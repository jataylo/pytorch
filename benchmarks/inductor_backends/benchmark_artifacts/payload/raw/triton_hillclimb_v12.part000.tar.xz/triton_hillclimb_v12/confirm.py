import csv,fcntl,hashlib,json,statistics,sys
from pathlib import Path
import torch
from search import ROWS,Case,measure,conf
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'confirmation';OUT.mkdir(exist_ok=True)

if __name__=='__main__':
    with open('/dev/shm/pytorch-simd-v2-entry.lock','a') as e,open('/dev/shm/pytorch-simd-v2-benchmark.lock','a') as b:
        fcntl.flock(e,fcntl.LOCK_EX);fcntl.flock(b,fcntl.LOCK_EX)
        rows=[]
        for row in ROWS:
            if len(sys.argv)>1 and row['index'] not in list(map(int,sys.argv[1].split(','))):continue
            final=json.loads((Path(row['folder'])/'FINAL.json').read_text());chosen=min((r for r in final['rows'] if r['label'].startswith('candidate')),key=lambda r:r['runtime_us']);cfg=chosen['config'];case=Case(row)
            entries=[dict(label='original',fn=case.native),dict(label='flydsl',fn=case.fly_fn),dict(label='improved',fn=case.callable(cfg))]
            samples={e['label']:[] for e in entries};errors={e['label']:[] for e in entries};hashes=[]
            for seed in [1701,2027]:
                case.refresh(seed);hashes.append(hashlib.sha256(case.args[0].flatten()[:1024].float().cpu().numpy().tobytes()).hexdigest());case.reset();case.native();torch.cuda.synchronize();case.expected=[case.args[i].clone() for i in case.outputs]
                for entry in entries:
                    compiled,err=case.validate(entry['fn']);errors[entry['label']].append(err)
                    if compiled is not None and hasattr(compiled,'asm'):
                        for ext in ['ttgir','amdgcn']:
                            if ext in compiled.asm:(OUT/f'{row["index"]:02d}_{entry["label"]}.{ext}').write_text(compiled.asm[ext])
                for entry,m in zip(entries,measure(case,entries,15,5)):samples[entry['label']]+=m['samples_us']
            if len(set(hashes))!=2:raise RuntimeError('fresh seeds did not change inputs')
            original=statistics.median(samples['original']);fly=statistics.median(samples['flydsl']);improved=statistics.median(samples['improved'])
            result=dict(index=row['index'],category=row['category'],model=row['model'],kernel_name=row['kernel_name'],original_triton_us=original,improved_triton_us=improved,flydsl_us=fly,time_saved_vs_original_percent=100*(original-improved)/original,time_saved_vs_flydsl_percent=100*(fly-improved)/fly,max_abs_error=max(errors['improved']),config=cfg,**conf(samples['original'],samples['improved']))
            (OUT/f'{row["index"]:02d}.json').write_text(json.dumps(dict(result=result,samples_us=samples,input_hashes=hashes,validation_errors=errors),indent=2));rows.append(result);print(json.dumps(result),flush=True)
            del entries,case;torch.cuda.empty_cache()
        rows=[json.loads(p.read_text())['result'] for p in sorted(OUT.glob('[0-9][0-9].json'))]
        (OUT/'SUMMARY.json').write_text(json.dumps(rows,indent=2))
        with (ROOT/'hillclimb_results.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows([dict(r,config=json.dumps(r['config'],sort_keys=True)) for r in rows])
