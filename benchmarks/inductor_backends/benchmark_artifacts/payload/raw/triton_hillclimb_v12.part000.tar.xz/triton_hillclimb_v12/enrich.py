import ast,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
rows=json.loads((ROOT/'manifest.json').read_text())
shared=Path('/dev/shm/pytorch-simd-mixed-single-v5-compiled-artifacts/shared_autotune1/triton')
for row in rows:
    text=Path(row['wrapper']).read_text(); pos=text.index(row['triton_name']+' = async_compile.triton')
    path=Path(re.findall(r'# kernel path: (.*)',text[:pos])[-1])
    configs=[]
    for p in path.parent.glob('*.best_config'):
        cfg=json.loads(p.read_text()); meta=shared/cfg.get('triton_cache_hash','')/(row['triton_name']+'.json')
        if meta.exists():configs.append((p,cfg))
    if len(configs)!=1:raise RuntimeError((row['index'],configs))
    row['baseline_config_path']=str(configs[0][0]);row['baseline_config']=configs[0][1]
    events=[json.loads(l) for l in Path(row['diagnostic_file']).read_text().splitlines()]
    lower=[e for e in events if e.get('kernel_name')==row['kernel_name'] and e.get('category')=='lowered' and all(a in e.get('buffers',{}) for a in row['actual_args'])]
    if not lower:raise RuntimeError(('buffers',row['index']))
    row['buffers']=lower[0]['buffers']
    tuned=[e for e in events if e.get('kernel_name')==row['kernel_name'] and e.get('category')=='autotune_selection' and not e.get('cache_hit')]
    if not tuned:raise RuntimeError(('flychoice',row['index']))
    row['fly_candidate']=tuned[0]['selected_candidate']
    row['original_kernel_path']=str(path)
    tree=ast.parse((Path(row['folder'])/'original_triton.py').read_text()); fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)); dec=next(d for d in fn.decorator_list if isinstance(d,ast.Call))
    sig=next(k.value for k in dec.keywords if k.arg=='triton_meta');row['signature']=ast.literal_eval(next(v for k,v in zip(sig.keys,sig.values) if ast.literal_eval(k)=='signature'))
    row['dims']={n.targets[0].id:ast.literal_eval(n.value) for n in fn.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['xnumel','r0_numel']}
    print(row['index'],row['baseline_config'],row['fly_candidate'])
(ROOT/'manifest.json').write_text(json.dumps(rows,indent=2))
