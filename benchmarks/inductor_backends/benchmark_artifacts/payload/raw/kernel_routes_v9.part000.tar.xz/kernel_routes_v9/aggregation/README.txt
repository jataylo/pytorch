coverage warning: The measured subset is biased: cached choices omit candidate timings, while non-first cached choices can be remeasured by the existing backend cache-read bug. These aggregates describe logged measurements, not overall backend win rates or operator performance guarantees.

row unit: One unique kernel-name training context per model/tuning/current placement, rank0 only; not runtime invocation counts and not weighted by dynamic frequency.

op meaning: Fused original ATen origin labels, not necessarily standalone operators. GEMM/conv ancestry remains native ATen. by_aten_origin overlaps across fused contexts, so its counts must not be summed.

cohorts: eager_validated is primary for inspection; training_only is separate. all_successful_training combines both explicitly. Numerical-warning and failed-model contexts are excluded from aggregates.

speedup: 100*(Triton_us-FlyDSL_us)/Triton_us, positive saves time. Geomean uses Triton/FlyDSL timing ratios first; it is not an average of percentages. Lower microsecond timings are better.

clear win: 3% ratio band: Triton/FlyDSL>1.03 is FlyDSL win, <1/1.03 is Triton win, otherwise near tie. This is a reporting threshold, not statistical significance.

favorable tables: At least five measured contexts across at least two models, eager-validated only, grouped separately per tuning mode. Consistent measured fusions additionally require the 10th percentile of logged FlyDSL time savings above zero. Bias warning still applies.

whole model: Kernel autotuner times are not full-step contributions. No per-model speedup is inferred by summing these kernel contexts.
