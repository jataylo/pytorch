"""Validate frozen comparison coverage and export descriptive resource evidence."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics


VARIANTS = ('stock', 'previous_native', 'new_native')


def geomean(values):
    return math.exp(statistics.mean(math.log(value) for value in values)) if values else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--exploratory', type=Path, default=Path(__file__).resolve().parent / 'results_smoke_r1')
    args = parser.parse_args()
    output = args.output
    manifest = json.loads((output / 'manifest.json').read_text())
    summary = json.loads((output / 'summary.json').read_text())
    cases = manifest['protocol']['cases']
    expected_reports = len(cases) * len(VARIANTS)
    fingerprints, hash_mismatches = {}, []
    for tag, source in manifest['sources'].items():
        fingerprint = json.loads(Path(source['fingerprint']).read_text())
        fingerprints[tag] = fingerprint
        for name, expected in fingerprint['sources'].items():
            path = Path(name)
            if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                hash_mismatches.append(name)
    reports, rows, failures = {}, {}, []
    worker_source_mismatches, overlay_mismatches, unexpected_codegen = [], [], []
    resources, multi_kernel_choices = {}, []
    for case in cases:
        for variant in VARIANTS:
            path = output / 'runs' / case['case'] / variant / 'worker_result.json'
            if not path.exists():
                continue
            report = json.loads(path.read_text())
            reports[case['case'], variant] = report
            tag = 'previous_native' if variant == 'previous_native' else 'candidate'
            if report.get('source_fingerprint') != fingerprints[tag]:
                worker_source_mismatches.append(str(path))
            loaded_modules = report.get('loaded_overlay_modules', {})
            missing = set(fingerprints[tag]['overlay_modules']) - set(loaded_modules)
            if missing:
                overlay_mismatches.append(dict(report=str(path), missing_modules=sorted(missing)))
            for module, loaded in loaded_modules.items():
                expected = Path(manifest['sources'][tag]['root']) / (module.replace('.', '/') + '.py')
                if Path(loaded).resolve() != expected.resolve():
                    overlay_mismatches.append(dict(report=str(path), module=module, loaded=loaded))
            for item in report.get('failures', []):
                failures.append(dict(case=case['case'], **item))
            for row in report.get('rows', []):
                if row.get('explicit_layout_kernels', 0) or row.get('approximate_math_kernels', 0):
                    unexpected_codegen.append(dict(report=str(path), invocation=row['invocation'], cache=row['cache']))
                rows[case['case'], variant, row['cache'], row['invocation']] = row
            for profile in report.get('kernel_launcher_profiles', []):
                if profile.get('selected_for_execution') is not True:
                    continue
                resources.setdefault((case['family'], variant), []).append(profile)
            for item in report.get('multi_kernel_choices', []):
                multi_kernel_choices.append(dict(case=case['case'], variant=variant, **item))
    common = summary['headline']['case_names']
    comparisons = {}
    for baseline in ('stock', 'previous_native'):
        deltas = []
        for name in common:
            ratios = [rows[name, baseline, cache, 'direct']['runtime_us'] /
                      rows[name, 'new_native', cache, 'direct']['runtime_us'] for cache in ('cold', 'warm')]
            deltas.append(dict(case=name, speedup_percent=100 * (geomean(ratios) - 1)))
        comparisons[baseline] = dict(top_wins=sorted(deltas, key=lambda item: item['speedup_percent'], reverse=True)[:10],
                                     worst_regressions=sorted(deltas, key=lambda item: item['speedup_percent'])[:10])
    setup_cost_summary = []
    for family in ['all', *sorted({case['family'] for case in cases})]:
        selected_names = [case['case'] for case in cases
                          if case['case'] in common and (family == 'all' or case['family'] == family)]
        item = dict(family=family, common_cases=len(selected_names), variants={})
        for variant in VARIANTS:
            values = [reports[name, variant]['rows'][0]['compile_seconds'] for name in selected_names]
            diagnostics = [record['record'] for name in selected_names
                           for record in reports[name, variant].get('tuning_diagnostics', [])]
            initial = [record['initial_candidates'] for record in diagnostics if 'initial_candidates' in record]
            measured = [record.get('measured_candidates', len(record.get('candidates', []))) for record in diagnostics]
            item['variants'][variant] = dict(
                compile_validate_capture_seconds=dict(
                    geometric_mean=geomean(values), median=statistics.median(values) if values else None,
                    maximum=max(values) if values else None, total=sum(values) if values else None,
                ),
                diagnosed_kernel_records=len(diagnostics),
                initial_candidate_count_range=[min(initial), max(initial)] if initial else None,
                measured_candidate_count_range=[min(measured), max(measured)] if measured else None,
            )
        ratios = [reports[name, 'previous_native']['rows'][0]['compile_seconds'] /
                  reports[name, 'new_native']['rows'][0]['compile_seconds'] for name in selected_names]
        item['previous_over_new_setup_geomean_ratio'] = geomean(ratios)
        setup_cost_summary.append(item)
    resource_ranges = []
    for (family, variant), profiles in sorted(resources.items()):
        item = dict(family=family, variant=variant, selected_kernel_profiles=len(profiles))
        for key in ('n_regs', 'n_spills', 'shared'):
            values = [profile[key] for profile in profiles if profile.get(key) is not None]
            item[key + '_range'] = [min(values), max(values)] if values else None
            item[key + '_missing'] = len(profiles) - len(values)
        item['profiles_with_spills'] = sum((profile.get('n_spills') or 0) > 0 for profile in profiles)
        resource_ranges.append(item)
    before_after = []
    for case in cases:
        current = reports.get((case['case'], 'new_native'))
        previous_path = args.exploratory / 'runs' / case['case'] / 'new_native/worker_result.json'
        if current is None or not previous_path.exists():
            continue
        old = json.loads(previous_path.read_text())
        def describe(report):
            return dict(
                compile_validate_capture_seconds=next((row['compile_seconds'] for row in report.get('rows', [])), None),
                selected_kernel_profiles=report.get('kernel_launcher_profiles', []),
                kernels=[dict(
                    kernel_name=item['record'].get('kernel_name'), initial_candidates=item['record'].get('initial_candidates'),
                    measured_candidates=item['record'].get('measured_candidates', len(item['record'].get('candidates', []))),
                    contains_32row_1warp_candidate=any(candidate['config'].get('XBLOCK') == 32 and candidate['config'].get('num_warps') == 1
                        for candidate in item['record'].get('candidates', [])),
                ) for item in report.get('tuning_diagnostics', [])],
                direct_runtime_us={row['cache']: row['runtime_us'] for row in report.get('rows', []) if row['invocation'] == 'direct'},
            )
        before_after.append(dict(case=case['case'], exploratory=describe(old), accepted=describe(current)))
    expected_rows = expected_reports * 4
    statuses = {}
    for report in reports.values():
        status = report['status']
        statuses[status] = statuses.get(status, 0) + 1
    gpu_uuids = sorted({report.get('gpu_uuid') for report in reports.values() if report.get('gpu_uuid')})
    torch_versions = sorted({report.get('torch_version') for report in reports.values() if report.get('torch_version')})
    missing_device_provenance = [name + '/' + variant for (name, variant), report in reports.items()
                                 if report['status'] == 'ok' and (not report.get('gpu_uuid') or not report.get('torch_version'))]
    validation = dict(
        run_state=summary.get('run_state'),
        expected_cases=len(cases), expected_workers=expected_reports, actual_workers=len(reports),
        expected_rows=expected_rows, actual_rows=len(rows), status_counts=statuses, failure_count=len(failures),
        frozen_file_hash_mismatches=hash_mismatches, worker_source_fingerprint_mismatches=worker_source_mismatches,
        loaded_overlay_mismatches=overlay_mismatches, unexpected_gluon_or_approximate_codegen=unexpected_codegen,
        gpu_uuids=gpu_uuids, torch_versions=torch_versions, missing_device_provenance=missing_device_provenance,
        all_common_cases=len(common) == len(cases),
        passed=len(reports) == expected_reports and len(rows) == expected_rows and not failures
        and not hash_mismatches and not worker_source_mismatches and not overlay_mismatches and not unexpected_codegen
        and statuses.get('ok') == expected_reports and len(gpu_uuids) == 1 and len(torch_versions) == 1
        and not missing_device_provenance,
    )
    (output / 'VALIDATION.json').write_text(json.dumps(validation, indent=2) + '\n')
    evidence = dict(
        headline=summary['headline'], by_split=summary['by_split'], graph_replay=summary['graph_replay'],
        comparisons=comparisons, selected_resource_ranges=resource_ranges, setup_cost_summary=setup_cost_summary,
        multi_kernel_choices=multi_kernel_choices, exploratory_vs_accepted=before_after,
        notes=(
            'Resource ranges include only launchers selected for graph execution; MultiKernel losers are excluded. '
            'Counters describe compiled Triton kernels, not ATen/library operations. '
            'Exploratory and accepted runs differ in source, cache history, and timing repetition counts; '
            'setup-time changes are descriptive observations, not isolated causal estimates. '
            'Accounted compiler counters can omit initial asynchronous compilation; use recorded compile/validate/capture wall time for broader setup cost.'
        ),
    )
    (output / 'resource_evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps(validation, indent=2))


if __name__ == '__main__':
    main()
