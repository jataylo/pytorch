# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/native_triton_v2/results_final_v3/runs/heldout_norm_backward_37x8192_bfloat16/previous_native/cache/inductor/at/cat6noqq27lxpqs7iaaaazjdsmuaodiuincp73d2wjjl4oikcqoj.py
# Topologically Sorted Source Nodes: [float_1, v, mul_1, sum_1, sub, mul_2, sum_2, mul_3, sub_1, value, float_2, mul_5, mul_6, to], Original ATen: [aten._to_copy, aten.mul, aten.sum, aten.sub]
# Source node to ATen node mapping:
#   float_1 => convert_element_type
#   float_2 => convert_element_type_1
#   mul_1 => mul_1
#   mul_2 => mul_2
#   mul_3 => mul_3
#   mul_5 => mul_5
#   mul_6 => mul_6
#   sub => sub
#   sub_1 => sub_1
#   sum_1 => sum_1
#   sum_2 => sum_2
#   to => convert_element_type_2
#   v => mul
#   value => mul_4
# Graph fragment:
#   %arg0_1 : Tensor "bf16[37, 8192][8192, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "f32[8192][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[37, 8192][8192, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg3_1 : Tensor "f32[37, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %sum_1 : Tensor "f32[37, 1][1, 37]cuda:0" = PlaceHolder[target=sum_1]
#   %sum_2 : Tensor "f32[37, 1][1, 37]cuda:0" = PlaceHolder[target=sum_2]
#   %mul_4 : Tensor "f32[37, 8192][8192, 1]cuda:0" = PlaceHolder[target=mul_4]
#   %arg4_1 : Tensor "b8[37, 8192][8192, 1]cuda:0" = PlaceHolder[target=arg4_1]
#   %convert_element_type : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %arg1_1), kwargs = {})
#   %mul_1 : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, 8192), kwargs = {})
#   %sum_1 : Tensor "f32[37, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul, [-1], True), kwargs = {})
#   %sub : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%mul_1, %sum_1), kwargs = {})
#   %mul_2 : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg2_1), kwargs = {})
#   %sum_2 : Tensor "f32[37, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_2, [-1], True), kwargs = {})
#   %mul_3 : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg2_1, %sum_2), kwargs = {})
#   %sub_1 : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%sub, %mul_3), kwargs = {})
#   %mul_4 : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg3_1, %sub_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %mul_5 : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, 1.1111111111111112), kwargs = {})
#   %mul_6 : Tensor "f32[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[37, 8192][8192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_6, torch.bfloat16), kwargs = {})
#   return %sum_1,%sum_2,%mul_4,%convert_element_type_2
triton_per_fused__to_copy_mul_sub_sum_0 = async_compile.triton('triton_per_fused__to_copy_mul_sub_sum_0', '''
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()
from triton.language.extra import libdevice

@triton.jit
def _amd_maximum(a, b):
    return tl.where((a > b) | (a != a), a, b)

@triton.jit
def _amd_max2(value, axis: tl.constexpr):
    return tl.reduce(value, axis, _amd_maximum)

@triton.jit
def _amd_any(value, axis: tl.constexpr):
    return tl.sum((value != 0).to(tl.int32), axis) != 0

@triton.jit
def _amd_reciprocal(value):
    return tl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[value], dtype=tl.float32, is_pure=True, pack=1)

@triton_heuristics.persistent_reduction(size_hints={'x': 64, 'r0_': 8192}, reduction_hint=ReductionHint.INNER, filename=__file__, triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*i1', 'out_ptr2': '*fp32', 'out_ptr3': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16]]}]}, inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy_mul_sub_sum_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 148, 'r0_': 5791744}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': False, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_warp_size': 64, 'amd_max_threads_per_block': 1024, 'amd_reduction_tuning': True, 'amd_kernel_autotune': True, 'amd_kernel_tuning_version': 5, 'amd_autotune_diagnostics_path': '/dockerx/pytorch-flex/agent_space/simd_bench/native_triton_v2/results_final_v3/runs/heldout_norm_backward_37x8192_bfloat16/previous_native/heldout_norm_backward_37x8192_bfloat16/previous_native.tuning.jsonl', 'amd_warm_arg_names': (), 'amd_confirm_tuning': True, 'amd_graph_tuning': True, 'amd_allow_atomic_tuning': False, 'use_gluon': False, 'amd_native_family': 'row_reduction', 'amd_reduction_extent': 8192, 'amd_row_count': 37, 'amd_approximate_math': False, 'amd_cache_policy': 'balanced'})
@triton.jit
def triton_per_fused__to_copy_mul_sub_sum_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK: tl.constexpr):
    xnumel = 37
    r0_numel = 8192
    R0_BLOCK: tl.constexpr = 8192
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1 + 8192 * x0), xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + r0_1, None, eviction_policy='evict_last')
    tmp8 = tl.load(in_ptr2 + (r0_1 + 8192 * x0), xmask, eviction_policy='evict_first', other=0.0)
    tmp14 = tl.load(in_ptr3 + x0, xmask, eviction_policy='evict_last')
    tmp21 = tl.load(in_ptr4 + (r0_1 + 8192 * x0), xmask, eviction_policy='evict_first', other=0.0)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tmp1 * tmp2
    tmp4 = tl.broadcast(tmp3, tl.full([XBLOCK, R0_BLOCK], 0, tmp3.dtype))[0]
    tmp6 = tl.where(xmask, tmp4, 0)
    tmp7 = tl.sum(tmp6, 1)[:, None].to(tl.float32)
    tmp9 = tmp3 * tmp8
    tmp10 = tl.broadcast(tmp9, tl.full([XBLOCK, R0_BLOCK], 0, tmp9.dtype))[0]
    tmp12 = tl.where(xmask, tmp10, 0)
    tmp13 = tl.sum(tmp12, 1)[:, None].to(tl.float32)
    tmp15 = tl.full([1, 1], 8192.0, tl.float32)
    tmp16 = tmp3 * tmp15
    tmp17 = tmp16 - tmp7
    tmp18 = tmp8 * tmp13
    tmp19 = tmp17 - tmp18
    tmp20 = tmp14 * tmp19
    tmp22 = tmp21.to(tl.float32)
    tmp23 = tl.full([1, 1], 1.1111111111111112, tl.float32)
    tmp24 = tmp22 * tmp23
    tmp25 = tmp20 * tmp24
    tmp26 = tmp25.to(tl.float32)
    tl.store(out_ptr2 + (r0_1 + 8192 * x0), tmp20, xmask)
    tl.store(out_ptr3 + (r0_1 + 8192 * x0), tmp26, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1, arg2_1, arg3_1, arg4_1), ((37, 8192), (8192, ), (37, 8192), (37, 1), (37, 8192)), ((8192, 1), (1, ), (8192, 1), (1, 1), (8192, 1)), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg1_1 = copy_if_misaligned(arg1_1)
            arg2_1 = copy_if_misaligned(arg2_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            arg4_1 = copy_if_misaligned(arg4_1)
            buf2 = empty_strided_cuda((37, 8192), (8192, 1), torch.float32)
            buf3 = empty_strided_cuda((37, 8192), (8192, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [float_1, v, mul_1, sum_1, sub, mul_2, sum_2, mul_3, sub_1, value, float_2, mul_5, mul_6, to], Original ATen: [aten._to_copy, aten.mul, aten.sum, aten.sub]
            raw_stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_mul_sub_sum_0.run(arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, buf2, buf3, 37, 8192, stream=raw_stream0)
            del arg0_1
            del arg1_1
            del arg2_1
            del arg3_1
            del arg4_1
        return (buf2, buf3, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((37, 8192), (8192, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((8192, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg2_1 = rand_strided((37, 8192), (8192, 1), device='cuda:0', dtype=torch.float32)
    arg3_1 = rand_strided((37, 1), (1, 1), device='cuda:0', dtype=torch.float32)
    arg4_1 = rand_strided((37, 8192), (8192, 1), device='cuda:0', dtype=torch.bool)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
