"""Exercise actual CompiledKernel finalization with a CPU-only mock HIP unloader."""
import gc
import json
import os
from pathlib import Path
from types import SimpleNamespace

import triton.compiler.compiler as compiler


def run(protected):
    state = {'capture': False, 'collecting': False}
    events = []
    original_enabled = gc.isenabled()
    original_threshold = gc.get_threshold()
    original_driver = compiler.driver
    original_hook = compiler.knobs.runtime.kernel_unload_hook

    def callback(phase, info):
        state['collecting'] = phase == 'start'

    def unload(module):
        events.append({'capture': state['capture'], 'cyclic_gc_active': state['collecting']})

    def discarded_launcher():
        binary = compiler.CompiledKernel.__new__(compiler.CompiledKernel)
        binary.module = 123
        binary._module_pid = os.getpid()
        binary.function = 456
        binary.name = 'diagnostic'
        binary.metadata_group = {}
        binary.hash = 'diagnostic'
        scope = {'bin': binary}
        exec('def launcher():\n    return None\n', scope)
        return scope['launcher']

    try:
        gc.collect()
        gc.disable()
        compiler.driver = SimpleNamespace(active=SimpleNamespace(utils=SimpleNamespace(unload_module=unload)))
        compiler.knobs.runtime.kernel_unload_hook = None
        gc.callbacks.append(callback)
        holder = [discarded_launcher()]
        holder.clear()
        state['capture'] = True
        gc.set_threshold(1, 1, 1)
        if not protected:
            gc.enable()
        allocations = [[] for _ in range(1000)]
        del allocations
        inside = list(events)
        state['capture'] = False
        gc.collect()
        return {'protected': protected, 'events_during_capture': inside, 'all_events': list(events)}
    finally:
        state['capture'] = False
        gc.collect()
        gc.callbacks.remove(callback)
        compiler.driver = original_driver
        compiler.knobs.runtime.kernel_unload_hook = original_hook
        gc.set_threshold(*original_threshold)
        if original_enabled:
            gc.enable()
        else:
            gc.disable()


results = [run(False), run(True)]
if results[0]['events_during_capture'] != [{'capture': True, 'cyclic_gc_active': True}]:
    raise RuntimeError('Unprotected cycle did not finalize during capture')
if results[1]['events_during_capture'] or results[1]['all_events'] != [{'capture': False, 'cyclic_gc_active': True}]:
    raise RuntimeError('Protected cycle did not defer finalization outside capture')
path = Path(__file__).with_name('cycle_proof.json')
path.write_text(json.dumps({'gpu_operations': False, 'actual_destructor': 'triton.compiler.compiler.CompiledKernel.__del__', 'results': results}, indent=2) + '\n')
print(path.read_text())
