"""Export completed GPU0 full-step measurements without mixing kernel timings."""

import csv
import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent
VARIANTS = ("stock", "previous_native", "new_native")


def main():
    complete = json.loads((ROOT / "COMPLETE.json").read_text())
    amendment = json.loads((ROOT / "PLAN_AMENDMENT.json").read_text()) if (ROOT / "PLAN_AMENDMENT.json").exists() else None
    expected_runs = amendment["amended_planned_runs"] if amendment else 6
    if complete["runs"] != expected_runs:
        raise RuntimeError("Completed model run count differs from the active plan")
    manifest = json.loads((ROOT / "manifest.json").read_text())
    models = []
    table = []
    failures = []
    source_mismatches = []
    all_uuids = set()
    for model in manifest["models"]:
        name = model["model"]
        actual_variants = tuple(variant for variant in VARIANTS if not (amendment and name == "mobilenetv3_large_100" and variant == "previous_native"))
        reports = {variant: json.loads((ROOT / "runs" / name / f"{variant}.json").read_text()) for variant in actual_variants}
        for variant, report in reports.items():
            for filename, expected in report["source_fingerprint"]["sources"].items():
                actual = hashlib.sha256(Path(filename).read_bytes()).hexdigest()
                if actual != expected:
                    source_mismatches.append({"variant": variant, "source": filename})
            if report.get("status") != "ok":
                failures.append({"model": name, "variant": variant, "status": report.get("status"), "error": report.get("error")})
            all_uuids.add(report.get("gpu_uuid"))
        reference = reports["stock"]
        initial_audit = {
            "parameter_samples_equal": all(report.get("initial_parameters") == reference.get("initial_parameters") for report in reports.values()),
            "input_samples_equal": all(report.get("initial_inputs") == reference.get("initial_inputs") for report in reports.values()),
            "input_shapes_equal": all(report.get("inputs") == reference.get("inputs") for report in reports.values()),
            "model_config_equal": all(report.get("model_config_sha256") == reference.get("model_config_sha256") for report in reports.values()),
            "model_implementation_equal": all(report.get("model_implementation") == reference.get("model_implementation") for report in reports.values()),
            "model_dependencies_equal": all(report.get("model_dependencies") == reference.get("model_dependencies") for report in reports.values()),
        }
        variants = {}
        for variant, report in reports.items():
            flags = report.get("inductor_config", {})
            expected_optimization = variant != "stock"
            flag_audit = all(flags.get("triton." + flag) is expected_optimization for flag in (
                "amd_kernel_optimizations", "amd_extended_kernel_optimizations", "amd_further_kernel_optimizations"
            )) and flags.get("triton.amd_use_gluon") is False and flags.get("triton.amd_approximate_math") is False
            before = report.get("loaded_overlay_modules_before", {})
            after = report.get("loaded_overlay_modules_after", {})
            variants[variant] = {
                "status": report.get("status"), "milliseconds": report.get("milliseconds"),
                "repeat_ms": report.get("repeat_ms"), "gpu_uuid": report.get("gpu_uuid"),
                "physical_gpu": report.get("physical_gpu"), "gpu": report.get("gpu"),
                "parameters": report.get("parameters"),
                "parameters_with_training_gradients": report.get("training_parameters_with_gradients"),
                "all_parameter_gradients_present": report.get("parameters") is not None and report.get("training_parameters_with_gradients") == report.get("parameters"),
                "timing_recompiles": report.get("timing_recompiles"),
                "timing_includes_cpu": True,
                "final_training_loss": report.get("final_training_loss"),
                "final_training_loss_finite": math.isfinite(report.get("final_training_loss", float("nan"))),
                "accuracy": {
                    "mode": report.get("validation_mode"),
                    "scope": report.get("validation"),
                    "eager_reference_status": report.get("eager_reference_status"),
                    "eager_loss": report.get("eager_loss"), "compiled_loss": report.get("compiled_loss"),
                    "gradient_samples": report.get("gradient_validation"),
                    "warnings": report.get("validation_warnings", []),
                    "timed_mode": "train; forward + backward + SGD",
                    "training_finite_gradient_check": "first/middle/last gradient tensors, first 1024 elements, after first compiled training step",
                },
                "source_flags_audit": {
                    "expected_flags_match": flag_audit,
                    "loaded_modules_before_after_equal": bool(before) and before == after,
                    "loaded_module_count": len(before),
                    "native_codegen_policy": report.get("native_codegen_policy"),
                    "codegen_audit": report.get("codegen_audit"),
                    "flags": flags,
                    "fingerprint": str(ROOT / f"{variant}_source_fingerprint.json"),
                },
                "compilation_seconds": {
                    "eval_validation": report.get("validation_compile_seconds"),
                    "first_train_step": report.get("first_compiled_step_seconds"),
                },
                "peak_allocated_bytes": report.get("peak_allocated_bytes"),
                "raw_result": str(ROOT / "runs" / name / f"{variant}.json"),
                "raw_log": str(ROOT / "runs" / name / f"{variant}.log"),
            }
        new = variants["new_native"]["milliseconds"]
        if "previous_native" not in variants:
            variants["previous_native"] = {
                "status": "not_run_optional_reference", "milliseconds": None, "repeat_ms": None,
                "reason": amendment["reason"],
            }
        gains = {
            baseline: (variants[baseline]["milliseconds"] / new - 1) * 100
            if new and variants[baseline]["milliseconds"] else None
            for baseline in ("stock", "previous_native")
        }
        models.append({
            **model, "inputs": reference.get("inputs"), "initial_state_audit": initial_audit,
            "variants": variants, "speedup_percent": gains,
        })
        table.append({
            "model": name, "batch_size": model["batch_size"],
            **{variant + "_ms": variants[variant]["milliseconds"] for variant in VARIANTS},
            "new_vs_stock_speedup_percent": gains["stock"],
            "new_vs_previous_native_speedup_percent": gains["previous_native"],
            "gpu_uuid": reference.get("gpu_uuid"), "physical_gpu": "0", "timing_includes_cpu": True,
            **{variant + "_status": variants[variant]["status"] for variant in VARIANTS},
            **{variant + "_repeat_ms": json.dumps(variants[variant]["repeat_ms"]) for variant in VARIANTS},
            "no_timing_recompiles": all(variants[variant]["timing_recompiles"] == 0 for variant in actual_variants),
            "all_parameter_gradients_present": all(variants[variant]["all_parameter_gradients_present"] for variant in actual_variants),
            "eval_accuracy_warnings": sum(len(variants[variant]["accuracy"]["warnings"]) for variant in actual_variants),
            "all_source_flags_audits_pass": all(
                variants[variant]["source_flags_audit"]["expected_flags_match"]
                and variants[variant]["source_flags_audit"]["loaded_modules_before_after_equal"]
                for variant in actual_variants
            ),
        })
    audit = {
        "run_count_matches_amended_plan": complete["runs"] == expected_runs,
        "same_physical_gpu_uuid": len(all_uuids) == 1 and None not in all_uuids,
        "all_status_ok": not failures,
        "frozen_sources_unchanged": not source_mismatches,
        "initial_states_match": all(all(model["initial_state_audit"].values()) for model in models),
        "no_timing_recompiles": all(row["no_timing_recompiles"] for row in table),
        "all_parameter_gradients_present": all(row["all_parameter_gradients_present"] for row in table),
        "all_source_flags_audits_pass": all(row["all_source_flags_audits_pass"] for row in table),
    }
    summary = {
        "scope": "two cached architecture-initialized models; GPU0 full train steps; separate from GPU3 kernel benchmarks",
        "protocol": manifest, "plan_amendment": amendment, "actual_runs": complete["runs"], "timing_includes_cpu": True,
        "speedup_definition": "100 * (baseline_ms / new_native_ms - 1)",
        "training_accuracy_limit": "eval-mode loss and sampled parameter-gradient comparisons (BatchNorm uses batch statistics when present), plus finite train-step checks; no convergence claim",
        "audit": audit, "failures": failures, "source_mismatches": source_mismatches, "models": models,
    }
    with (ROOT / "per_model.csv").open("w") as file:
        writer = csv.DictWriter(file, fieldnames=list(table[0]))
        writer.writeheader()
        writer.writerows(table)
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"audit": audit, "models": table}, indent=2))


if __name__ == "__main__":
    main()
