# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/native_triton_v2/results_final/runs/anchor_transpose_float32/new_native/cache/inductor/zg/czg4wlfjcylqejlvq6odyrdx7jpq7pa4n7hvhnc5pjvxs7vsgkxi.py
# Topologically Sorted Source Nodes: [permute, contiguous], Original ATen: [aten.permute, aten.clone]
# Source node to ATen node mapping:
#   contiguous => clone
#   permute => permute
# Graph fragment:
#   %arg0_1 : Tensor "f32[16, 32, 128, 80][327680, 10240, 80, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %permute : Tensor "f32[16, 128, 32, 80][327680, 80, 10240, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg0_1, [0, 2, 1, 3]), kwargs = {})
#   %clone : Tensor "f32[16, 128, 32, 80][327680, 2560, 80, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone
triton_poi_fused_clone_permute_0 = async_compile.triton('triton_poi_fused_clone_permute_0', '''
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(size_hints={'x': 8388608}, filename=__file__, triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr', 'AMD_TILE_M': 'constexpr', 'AMD_TILE_N': 'constexpr', 'AMD_READ_ORDER': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16]]}]}, inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_clone_permute_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 62914560}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': False, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_warp_size': 64, 'amd_max_threads_per_block': 1024, 'amd_reduction_tuning': True, 'amd_kernel_autotune': True, 'amd_kernel_tuning_version': 6, 'amd_autotune_diagnostics_path': '/dockerx/pytorch-flex/agent_space/simd_bench/native_triton_v2/results_final/runs/anchor_transpose_float32/new_native/anchor_transpose_float32/new_native.tuning.jsonl', 'amd_warm_arg_names': (), 'amd_confirm_tuning': False, 'amd_graph_tuning': False, 'amd_allow_atomic_tuning': False, 'amd_native_family': 'tiled_transpose', 'use_gluon': False, 'amd_transpose_shape': (16, 32, 128, 80), 'amd_cache_policy': 'balanced'}, min_elem_per_thread=0)
@triton.jit
def triton_poi_fused_clone_permute_0(in_ptr0, out_ptr0, xnumel, XBLOCK: tl.constexpr, AMD_TILE_M: tl.constexpr, AMD_TILE_N: tl.constexpr, AMD_READ_ORDER: tl.constexpr):
    if AMD_TILE_M == 0:
        if AMD_READ_ORDER == 0:
            xnumel = 5242880
            xoffset = tl.program_id(0) * XBLOCK
            xindex = xoffset + tl.arange(0, XBLOCK)[:]
            xmask = xindex < 5242880
            x0 = xindex % 80
            x1 = xindex // 80 % 32
            x2 = xindex // 2560 % 128
            x3 = xindex // 327680
            x4 = xindex
            tmp0 = tl.load(in_ptr0 + (x0 + 80 * x2 + 10240 * x1 + 327680 * x3), xmask)
            tl.store(out_ptr0 + x4, tmp0, xmask)
        else:
            _amd_linear = tl.program_id(0) * XBLOCK + tl.arange(0, XBLOCK)
            _amd_linear_mask = _amd_linear < 5242880
            _amd_output = _amd_linear // 327680 * 327680 + _amd_linear // 80 % 128 * 2560 + _amd_linear // 10240 % 32 * 80 + _amd_linear % 80
            _amd_value = tl.load(in_ptr0 + _amd_linear, _amd_linear_mask)
            tl.store(out_ptr0 + _amd_output, _amd_value, _amd_linear_mask)
    else:
        _amd_tiles_m: tl.constexpr = triton.cdiv(32, AMD_TILE_M)
        _amd_tiles_n: tl.constexpr = triton.cdiv(10240, AMD_TILE_N)
        for _amd_tile in tl.range(tl.program_id(0), 16 * _amd_tiles_m * _amd_tiles_n, tl.num_programs(0)):
            _amd_batch = _amd_tile // (_amd_tiles_m * _amd_tiles_n)
            _amd_row = _amd_tile // _amd_tiles_n % _amd_tiles_m * AMD_TILE_M + tl.arange(0, AMD_TILE_M)[:, None]
            _amd_col = _amd_tile % _amd_tiles_n * AMD_TILE_N + tl.arange(0, AMD_TILE_N)[None, :]
            _amd_mask = (_amd_row < 32) & (_amd_col < 10240)
            _amd_value = tl.load(in_ptr0 + _amd_batch * 327680 + _amd_row * 10240 + _amd_col, _amd_mask)
            tl.store(out_ptr0 + _amd_batch * 327680 + _amd_col // 80 * 2560 + _amd_row * 80 + _amd_col % 80, _amd_value, _amd_mask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, = args
        args.clear()
        assert_size_stride(arg0_1, (16, 32, 128, 80), (327680, 10240, 80, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf0 = empty_strided_cuda((16, 128, 32, 80), (327680, 2560, 80, 1), torch.float32)
            # Topologically Sorted Source Nodes: [permute, contiguous], Original ATen: [aten.permute, aten.clone]
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_permute_0.run(arg0_1, buf0, 5242880, stream=raw_stream0)
            del arg0_1
        return (buf0, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((16, 32, 128, 80), (327680, 10240, 80, 1), device='cuda:0', dtype=torch.float32)
    return [arg0_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
