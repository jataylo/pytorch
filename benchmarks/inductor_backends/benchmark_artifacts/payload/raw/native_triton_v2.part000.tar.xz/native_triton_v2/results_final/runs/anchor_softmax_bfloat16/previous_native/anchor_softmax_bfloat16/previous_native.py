# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/native_triton_v2/results_final/runs/anchor_softmax_bfloat16/previous_native/cache/inductor/bu/cbut2jpv33pnmy6yjpuiynoi6lfsuav233pwbd5gmpcgyhsmoj2s.py
# Topologically Sorted Source Nodes: [invert, masked_fill, float_1, softmax], Original ATen: [aten.bitwise_not, aten.masked_fill, aten._to_copy, prims.prepare_softmax_online, aten._softmax]
# Source node to ATen node mapping:
#   float_1 => convert_element_type
#   invert => bitwise_not
#   masked_fill => full_default, where
#   softmax => div, exp_default, sub_tensor
# Graph fragment:
#   %arg1_1 : Tensor "b8[4096, 1024][1024, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[4096, 1024][1024, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %getitem : Tensor "f32[4096, 1][1, 4096]cuda:0" = PlaceHolder[target=getitem]
#   %getitem_1 : Tensor "f32[4096, 1][1, 4096]cuda:0" = PlaceHolder[target=getitem_1]
#   %bitwise_not : Tensor "b8[4096, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.bitwise_not.default](args = (%arg1_1,), kwargs = {})
#   %full_default : Tensor "f32[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float32, layout: torch.strided, device: cuda:0, pin_memory: False})
#   %convert_element_type : Tensor "f32[4096, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %where : Tensor "f32[4096, 1024][1024, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%bitwise_not, %full_default, %convert_element_type), kwargs = {})
#   %prepare_softmax_online_default : [num_users=2] = call_function[target=torch.ops.prims.prepare_softmax_online.default](args = (%where, -1), kwargs = {})
#   %sub_tensor : Tensor "f32[4096, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%where, %getitem), kwargs = {})
#   %exp_default : Tensor "f32[4096, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%sub_tensor,), kwargs = {})
#   %div : Tensor "f32[4096, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_default, %getitem_1), kwargs = {})
#   return %getitem,%getitem_1,%div
triton_per_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_0 = async_compile.triton('triton_per_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_0', '''
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()
from triton.language.extra import libdevice

@triton.jit
def _amd_maximum(a, b):
    return tl.where((a > b) | (a != a), a, b)

@triton.jit
def _amd_max2(value, axis: tl.constexpr):
    return tl.reduce(value, axis, _amd_maximum)

@triton.jit
def _amd_any(value, axis: tl.constexpr):
    return tl.sum((value != 0).to(tl.int32), axis) != 0

@triton.jit
def _amd_reciprocal(value):
    return tl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[value], dtype=tl.float32, is_pure=True, pack=1)

@triton_heuristics.persistent_reduction(size_hints={'x': 4096, 'r0_': 1024}, reduction_hint=ReductionHint.INNER, filename=__file__, triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*bf16', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]}, inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 4, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 46137344}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': False, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_warp_size': 64, 'amd_max_threads_per_block': 1024, 'amd_reduction_tuning': True, 'amd_kernel_autotune': True, 'amd_kernel_tuning_version': 5, 'amd_autotune_diagnostics_path': '/dockerx/pytorch-flex/agent_space/simd_bench/native_triton_v2/results_final/runs/anchor_softmax_bfloat16/previous_native/anchor_softmax_bfloat16/previous_native.tuning.jsonl', 'amd_warm_arg_names': (), 'amd_confirm_tuning': True, 'amd_graph_tuning': True, 'amd_allow_atomic_tuning': False, 'use_gluon': False, 'amd_native_family': 'row_reduction', 'amd_reduction_extent': 1024, 'amd_row_count': 4096, 'amd_approximate_math': False, 'amd_cache_policy': 'balanced'})
@triton.jit
def triton_per_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_0(in_ptr0, in_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK: tl.constexpr):
    xnumel = 4096
    r0_numel = 1024
    R0_BLOCK: tl.constexpr = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1 + 1024 * x0), xmask, eviction_policy='evict_first', other=0.0)
    tmp2 = tl.load(in_ptr1 + (r0_1 + 1024 * x0), xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
    tmp1 = tmp0 == 0
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tl.full([1, 1], float('-inf'), tl.float32)
    tmp5 = tl.where(tmp1, tmp4, tmp3)
    tmp6 = tl.broadcast(tmp5, tl.full([XBLOCK, R0_BLOCK], 0, tmp5.dtype))[0]
    tmp8 = tl.broadcast(tmp6, tl.full([XBLOCK, R0_BLOCK], 0, tmp6.dtype))[0]
    tmp10 = tl.where(xmask, tmp8, float('-inf'))
    tmp11 = tl.max(tmp10, 1)[:, None].to(tl.float32)
    tmp12 = tmp6 - tmp11
    tmp13 = libdevice.exp(tmp12)
    tmp14 = tl.broadcast(tmp13, tl.full([XBLOCK, R0_BLOCK], 0, tmp13.dtype))[0]
    tmp16 = tl.where(xmask, tmp14, 0)
    tmp17 = tl.sum(tmp16, 1)[:, None].to(tl.float32)
    tmp18 = tmp5 - tmp11
    tmp19 = libdevice.exp(tmp18)
    tmp20 = tmp19 / tmp17
    tl.store(out_ptr2 + (r0_1 + 1024 * x0), tmp20, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride_grouped((arg1_1, arg0_1), ((4096, 1024), (4096, 1024)), ((1024, 1), (1024, 1)), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf2 = empty_strided_cuda((4096, 1024), (1024, 1), torch.float32)
            # Topologically Sorted Source Nodes: [invert, masked_fill, float_1, softmax], Original ATen: [aten.bitwise_not, aten.masked_fill, aten._to_copy, prims.prepare_softmax_online, aten._softmax]
            raw_stream0 = get_raw_stream(0)
            triton_per_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_0.run(arg1_1, arg0_1, buf2, 4096, 1024, stream=raw_stream0)
            del arg0_1
            del arg1_1
        return (buf2, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((4096, 1024), (1024, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((4096, 1024), (1024, 1), device='cuda:0', dtype=torch.bool)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
