"""Export exact-V4 stock/new training results and explicit numerical-error context."""

import csv
import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent
VARIANTS = ("stock", "new_native")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    complete = json.loads((ROOT / "COMPLETE.json").read_text())
    if complete["runs"] != 4:
        raise RuntimeError("Expected four V4 model runs")
    manifest = json.loads((ROOT / "manifest.json").read_text())
    rows, models, errors, source_mismatches, old_cache_mismatches = [], [], [], [], []
    gpu_uuids = set()
    for model in manifest["models"]:
        reports = {variant: json.loads((ROOT / "runs" / model["model"] / f"{variant}.json").read_text()) for variant in VARIANTS}
        variants = {}
        for variant, report in reports.items():
            for filename, expected in report["source_fingerprint"]["sources"].items():
                if sha(Path(filename)) != expected:
                    source_mismatches.append({"variant": variant, "source": filename})
            if report.get("status") != "ok":
                errors.append({"model": model["model"], "variant": variant, "status": report.get("status"), "error": report.get("error")})
            flags = report.get("inductor_config", {})
            enabled = variant != "stock"
            flag_audit = all(flags.get("triton." + name) is enabled for name in (
                "amd_kernel_optimizations", "amd_extended_kernel_optimizations", "amd_further_kernel_optimizations"
            )) and flags.get("triton.amd_use_gluon") is False and flags.get("triton.amd_approximate_math") is False
            gpu_uuids.add(report.get("gpu_uuid"))
            reuse = report["compiler_artifact_reuse"]
            if sha(Path(reuse["original_result"])) != reuse["original_result_sha256"]:
                old_cache_mismatches.append({"result": reuse["original_result"]})
            with Path(reuse["ledger"]).open() as file:
                for line in file:
                    entry = json.loads(line)
                    expected = entry.get("old_sha256", entry.get("sha256"))
                    if sha(Path(entry["old"])) != expected:
                        old_cache_mismatches.append({"artifact": entry["old"]})
            before, after = report.get("loaded_overlay_modules_before", {}), report.get("loaded_overlay_modules_after", {})
            variants[variant] = {
                "status": report.get("status"), "milliseconds": report.get("milliseconds"), "repeat_ms": report.get("repeat_ms"),
                "gpu_uuid": report.get("gpu_uuid"), "physical_gpu": report.get("physical_gpu"), "gpu": report.get("gpu"),
                "parameters": report.get("parameters"), "parameters_with_training_gradients": report.get("training_parameters_with_gradients"),
                "all_parameter_gradients_present": report.get("parameters") is not None and report.get("parameters") == report.get("training_parameters_with_gradients"),
                "timing_recompiles": report.get("timing_recompiles"), "timing_includes_cpu": True,
                "final_training_loss": report.get("final_training_loss"),
                "final_training_loss_finite": math.isfinite(report.get("final_training_loss", float("nan"))),
                "accuracy": {
                    "mode": report.get("validation_mode"), "scope": report.get("validation"),
                    "eager_reference_status": report.get("eager_reference_status"),
                    "eager_loss": report.get("eager_loss"), "compiled_loss": report.get("compiled_loss"),
                    "gradient_samples": report.get("gradient_validation", {}), "warnings": report.get("validation_warnings", []),
                    "tolerances": report.get("accuracy_tolerances"), "limit": report.get("accuracy_limit"),
                    "timed_mode": "train; full forward + backward + SGD",
                    "training_finite_gradient_check": "first/middle/last gradient tensors, first1024 elements, after first training step",
                },
                "source_flags_audit": {
                    "expected_flags_match": flag_audit, "flags": flags,
                    "loaded_module_count": len(before), "loaded_modules_before_after_equal": bool(before) and before == after,
                    "native_codegen_policy": report.get("native_codegen_policy"), "codegen_audit": report.get("codegen_audit"),
                    "fingerprint": str(ROOT / f"{variant}_source_fingerprint.json"),
                },
                "cache_audit": {
                    "inductor_cache_started_empty": report.get("inductor_cache_started_empty"),
                    "selection_cache_reuse": report.get("selection_cache_reuse"),
                    "autotune_local_cache": flags.get("autotune_local_cache"), "autotune_remote_cache": flags.get("autotune_remote_cache"),
                    "compiler_artifact_manifest": report.get("compiler_artifact_reuse_manifest"),
                    "compiler_groups_preseeded": reuse["complete_compiler_groups"],
                    "old_artifacts_rechecked_immutable": True, "compile_times_cold_setup_comparable": False,
                },
                "compilation_seconds_preseeded_not_cold": {
                    "eval_validation": report.get("validation_compile_seconds"), "first_train_step": report.get("first_compiled_step_seconds"),
                },
                "raw_result": str(ROOT / "runs" / model["model"] / f"{variant}.json"),
                "raw_log": str(ROOT / "runs" / model["model"] / f"{variant}.log"),
            }
        stock, new = reports["stock"], reports["new_native"]
        initial = {
            name: stock.get(name) == new.get(name)
            for name in ("initial_parameters", "initial_inputs", "inputs", "model_config_sha256", "model_implementation", "model_dependencies")
        }
        accuracy_comparison = {
            "scope": "each compiled variant versus its own eager reference, not a direct gradient-vector comparison",
            "stock_eager_loss": stock.get("eager_loss"), "new_eager_loss": new.get("eager_loss"),
            "stock_compiled_loss": stock.get("compiled_loss"), "new_compiled_loss": new.get("compiled_loss"),
            "new_vs_stock_relative_compiled_loss_error": abs(new["compiled_loss"] - stock["compiled_loss"]) / max(abs(stock["compiled_loss"]), 1e-12) if new.get("compiled_loss") is not None and stock.get("compiled_loss") is not None else None,
            "gradient_error_metrics_side_by_side": {
                name: {variant: report.get("gradient_validation", {}).get(name) for variant, report in reports.items()}
                for name in stock.get("gradient_validation", {})
            },
            "interpretation": "Original tolerances unchanged. Small absolute gradients can have large relative RMS errors; stock errors are retained alongside new errors. No tight relative-gradient or convergence claim.",
        }
        speedup = (stock["milliseconds"] / new["milliseconds"] - 1) * 100 if stock.get("milliseconds") is not None and new.get("milliseconds") is not None else None
        models.append({**model, "inputs": stock["inputs"], "initial_state_audit": initial, "variants": variants,
                       "new_vs_stock_speedup_percent": speedup, "accuracy_comparison": accuracy_comparison})
        rows.append({
            "model": model["model"], "batch_size": model["batch_size"], "stock_ms": stock.get("milliseconds"),
            "new_native_ms": new.get("milliseconds"), "new_vs_stock_speedup_percent": speedup,
            "physical_gpu": "0", "gpu_uuid": stock["gpu_uuid"], "timing_includes_cpu": True,
            "stock_status": stock["status"], "new_native_status": new["status"],
            "stock_repeat_ms": json.dumps(stock.get("repeat_ms")), "new_repeat_ms": json.dumps(new.get("repeat_ms")),
            "no_timing_recompiles": all(v["timing_recompiles"] == 0 for v in variants.values()),
            "all_parameter_gradients_present": all(v["all_parameter_gradients_present"] for v in variants.values()),
            "original_tolerance_warnings": sum(len(v["accuracy"]["warnings"]) for v in variants.values()),
        })
    audit = {
        "exactly_four_runs": complete["runs"] == 4, "all_status_ok": not errors,
        "same_physical_gpu_uuid": len(gpu_uuids) == 1 and None not in gpu_uuids,
        "frozen_sources_unchanged": not source_mismatches, "old_v3_artifacts_and_results_unchanged": not old_cache_mismatches,
        "initial_states_match": all(all(model["initial_state_audit"].values()) for model in models),
        "no_timing_recompiles": all(row["no_timing_recompiles"] for row in rows),
        "all_parameter_gradients_present": all(row["all_parameter_gradients_present"] for row in rows),
        "source_flags_match": all(v["source_flags_audit"]["expected_flags_match"] and v["source_flags_audit"]["loaded_modules_before_after_equal"] for m in models for v in m["variants"].values()),
        "no_inductor_or_selection_cache_reuse": all(v["cache_audit"]["inductor_cache_started_empty"] and not v["cache_audit"]["selection_cache_reuse"] and v["cache_audit"]["autotune_local_cache"] is False and v["cache_audit"]["autotune_remote_cache"] is False for m in models for v in m["variants"].values()),
    }
    summary = {
        "source_revision": "V4 exact final mixed-dtype fix", "protocol": manifest, "actual_runs": 4,
        "scope": "GPU0 full training steps; separate from GPU3 kernel benchmarks", "timing_includes_cpu": True,
        "speedup_definition": "100 * (stock_ms / new_native_ms - 1)", "compile_times_cold_setup_comparable": False,
        "accuracy_limit": "Eval-mode loss and sampled-gradient checks (BatchNorm batch statistics when present), plus finite train-step checks. Original tolerances unchanged; explicit stock-error context; no convergence claim.",
        "audit": audit, "errors": errors, "source_mismatches": source_mismatches, "old_cache_mismatches": old_cache_mismatches, "models": models,
    }
    with (ROOT / "per_model.csv").open("w") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"audit": audit, "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
