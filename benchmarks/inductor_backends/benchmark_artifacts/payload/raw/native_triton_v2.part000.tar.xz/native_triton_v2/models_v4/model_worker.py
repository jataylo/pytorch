import argparse
import atexit
import gc
import fcntl
import faulthandler
import functools
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time
import traceback


TASK_ROOT = Path('/dockerx/pytorch-flex/agent_space/simd_bench')
sys.path.insert(0, str(TASK_ROOT))


def read_source_fingerprint():
    path = Path(os.environ['MODEL_SOURCE_FINGERPRINT'])
    if not path.exists():
        raise RuntimeError('Missing model source fingerprint')
    fingerprint = json.loads(path.read_text())
    if not fingerprint.get('sources'):
        raise RuntimeError('Model source fingerprint has no sources')
    for source_path, expected in fingerprint['sources'].items():
        if hashlib.sha256(Path(source_path).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Model source changed: ' + source_path)
    return fingerprint



def audit_loaded_sources():
    import importlib
    fingerprint = read_source_fingerprint()
    source_root = Path(os.environ['AMD_CODEGEN_SOURCE_ROOT']).resolve()
    loaded = {}
    for name in fingerprint['overlay_modules']:
        module = importlib.import_module(name)
        actual = Path(module.__file__).resolve()
        expected = (source_root / (name.replace('.', '/') + '.py')).resolve()
        if actual != expected:
            raise RuntimeError(f'Wrong model compiler overlay: {name}: {actual} != {expected}')
        digest = hashlib.sha256(actual.read_bytes()).hexdigest()
        if fingerprint['sources'].get(str(expected)) != digest:
            raise RuntimeError(f'Unexpected loaded source hash: {name}')
        loaded[name] = {'path': str(actual), 'sha256': digest}
    return loaded


def tensor_digest(value):
    import torch
    sample = value.detach().reshape(-1)[:1024].contiguous().view(torch.uint8).cpu()
    return {'shape': list(value.shape), 'dtype': str(value.dtype),
            'sample_sha256': hashlib.sha256(sample.numpy().tobytes()).hexdigest()}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--variant', choices=['stock', 'new_native'], required=True)
    parser.add_argument('--suite', required=True)
    parser.add_argument('--model', required=True)
    parser.add_argument('--batch-size', type=int, required=True)
    parser.add_argument('--backend', choices=['triton', 'flydsl'], required=True)
    parser.add_argument('--autotune', type=int, choices=[0, 1], required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--skip-eager-reference', action='store_true')
    parser.add_argument('--warmup', type=int, default=5)
    parser.add_argument('--iterations', type=int, default=20)
    parser.add_argument('--repeats', type=int, default=5)
    parser.add_argument('--fsdp', action='store_true')
    parser.add_argument('--backend-selection', action='store_true')
    args = parser.parse_args()
    if args.iterations < 1 or args.repeats < 1 or args.warmup < 0:
        parser.error('iterations/repeats must be positive and warmup must be nonnegative')
    faulthandler.enable()
    rank = int(os.environ.get('RANK', '0')) if args.fsdp else 0
    world_size = int(os.environ.get('WORLD_SIZE', '1')) if args.fsdp else 1
    local_rank = int(os.environ.get('LOCAL_RANK', '0')) if args.fsdp else 0
    base_output = Path(args.output)
    if args.fsdp and rank:
        args.output = str(base_output.parent / 'ranks' / f'{base_output.stem}.world{world_size}.rank{rank}.json')
    diagnostics = base_output.parent / 'kernels' / f'{base_output.stem}.world{world_size}.rank{rank}.jsonl'
    os.environ['TORCHINDUCTOR_FLYDSL_SIMD_DIAGNOSTICS'] = str(diagnostics)
    timing_lock = Path(__file__).with_name('gpu0-training-timing.lock').open('a')
    entry_gate = Path(__file__).with_name('gpu0-training-entry.lock').open('a')
    atexit.register(timing_lock.close)
    atexit.register(entry_gate.close)
    if not args.fsdp:
        fcntl.flock(entry_gate, fcntl.LOCK_EX)
    fcntl.flock(timing_lock, fcntl.LOCK_SH)
    if not args.fsdp:
        fcntl.flock(entry_gate, fcntl.LOCK_UN)
    result = vars(args).copy()
    result.update(status='started', mode='training', dtype='amp_bf16', checkpoint=False)
    result['physical_gpu'] = os.environ.get('CUDA_VISIBLE_DEVICES')
    result['launch_environment_overrides'] = json.loads(os.environ.get('BENCHMARK_LAUNCH_OVERRIDES', '{}'))
    result['placement_override'] = os.environ.get('BENCHMARK_PLACEMENT_OVERRIDE') == '1'
    result['attempt_id'] = os.environ.get('BENCHMARK_ATTEMPT_ID', str(time.time_ns()))
    result.update(rank=rank, world_size=world_size, parallelism='fsdp' if args.fsdp else 'single_gpu',
                  diagnostics_file=str(diagnostics), benchmark_variant='native_triton_v4_full_model_training_gpu0')
    result['source_fingerprint'] = read_source_fingerprint()
    result['benchmark_protocol'] = json.loads(os.environ.get('BENCHMARK_PROTOCOL_JSON', '{}'))
    started = time.monotonic()

    def save():
        os.environ['TORCHINDUCTOR_FLYDSL_DIAGNOSTIC_CONTEXT'] = json.dumps({
            'suite': args.suite, 'model': args.model, 'backend': args.backend, 'requested_backend': args.backend,
            'autotune': args.autotune, 'rank': rank, 'world_size': world_size,
            'gpu_group': result['physical_gpu'], 'phase': result.get('phase'), 'attempt_id': result['attempt_id'],
        })
        result['wall_seconds'] = time.monotonic() - started
        target = Path(args.output)
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_suffix('.tmp')
        temp.write_text(json.dumps(result, indent=2, default=str) + '\n')
        temp.replace(target)

    save()
    try:
        os.environ['TORCHINDUCTOR_COMPILE_THREADS'] = '1'
        if args.fsdp:
            os.environ['TORCHINDUCTOR_CACHE_DIR'] = str(Path(os.environ['TORCHINDUCTOR_CACHE_DIR']) / f'rank{rank}')
        result['inductor_cache'] = os.environ['TORCHINDUCTOR_CACHE_DIR']
        if Path(result['inductor_cache']).exists() and any(Path(result['inductor_cache']).rglob('*')):
            raise RuntimeError('V4 model Inductor cache must start empty')
        reuse_path = Path(os.environ['MODEL_COMPILER_REUSE_MANIFEST'])
        result['compiler_artifact_reuse'] = json.loads(reuse_path.read_text())
        result['compiler_artifact_reuse_manifest'] = {'path': str(reuse_path), 'sha256': hashlib.sha256(reuse_path.read_bytes()).hexdigest()}
        result['inductor_cache_started_empty'] = True
        result['selection_cache_reuse'] = False
        result['compile_time_cold_setup_comparable'] = False
        binary_cache = Path(os.environ['MODEL_BINARY_CACHE'])
        binary_cache /= f"gpu{result['physical_gpu']}/{args.backend}_autotune{args.autotune}"
        binary_cache.mkdir(parents=True, exist_ok=True)
        triton_cache = Path(os.environ['MODEL_BINARY_CACHE']) / 'triton'
        os.environ['TRITON_CACHE_DIR'] = str(triton_cache)
        os.environ['FLYDSL_RUNTIME_CACHE_DIR'] = str(binary_cache / 'flydsl')
        result['compiled_artifact_cache'] = str(binary_cache)
        result['triton_binary_cache'] = str(triton_cache)
        import torch
        from torch._dynamo.utils import counters
        from torch._inductor import config
        config.triton.amd_kernel_optimizations = args.variant != 'stock'
        config.triton.amd_extended_kernel_optimizations = args.variant != 'stock'
        config.triton.amd_further_kernel_optimizations = args.variant != 'stock'
        config.triton.amd_use_gluon = False
        config.triton.amd_approximate_math = False
        config.triton.amd_autotune_diagnostics_path = str(base_output.with_suffix('.tuning.jsonl'))

        sys.path.insert(0, '/dockerx/Triton_Conv_Development/scripts')
        from common import (
            is_diffusion_model, load_model, load_model_meta,
            make_model_input, register_grouped_mm_autocast, resolve_dtype_spec,
        )

        if args.fsdp:
            import torch.distributed as dist
            from datetime import timedelta
            torch.cuda.set_device(local_rank)
            dist.init_process_group('nccl', timeout=timedelta(minutes=30))
            from torch._inductor.fx_passes.joint_graph import lazy_init
            lazy_init(torch.device('cuda', local_rank))
            torch.cuda.synchronize()
            dist.barrier()
        torch.set_num_threads(8)
        torch.manual_seed(2026)
        torch.cuda.manual_seed_all(2026)
        torch._dynamo.config.suppress_errors = False
        config.flydsl.simd = args.backend == 'flydsl'
        config.flydsl.simd_autotune_backend = args.backend_selection
        config.flydsl.simd_diagnostics_path = str(diagnostics)
        config.max_autotune = False
        config.max_autotune_gemm = False
        config.max_autotune_gemm_backends = 'ATEN'
        config.max_autotune_conv_backends = 'ATEN'
        config.conv_1x1_as_mm = False
        config.max_autotune_pointwise = bool(args.autotune)
        config.triton.autotune_pointwise = bool(args.autotune)
        config.fx_graph_cache = False
        config.autotune_local_cache = False
        config.autotune_remote_cache = False
        config.triton.cudagraphs = False
        result['inductor_config'] = {
            'autotune_local_cache': config.autotune_local_cache,
            'autotune_remote_cache': config.autotune_remote_cache,
            'triton.amd_use_gluon': config.triton.amd_use_gluon,
            'triton.amd_approximate_math': config.triton.amd_approximate_math,
            'triton.amd_kernel_optimizations': config.triton.amd_kernel_optimizations,
            'triton.amd_extended_kernel_optimizations': config.triton.amd_extended_kernel_optimizations,
            'triton.amd_further_kernel_optimizations': config.triton.amd_further_kernel_optimizations,
            'flydsl.simd': config.flydsl.simd,
            'flydsl.simd_autotune_backend': config.flydsl.simd_autotune_backend,
            'flydsl.simd_autotune_min_numel': config.flydsl.simd_autotune_min_numel,
            'flydsl.simd_autotune_max_configs': config.flydsl.simd_autotune_max_configs,
            'max_autotune': config.max_autotune,
            'max_autotune_gemm': config.max_autotune_gemm,
            'conv_1x1_as_mm': config.conv_1x1_as_mm,
            'max_autotune_pointwise': config.max_autotune_pointwise,
            'triton.autotune_pointwise': config.triton.autotune_pointwise,
            'max_autotune_gemm_backends': config.max_autotune_gemm_backends,
            'max_autotune_conv_backends': config.max_autotune_conv_backends,
            'triton.cudagraphs': config.triton.cudagraphs,
        }
        if os.environ.get('BENCHMARK_EXTRA_MODEL_DEPS') == '1':
            dependency_root = Path(__file__).resolve().parent / 'optional_model_deps_v3'
            manifest_path = dependency_root.with_name('optional_model_deps_v3_manifest.json')
            dependency_manifest = json.loads(manifest_path.read_text())
            for name, expected in dependency_manifest['file_hashes'].items():
                if hashlib.sha256((dependency_root / name).read_bytes()).hexdigest() != expected:
                    raise RuntimeError(f'Optional model dependency source changed: {name}')
            import fla
            if not Path(fla.__file__).resolve().is_relative_to(dependency_root.resolve()):
                raise RuntimeError(f'Wrong optional dependency path: {fla.__file__}')
            result['optional_model_dependencies'] = {
                'package': 'fla-core', 'version': fla.__version__, 'path': fla.__file__,
                'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
            }
        result['source_overlay'] = os.environ['AMD_CODEGEN_SOURCE_ROOT']
        result['loaded_overlay_modules_before'] = audit_loaded_sources()
        register_grouped_mm_autocast()
        props = torch.cuda.get_device_properties(local_rank)
        result.update(torch_version=torch.__version__, torch_git=torch.version.git_version,
                      gpu=props.name, arch=props.gcnArchName, total_vram_bytes=props.total_memory,
                      gpu_uuid=str(props.uuid), pci_bus_id=props.pci_bus_id)
        if str(props.uuid) != result['compiler_artifact_reuse']['original_gpu_uuid']:
            raise RuntimeError('V4 model GPU differs from the original same-variant artifact provenance')
        if args.backend == 'flydsl':
            from torch._inductor.codegen.flydsl.flydsl_utils import simd_enabled
            if not simd_enabled():
                raise RuntimeError('FlyDSL SIMD was requested but is unavailable')
        spec = resolve_dtype_spec('amp_bf16')
        result['phase'] = 'model_capacity'
        save()
        meta = load_model_meta(args.model, spec)
        expected_revision = os.environ.get('BENCHMARK_OFFICIAL_MODEL_REVISION')
        if expected_revision and expected_revision not in type(meta).__module__:
            raise RuntimeError(f'Unexpected official model revision: {type(meta).__module__}')
        parameters = sum(p.numel() for p in meta.parameters())
        parameter_bytes = parameters * torch.empty((), dtype=spec.param_dtype).element_size()
        result.update(parameters=parameters, parameter_bytes=parameter_bytes,
                      component='diffusion_denoiser' if is_diffusion_model(meta) else 'full_model')
        if getattr(meta, 'config', None) is not None:
            model_config = meta.config.to_dict() if hasattr(meta.config, 'to_dict') else dict(meta.config)
            result['model_config_sha256'] = hashlib.sha256(json.dumps(model_config, sort_keys=True, default=str).encode()).hexdigest()
            result['model_config_commit'] = getattr(meta.config, '_commit_hash', None)
        free, _ = torch.cuda.mem_get_info()
        total_free = free
        if args.fsdp:
            capacities = [None] * world_size
            dist.all_gather_object(capacities, {'free': free, 'uuid': str(props.uuid), 'pci': props.pci_bus_id})
            total_free = sum(c['free'] for c in capacities)
            result['gpu_group'] = capacities
        result['free_vram_before_load_bytes'] = free
        if args.fsdp and os.environ.get('BENCHMARK_VERIFY_FSDP_MEMORY_BOUND') == '1':
            from fsdp_memory_bound_v3 import fsdp_backward_memory_bound
            bound = fsdp_backward_memory_bound(meta.to(spec.param_dtype), world_size,
                free_bytes_per_rank=[capacity['free'] for capacity in capacities])
            if bound is None:
                from fsdp_large_embedding_bound_v3 import fsdp_large_embedding_memory_bound
                bound = fsdp_large_embedding_memory_bound(meta, world_size,
                    free_bytes_per_rank=[capacity['free'] for capacity in capacities])
            result['fsdp_memory_bound'] = bound
            if bound is not None and bound.get('insufficient_capacity'):
                result.update(status='capacity_skip', error=bound['reason'])
                save()
                return
        del meta
        gc.collect()
        if parameter_bytes * 2 > total_free:
            result.update(status='capacity_skip', error='FP32 weights plus gradients alone exceed aggregate free GPU memory')
            save()
            return

        result['phase'] = 'model_load'
        save()
        if args.fsdp:
            from torch.distributed.fsdp import FullyShardedDataParallel as FSDP, MixedPrecision
            from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy
            model = (load_model(args.model, spec, 'cpu', pretrained=False) if rank == 0
                     else load_model_meta(args.model, spec).to(spec.param_dtype)).eval()
            if os.environ.get('BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS') == '1':
                from diffusion_meta_constants_v3 import restore_diffusion_meta_constants
                result['restored_diffusion_constants'] = restore_diffusion_meta_constants(model)
            split_names = set(getattr(model, '_no_split_modules', None) or [])
            block_types = {type(m) for m in model.modules() if type(m).__name__ in split_names}
            if not block_types:
                block_types = {type(child) for m in model.modules() if isinstance(m, torch.nn.ModuleList)
                               for child in m if sum(p.numel() for p in child.parameters()) > 1000000}
            if not block_types:
                raise RuntimeError('No safe transformer/denoiser block boundary found for FSDP')
            local_batch = args.batch_size // world_size if args.batch_size % world_size == 0 else args.batch_size
            replicated = args.batch_size % world_size != 0
            result.update(local_batch_size=local_batch, batch_distribution='replicated' if replicated else 'data_parallel',
                          effective_global_batch_size=local_batch * world_size,
                          fsdp_block_types=sorted(t.__name__ for t in block_types))
            torch.manual_seed(2026 if replicated else 2026 + rank)
            inputs, kwargs = make_model_input(model, args.model, local_batch, spec, 'cuda')
            materialized = {}

            def materialize(module):
                for name, parameter in module._parameters.items():
                    if parameter is None or not parameter.is_meta:
                        continue
                    key = id(parameter)
                    if key not in materialized:
                        materialized[key] = torch.nn.Parameter(
                            torch.empty_like(parameter, device=torch.device('cuda', local_rank)),
                            requires_grad=parameter.requires_grad)
                    module._parameters[name] = materialized[key]
                for name, buffer in module._buffers.items():
                    if buffer is not None and buffer.is_meta:
                        module._buffers[name] = torch.empty_like(buffer, device=torch.device('cuda', local_rank))

            model = FSDP(model, device_id=local_rank, use_orig_params=True, sync_module_states=True,
                         param_init_fn=materialize,
                         auto_wrap_policy=functools.partial(transformer_auto_wrap_policy, transformer_layer_cls=block_types),
                         mixed_precision=MixedPrecision(param_dtype=torch.bfloat16, reduce_dtype=torch.float32))
            del materialized
            args.skip_eager_reference = True
            result['skip_eager_reference'] = True
        else:
            model = load_model(args.model, spec, 'cuda', pretrained=False).eval()
            inputs, kwargs = make_model_input(model, args.model, args.batch_size, spec, 'cuda')
        if os.environ.get('BENCHMARK_ADD_MM_TOKEN_TYPES') == '1':
            from multimodal_inputs_v2 import with_mm_token_type_ids
            inputs = with_mm_token_type_ids(model, inputs)
        result['inputs'] = {
            k: {'shape': list(v.shape), 'dtype': str(v.dtype)} if isinstance(v, torch.Tensor) else str(v)
            for k, v in (inputs.items() if kwargs else [('input', inputs)])
        }
        result['initial_parameters'] = {
            name: tensor_digest(parameter)
            for index, (name, parameter) in enumerate(model.named_parameters())
            if index in (0, len(list(model.named_parameters())) // 2, len(list(model.named_parameters())) - 1)
        }
        result['initial_inputs'] = {
            name: tensor_digest(value)
            for name, value in (inputs.items() if kwargs else [('input', inputs)])
            if isinstance(value, torch.Tensor)
        }
        import importlib
        import importlib.metadata
        model_module = importlib.import_module(type(model).__module__)
        result['model_implementation'] = {
            'module': type(model).__module__, 'path': model_module.__file__,
            'sha256': hashlib.sha256(Path(model_module.__file__).read_bytes()).hexdigest(),
        }
        result['model_dependencies'] = {
            name: importlib.metadata.version(name) for name in ('transformers', 'timm')
        }
        optimizer = torch.optim.SGD(model.parameters(), lr=0.0001, momentum=0.0, foreach=True)
        result['optimizer'] = 'SGD(lr=0.0001, momentum=0, foreach=True)'
        result['loss'] = 'mean squared first differentiable model output; synthetic training objective'

        def objective(output):
            if isinstance(output, torch.Tensor):
                if not output.requires_grad:
                    raise RuntimeError('Model output has no gradients')
                return output.float().square().mean()
            if isinstance(output, dict):
                for key in ('logits', 'last_hidden_state', 'prediction_logits', 'sample', 'loss'):
                    if key in output and isinstance(output[key], torch.Tensor) and output[key].requires_grad:
                        return objective(output[key])
                values = output.values()
            elif isinstance(output, (tuple, list)):
                values = output
            else:
                raise RuntimeError(f'Unsupported output type: {type(output)}')
            for value in values:
                if isinstance(value, torch.Tensor) and value.requires_grad:
                    return objective(value)
            raise RuntimeError('No differentiable output found')

        def forward_loss():
            with spec.autocast('cuda'):
                output = model(**inputs) if kwargs else model(inputs)
                return objective(output)

        norms = [m for m in model.modules() if isinstance(m, torch.nn.modules.batchnorm._BatchNorm)]
        for norm in norms:
            norm.training = True
        result['validation_mode'] = 'eval with BatchNorm batch statistics' if norms else 'eval'

        result['phase'] = 'eager_validation'
        save()
        torch.manual_seed(2026)
        eager_loss = None
        eager_grads = {}
        validation_warnings = []
        if args.skip_eager_reference:
            result['eager_reference_status'] = 'skipped_for_direct_training_recheck'
            result['validation_mode'] = 'not run; direct training recheck'
            validation_warnings.append('Eager numerical comparison skipped; full compiled training has finite loss and sampled-gradient checks')
        else:
            try:
                eager_loss = forward_loss()
                eager_loss.backward()
                torch.cuda.synchronize()
                result['eager_loss'] = eager_loss.detach().item()
                if not torch.isfinite(eager_loss).item():
                    raise RuntimeError('Eager training loss is not finite')
                named = [(name, p) for name, p in model.named_parameters() if p.grad is not None]
                result['parameters_with_gradients'] = sum(p.numel() for _, p in named)
                chosen = sorted(set([0, len(named) // 2, len(named) - 1])) if named else []
                eager_grads = {named[i][0]: named[i][1].grad.detach().flatten()[:1024].clone() for i in chosen}
                result['eager_reference_status'] = 'available'
            except torch.OutOfMemoryError as exc:
                result['eager_reference_status'] = 'out_of_memory'
                result['eager_reference_error'] = str(exc)
                eager_grads = {}
                validation_warnings.append('Eager reference exceeded memory; compiled training attempted without a numerical reference')
        eager_loss = None
        optimizer.zero_grad(set_to_none=True)
        if result['eager_reference_status'] == 'out_of_memory':
            gc.collect()
            torch.cuda.empty_cache()
        if os.environ.get('BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE') == '1':
            reset_modules = 0
            for module in model.modules():
                cache = getattr(module, 'attention_bias_cache', None)
                if isinstance(cache, dict):
                    cache.clear()
                    reset_modules += 1
            result['validation_cache_reset_modules'] = reset_modules
        counters.clear()
        if result['eager_reference_status'] == 'available':
            compiled = torch.compile(forward_loss, backend='inductor')
            result['phase'] = 'compile_validation'
            save()
            torch.manual_seed(2026)
            compile_start = time.monotonic()
            compiled_loss = compiled()
            compiled_loss.backward()
            torch.cuda.synchronize()
            result['validation_compile_seconds'] = time.monotonic() - compile_start
            result['compiled_loss'] = compiled_loss.detach().item()
            if not torch.isfinite(compiled_loss).item():
                raise RuntimeError('Compiled training loss is not finite')
            if result['eager_reference_status'] == 'available':
                try:
                    torch.testing.assert_close(compiled_loss.detach(), torch.tensor(result['eager_loss'], device='cuda'), rtol=0.03, atol=0.003)
                except AssertionError as exc:
                    validation_warnings.append(f'loss: {exc}')
            param_map = dict(model.named_parameters())
            for name, expected in eager_grads.items():
                actual = param_map[name].grad
                if actual is None:
                    raise RuntimeError(f'Missing compiled gradient: {name}')
                sample = actual.detach().flatten()[:1024]
                if not torch.isfinite(sample).all().item():
                    raise RuntimeError(f'Compiled gradient is not finite: {name}')
                rms_error = (sample - expected).square().mean().sqrt().item()
                rms_reference = expected.square().mean().sqrt().item()
                result.setdefault('gradient_validation', {})[name] = {
                    'rms_error': rms_error,
                    'relative_rms_error': rms_error / max(rms_reference, 1e-12),
                    'reference_rms': rms_reference,
                    'max_abs_error': (sample - expected).abs().max().item(),
                }
                try:
                    torch.testing.assert_close(sample, expected, rtol=0.05, atol=0.005)
                except AssertionError as exc:
                    validation_warnings.append(f'gradient {name}: {exc}')
            result['validation'] = 'deterministic eager loss and up to 1024 elements of first/middle/last parameter gradients; normalization mode recorded separately; timing uses train mode'
            result['validation_warnings'] = validation_warnings
            result['accuracy_tolerances'] = {'loss': {'rtol': 0.03, 'atol': 0.003}, 'sampled_gradient': {'rtol': 0.05, 'atol': 0.005}}
            result['accuracy_limit'] = 'Original criteria preserved; absolute and relative RMS errors reported explicitly. Passing absolute tolerances is not tight relative-gradient or convergence validation.'
            del compiled_loss, eager_grads, param_map
        else:
            result['validation'] = 'Numerical comparison unavailable for this run; actual compiled training attempted directly'
            result['validation_warnings'] = validation_warnings
        optimizer.zero_grad(set_to_none=True)
        model.train()
        if args.fsdp:
            result['phase'] = 'fsdp_state_initialization' if os.environ.get('BENCHMARK_FSDP_STATE_INIT_ONLY') == '1' else 'fsdp_eager_initialization'
            save()
            if os.environ.get('BENCHMARK_FSDP_STATE_INIT_ONLY') == '1':
                from fsdp_state_init_v3 import initialize_fsdp_state_for_compile
                result['fsdp_initialization_details'] = initialize_fsdp_state_for_compile(model)
                result['fsdp_initialization_mode'] = 'state_only'
            else:
                initialization_loss = forward_loss()
                initialization_loss.backward()
                torch.cuda.synchronize()
                if not torch.isfinite(initialization_loss).item():
                    raise RuntimeError('FSDP eager initialization loss is not finite')
                result['fsdp_initialization_loss'] = initialization_loss.detach().item()
                del initialization_loss
                optimizer.zero_grad(set_to_none=True)
                dist.barrier()
                result['fsdp_initialization_mode'] = 'eager_training'
            save()
        torch._dynamo.reset()
        counters.clear()
        compiled = torch.compile(forward_loss, backend='inductor')

        def step():
            optimizer.zero_grad(set_to_none=True)
            loss = compiled()
            loss.backward()
            optimizer.step()
            return loss

        result['phase'] = 'warmup'
        save()
        compile_start = time.monotonic()
        initial_loss = step()
        torch.cuda.synchronize()
        result['first_compiled_step_seconds'] = time.monotonic() - compile_start
        if not torch.isfinite(initial_loss).item():
            raise RuntimeError('First compiled training loss is not finite')
        gradients = [p.grad for p in model.parameters() if p.grad is not None]
        if not gradients:
            raise RuntimeError('Compiled training produced no parameter gradients')
        result['training_parameters_with_gradients'] = sum(g.numel() for g in gradients)
        for index in sorted(set([0, len(gradients) // 2, len(gradients) - 1])):
            if not torch.isfinite(gradients[index].flatten()[:1024]).all().item():
                raise RuntimeError('Compiled training produced nonfinite sampled gradients')
        del initial_loss, gradients
        for _ in range(args.warmup):
            step()
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        result['phase'] = 'waiting_for_isolated_timing'
        save()
        fcntl.flock(timing_lock, fcntl.LOCK_UN)
        if args.fsdp:
            dist.barrier()
        if rank == 0:
            if not args.fsdp:
                fcntl.flock(entry_gate, fcntl.LOCK_EX)
            fcntl.flock(timing_lock, fcntl.LOCK_EX)
        if args.fsdp:
            dist.barrier()
        steady_steps = int(os.environ['BENCHMARK_STEADY_WARMUP_STEPS'])
        for _ in range(steady_steps): step()
        torch.cuda.synchronize()
        result['timing_warmup'] = steady_steps
        result['phase'] = 'timing'
        result['timing_graphs_before'] = counters['stats']['unique_graphs']
        result['timing_begin_ns'] = time.time_ns()
        save()
        samples = []
        for _ in range(args.repeats):
            torch.cuda.synchronize()
            if args.fsdp:
                dist.barrier()
            begin = time.perf_counter()
            for _ in range(args.iterations):
                last_loss = step()
            torch.cuda.synchronize()
            elapsed = (time.perf_counter() - begin) * 1000 / args.iterations
            if args.fsdp:
                elapsed_tensor = torch.tensor(elapsed, device='cuda')
                dist.all_reduce(elapsed_tensor, op=dist.ReduceOp.MAX)
                elapsed = elapsed_tensor.item()
            samples.append(elapsed)
        result['timing_end_ns'] = time.time_ns()
        result['timing_recompiles'] = counters['stats']['unique_graphs'] - result['timing_graphs_before']
        if args.fsdp:
            recompiles = torch.tensor(result['timing_recompiles'], device='cuda')
            dist.all_reduce(recompiles, op=dist.ReduceOp.MAX)
            result['timing_recompiles'] = recompiles.item()
        if args.fsdp:
            dist.barrier()
        if rank == 0:
            fcntl.flock(timing_lock, fcntl.LOCK_UN)
            if not args.fsdp:
                fcntl.flock(entry_gate, fcntl.LOCK_UN)
        if not args.fsdp:
            fcntl.flock(entry_gate, fcntl.LOCK_EX)
        fcntl.flock(timing_lock, fcntl.LOCK_SH)
        if not args.fsdp:
            fcntl.flock(entry_gate, fcntl.LOCK_UN)
        if not torch.isfinite(last_loss).item():
            raise RuntimeError('Training loss is not finite after timing')
        result['final_training_loss'] = last_loss.detach().item()
        status = 'numerical_warning' if validation_warnings else 'ok'
        if result['eager_reference_status'] == 'out_of_memory':
            status = 'reference_unavailable'
        elif result['eager_reference_status'] != 'available':
            status = 'validation_unavailable'
        if result['timing_recompiles']:
            status = 'timing_recompile'
        result['loaded_overlay_modules_after'] = audit_loaded_sources()
        if result['loaded_overlay_modules_before'] != result['loaded_overlay_modules_after']:
            raise RuntimeError('Loaded overlay modules changed during model execution')
        if read_source_fingerprint() != result['source_fingerprint']:
            raise RuntimeError('Model source fingerprint changed during execution')
        result.update(status=status, phase='complete', milliseconds=statistics.median(samples),
                      repeat_ms=samples, peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                      peak_reserved_bytes=torch.cuda.max_memory_reserved(),
                      flydsl_counters=dict(counters['flydsl_simd']),
                      dynamo_stats={k: dict(v) for k, v in counters.items()})
        from collect_codegen_v2 import collect_codegen
        result['codegen_audit'] = collect_codegen(os.environ['TORCHINDUCTOR_CACHE_DIR'],
            base_output.parent / 'codegen' / f'{base_output.stem}.world{world_size}.rank{rank}.json')
        import re
        from collections import Counter
        families = Counter()
        policy_failures = []
        for path in Path(os.environ['TORCHINDUCTOR_CACHE_DIR']).rglob('*.py'):
            text = path.read_text()
            families.update(re.findall(r"['\"]amd_native_family['\"]: ['\"]([^'\"]+)['\"]", text))
            if '@gluon.jit' in text or 'from triton.experimental import gluon' in text or re.search(r"['\"]amd_approximate_math['\"]: True", text):
                policy_failures.append(str(path))
        result['native_codegen_policy'] = {'family_file_occurrences': dict(families), 'violations': policy_failures}
        if policy_failures or args.variant == 'stock' and families:
            raise RuntimeError('Unexpected native/Gluon/approximation codegen policy')
        if validation_warnings:
            result['error'] = '\n'.join(validation_warnings)
        if args.backend == 'flydsl' and not counters['flydsl_simd']['flydsl_kernels']:
            result['coverage_note'] = 'No FlyDSL kernels generated; this is a fallback-only run'
    except Exception as exc:
        try:
            from torch._inductor.codegen.flydsl.flydsl_diagnostics import record_kernel_decision
            record_kernel_decision({'category': 'compile_or_execution_failure', 'error': str(exc),
                                    'phase': result.get('phase'), 'traceback': traceback.format_exc()})
        except Exception:
            pass
        result.update(status='error', error=f'{type(exc).__name__}: {exc}', traceback=traceback.format_exc())
        traceback.print_exc()
    finally:
        save()
        if args.fsdp and result['status'] == 'error':
            raise SystemExit(1)
        if args.fsdp and 'dist' in locals() and dist.is_initialized():
            dist.destroy_process_group()
    print(json.dumps({k: result.get(k) for k in ['model', 'backend', 'autotune', 'status', 'milliseconds', 'error']}), flush=True)


if __name__ == '__main__':
    main()
