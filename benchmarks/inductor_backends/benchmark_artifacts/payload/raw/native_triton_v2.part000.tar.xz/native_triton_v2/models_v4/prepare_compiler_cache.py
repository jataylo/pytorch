"""Copy only complete same-variant V3 compiler cache groups for V4 retuning."""

import base64
import hashlib
import json
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parent
OLD = ROOT.with_name("models")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    provenance = ROOT / "reuse_provenance"
    provenance.mkdir()
    summaries = []
    for model in ("DistillGPT2", "mobilenetv3_large_100"):
        for variant in ("stock", "new_native"):
            source = OLD / "binary_cache" / model / variant / "triton"
            target = ROOT / "binary_cache" / model / variant / "triton"
            target.mkdir(parents=True)
            original_report = OLD / "runs" / model / f"{variant}.json"
            report = json.loads(original_report.read_text())
            if report["status"] != "ok" or report["physical_gpu"] != "0":
                raise RuntimeError("Compiler cache provenance is not a validated same-GPU run")
            ledger = provenance / f"{model}--{variant}.jsonl"
            groups = files = byte_count = 0
            with ledger.open("w") as output:
                for folder in sorted(source.iterdir()):
                    if not folder.is_dir():
                        continue
                    group_files = list(folder.glob("__grp__*.json"))
                    if len(group_files) != 1:
                        continue
                    group_file = group_files[0]
                    group = json.loads(group_file.read_text())
                    if set(group) != {"child_paths"}:
                        raise RuntimeError("Unexpected compiler cache group schema")
                    metadata_file = folder / group_file.name.removeprefix("__grp__")
                    metadata = json.loads(metadata_file.read_text())
                    key = base64.b32encode(bytes.fromhex(metadata["hash"])).decode().rstrip("=")
                    if key != folder.name:
                        raise RuntimeError("Compiler metadata hash does not match its cache key directory")
                    if metadata["target"] != {"backend": "hip", "arch": "gfx950", "warp_size": 64}:
                        raise RuntimeError("Compiler cache target differs from validated GPU0 hardware")
                    if metadata["triton_version"] != "3.9.0" or "best_config" in metadata:
                        raise RuntimeError("Unexpected compiler version or selection-cache artifact")
                    destination = target / folder.name
                    destination.mkdir()
                    for name, filename in group["child_paths"].items():
                        path = Path(filename)
                        if path.parent != folder or path.name != name:
                            raise RuntimeError("Compiler group references a different cache/model/variant")
                        if path.suffix not in (".source", ".ttir", ".ttgir", ".llir", ".amdgcn", ".hsaco", ".json"):
                            raise RuntimeError("Unexpected compiler artifact type")
                        copied = destination / name
                        original_hash = sha(path)
                        shutil.copy2(path, copied)
                        if sha(copied) != original_hash:
                            raise RuntimeError("Compiler artifact copy hash mismatch")
                        output.write(json.dumps({"old": str(path), "copy": str(copied), "sha256": original_hash}) + "\n")
                        files += 1
                        byte_count += path.stat().st_size
                    copied_group = destination / group_file.name
                    copied_group.write_text(json.dumps({"child_paths": {name: str(destination / name) for name in group["child_paths"]}}))
                    output.write(json.dumps({"old": str(group_file), "copy": str(copied_group), "old_sha256": sha(group_file), "copy_sha256": sha(copied_group), "transform": "rebase child paths to the separate V4 cache copy"}) + "\n")
                    files += 1
                    groups += 1
            summary = {
                "model": model, "variant": variant, "original_cache": str(source), "copied_cache": str(target),
                "original_result": str(original_report), "original_result_sha256": sha(original_report),
                "original_gpu_uuid": report["gpu_uuid"], "original_source_fingerprint": report["source_fingerprint"],
                "complete_compiler_groups": groups, "copied_files": files, "copied_artifact_bytes": byte_count,
                "ledger": str(ledger), "ledger_sha256": sha(ledger), "regular_copies_not_hardlinks": True,
                "compiler_key_validation": "directory == base32(metadata.hash); live Triton additionally keys compiler/source/backend/options/environment",
                "target": {"backend": "hip", "arch": "gfx950", "warp_size": 64}, "triton_version": "3.9.0",
                "group_paths_rebased": True, "inductor_or_selection_cache_reused": False,
                "launcher_shared_objects_reused": False, "cold_compilation_comparable": False,
            }
            (provenance / f"{model}--{variant}.json").write_text(json.dumps(summary, indent=2) + "\n")
            summaries.append(summary)
            print(model, variant, "copied groups", groups, "bytes", byte_count, flush=True)
    (ROOT / "compiler_reuse_summary.json").write_text(json.dumps({"runs": summaries, "old_caches_modified": False}, indent=2) + "\n")


if __name__ == "__main__":
    main()
