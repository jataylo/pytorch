import ast,sys
from pathlib import Path
from torch._inductor.codegen.amd_kernel_optimizations import _row_tail_safe
s=Path(__file__).with_name('dynamic_generated.py').read_text()
for n in ast.walk(ast.parse(s)):
 if isinstance(n,ast.Call) and ast.unparse(n.func)=='async_compile.triton':
  t=ast.parse(ast.literal_eval(n.args[1]));fn=next(n for n in t.body if isinstance(n,ast.FunctionDef));a={n.targets[0].id:n.value for n in fn.body if isinstance(n,ast.Assign)}
  def trace(f,event,arg):
   if f.f_code.co_name=='_row_tail_safe' and event=='return':
    print('RETURN',f.f_lineno,arg)
    print({k:ast.unparse(v) if isinstance(v,ast.AST) else str(v) for k,v in f.f_locals.items() if k in ['expression','call','position','mask','node','name','axis']})
   return trace
  sys.settrace(trace);print('proof',_row_tail_safe(fn,a));sys.settrace(None)
