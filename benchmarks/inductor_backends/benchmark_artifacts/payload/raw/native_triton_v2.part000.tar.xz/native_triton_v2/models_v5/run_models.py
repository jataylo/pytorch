"""Run two cached full training models under verified frozen native overlays."""

import csv
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import signal
import subprocess
import time


HERE = Path(__file__).resolve().parent
TASK = HERE.parent.parent
FROZEN = HERE.parent / "results_final_v5"
VARIANTS = {"stock": "candidate", "new_native": "candidate"}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify(fingerprint):
    for path, expected in fingerprint["sources"].items():
        if digest(path) != expected:
            raise RuntimeError("Frozen training source changed: " + path)


def main():
    original_manifest = TASK / "inductor_hillclimb_v16/model_manifest.json"
    selected = {"DistillGPT2", "mobilenetv3_large_100"}
    models = [model for model in json.loads(original_manifest.read_text())["models"] if model["model"] in selected]
    models.sort(key=lambda model: model["model"] != "mobilenetv3_large_100")
    if len(models) != 2:
        raise RuntimeError("Expected exactly two original model batches")
    harness = HERE / "harness"
    harness.mkdir(exist_ok=True)
    for name in ("run_env.sh", "run_source_overlay.py"):
        shutil.copy2(FROZEN / "harness" / name, harness / name)
    extra_sources = [
        Path(__file__), HERE / "model_worker.py", HERE / "original_model_worker.py", HERE / "v3_model_worker.py", HERE / "v4_model_worker.py",
        HERE / "compiler_reuse_summary.json", *sorted((HERE / "reuse_provenance").glob("*.json")),
        *sorted((HERE / "reuse_provenance").glob("*.jsonl")),
        original_manifest, TASK / "collect_codegen_v2.py",
        Path("/dockerx/Triton_Conv_Development/scripts/common.py"),
        *harness.iterdir(), *sorted((TASK / "hf_config_cache").rglob("config.json")),
    ]
    fingerprints = {}
    for variant, source in VARIANTS.items():
        original = json.loads((FROZEN / f"{source}_source_fingerprint.json").read_text())
        verify(original)
        fingerprints[variant] = {
            **original,
            "sources": {**original["sources"], **{str(path): digest(path) for path in extra_sources}},
            "training_worker_original": str(TASK / "inductor_hillclimb_v16/model_worker.py"),
            "training_worker_adaptation": str(HERE / "model_worker.py"),
            "variant": variant,
        }
        (HERE / f"{variant}_source_fingerprint.json").write_text(json.dumps(fingerprints[variant], indent=2) + "\n")
    manifest = {
        "models": models, "variants": VARIANTS, "physical_gpu": "0",
        "dtype": "amp_bf16", "checkpoint": False,
        "optimizer": "SGD(lr=0.0001, momentum=0, foreach=True)",
        "warmup": 5, "steady_warmup": 10, "iterations": 20, "repeats": 7,
        "timing": "synchronized wall time of full forward/backward/SGD steps",
        "host_overhead_included": True, "compile_time_included": False,
        "eager_reference": "loss and first/middle/last parameter gradient samples",
        "original_protocol": "inductor_hillclimb_v16/run_models.py",
        "offline": True, "pretrained": False,
        "concurrent_other_gpu_work": "GPU3 V5 kernel benchmark starts only after MobileNet-new preflight; GPU5 focused validation",
        "source_revision": "V5", "compiler_artifacts_preseeded": True,
        "compile_times_cold_setup_comparable": False, "inductor_selection_cache_reused": False,
    }
    (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    rows = []
    for index, model in enumerate(models):
        name = model["model"]
        folder = HERE / "runs" / name
        folder.mkdir(parents=True, exist_ok=True)
        variants = list(VARIANTS)
        random.Random(2027 + index).shuffle(variants)
        if index == 0:
            if name != "mobilenetv3_large_100":
                raise RuntimeError("The V5 preflight model must be MobileNet")
            variants = ["new_native", "stock"]
        reference_state = None
        reference_gpu = None
        for variant in variants:
            fingerprint = fingerprints[variant]
            verify(fingerprint)
            output = folder / f"{variant}.json"
            if output.exists():
                raise RuntimeError("Refusing to overwrite a training result: " + str(output))
            protocol = {**manifest, **model, "variant": variant, "variant_order": variants}
            env = os.environ.copy()
            env.update(
                CUDA_VISIBLE_DEVICES="0", AMD_CODEGEN_SOURCE_ROOT=str(FROZEN / "sources" / VARIANTS[variant]),
                MODEL_SOURCE_FINGERPRINT=str(HERE / f"{variant}_source_fingerprint.json"),
                MODEL_BINARY_CACHE=str(HERE / "binary_cache" / name / variant),
                MODEL_COMPILER_REUSE_MANIFEST=str(HERE / "reuse_provenance" / f"{name}--{variant}.json"),
                TORCHINDUCTOR_CACHE_DIR=str(HERE / "inductor_cache" / name / variant),
                TORCHINDUCTOR_COMPILE_THREADS="1", TRITON_DEFAULT_FP_FUSION="1",
                OMP_NUM_THREADS="8", MKL_NUM_THREADS="8",
                BENCHMARK_STEADY_WARMUP_STEPS="10", BENCHMARK_PROTOCOL_JSON=json.dumps(protocol),
                BENCHMARK_LAUNCH_OVERRIDES="{}", HF_HOME=str(TASK / "hf_config_cache"),
                HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1",
                TOKENIZERS_PARALLELISM="false",
            )
            command = [
                "bash", str(harness / "run_env.sh"), str(harness / "run_source_overlay.py"),
                str(HERE / "model_worker.py"), "--variant", variant,
                "--suite", model["suite"], "--model", name, "--batch-size", str(model["batch_size"]),
                "--backend", "triton", "--autotune", "1", "--output", str(output),
                "--warmup", "5", "--iterations", "20", "--repeats", "7",
            ]
            print("START", name, variant, "GPU0", flush=True)
            begin = time.monotonic()
            timed_out = False
            with output.with_suffix(".log").open("w") as log:
                process = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    process.wait(timeout=2400)
                except subprocess.TimeoutExpired:
                    timed_out = True
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=30)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
            result = json.loads(output.read_text()) if output.exists() else {**model, "variant": variant}
            result["worker_returncode"] = process.returncode
            result["launcher_wall_seconds"] = time.monotonic() - begin
            if timed_out:
                result.update(status="timeout", timeout_seconds=2400)
            elif process.returncode:
                result.update(status="process_failed")
            verify(fingerprint)
            if result.get("status") in ("ok", "numerical_warning"):
                state = (result["initial_parameters"], result["initial_inputs"], result.get("model_config_sha256"), result["inputs"])
                if reference_state is not None and reference_state != state:
                    raise RuntimeError("Initial model/input state differs between variants: " + name)
                if reference_gpu is not None and reference_gpu != result["gpu_uuid"]:
                    raise RuntimeError("Physical GPU changed within model comparison")
                reference_state, reference_gpu = state, result["gpu_uuid"]
            output.write_text(json.dumps(result, indent=2) + "\n")
            row = {"model": name, "batch_size": model["batch_size"], "variant": variant,
                   "status": result.get("status"), "milliseconds": result.get("milliseconds"),
                   "warnings": len(result.get("validation_warnings", [])), "gpu_uuid": result.get("gpu_uuid"),
                   "eager_reference_status": result.get("eager_reference_status"),
                   "timing_recompiles": result.get("timing_recompiles"), "result": str(output)}
            rows.append(row)
            with (HERE / "summary.csv").open("w") as file:
                writer = csv.DictWriter(file, fieldnames=list(row))
                writer.writeheader()
                writer.writerows(rows)
            print("DONE", name, variant, row["status"], row["milliseconds"], "ms", round(result["launcher_wall_seconds"], 1), "seconds", flush=True)
            if index == 0 and variant == 'new_native':
                gate = {'model': name, 'variant': variant, 'status': result.get('status'),
                        'source_fingerprint': result.get('source_fingerprint'), 'gpu_uuid': result.get('gpu_uuid'),
                        'milliseconds': result.get('milliseconds'), 'raw_result': str(output),
                        'loaded_overlay_modules_after': result.get('loaded_overlay_modules_after'),
                        'validation_warnings': result.get('validation_warnings')}
                target = HERE / ('PREFLIGHT_PASS.json' if result.get('status') == 'ok' else 'PREFLIGHT_FAILED.json')
                target.write_text(json.dumps(gate, indent=2) + '\n')
                if result.get('status') != 'ok':
                    raise RuntimeError('MobileNet-new V5 preflight failed; later model runs not launched')

    for fingerprint in fingerprints.values():
        verify(fingerprint)
    (HERE / "COMPLETE.json").write_text(json.dumps({"runs": len(rows), "rows": rows, "sources_verified": True}, indent=2) + "\n")


if __name__ == "__main__":
    main()
