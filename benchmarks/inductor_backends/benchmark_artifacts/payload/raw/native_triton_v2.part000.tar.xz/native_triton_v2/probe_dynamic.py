import torch,ast
from pathlib import Path
from torch._inductor import config
from torch._inductor.utils import run_and_get_code
from torch._inductor.codegen.amd_kernel_optimizations import optimize_row_source,_row_tail_safe
x=torch.randn(37,128,device='cuda');torch._dynamo.mark_dynamic(x,0)
with config.patch({'triton.amd_kernel_optimizations':True,'triton.amd_extended_kernel_optimizations':True,'triton.amd_further_kernel_optimizations':True,'triton.amd_use_gluon':False,'fx_graph_cache':False}):
 y,sources=run_and_get_code(torch.compile(lambda x:torch.softmax(x,-1),fullgraph=True),x)
for src in sources:
 Path(__file__).with_name('dynamic_generated.py').write_text(src)
 for node in ast.walk(ast.parse(src)):
  if isinstance(node,ast.Call) and ast.unparse(node.func)=='async_compile.triton':
   source=ast.literal_eval(node.args[1]);t=ast.parse(source);fn=next(n for n in t.body if isinstance(n,ast.FunctionDef));assign={n.targets[0].id:n.value for n in fn.body if isinstance(n,ast.Assign)}
   print('args', [a.arg for a in fn.args.args], 'xnumel',ast.unparse(assign.get('xnumel',ast.Constant(None))),'proof',_row_tail_safe(fn,assign))
   print(ast.unparse(fn)[:2200]);out=optimize_row_source(source,extended=True,further=True,use_gluon=False);print('recognized',out!=source)
