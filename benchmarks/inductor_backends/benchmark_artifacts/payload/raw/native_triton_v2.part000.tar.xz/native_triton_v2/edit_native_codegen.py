from pathlib import Path
p=Path('/dockerx/pytorch-flex/agent_space/simd_bench/pytorch_triton_only/torch/_inductor/codegen/amd_kernel_optimizations.py')
s=p.read_text()
s=s.replace('def optimize_pointwise_source(source: str, *, extended: bool = False) -> str:', 'def optimize_pointwise_source(\n    source: str, *, extended: bool = False, use_gluon: bool = True\n) -> str:')
s=s.replace('    if len(stores) != 1 or not isinstance(assignments.get("xnumel"), ast.Constant):\n        return source\n    n = assignments["xnumel"].value\n    if not isinstance(n, int) or n <= 0 or n >= 2**31:\n        return source', '''    if len(stores) != 1:
        return source
    numel_node = assignments.get("xnumel")
    dynamic = numel_node is None and not use_gluon and any(arg.arg == "xnumel" for arg in fn.args.args)
    n = numel_node.value if isinstance(numel_node, ast.Constant) else None
    if not dynamic and (not isinstance(n, int) or n <= 0 or n >= 2**31):
        return source
    extent = "xnumel" if dynamic else str(n)''',1)
s=s.replace('ast.parse(f"(load0 * {1.0 / n!r}) * (load1 * 2.0)", mode="eval").body','ast.parse(f"(load0 * {1.0 / n!r}) * (load1 * 2.0)", mode="eval").body\n            if n is not None else ast.Constant(None)',1)
s=s.replace('        len(loads) == 1\n        and pointers == ["in_ptr0", "out_ptr0"]','        n is not None\n        and len(loads) == 1\n        and pointers == ["in_ptr0", "out_ptr0"]',1)
s=s.replace('        family is None\n        and len(loads) == 1','        family is None\n        and n is not None\n        and len(loads) == 1',1)
# Only recognized template extents are changed, leaving address-expression proof intact.
a=s.index('def optimize_pointwise_source');b=s.index('\ndef simplify_masked_modulo',a)
part=s[a:b].replace('i < {n}', 'i < {extent}')
needle='    for name in extra_args:\n'
pos=part.index(needle)
part=part[:pos]+'''    if not use_gluon:
        extra_args = ["AMD_UNROLL"] + (["AMD_READ_ORDER"] if family == "transpose" else [])
        for name in extra_args:
            values["signature"].keys.append(ast.Constant(name))
            values["signature"].values.append(ast.Constant("constexpr"))
            fn.args.args.append(ast.arg(arg=name, annotation=ast.parse("tl.constexpr", mode="eval").body))
        _native_metadata(keywords["inductor_meta"], family, amd_cache_policy="balanced" if extended else "producer")
        fn.body = ast.parse("lane = tl.arange(0, XBLOCK // AMD_UNROLL)\\n" + body.replace("gl.", "tl.")).body
        ast.fix_missing_locations(tree)
        return ast.unparse(tree) + "\\n"
''' +part[pos:]
s=s[:a]+part+s[b:]
# Native rows preserve native operators and use a mask proof to admit partial rows.
s=s.replace('''    xnumel = assignments.get("xnumel")
    if (
        not isinstance(xnumel, ast.Constant)
        or not isinstance(xnumel.value, int)
        or xnumel.value <= 0
    ):
        return source
    softmax''','''    xnumel = assignments.get("xnumel")
    dynamic_rows = xnumel is None and not use_gluon and any(arg.arg == "xnumel" for arg in fn.args.args)
    if not dynamic_rows and (
        not isinstance(xnumel, ast.Constant)
        or not isinstance(xnumel.value, int)
        or xnumel.value <= 0
    ):
        return source
    row_tail_safe = _row_tail_safe(fn, assignments) if not use_gluon else False
    if dynamic_rows and not row_tail_safe:
        return source
    softmax''',1)
needle='    class Convert(ast.NodeTransformer):\n'
a=s.index('def optimize_row_source(');pos=s.index(needle,a)
s=s[:pos]+'''    if not use_gluon:
        if approximate and softmax:
            class Approximate(ast.NodeTransformer):
                def visit_Call(self, node):
                    self.generic_visit(node)
                    if _call(node, "libdevice.exp"):
                        node.func = ast.parse("tl.exp", mode="eval").body
                    return node

                def visit_BinOp(self, node):
                    self.generic_visit(node)
                    if isinstance(node.op, ast.Div):
                        node.op = ast.Mult()
                        node.right = ast.Call(func=ast.Name(id="_amd_reciprocal", ctx=ast.Load()), args=[node.right], keywords=[])
                    return node
            fn.body = [Approximate().visit(statement) for statement in fn.body]
            tree.body.insert(tree.body.index(fn), ast.parse("@triton.jit\\ndef _amd_reciprocal(value):\\n    return tl.inline_asm_elementwise(\\\"v_rcp_f32 $0, $1\\\", constraints=\\\"=v,v\\\", args=[value], dtype=tl.float32, is_pure=True, pack=1)").body[0])
        _native_metadata(
            keywords["inductor_meta"], "row_reduction",
            amd_reduction_extent=hints["r0_"],
            amd_row_count=None if dynamic_rows else xnumel.value,
            amd_row_tail_safe=row_tail_safe,
            amd_approximate_math=approximate and softmax,
            amd_cache_policy="balanced" if extended else "producer",
        )
        if scan:
            _native_metadata(keywords["inductor_meta"], "row_reduction", amd_graph_tuning=True, amd_confirm_tuning=True)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree) + "\\n"

''' +s[pos:]
# Native flat fusion retains native AST, adjusting only subtile indices and masks.
a=s.index('def optimize_flat_pointwise_source(')
start=s.index('    n = assignments.get("xnumel")',a)
end=s.index('    expected = {',start)
s=s[:start]+'''    n = assignments.get("xnumel")
    dynamic = n is None and not use_gluon and any(arg.arg == "xnumel" for arg in fn.args.args)
    if (
        not dynamic and (not isinstance(n, ast.Constant) or not isinstance(n.value, int) or not 0 < n.value < 2**31)
    ) or not stores or not loads:
        return source
    extent = "xnumel" if dynamic else str(n.value)
''' +s[end:]
pos=s.index('    class Convert(ast.NodeTransformer):',a)
s=s[:pos]+'''    if not use_gluon:
        body = []
        for statement in fn.body:
            name = statement.targets[0].id if isinstance(statement, ast.Assign) else None
            if name in ("xnumel", "xoffset"):
                continue
            if name == "xindex":
                statement = ast.parse("xindex = tl.program_id(0) * XBLOCK + _amd_u * (XBLOCK // AMD_UNROLL) + tl.arange(0, XBLOCK // AMD_UNROLL)").body[0]
            elif name == "xmask":
                statement = ast.parse(f"xmask = xindex < {extent}").body[0]
            for node in ast.walk(statement):
                if isinstance(node, ast.List):
                    node.elts = [ast.parse("XBLOCK // AMD_UNROLL", mode="eval").body if isinstance(item, ast.Name) and item.id == "XBLOCK" else item for item in node.elts]
            body.append(statement)
        loop = ast.parse("for _amd_u in tl.static_range(AMD_UNROLL):\\n    pass").body[0]
        loop.body = body
        fn.body = ([] if dynamic else ast.parse(f"xnumel = {n.value}").body) + [loop]
        signature_node.keys.append(ast.Constant("AMD_UNROLL"))
        signature_node.values.append(ast.Constant("constexpr"))
        fn.args.args.append(ast.arg(arg="AMD_UNROLL", annotation=ast.parse("tl.constexpr", mode="eval").body))
        _native_metadata(keywords["inductor_meta"], "flat_pointwise", amd_cache_policy="balanced")
        ast.fix_missing_locations(tree)
        return ast.unparse(tree) + "\\n"

''' +s[pos:]
# Helpers shared by native codegen paths, not a generated-source conversion layer.
pos=s.index('\ndef optimize_pointwise_source(')
s=s[:pos]+'''
def _native_metadata(meta: ast.Dict, family: str, **values) -> None:
    values = {"amd_native_family": family, "use_gluon": False, **values}
    for key, value in values.items():
        index = next((i for i, name in enumerate(meta.keys) if ast.literal_eval(name) == key), None)
        if index is None:
            meta.keys.append(ast.Constant(key))
            meta.values.append(ast.Constant(value))
        else:
            meta.values[index] = ast.Constant(value)


def _row_tail_safe(fn: ast.FunctionDef, assignments: dict[str, ast.AST]) -> bool:
    def protected(node, seen=()):
        if isinstance(node, ast.Compare) and len(node.ops) == 1 and isinstance(node.ops[0], ast.Lt):
            return ast.unparse(node.left) == "xindex" and ast.unparse(node.comparators[0]) == "xnumel"
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitAnd):
            return protected(node.left, seen) or protected(node.right, seen)
        if isinstance(node, ast.Name) and node.id in assignments and node.id not in seen:
            return protected(assignments[node.id], (*seen, node.id))
        return False

    # A row tile must advance monotonically from a nonnegative program index.
    xindex = assignments.get("xindex")
    if xindex is None:
        return False
    expression = ast.unparse(xindex)
    offset = assignments.get("xoffset")
    if offset is not None:
        expression = expression.replace("xoffset", ast.unparse(offset))
    if expression != "tl.program_id(0) * XBLOCK + tl.arange(0, XBLOCK)[:, None]":
        return False
    memory = [node for node in ast.walk(fn) if _call(node, "tl.load") or _call(node, "tl.store")]
    if not memory:
        return False
    for call in memory:
        position = 1 if _call(call, "tl.load") else 2
        mask = call.args[position] if len(call.args) > position else next((kw.value for kw in call.keywords if kw.arg == "mask"), None)
        if mask is None or not protected(mask):
            return False
    # A reduction across rows could allow masked rows to influence valid outputs.
    for node in ast.walk(fn):
        if isinstance(node, ast.Call) and ast.unparse(node.func) in ("tl.sum", "tl.max", "tl.min", "tl.reduce", "tl.associative_scan", "triton_helpers.fmax2", "triton_helpers.max2", "triton_helpers.any"):
            axis = node.args[1] if len(node.args) > 1 else next((kw.value for kw in node.keywords if kw.arg == "axis"), None)
            if not isinstance(axis, ast.Constant) or axis.value != 1:
                return False
    return True

''' +s[pos:]
p.write_text(s)
# Wire direct native emission. No final Gluon-source projection in native path.
p=p.parent/'triton.py';s=p.read_text().replace('                use_triton_language,\n','')
s=s.replace('source, extended=config.triton.amd_extended_kernel_optimizations\n            )','source, extended=config.triton.amd_extended_kernel_optimizations,\n                use_gluon=config.triton.amd_use_gluon,\n            )',1)
s=s.replace('            if not config.triton.amd_use_gluon:\n                source = use_triton_language(source)\n','')
p.write_text(s)
