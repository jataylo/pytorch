"""Build independent anchor and heldout case manifests; no GPU imports."""

import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ANCHORS = (
    ('cast_add', (4608000,)), ('broadcast', (4608000,)),
    ('transpose', (16, 32, 128, 80)), ('softmax', (4096, 1024)),
    ('softmax_backward', (1024, 8192)), ('norm_backward', (4096, 1024)),
    ('cross_entropy_backward', (256, 1024)), ('cumsum', (64, 32768)),
)
REDUCTIONS = (
    (37, 127), (127, 128), (8192, 256), (37, 512), (127, 1024),
    (37, 2048), (127, 4096), (37, 8192), (127, 16384), (8, 32768), (257, 32768),
)


def main():
    cases = []
    for family, shape in ANCHORS:
        for dtype in ('bfloat16', 'float32'):
            cases.append(dict(case=f'anchor_{family}_{dtype}', family=family, shape=shape, dtype=dtype, split='anchor'))
    for family in ('softmax', 'softmax_backward', 'norm_backward', 'cross_entropy_backward', 'cumsum'):
        for rows, width in REDUCTIONS:
            for dtype in ('bfloat16', 'float32'):
                cases.append(dict(
                    case=f'heldout_{family}_{rows}x{width}_{dtype}', family=family,
                    shape=(rows, width), dtype=dtype, split='heldout',
                ))
    for family in ('cast_add', 'silu_gate'):
        for size in (4099, 65537):
            for dtype in ('bfloat16', 'float32'):
                cases.append(dict(
                    case=f'heldout_{family}_{size}_{dtype}', family=family,
                    shape=(size,), dtype=dtype, split='heldout',
                ))
    for shape in ((37, 127), (127, 128), (2, 5, 37, 127), (2, 3, 127, 128)):
        for dtype in ('bfloat16', 'float32'):
            case = dict(
                case='heldout_transpose_' + 'x'.join(map(str, shape)) + '_' + dtype,
                family='transpose', shape=shape, dtype=dtype, split='heldout',
            )
            if len(shape) == 2:
                case['transpose_mode'] = 'matrix'
            cases.append(case)
    (HERE / 'cases.json').write_text(json.dumps(cases, indent=2) + '\n')
    smoke = [case for case in cases if case['case'].startswith('anchor_')]
    smoke.extend(case for case in cases if case['case'] in (
        'heldout_softmax_37x127_float32', 'heldout_cumsum_8x32768_float32',
        'heldout_transpose_37x127_float32', 'heldout_silu_gate_4099_float32',
    ))
    (HERE / 'cases_smoke.json').write_text(json.dumps(smoke, indent=2) + '\n')
    print(len(cases), 'full cases;', len(smoke), 'smoke cases')


if __name__ == '__main__':
    main()
