from pathlib import Path
root=Path('/dockerx/pytorch-flex/agent_space/simd_bench/pytorch_triton_only')
p=root/'torch/_inductor/codegen/amd_kernel_optimizations.py';s=p.read_text();pos=s.index('\ndef optimize_pointwise_source(')
s=s[:pos]+'''
def amd_persistent_reduction_eligible(
    device: DeviceProperties, rows: int, width: int, *, input_count: int,
    reduction_count: int, dtype_bytes: int = 4, compare: bool = False,
) -> bool:
    """Bound persistent live values and desired residency using device resources."""
    if not supports_amd_kernel_optimizations(device) or rows < 1 or width < 1:
        return False
    limits = AMDConfigLimits.from_device(device)
    padded = 1 << (width - 1).bit_length()
    if padded > limits.max_tile:
        return False
    registers = device.regs_per_multiprocessor or limits.max_tile * 4
    live_values = 2 + min(4, max(1, input_count)) + min(4, max(1, reduction_count))
    live_registers = padded * live_values * max(1, (dtype_bytes + 3) // 4)
    # Comparing both implementations permits the full per-CU budget; measurement decides residency.
    resident_blocks = 1 if compare else min(4, max(1, (rows + device.multi_processor_count - 1) // max(1, device.multi_processor_count)))
    return live_registers <= registers // resident_blocks

''' +s[pos:];p.write_text(s)
p=root/'torch/_inductor/config.py';s=p.read_text().replace('    amd_use_gluon = False\n','    amd_use_gluon = False\n    amd_persistent_reduction_autotune = True\n');p.write_text(s)
p=root/'torch/_inductor/codegen/triton.py';s=p.read_text().replace('from .amd_kernel_optimizations import supports_amd_kernel_optimizations','from .amd_kernel_optimizations import (\n    amd_persistent_reduction_eligible,\n    supports_amd_kernel_optimizations,\n)')
needle='''                if (
                    int(features.reduction_numel)
                    <= AMDConfigLimits.from_device(device).max_tile
                ):
                    return True'''
repl='''                if not config.triton.amd_use_gluon:
                    reads = features.buffer_read_counts()
                    dtype_bytes = max(
                        (torch.empty((), dtype=V.graph.get_dtype(name)).element_size() for name in reads),
                        default=4,
                    )
                    rows = max(1, V.graph.sizevars.optimization_hint(features.numel, fallback=1))
                    if amd_persistent_reduction_eligible(
                        device, rows, int(features.reduction_numel),
                        input_count=len(reads), reduction_count=len(features.reduction_nodes()),
                        dtype_bytes=dtype_bytes, compare=config.triton.amd_persistent_reduction_autotune,
                    ):
                        return True
                elif int(features.reduction_numel) <= AMDConfigLimits.from_device(device).max_tile:
                    return True'''
if needle not in s: raise RuntimeError('persistence override anchor missing')
s=s.replace(needle,repl,1)
needle='''        if not config.triton.multi_kernel:
            return kernels

        optional_persistent'''
repl='''        amd_compare = (
            config.triton.amd_kernel_optimizations
            and config.triton.amd_extended_kernel_optimizations
            and not config.triton.amd_use_gluon
            and config.triton.amd_persistent_reduction_autotune
            and kernel.persistent_reduction
            and not kernel.cooperative_reduction
            and not kernel.features.get_mutations()
            and isinstance(kernel.features.reduction_numel, (int, sympy.Integer))
            and 1024 < int(kernel.features.reduction_numel) <= 32768
            and not (config.deterministic or config.batch_invariant or torch.are_deterministic_algorithms_enabled())
            and supports_amd_kernel_optimizations(DeviceProperties.create(V.graph.get_current_device_or_throw()))
        )
        if not config.triton.multi_kernel and not amd_compare:
            return kernels

        optional_persistent'''
if needle not in s:raise RuntimeError('multikernel anchor missing')
s=s.replace(needle,repl,1)
p.write_text(s)
