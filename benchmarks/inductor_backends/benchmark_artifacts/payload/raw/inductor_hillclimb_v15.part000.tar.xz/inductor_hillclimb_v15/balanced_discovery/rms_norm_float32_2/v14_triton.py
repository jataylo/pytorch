# AOT ID: ['197_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/gy/cgyc5hgomlg2f5d6hyq6dt5xoxxzl262ib7nkwqcujppmd3ku4va.py
# Topologically Sorted Source Nodes: [square, mean, add, r, mul, mul_1], Original ATen: [aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add => add
#   mean => mean
#   mul => mul
#   mul_1 => mul_1
#   r => rsqrt
#   square => pow_1
# Graph fragment:
#   %arg0_1 : Tensor "f32[8192, 256][256, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[8192, 1][1, 8192]cuda:0" = PlaceHolder[target=buf0]
#   %rsqrt : Tensor "f32[8192, 1][1, 1]cuda:0" = PlaceHolder[target=rsqrt]
#   %arg1_1 : Tensor "f32[256][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %pow_1 : Tensor "f32[8192, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%arg0_1, 2), kwargs = {})
#   %mean : Tensor "f32[8192, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[8192, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[8192, 1][1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[8192, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg0_1, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[8192, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg1_1), kwargs = {})
#   return %buf0,%rsqrt,%mul_1
triton_per_fused_add_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_per_fused_add_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()
from triton.experimental import gluon
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language.extra import libdevice

@gluon.jit
def _amd_maximum(a, b):
    return gl.where((a > b) | (a != a), a, b)

@gluon.jit
def _amd_max2(value, axis: gl.constexpr):
    return gl.reduce(value, axis, _amd_maximum)

@gluon.jit
def _amd_any(value, axis: gl.constexpr):
    return gl.sum((value != 0).to(gl.int32), axis) != 0

@gluon.jit
def _amd_reciprocal(value):
    return gl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[value], dtype=gl.float32, is_pure=True, pack=1)

@triton_heuristics.persistent_reduction(size_hints={'x': 8192, 'r0_': 256}, reduction_hint=ReductionHint.INNER, filename=__file__, triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'AMD_LANES': 'constexpr', 'AMD_VEC': 'constexpr', 'AMD_WARPS': 'constexpr', 'AMD_SPLIT_WARPS': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]}, inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused_add_mean_mul_pow_rsqrt_0', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 65536, 'r0_': 25166848}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': False, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_reduction_tuning': True, 'amd_kernel_autotune': True, 'amd_kernel_tuning_version': 2, 'amd_autotune_diagnostics_path': 'agent_space/simd_bench/inductor_hillclimb_v15/balanced_discovery/rms_norm_float32_2/v14_triton.tuning.jsonl', 'amd_warm_arg_names': (), 'use_gluon': True, 'amd_gluon_family': 'row_reduction', 'amd_reduction_extent': 256, 'amd_row_count': 8192, 'amd_approximate_math': False})
@gluon.jit
def triton_per_fused_add_mean_mul_pow_rsqrt_0(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, xnumel, r0_numel, XBLOCK: tl.constexpr, AMD_LANES: gl.constexpr, AMD_VEC: gl.constexpr, AMD_WARPS: gl.constexpr, AMD_SPLIT_WARPS: gl.constexpr):
    _amd_layout: gl.constexpr = gl.BlockedLayout([1, AMD_VEC], [64 // AMD_LANES, AMD_LANES], [1, AMD_WARPS] if AMD_SPLIT_WARPS else [AMD_WARPS, 1], [1, 0])
    xnumel = 8192
    r0_numel = 256
    R0_BLOCK: gl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: gl.constexpr = R0_BLOCK
    xoffset = gl.program_id(0) * XBLOCK
    xindex = xoffset + gl.arange(0, XBLOCK, layout=gl.SliceLayout(1, _amd_layout))[:, None]
    xmask = gl.full([XBLOCK], True, gl.int1, layout=gl.SliceLayout(1, _amd_layout))[:, None]
    r0_index = gl.arange(0, R0_BLOCK, layout=gl.SliceLayout(0, _amd_layout))[None, :]
    r0_offset = 0
    r0_mask = gl.full([R0_BLOCK], True, gl.int1, layout=gl.SliceLayout(0, _amd_layout))[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = gl.load(in_ptr0 + (r0_1 + 256 * x0), None, eviction_policy='evict_first')
    tmp11 = gl.load(in_ptr1 + r0_1, None, eviction_policy='evict_last')
    tmp1 = tmp0 * tmp0
    tmp2 = gl.broadcast(tmp1, gl.full([XBLOCK, R0_BLOCK], 0, tmp1.dtype, layout=_amd_layout))[0]
    tmp4 = gl.sum(tmp2, 1)[:, None].to(gl.float32)
    tmp5 = gl.full([1, 1], 256.0, gl.float32, layout=_amd_layout)
    tmp6 = tmp4 / tmp5
    tmp7 = gl.full([1, 1], 1e-06, gl.float32, layout=_amd_layout)
    tmp8 = tmp6 + tmp7
    tmp9 = gl.rsqrt(tmp8)
    tmp10 = tmp0 * tmp9
    tmp12 = tmp10 * tmp11
    gl.store(in_out_ptr0 + x0, tmp9, None)
    gl.store(out_ptr0 + (r0_1 + 256 * x0), tmp12, None)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1), ((8192, 256), (256, )), ((256, 1), (1, )), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf0 = empty_strided_cuda((8192, 1), (1, 8192), torch.float32)
            buf1 = reinterpret_tensor(buf0, (8192, 1), (1, 1), 0); del buf0  # reuse
            buf2 = empty_strided_cuda((8192, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [square, mean, add, r, mul, mul_1], Original ATen: [aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_per_fused_add_mean_mul_pow_rsqrt_0.run(buf1, arg0_1, arg1_1, buf2, 8192, 256, stream=raw_stream0)
            del arg0_1
            del arg1_1
        return (buf2, buf1, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((8192, 256), (256, 1), device='cuda:0', dtype=torch.float32)
    arg1_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
