# AOT ID: ['211_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/oe/coe7h5vj566rogc4nfqbhbeogb5piynuegof5ihzpu6qrezx54z2.flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/mo/cmo6tveagtzizgbyq2cfoh4wgu5uz2e4daqlce7lszaco4ytmrq3.py
# Topologically Sorted Source Nodes: [float_1, log_softmax], Original ATen: [aten._to_copy, prims.prepare_softmax_online, aten._log_softmax]
# Source node to ATen node mapping:
#   float_1 => convert_element_type
#   log_softmax => log, sub_1, sub_tensor
# Graph fragment:
#   %arg0_1 : Tensor "bf16[37, 127][127, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %getitem : Tensor "f32[37, 1][1, 37]cuda:0" = PlaceHolder[target=getitem]
#   %getitem_1 : Tensor "f32[37, 1][1, 37]cuda:0" = PlaceHolder[target=getitem_1]
#   %convert_element_type : Tensor "f32[37, 127][127, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %prepare_softmax_online_default : [num_users=2] = call_function[target=torch.ops.prims.prepare_softmax_online.default](args = (%convert_element_type, -1), kwargs = {})
#   %sub_tensor : Tensor "f32[37, 127][127, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convert_element_type, %getitem), kwargs = {})
#   %log : Tensor "f32[37, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.log.default](args = (%getitem_1,), kwargs = {})
#   %sub_1 : Tensor "f32[37, 127][127, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%sub_tensor, %log), kwargs = {})
#   return %getitem,%getitem_1,%sub_1
flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e = fdp_rt.compiled(async_compile, 'flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e', r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class _Smem:
    words: fx.Array[fx.Int32, 256, 16]

def flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_kernel(in_ptr0: fx.Int64, out_ptr2: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=37 rnumel=127 ept=1 unroll=1 tpr=128 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 9398)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 18796)
    _smem = fx.SharedAllocator().allocate(_Smem).peek().words.view(fx.make_layout(256, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 128
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 128
        x0 = xindex
        _acc1_items = []
        for r0_offset in range_constexpr(0, 127, 128):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 127
                r0_1 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 127*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 127*x0, 'bf16', mask=r0_mask))
        for r0_offset in range_constexpr(0, 127, 128):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 127
                r0_1 = r0_index
                tmp4 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 127*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 127*x0, 'bf16', mask=r0_mask))
        for r0_offset in range_constexpr(0, 127, 128):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 127
                r0_1 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 127*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 127*x0, 'bf16', mask=r0_mask))
                tmp1 = fdp.to(tmp0, 'f32')
                _acc1_items.append((tmp1, r0_mask))
        tmp2, tmp3 = fdp.group_softmax_twopass(_acc1_items, 128, _smem, 128, 1)
        for r0_offset in range_constexpr(0, 127, 128):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 127
                r0_1 = r0_index
                tmp4 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 127*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 127*x0, 'bf16', mask=r0_mask))
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.sub(tmp5, tmp2)
                tmp7 = fdp.log(tmp3)
                tmp8 = fdp.sub(tmp6, tmp7)
                fdp.store(_r_out_ptr2, r0_1 + 127*x0, tmp8, 'f32', mask=r0_mask)
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_launch_fn(in_ptr0: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_kernel(in_ptr0, out_ptr2).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_launch = None


def flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_kernel, flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_launch
    if flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_launch is None:
        flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_kernel = flyc.kernel(flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_kernel)
        flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_launch = flyc.jit(flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_launch_fn)
        flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_launch


flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_compiled = None
flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e.hsaco"


def flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_main(in_ptr0, out_ptr2, stream=None):
    global flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_compiled
    if flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_compiled is None:
        flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_compiled = fdp.load_binary(
            flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_binary, "flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_kernel_0", 128, 'OO'
        )
        if flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_flydsl(), in_ptr0.data_ptr(), out_ptr2.data_ptr(), 37, 0 if stream is None else stream)
            flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_compiled(37, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr2, )


def flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_binary):
        return
    launch = flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_binary, "flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e_kernel_0")
''', '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/oe/coe7h5vj566rogc4nfqbhbeogb5piynuegof5ihzpu6qrezx54z2.flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e.hsaco', precompile_metadata={})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, = args
        args.clear()
        assert_size_stride(arg0_1, (37, 127), (127, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf2 = empty_strided_cuda((37, 127), (127, 1), torch.float32)
            # Topologically Sorted Source Nodes: [float_1, log_softmax], Original ATen: [aten._to_copy, prims.prepare_softmax_online, aten._log_softmax]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused__log_softmax__to_copy_prepare_softmax_online_c6768d8e.run(arg0_1, buf2, stream=raw_stream0)
            del arg0_1
        return (buf2, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((37, 127), (127, 1), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
