# AOT ID: ['151_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/ie/ciezwmafggsekzhsu5m6bmpshgklrtfzrkim5sqeakr4r2jpl5ur.flydsl_fused_native_layer_norm_75615665.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/qh/cqhiga4qwub7ercsjombhasu4hdwtwsk4wausu3ewkuy5exy7xw5.py
# Topologically Sorted Source Nodes: [native_layer_norm], Original ATen: [aten.native_layer_norm]
# Source node to ATen node mapping:
#   native_layer_norm => add, add_1, mul, mul_1, rsqrt, sub, var_mean
# Graph fragment:
#   %arg0_1 : Tensor "f32[37, 127][127, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %buf1 : Tensor "f32[37, 1][1, 37]cuda:0" = PlaceHolder[target=buf1]
#   %getitem_1 : Tensor "f32[37, 1][1, 1]cuda:0" = PlaceHolder[target=getitem_1]
#   %rsqrt : Tensor "f32[37, 1][1, 1]cuda:0" = PlaceHolder[target=rsqrt]
#   %arg1_1 : Tensor "f32[127][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[127][1]cuda:0" = PlaceHolder[target=arg2_1]
#   %var_mean : [num_users=2] = call_function[target=torch.ops.aten.var_mean.correction](args = (%arg0_1, [1]), kwargs = {correction: 0, keepdim: True})
#   %sub : Tensor "f32[37, 127][127, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%arg0_1, %getitem_1), kwargs = {})
#   %add : Tensor "f32[37, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%getitem, 1e-05), kwargs = {})
#   %rsqrt : Tensor "f32[37, 1][1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[37, 127][127, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[37, 127][127, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg1_1), kwargs = {})
#   %add_1 : Tensor "f32[37, 127][127, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_1, %arg2_1), kwargs = {})
#   return %getitem_1,%buf1,%rsqrt,%add_1
flydsl_fused_native_layer_norm_75615665 = fdp_rt.compiled(async_compile, 'flydsl_fused_native_layer_norm_75615665', r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class _Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused_native_layer_norm_75615665_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=37 rnumel=127 ept=1 unroll=1 tpr=128 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 148)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 18796)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 508)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 508)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 148)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 18796)
    _smem = fx.SharedAllocator().allocate(_Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 128
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 128
        x0 = xindex
        _acc1_items = []
        for r0_offset in range_constexpr(0, 127, 128):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 127
                r0_1 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 127*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 127*x0, 'f32', mask=r0_mask))
        for r0_offset in range_constexpr(0, 127, 128):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 127
                r0_1 = r0_index
                tmp9 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 127*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 127*x0, 'f32', mask=r0_mask))
                tmp12 = fdp.memo(_lc, (('in_ptr1', 'r0_1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_1, 'f32', mask=r0_mask))
                tmp14 = fdp.memo(_lc, (('in_ptr2', 'r0_1', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, r0_1, 'f32', mask=r0_mask))
        for r0_offset in range_constexpr(0, 127, 128):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 127
                r0_1 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 127*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 127*x0, 'f32', mask=r0_mask))
                _acc1_items.append((tmp0, r0_mask))
        tmp1, tmp2, tmp3 = fdp.group_welford_twopass(_acc1_items, 128, _smem, 128, 1, count=127)
        fdp.store(_r_out_ptr0, x0, tmp1, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        tmp4 = fdp.const(127.0, 'f32')
        tmp5 = fdp.truediv(tmp2, tmp4)
        tmp6 = fdp.const(1e-05, 'f32')
        tmp7 = fdp.add(tmp5, tmp6)
        tmp8 = fdp.rsqrt(tmp7)
        fdp.store(_r_in_out_ptr0, x0, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 127, 128):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 127
                r0_1 = r0_index
                tmp9 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 127*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 127*x0, 'f32', mask=r0_mask))
                tmp12 = fdp.memo(_lc, (('in_ptr1', 'r0_1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_1, 'f32', mask=r0_mask))
                tmp14 = fdp.memo(_lc, (('in_ptr2', 'r0_1', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, r0_1, 'f32', mask=r0_mask))
                tmp10 = fdp.sub(tmp9, tmp1)
                tmp11 = fdp.mul(tmp10, tmp8)
                tmp13 = fdp.mul(tmp11, tmp12)
                tmp15 = fdp.add(tmp13, tmp14)
                fdp.store(_r_out_ptr1, r0_1 + 127*x0, tmp15, 'f32', mask=r0_mask)
        fdp.forget(_lc, 'out_ptr1')


def flydsl_fused_native_layer_norm_75615665_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_native_layer_norm_75615665_kernel(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused_native_layer_norm_75615665_launch = None


def flydsl_fused_native_layer_norm_75615665_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_native_layer_norm_75615665_kernel, flydsl_fused_native_layer_norm_75615665_launch
    if flydsl_fused_native_layer_norm_75615665_launch is None:
        flydsl_fused_native_layer_norm_75615665_kernel = flyc.kernel(flydsl_fused_native_layer_norm_75615665_kernel)
        flydsl_fused_native_layer_norm_75615665_launch = flyc.jit(flydsl_fused_native_layer_norm_75615665_launch_fn)
        flydsl_fused_native_layer_norm_75615665_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_native_layer_norm_75615665_launch


flydsl_fused_native_layer_norm_75615665_compiled = None
flydsl_fused_native_layer_norm_75615665_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_native_layer_norm_75615665.hsaco"


def flydsl_fused_native_layer_norm_75615665_main(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=None):
    global flydsl_fused_native_layer_norm_75615665_compiled
    if flydsl_fused_native_layer_norm_75615665_compiled is None:
        flydsl_fused_native_layer_norm_75615665_compiled = fdp.load_binary(
            flydsl_fused_native_layer_norm_75615665_binary, "flydsl_fused_native_layer_norm_75615665_kernel_0", 128, 'OOOOOO'
        )
        if flydsl_fused_native_layer_norm_75615665_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_native_layer_norm_75615665_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), 37, 0 if stream is None else stream)
            flydsl_fused_native_layer_norm_75615665_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_native_layer_norm_75615665_compiled(37, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, )


def flydsl_fused_native_layer_norm_75615665_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_native_layer_norm_75615665_binary):
        return
    launch = flydsl_fused_native_layer_norm_75615665_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_native_layer_norm_75615665_binary, "flydsl_fused_native_layer_norm_75615665_kernel_0")
''', '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/ie/ciezwmafggsekzhsu5m6bmpshgklrtfzrkim5sqeakr4r2jpl5ur.flydsl_fused_native_layer_norm_75615665.hsaco', precompile_metadata={})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1, arg2_1), ((37, 127), (127, ), (127, )), ((127, 1), (1, ), (1, )), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg1_1 = copy_if_misaligned(arg1_1)
            arg2_1 = copy_if_misaligned(arg2_1)
            buf0 = empty_strided_cuda((37, 1), (1, 1), torch.float32)
            buf1 = empty_strided_cuda((37, 1), (1, 37), torch.float32)
            buf3 = reinterpret_tensor(buf1, (37, 1), (1, 1), 0); del buf1  # reuse
            buf4 = empty_strided_cuda((37, 127), (127, 1), torch.float32)
            # Topologically Sorted Source Nodes: [native_layer_norm], Original ATen: [aten.native_layer_norm]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused_native_layer_norm_75615665.run(buf3, arg0_1, arg1_1, arg2_1, buf0, buf4, stream=raw_stream0)
            del arg0_1
            del arg1_1
            del arg2_1
        return (buf4, buf0, buf3, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((37, 127), (127, 1), device='cuda:0', dtype=torch.float32)
    arg1_1 = rand_strided((127, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg2_1 = rand_strided((127, ), (1, ), device='cuda:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
