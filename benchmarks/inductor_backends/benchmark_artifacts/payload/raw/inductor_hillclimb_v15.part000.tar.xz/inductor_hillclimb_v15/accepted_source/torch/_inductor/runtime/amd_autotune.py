from __future__ import annotations

import json
import math
import statistics

import torch


def benchmark_configs(tuner, launchers, args, kwargs, *, rounds=5, repeats=3, cache_samples=None):
    """Time GPU execution after restoring aliases and modeled cache residency."""
    names = tuner.fn.arg_names[:len(args)]
    values = dict(zip(names,args)) | kwargs
    mutations = {value.untyped_storage()._cdata for name,value in values.items()
                 if name in tuner.mutated_arg_names and isinstance(value,torch.Tensor)}
    storages = {}
    for value in values.values():
        if isinstance(value,torch.Tensor) and value.untyped_storage()._cdata in mutations:
            key=value.untyped_storage()._cdata
            if key not in storages:
                original=torch.empty(0,device=value.device,dtype=torch.uint8).set_(value.untyped_storage())
                storages[key]=(original,original.clone())
    def scratch(value):
        if isinstance(value,torch.Tensor) and value.untyped_storage()._cdata in storages:
            copy=storages[value.untyped_storage()._cdata][1]
            return torch.empty(0,device=value.device,dtype=value.dtype).set_(copy.untyped_storage(),value.storage_offset(),value.size(),value.stride())
        return value
    scratch_args=[scratch(value) for value in args]
    scratch_kwargs={name:scratch(value) for name,value in kwargs.items()}
    scratch_values=dict(zip(names,scratch_args)) | scratch_kwargs
    warm_names=tuner.inductor_meta.get('amd_warm_arg_names',())
    warm=[torch.empty(0,device=value.device,dtype=torch.uint8).set_(value.untyped_storage())
          for name,value in scratch_values.items() if (name in warm_names or name in tuner.mutated_arg_names) and isinstance(value,torch.Tensor)]
    flush=torch.empty(256<<20,device=tuner.device_props.index,dtype=torch.uint8)
    stream=tuner.get_device_interface().get_raw_stream(tuner.device_props.index)
    balanced = tuner.inductor_meta.get('amd_cache_policy') == 'balanced'
    input_warm = []
    if balanced:
        seen_warm = set()
        for name, value in scratch_values.items():
            if not name.startswith(('in_ptr', 'in_out_ptr')) or not isinstance(value, torch.Tensor):
                continue
            key = value.untyped_storage()._cdata
            if key not in seen_warm:
                seen_warm.add(key)
                input_warm.append(torch.empty(0, device=value.device, dtype=torch.uint8).set_(value.untyped_storage()))
    def before(all_inputs_warm=False):
        flush.zero_()
        for original,copy in storages.values():
            copy.copy_(original)
        tuner.reset_to_zero_args(*scratch_args,**scratch_kwargs)
        for value in input_warm if all_inputs_warm else warm:
            value.add_(0)
    def call(launcher):
        launcher(*scratch_args,**scratch_kwargs,stream=stream)
    events=[[(torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)) for _ in range(repeats)] for _ in launchers]
    samples={launcher:[] for launcher in launchers}
    scratch_mutations={copy.untyped_storage()._cdata for original,copy in storages.values()}
    output_items=[(name,value) for name,value in scratch_values.items() if isinstance(value,torch.Tensor) and name.startswith(('out_ptr','in_out_ptr'))]
    outputs=[value for name,value in output_items]
    before();call(launchers[0]);torch.cuda.synchronize()
    reference=[value.clone() for value in outputs]
    valid=[]
    for launcher in launchers:
        before()
        for (name,actual),expected in zip(output_items,reference):
            if actual.untyped_storage()._cdata not in scratch_mutations:
                if actual.is_floating_point():
                    actual.copy_(torch.where(torch.isnan(expected),float('inf'),float('nan')))
                else:
                    actual.copy_(expected)
                    raw=torch.empty(0,device=actual.device,dtype=torch.uint8).set_(actual.untyped_storage())
                    raw.bitwise_not_()
        call(launcher);torch.cuda.synchronize()
        try:
            for actual,expected in zip(outputs,reference):
                low=actual.dtype in (torch.float16,torch.bfloat16)
                floating=actual.is_floating_point()
                torch.testing.assert_close(actual,expected,atol=.02 if low else 1e-4 if floating else 0,rtol=.02 if low else 1e-4 if floating else 0,equal_nan=True)
        except AssertionError:
            continue
        valid.append(launcher)
    del reference
    if not valid:
        raise RuntimeError('No numerically valid AMD kernel configuration')
    launchers=valid
    events=[[(torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)) for _ in range(repeats)] for _ in launchers]
    contexts = ('producer', 'inputs_warm') if balanced else ('producer',)
    context_samples = {launcher: {context: [] for context in contexts} for launcher in launchers}
    for iteration in range(rounds):
        torch.cuda._sleep(40_000_000)
        for context in contexts[iteration % len(contexts):] + contexts[:iteration % len(contexts)]:
            for offset in range(len(launchers)):
                index=(iteration+offset)%len(launchers)
                launcher=launchers[index]
                for start,end in events[index]:
                    before(context == 'inputs_warm');start.record();call(launcher);end.record()
            torch.cuda.synchronize()
            for launcher,pairs in zip(launchers,events):
                context_samples[launcher][context].append(statistics.mean(start.elapsed_time(end) for start,end in pairs))
    for launcher in launchers:
        samples[launcher] = [math.exp(statistics.mean(math.log(max(context_samples[launcher][context][index], 1e-9)) for context in contexts)) for index in range(rounds)]
    if cache_samples is not None:
        cache_samples.update(context_samples)

    return {launcher:statistics.median(values) if values else float('inf') for launcher,values in samples.items()},samples


def _key(cfg):
    return (*sorted(cfg.kwargs.items()),cfg.num_warps,cfg.num_stages)


def _neighbors(tuner,config,args,kwargs):
    from .triton_compat import Config
    values=dict(zip(tuner.fn.arg_names,args)) | kwargs
    xnumel=values.get('xnumel')
    gluon=tuner.inductor_meta.get('use_gluon',False)
    options={'XBLOCK':[max(1,config.kwargs['XBLOCK']//2),config.kwargs['XBLOCK']*2]}
    for field in ('R0_BLOCK','AMD_VEC','AMD_UNROLL','AMD_LANES'):
        if field in config.kwargs:
            options[field]=[max(1,config.kwargs[field]//2),config.kwargs[field]*2]
    options['waves_per_eu']=[0,1,2]
    if 'AMD_READ_ORDER' in config.kwargs:
        options['AMD_READ_ORDER']=[0,1]
    if 'AMD_SPLIT_WARPS' in config.kwargs:
        options['AMD_SPLIT_WARPS']=[0,1]
    for field,choices in options.items():
        for value in choices:
            kw=dict(config.kwargs);kw[field]=value
            if kw==config.kwargs or kw.get('AMD_VEC',1)>32 or kw.get('AMD_UNROLL',1)>8 or not 8<=kw.get('AMD_LANES',16)<=64:
                continue
            if 'R0_BLOCK' not in kw and isinstance(values.get('r0_numel'),int) and kw['XBLOCK']*values['r0_numel']>32768:
                continue
            if kw['XBLOCK']>16384 or kw.get('R0_BLOCK',1)>8192 or kw['XBLOCK']*kw.get('R0_BLOCK',1)>32768:
                continue
            if tuner.inductor_meta.get('amd_gluon_family')=='transpose' and kw.get('AMD_UNROLL',1)!=1:
                continue
            if kw['XBLOCK']%kw.get('AMD_UNROLL',1):
                continue
            if isinstance(xnumel,int) and (not gluon or tuner.inductor_meta.get('amd_gluon_family')=='row_reduction') and xnumel%kw['XBLOCK']:
                continue
            yield Config(kw,num_warps=config.num_warps,num_stages=config.num_stages)
    for warps in (config.num_warps//2,config.num_warps*2):
        if warps not in (1,2,4,8):
            continue
        kw=dict(config.kwargs)
        if 'AMD_WARPS' in kw:
            kw['AMD_WARPS']=warps
        yield Config(kw,num_warps=warps,num_stages=config.num_stages)


def tune(tuner,args,kwargs):
    values=dict(zip(tuner.fn.arg_names,args)) | kwargs
    tensors={value.untyped_storage()._cdata:value for value in values.values() if isinstance(value,torch.Tensor)}
    needed=sum(value.untyped_storage().nbytes() for value in tensors.values())
    free,_=torch.cuda.mem_get_info(tuner.device_props.index)
    if 3*needed+(256<<20)>free//2:
        return None
    cache_samples = {}
    timings,samples=benchmark_configs(tuner,tuner.launchers,args,kwargs,cache_samples=cache_samples)
    seen={_key(launcher.config) for launcher in tuner.launchers}
    for _ in range(3):
        best=min(timings,key=timings.get)
        neighbors=[]
        for config in _neighbors(tuner,best.config,args,kwargs):
            key=_key(config)
            if key in seen:
                continue
            seen.add(key)
            if len(neighbors)>=10:
                break
            try:
                with tuner.lock:
                    result=tuner._precompile_config(config)
                    launcher=result.make_launcher()
                tuner.compile_results.append(result)
                tuner.launchers.append(launcher)
                neighbors.append(launcher)
            except Exception as error:
                from triton.runtime.errors import OutOfResources
                if not isinstance(error,OutOfResources):
                    raise
        if not neighbors:
            break
        measured,raw=benchmark_configs(tuner,[best,*neighbors],args,kwargs,cache_samples=cache_samples)
        timings.update(measured);samples.update(raw)
        if min(measured,key=measured.get) is best:
            break
    for launcher,timing in timings.items():
        tuner.coordesc_tuner.cache_benchmark_result(launcher.config,timing)
    selected=min(timings,key=timings.get)
    report=dict(kernel_name=tuner.inductor_meta.get('kernel_name'), family=tuner.inductor_meta.get('amd_gluon_family',tuner.inductor_meta.get('amd_pointwise_family','native')),approximate_math=tuner.inductor_meta.get('amd_approximate_math',False),cache_policy=tuner.inductor_meta.get('amd_cache_policy','producer'),score_statistic='median_round_geomean_ms',inputs=[dict(name=name,shape=list(value.shape),stride=list(value.stride()),dtype=str(value.dtype)) for name,value in values.items() if isinstance(value,torch.Tensor)],warm_arg_names=tuner.inductor_meta.get('amd_warm_arg_names',()),
                selected_config=dict(selected.config.kwargs,num_warps=selected.config.num_warps,num_stages=selected.config.num_stages),
                candidates=[dict(config=dict(launcher.config.kwargs,num_warps=launcher.config.num_warps),median_ms=value if math.isfinite(value) else None,samples_ms=samples[launcher],cache_samples_ms=cache_samples.get(launcher,{})) for launcher,value in timings.items()])
    from torch._logging import trace_structured
    trace_structured('artifact',metadata_fn=lambda:dict(name='amd_kernel_autotune',encoding='json'),payload_fn=lambda:json.dumps(report))
    path=tuner.inductor_meta.get('amd_autotune_diagnostics_path')
    if path:
        from pathlib import Path
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        with open(path,'a') as output:
            output.write(json.dumps(report)+'\n')
    return timings
