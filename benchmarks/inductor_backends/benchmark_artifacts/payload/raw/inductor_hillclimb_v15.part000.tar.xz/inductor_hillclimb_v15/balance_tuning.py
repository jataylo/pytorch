from pathlib import Path
b=Path(__file__).resolve().parent.parent/'pytorch_codegen_v13'
p=b/'torch/_inductor/runtime/amd_autotune.py';s=p.read_text();s=s.replace('*, rounds=5, repeats=3):','*, rounds=5, repeats=3, cache_samples=None):',1)
s=s.replace('    def before():','''    balanced = tuner.inductor_meta.get('amd_cache_policy') == 'balanced'
    input_warm = []
    if balanced:
        seen_warm = set()
        for name, value in scratch_values.items():
            if not name.startswith(('in_ptr', 'in_out_ptr')) or not isinstance(value, torch.Tensor):
                continue
            key = value.untyped_storage()._cdata
            if key not in seen_warm:
                seen_warm.add(key)
                input_warm.append(torch.empty(0, device=value.device, dtype=torch.uint8).set_(value.untyped_storage()))
    def before(all_inputs_warm=False):''')
s=s.replace('        for value in warm:\n            value.add_(0)','        for value in input_warm if all_inputs_warm else warm:\n            value.add_(0)')
a=s.index('    for iteration in range(rounds):');z=s.index('\n    return {launcher:statistics.median',a)
s=s[:a]+'''    contexts = ('producer', 'inputs_warm') if balanced else ('producer',)
    context_samples = {launcher: {context: [] for context in contexts} for launcher in launchers}
    for iteration in range(rounds):
        torch.cuda._sleep(40_000_000)
        for context in contexts[iteration % len(contexts):] + contexts[:iteration % len(contexts)]:
            for offset in range(len(launchers)):
                index=(iteration+offset)%len(launchers)
                launcher=launchers[index]
                for start,end in events[index]:
                    before(context == 'inputs_warm');start.record();call(launcher);end.record()
            torch.cuda.synchronize()
            for launcher,pairs in zip(launchers,events):
                context_samples[launcher][context].append(statistics.mean(start.elapsed_time(end) for start,end in pairs))
    for launcher in launchers:
        samples[launcher] = [math.exp(statistics.mean(math.log(max(context_samples[launcher][context][index], 1e-9)) for context in contexts)) for index in range(rounds)]
    if cache_samples is not None:
        cache_samples.update(context_samples)
''' +s[z:]
s=s.replace('    timings,samples=benchmark_configs(tuner,tuner.launchers,args,kwargs)','    cache_samples = {}\n    timings,samples=benchmark_configs(tuner,tuner.launchers,args,kwargs,cache_samples=cache_samples)')
s=s.replace('benchmark_configs(tuner,[best,*neighbors],args,kwargs)','benchmark_configs(tuner,[best,*neighbors],args,kwargs,cache_samples=cache_samples)')
s=s.replace("approximate_math=tuner.inductor_meta.get('amd_approximate_math',False),inputs=", "approximate_math=tuner.inductor_meta.get('amd_approximate_math',False),cache_policy=tuner.inductor_meta.get('amd_cache_policy','producer'),score_statistic='median_round_geomean_ms',inputs=")
s=s.replace('samples_ms=samples[launcher])','samples_ms=samples[launcher],cache_samples_ms=cache_samples.get(launcher,{}))')
p.write_text(s)
p=b/'torch/_inductor/codegen/triton.py';s=p.read_text().replace('            inductor_meta["amd_warm_arg_names"] = self._amd_warm_arg_names()','            inductor_meta["amd_warm_arg_names"] = self._amd_warm_arg_names()\n            if config.triton.amd_extended_kernel_optimizations:\n                inductor_meta["amd_cache_policy"] = "balanced"');p.write_text(s)
p=b/'torch/_inductor/runtime/hints.py';s=p.read_text();idx=s.index('    amd_kernel_autotune:');s=s[:idx]+'    amd_cache_policy: str\n'+s[idx:];p.write_text(s)
