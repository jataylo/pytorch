from pathlib import Path
import torch
from torch._inductor import config
import json
h=Path(__file__).resolve().parent
reports=[]
for offset in (0.,1000.,1e5):
 x=(offset+torch.randn(37,8192,device='cuda')*.1)
 expected=torch.native_layer_norm(x.double(),(8192,),None,None,1e-5)
 versions={}
 for extended in (False,True):
  torch._dynamo.reset()
  with config.patch({'triton.amd_kernel_optimizations':True,'triton.amd_extended_kernel_optimizations':extended,'fx_graph_cache':False}):
   fn=torch.compile(lambda x:torch.native_layer_norm(x,(8192,),None,None,1e-5),fullgraph=True)
   output=fn(x)
  versions[str(extended)]=[float((a.double()-b).abs().max()) for a,b in zip(output,expected)]
 reports.append(dict(offset=offset,max_error_vs_float64=versions))
 print(reports[-1],flush=True)
(h/'variance_accuracy.json').write_text(json.dumps(reports,indent=2))
