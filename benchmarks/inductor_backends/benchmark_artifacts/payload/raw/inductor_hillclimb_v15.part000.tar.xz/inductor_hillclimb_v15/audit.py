from pathlib import Path
import csv
import difflib
import hashlib
import json
import statistics
import subprocess
import xml.etree.ElementTree as ET
h=Path(__file__).resolve().parent
b=h.parent/'pytorch_codegen_v13'
fp=json.loads((h/'source_fingerprint.json').read_text())
def check(value,message):
 if not value:raise RuntimeError(message)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for name,expected in fp['sources'].items():
 check(sha(b/name)==expected,'Source changed: '+name)
 check(sha(h/'accepted_source'/name)==expected,'Snapshot differs: '+name)
counts={}
policy_counts={}
for suite,count in [('new_ops_final',62),('reference_final',18)]:
 root=h/suite
 check(json.loads((root/'failures.json').read_text())==[],'Variant failures: '+suite)
 cases=list(root.glob('*/result.json'))
 check(len(cases)==count,'Case count: '+suite)
 rows=list(csv.DictReader((root/'per_case.csv').open()))
 check(len(rows)==count*16,'Timing row count: '+suite)
 for path in cases:
  data=json.loads(path.read_text())
  check(data['failures']==[],'Case failures')
  check(data['frozen_backend_callbacks']==[1,1,1,1],'Frozen backend replaced')
  check(len(data['rows'])==16,'Incomplete timing rows')
  for name,expected in data['source_fingerprint'].items():check(sha(Path(name))==expected,'Per-case fingerprint differs: '+name)
  for row in data['rows']:
   key='_'.join(row[k] for k in ['variant','cache','invocation'])
   values=data['samples_us'][key]
   check(len(values)==15,'Missing timing samples')
   check(abs(statistics.median(values)-row['runtime_us'])<1e-8,'Runtime median differs')
   check(sha(path.parent/(row['variant']+'.py'))==row['source_sha256'],'Generated code hash differs')
  for log in path.parent.glob('*.tuning.jsonl'):
   for line in log.read_text().splitlines():
    record=json.loads(line)
    policy=record.get('cache_policy','producer')
    policy_counts[policy]=policy_counts.get(policy,0)+1
    for candidate in record['candidates']:
     if candidate['median_ms'] is None:continue
     contexts=candidate['cache_samples_ms']
     check(set(contexts)==({'producer','inputs_warm'} if policy=='balanced' else {'producer'}),'Missing cache context')
     check(all(len(values)==5 for values in contexts.values()),'Missing tuner rounds')
  if data['case']['family']=='gelu_forward':
   source=(path.parent/'optimized_triton.py').read_text()
   check("'amd_gluon_family': 'flat_pointwise'" not in source,'Rejected GELU path active')
 counts[suite]={'cases':count,'timing_rows':len(rows)}
svg_paths=list(h.glob('*.svg'))
for suite in counts:svg_paths.extend((h/suite).rglob('*.svg'))
for path in svg_paths:ET.parse(path)
tests={'test_amd_kernel_optimizations.log':27,'test_amd_kernel_autotune.log':19,'test_amd_extended_kernel_optimizations.log':29,'test_flydsl_backend_selection_cache.log':2}
for name,count in tests.items():
 text=(h/name).read_text();check(f'Ran {count} tests' in text and '\nOK' in text,'Failed test log: '+name)
subprocess.run(['git','diff','--check'],cwd=b,check=True)
full=subprocess.run(['git','diff','--binary'],cwd=b,check=True,capture_output=True).stdout
untracked=subprocess.run(['git','ls-files','--others','--exclude-standard'],cwd=b,check=True,capture_output=True,text=True).stdout.splitlines()
for name in untracked:
 result=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=b,capture_output=True)
 check(result.returncode in (0,1),'Full patch failed: '+name)
 full+=result.stdout
(h/'branch_changes.patch').write_bytes(full)
old_files={str(path.relative_to(h/'v14_source')):path.read_text() for path in (h/'v14_source').rglob('*.py')}
old_patch=(h.parent/'inductor_hillclimb_v14/branch_changes.patch').read_text()
for section in old_patch.split('diff --git ')[1:]:
 lines=section.splitlines(keepends=True)
 name=next((line[6:].strip() for line in lines if line.startswith('+++ b/')),None)
 if name and '--- /dev/null\n' in lines:
  start=next(i for i,line in enumerate(lines) if line.startswith('@@ '))+1
  old_files.setdefault(name,''.join(line[1:] for line in lines[start:] if line.startswith('+')))
names=set(fp['sources'])|{'test/inductor/test_amd_kernel_autotune.py','test/inductor/test_amd_extended_kernel_optimizations.py','benchmarks/inductor_backends/plot_amd_extended_kernel_hillclimb.py','benchmarks/inductor_backends/README_amd_extended_kernel_hillclimb.md'}
delta=[]
for name in sorted(names):
 previous=old_files.get(name,'')
 current=(b/name).read_text()
 if previous!=current:
  delta.append('diff --git a/'+name+' b/'+name+'\n')
  delta.extend(difflib.unified_diff(previous.splitlines(keepends=True),current.splitlines(keepends=True),fromfile='a/'+name if previous else '/dev/null',tofile='b/'+name))
(h/'v15_vs_v14.patch').write_text(''.join(delta))
subprocess.run(['git','apply','--check','--reverse',str(h/'v15_vs_v14.patch')],cwd=b,check=True)
validation={'status':'passed','source_fingerprints_verified':len(fp['sources']),'compiled_benchmarks':counts,'compiled_cases':80,'variants_per_case':4,'timing_rows':1280,'accuracy_input_seeds':[2026,1701,2027],'rounds':15,'repeats':5,'tests_passed':sum(tests.values()),'test_logs':tests,'tuner_cache_policy_records':policy_counts,'svg_files_parsed':len(svg_paths),'git_diff_check':'passed','incremental_patch_reverse_check':'passed','approximate_math':False,'device':'MI355X gfx950','compiler_threads':1,'limits':['Operation-graph measurements; no new full-model training throughput/convergence claim.','GELU-forward layout rejected and retained as a control.','Bounded hill climb; individual regressions remain visible.','FP32 large-offset normalization accuracy is not FP64 accuracy; variance probes retained.','Asynchronous compiler workers and repository lint not validated; spin is absent.'],'source_fingerprint':fp}
(h/'VALIDATION.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({k:v for k,v in validation.items() if k!='source_fingerprint'},indent=2))
