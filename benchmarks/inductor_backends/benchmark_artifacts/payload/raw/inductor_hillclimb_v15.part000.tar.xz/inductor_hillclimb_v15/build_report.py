from pathlib import Path
import csv
import html
import importlib.util
import json
import subprocess
import sys
h=Path(__file__).resolve().parent
b=h.parent/'pytorch_codegen_v13'
sys.path.insert(0,str(b/'benchmarks/inductor_backends'))
import plot_amd_extended_kernel_hillclimb as plot
summaries={}
for name in ('new_ops_final','reference_final'):
 summaries[name]=plot.compare(h/name)
summary=summaries['new_ops_final']
rows=[r for r in summary if r['invocation']=='direct']
families=sorted(set(r['family'] for r in rows))
width,height,left,right=1200,170+70*len(families),255,1010
lo=min(-5,min(r['geomean_time_saved_vs_previous_percent'] for r in rows)-2)
hi=max(12,max(r['geomean_time_saved_vs_previous_percent'] for r in rows)+3)
x=lambda value:left+(right-left)*(value-lo)/(hi-lo)
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"><rect width="100%" height="100%" fill="white"/><g font-family="Arial,sans-serif">',plot.base.text(22,30,'Incremental improvement over previous optimized Inductor',22),plot.base.text(22,54,'MI355X | geometric means across all shapes/dtypes | direct GPU-event execution',13)]
for j,(cache,color) in enumerate([('cold','#3976bd'),('warm','#15966a')]):
 parts.extend([f'<rect x="{30+j*220}" y="73" width="15" height="12" fill="{color}"/>',plot.base.text(53+j*220,85,cache+' inputs')])
for value in range(int(lo//5)*5,int(hi)+1,5):
 if value<lo:continue
 parts.extend([f'<path d="M{x(value):.2f},108 V{height-45}" stroke="#dde3e9"/>',plot.base.text(x(value),height-24,f'{value}%',11,'middle')])
parts.append(f'<path d="M{x(0):.2f},105 V{height-45}" stroke="#333"/>')
for i,family in enumerate(families):
 y=120+i*70
 parts.append(plot.base.text(left-15,y+22,family,13,'end'))
 for j,(cache,color) in enumerate([('cold','#3976bd'),('warm','#15966a')]):
  row=next(r for r in rows if r['family']==family and r['cache']==cache)
  value=row['geomean_time_saved_vs_previous_percent'];start,end=sorted((x(0),x(value)))
  parts.extend([f'<rect x="{start:.2f}" y="{y+j*22}" width="{max(.5,end-start):.2f}" height="17" fill="{color}"/>',plot.base.text(end+7,y+j*22+13,f'{value:+.2f}%',12)])
parts.extend([plot.base.text((left+right)/2,height-4,'Runtime reduction vs previous optimized Triton (%) - positive is faster',12,'middle'),'</g></svg>'])
(h/'incremental_speedup.svg').write_text('\n'.join(parts))
table=[]
for row in summary:
 if row['cache']=='warm' and row['invocation']=='direct':
  table.append('<tr><td>'+html.escape(row['family'])+'</td><td>'+str(row['cases'])+'</td>'+''.join(f'<td>{row["geomean_time_saved_vs_"+baseline+"_percent"]:+.2f}%</td>' for baseline in ('regular','previous','flydsl'))+'</tr>')
(h/'report.html').write_text('''<!doctype html><meta charset="utf-8"><title>Inductor hill climb, next operations</title><style>body{max-width:1400px;margin:32px auto;font:16px Arial;color:#253445}td,th{padding:10px;border-bottom:1px solid #ddd}img{width:100%;height:auto}</style>
<h1>Inductor lowering: next-operation hill climb</h1>
<p>The retained changes add guarded layouts for flat dropout/SiLU fusions, native-like layout search seeds, persistent alternatives for wider inner reductions, and balanced cache-context tuning. All are opt-in on gfx950. Existing math functions are retained; approximate math is disabled in this comparison.</p>
<p>Three iterations were tested: generic layouts, balanced cache selection with wider persistent reductions, and additional vector-width-one seeds. GELU-forward layouts showed no useful aggregate gain and were rejected; GELU forward is retained as a control. Unsupported operations keep the existing path.</p>
<h2>Incremental gains from this round</h2><p>Each case rotates regular Triton, previous optimized Triton (extension disabled), extended optimized Triton, and FlyDSL in the same process. The chart compares against the previous optimized path, so it isolates the additional changes. Negative values are regressions.</p>
<img src="incremental_speedup.svg"/><h2>New operations: warm inputs, direct execution</h2><table><tr><th>Operation</th><th>Cases</th><th>Runtime saved vs regular Triton</th><th>vs previous optimized Triton</th><th>vs FlyDSL</th></tr>'''+''.join(table)+'''</table>
<p><a href="new_ops_final/report.html">62 new cases: graphs, raw data and regressions</a> | <a href="new_ops_final/comparison.csv">Per-case comparisons CSV</a> | <a href="new_ops_final/comparison_summary.csv">Per-operation summary CSV</a></p>
<h2>Previously targeted operations</h2><p><a href="reference_final/report.html">18 recorded model/kernel geometries: regression comparison</a> | <a href="reference_final/comparison.csv">Reference comparisons CSV</a></p>
<h2>Protocol and validation</h2><p>One MI355X and one compiler thread. Fifteen rotating rounds, five invocations per sample; separate cold/warm inputs and direct/CUDA graph replay. Mandatory mutation restores and 256 MiB cache flushes occur before GPU events. Three accuracy seeds. ATen GEMM/convolution. Input-restoration can warm mutable buffers in either context. FlyDSL competition is disabled, but unsupported operations may still fall back.</p>
<p>These are kernel/operation-graph timings, not new full-model training throughput or convergence results. Wider-sweep regressions remain visible. The best measured configuration in a bounded search is not proof of global optimality. Compilation overhead is reported separately. Asynchronous overlay workers and lint remain unvalidated; spin is absent from the existing environment.</p>
<p><a href="VALIDATION.json">Validation and source hashes</a> | <a href="v15_vs_v14.patch">Incremental code patch</a> | <a href="branch_changes.patch">Full branch patch</a> | <a href="variance_accuracy.json">Large-offset variance accuracy probes</a></p><p>Branch flydsl/triton-hillclimb; all changes remain uncommitted. The v14 source snapshot is retained in v14_source/, and the accepted v15 execution sources in accepted_source/.</p>''')
print(json.dumps([r for r in summary if r['cache']=='warm' and r['invocation']=='direct'],indent=2))
