def flydsl_fused_gelu_gelu_backward_view_2631963e_c1_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=41943040 ept=8 unroll=1
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 83886080)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(8):
        xindex = _b * 1024 + (_j // 8) * 1024 + _t * 8 + _j % 8
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_out_ptr0', 'x0', 0), _j, 8, _r_in_out_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 8, _r_in_ptr0, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.const(0.7071067811865476, 'f32')
        tmp5 = fdp.mul(tmp3, tmp4)
        tmp6 = fdp.erf(tmp5)
        tmp7 = fdp.const(1.0, 'f32')
        tmp8 = fdp.add(tmp6, tmp7)
        tmp9 = fdp.const(0.5, 'f32')
        tmp10 = fdp.mul(tmp8, tmp9)
        tmp11 = fdp.mul(tmp3, tmp3)
        tmp12 = fdp.const(-0.5, 'f32')
        tmp13 = fdp.mul(tmp11, tmp12)
        tmp14 = fdp.exp(tmp13)
        tmp15 = fdp.const(0.3989422804014327, 'f32')
        tmp16 = fdp.mul(tmp14, tmp15)
        tmp17 = fdp.mul(tmp3, tmp16)
        tmp18 = fdp.add(tmp10, tmp17)
        tmp19 = fdp.mul(tmp1, tmp18)
        tmp20 = fdp.to(tmp19, 'f32')
        fdp.vstore(_sc, 'st5_in_out_ptr0', _j, 8, _r_in_out_ptr0, x0, tmp20, 'bf16')
def flydsl_fused_gelu_gelu_backward_view_2631963e_c1_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_gelu_gelu_backward_view_2631963e_c1_kernel(in_out_ptr0, in_ptr0).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)
