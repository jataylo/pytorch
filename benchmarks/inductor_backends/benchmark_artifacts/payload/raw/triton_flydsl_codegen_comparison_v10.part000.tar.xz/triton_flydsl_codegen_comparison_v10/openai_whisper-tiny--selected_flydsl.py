def flydsl_fused__to_copy_add_view_f3e09529_c9_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=4608000 ept=4 unroll=8
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 9216000)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 9216000)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 18432000)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 32, 4):
        xindex = _b * 2048 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
    for _j in range_constexpr(32):
        xindex = _b * 2048 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')
def flydsl_fused__to_copy_add_view_f3e09529_c9_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_view_f3e09529_c9_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)
