def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=4 unroll=1 tpr=16 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 16
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 4 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 64 + _rl * 4 + _j % 4
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 64 + _rl * 4 + _j % 4
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 64 + _rl * 4 + _j % 4
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, None))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 16, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 16, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 64 + _rl * 4 + _j % 4
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')
def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)
