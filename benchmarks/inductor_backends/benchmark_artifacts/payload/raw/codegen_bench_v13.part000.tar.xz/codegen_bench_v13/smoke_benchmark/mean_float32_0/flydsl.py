# AOT ID: ['5_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/oe/coeuyjvvymjk3jyhdpymwof5mjztz5as3ju3j6nfgrrnhzuhzpt7.flydsl_fused_mean_pow_0935aaf3.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/oo/coosa4loeeq3njysah4n7z4kvh67nif6z23igzccyayd3ku7qb3a.py
# Topologically Sorted Source Nodes: [square, mean], Original ATen: [aten.pow, aten.mean]
# Source node to ATen node mapping:
#   mean => mean
#   square => pow_1
# Graph fragment:
#   %arg0_1 : Tensor "f32[37, 127][127, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[][]cuda:0" = PlaceHolder[target=buf0]
#   %pow_1 : Tensor "f32[37, 127][127, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%arg0_1, 2), kwargs = {})
#   %mean : Tensor "f32[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.default](args = (%pow_1,), kwargs = {})
#   return %buf0,%mean
flydsl_fused_mean_pow_0935aaf3 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_0935aaf3', r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class _Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused_mean_pow_0935aaf3_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1 rnumel=4699 ept=1 unroll=1 tpr=1024 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 4)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 18796)
    _smem = fx.SharedAllocator().allocate(_Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 1024
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 1024
        _acc1 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 4699, 1024):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 1024 + _rl * 1 + _j % 1
                r0_mask = r0_index < 4699
                r0_0 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_0, 'f32', mask=r0_mask))
        for r0_offset in range_constexpr(0, 4699, 1024):
            _acc1_items = []
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 1024 + _rl * 1 + _j % 1
                r0_mask = r0_index < 4699
                r0_0 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_0, 'f32', mask=r0_mask))
                tmp1 = fdp.mul(tmp0, tmp0)
                _acc1_items.append((tmp1, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp2 = fdp.group_reduce('sum', _acc1, 1024, _smem, 1024, 1)
        tmp3 = fdp.const(4699.0, 'f32')
        tmp4 = fdp.truediv(tmp2, tmp3)
        fdp.store(_r_in_out_ptr0, 0, tmp4, 'f32', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')


def flydsl_fused_mean_pow_0935aaf3_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_0935aaf3_kernel(in_out_ptr0, in_ptr0).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused_mean_pow_0935aaf3_launch = None


def flydsl_fused_mean_pow_0935aaf3_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_0935aaf3_kernel, flydsl_fused_mean_pow_0935aaf3_launch
    if flydsl_fused_mean_pow_0935aaf3_launch is None:
        flydsl_fused_mean_pow_0935aaf3_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused_mean_pow_0935aaf3_kernel)
        flydsl_fused_mean_pow_0935aaf3_launch = flyc.jit(flydsl_fused_mean_pow_0935aaf3_launch_fn)
        flydsl_fused_mean_pow_0935aaf3_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_0935aaf3_launch


flydsl_fused_mean_pow_0935aaf3_compiled = None
flydsl_fused_mean_pow_0935aaf3_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_0935aaf3.hsaco"


def flydsl_fused_mean_pow_0935aaf3_main(in_out_ptr0, in_ptr0, stream=None):
    global flydsl_fused_mean_pow_0935aaf3_compiled
    if flydsl_fused_mean_pow_0935aaf3_compiled is None:
        flydsl_fused_mean_pow_0935aaf3_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_0935aaf3_binary, "flydsl_fused_mean_pow_0935aaf3_kernel_0", 1024, 'OO'
        )
        if flydsl_fused_mean_pow_0935aaf3_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_0935aaf3_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), 1, 0 if stream is None else stream)
            flydsl_fused_mean_pow_0935aaf3_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_0935aaf3_compiled(1, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, )


def flydsl_fused_mean_pow_0935aaf3_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_0935aaf3_binary):
        return
    launch = flydsl_fused_mean_pow_0935aaf3_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_0935aaf3_binary, "flydsl_fused_mean_pow_0935aaf3_kernel_0")
''', '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/oe/coeuyjvvymjk3jyhdpymwof5mjztz5as3ju3j6nfgrrnhzuhzpt7.flydsl_fused_mean_pow_0935aaf3.hsaco', precompile_metadata={})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, = args
        args.clear()
        assert_size_stride(arg0_1, (37, 127), (127, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf0 = empty_strided_cuda((), (), torch.float32)
            buf1 = buf0; del buf0  # reuse
            # Topologically Sorted Source Nodes: [square, mean], Original ATen: [aten.pow, aten.mean]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused_mean_pow_0935aaf3.run(buf1, arg0_1, stream=raw_stream0)
            del arg0_1
        return (buf1, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((37, 127), (127, 1), device='cuda:0', dtype=torch.float32)
    return [arg0_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
