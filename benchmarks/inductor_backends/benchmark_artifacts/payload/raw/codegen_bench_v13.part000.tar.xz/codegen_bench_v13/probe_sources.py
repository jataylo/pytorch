import json
from pathlib import Path
from torch._inductor.codegen.amd_kernel_optimizations import optimize_pointwise_source
root=Path(__file__).resolve().parent.parent/'triton_hillclimb_v12'
for row in json.loads((root/'manifest.json').read_text()):
    if row['category'] not in ['broadcast','transpose']:continue
    source=(Path(row['folder'])/'original_triton.py').read_text();result=optimize_pointwise_source(source);print(row['index'],len(source),len(result),'matched',source!=result)
    (Path(__file__).resolve().parent/f'probe_{row["index"]}.py').write_text(result)
