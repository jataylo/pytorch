import importlib.abc,importlib.util,os,runpy,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent/'pytorch_codegen_v13'
os.environ['AMD_CODEGEN_SOURCE_ROOT']=str(ROOT)
startup=str(ROOT.parent/'codegen_startup_v13')
sys.path.insert(0,startup)
os.environ['PYTHONPATH']=os.pathsep.join([startup,*[p for p in os.environ.get('PYTHONPATH','').split(os.pathsep) if p and p!=startup]])
NAMES={'torch._inductor.config','torch._inductor.scheduler','torch._inductor.codegen.simd','torch._inductor.codegen.triton','torch._inductor.runtime.triton_heuristics','torch._inductor.runtime.hints','torch._inductor.runtime.amd_autotune','torch._inductor.codegen.amd_kernel_optimizations'}
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname in NAMES or fullname.startswith('torch._inductor.codegen.flydsl.'):
            p=ROOT/(fullname.replace('.','/')+'.py')
            if p.exists():return importlib.util.spec_from_file_location(fullname,p)
sys.meta_path.insert(0,Finder())
os.environ['TORCHINDUCTOR_FLYDSL_BASELINE_DIR']=str(ROOT/'torch/_inductor/codegen/flydsl')
os.environ.setdefault('TORCHINDUCTOR_CACHE_DIR',str(Path(__file__).resolve().parent/'cache/inductor'))
os.environ.setdefault('TRITON_CACHE_DIR',str(Path(__file__).resolve().parent/'cache/triton'))
os.environ.setdefault('FLYDSL_RUNTIME_CACHE_DIR',str(Path(__file__).resolve().parent/'cache/flydsl'))
p=Path(sys.argv[1]).resolve();sys.path.insert(0,str(p.parent));sys.argv=[str(p),*sys.argv[2:]];runpy.run_path(str(p),run_name='__main__')
