from triton.experimental import gluon
from triton.experimental.gluon import language as gl
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(size_hints={'x': 33554432}, filename=__file__, triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr', 'AMD_VEC': 'constexpr', 'AMD_UNROLL': 'constexpr', 'AMD_WARPS': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16]]}]}, inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_clone_transpose_view_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 170164224}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_gluon_family': 'transpose', 'use_gluon': True}, min_elem_per_thread=0)
@gluon.jit
def triton_poi_fused__to_copy__unsafe_view_clone_transpose_view_11(in_ptr0, out_ptr0, xnumel, XBLOCK: tl.constexpr, AMD_VEC: gl.constexpr, AMD_UNROLL: gl.constexpr, AMD_WARPS: gl.constexpr):
    lane = gl.arange(0, XBLOCK // AMD_UNROLL, layout=gl.BlockedLayout([AMD_VEC], [64], [AMD_WARPS], [0]))
    i = gl.program_id(0) * XBLOCK + lane
    output = i // 443136 * 443136 + i // 64 % 577 * 768 + i // 36928 % 12 * 64 + i % 64
    value = gl.load(in_ptr0 + i, i < 28360704, other=0)
    gl.store(out_ptr0 + output, value, i < 28360704)
