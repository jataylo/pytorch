# AOT ID: ['41_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/sy/csyrjsmonaurqav372phit2nh3iiarn7e3ivnkrg7l5mpoypfhib.flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/4i/c4itnpc6n2xvbssrfje7eun3ubt4zajssas6jzng5p4tttalawh5.py
# Topologically Sorted Source Nodes: [neg, float_1, mul, mul_1, product, sum_1, addcmul], Original ATen: [aten.neg, aten._to_copy, aten.mul, aten.sum, aten.addcmul]
# Source node to ATen node mapping:
#   addcmul => addcmul
#   float_1 => convert_element_type
#   mul => mul
#   mul_1 => mul_1
#   neg => neg
#   product => mul_2
#   sum_1 => sum_1
# Graph fragment:
#   %arg1_1 : Tensor "f32[256, 128][128, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "b8[256, 128][128, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg2_1 : Tensor "f32[256, 128][128, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %sum_1 : Tensor "f32[256, 1][1, 256]cuda:0" = PlaceHolder[target=sum_1]
#   %neg : Tensor "f32[256, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%arg2_1,), kwargs = {})
#   %convert_element_type : Tensor "f32[256, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[256, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, 1.1111111111111112), kwargs = {})
#   %mul_1 : Tensor "f32[256, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, %mul), kwargs = {})
#   %mul_2 : Tensor "f32[256, 128][128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_1, %arg2_1), kwargs = {})
#   %sum_1 : Tensor "f32[256, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_2, [-1], True), kwargs = {})
#   %addcmul : Tensor "f32[256, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.addcmul.default](args = (%mul_2, %neg, %sum_1), kwargs = {})
#   return %sum_1,%addcmul
flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79', r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr1: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=256 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 131072)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 32768)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 131072)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 131072)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 16
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 4 + _xr * 4 + _t // 16
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 128*x0', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_1 + 128*x0, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_1 + 128*x0', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_1 + 128*x0, 'b1')
                tmp6 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 128*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 128*x0, 'f32')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 128*x0', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_1 + 128*x0, 'f32')
                tmp10 = fdp.vload(_lc, ('in_ptr1', 'r0_1 + 128*x0', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_1 + 128*x0, 'b1')
                tmp15 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 128*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 128*x0, 'f32')
        for r0_offset in range_constexpr(0, 128, 128):
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 128*x0', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_1 + 128*x0, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_1 + 128*x0', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_1 + 128*x0, 'b1')
                tmp6 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 128*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 128*x0, 'f32')
                tmp2 = fdp.to(tmp1, 'f32')
                tmp3 = fdp.const(1.1111111111111112, 'f32')
                tmp4 = fdp.mul(tmp2, tmp3)
                tmp5 = fdp.mul(tmp0, tmp4)
                tmp7 = fdp.mul(tmp5, tmp6)
                _acc1_items.append((tmp7, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 16, None, 64, 1)
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 128*x0', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_1 + 128*x0, 'f32')
                tmp10 = fdp.vload(_lc, ('in_ptr1', 'r0_1 + 128*x0', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_1 + 128*x0, 'b1')
                tmp15 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 128*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 128*x0, 'f32')
                tmp11 = fdp.to(tmp10, 'f32')
                tmp12 = fdp.const(1.1111111111111112, 'f32')
                tmp13 = fdp.mul(tmp11, tmp12)
                tmp14 = fdp.mul(tmp9, tmp13)
                tmp16 = fdp.mul(tmp14, tmp15)
                tmp17 = fdp.neg(tmp15)
                tmp18 = fdp.add(fdp.mul(tmp17, tmp8), tmp16)
                fdp.vstore(_sc, 'st7_out_ptr1', _j, 4, _r_out_ptr1, r0_1 + 128*x0, tmp18, 'f32', seed=(_lc, ('out_ptr1', 'r0_1 + 128*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr1')


def flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr1: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_kernel(in_ptr0, in_ptr1, in_ptr2, out_ptr1).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_launch = None


def flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_kernel, flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_launch
    if flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_launch is None:
        flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_kernel = flyc.kernel(flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_kernel)
        flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_launch = flyc.jit(flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_launch_fn)
        flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_launch


flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_compiled = None
flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79.hsaco"


def flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_main(in_ptr0, in_ptr1, in_ptr2, out_ptr1, stream=None):
    global flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_compiled
    if flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_compiled is None:
        flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_compiled = fdp.load_binary(
            flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_binary, "flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_kernel_0", 64, 'OOOO'
        )
        if flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), out_ptr1.data_ptr(), 64, 0 if stream is None else stream)
            flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_compiled(64, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, out_ptr1, )


def flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_binary):
        return
    launch = flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_binary, "flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79_kernel_0")
''', '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/sy/csyrjsmonaurqav372phit2nh3iiarn7e3ivnkrg7l5mpoypfhib.flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79.hsaco', precompile_metadata={})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1 = args
        args.clear()
        assert_size_stride_grouped((arg1_1, arg0_1, arg2_1), ((256, 128), (256, 128), (256, 128)), ((128, 1), (128, 1), (128, 1)), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg2_1 = copy_if_misaligned(arg2_1)
            buf1 = empty_strided_cuda((256, 128), (128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [neg, float_1, mul, mul_1, product, sum_1, addcmul], Original ATen: [aten.neg, aten._to_copy, aten.mul, aten.sum, aten.addcmul]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused__to_copy_addcmul_mul_neg_sum_e4ddba79.run(arg1_1, arg0_1, arg2_1, buf1, stream=raw_stream0)
            del arg0_1
            del arg1_1
            del arg2_1
        return (buf1, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((256, 128), (128, 1), device='cuda:0', dtype=torch.bool)
    arg1_1 = rand_strided((256, 128), (128, 1), device='cuda:0', dtype=torch.float32)
    arg2_1 = rand_strided((256, 128), (128, 1), device='cuda:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
