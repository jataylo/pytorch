import ast,csv,hashlib,json,statistics,subprocess
from datetime import datetime,timezone
from pathlib import Path
from xml.etree import ElementTree
ROOT=Path(__file__).resolve().parent;BRANCH=ROOT.parent/'pytorch_codegen_v13';OUT=ROOT/'performance'
fp=json.loads((ROOT/'source_fingerprint.json').read_text());drift=[p for p,h in fp['sources'].items() if hashlib.sha256((BRANCH/p).read_bytes()).hexdigest()!=h]
if drift:raise RuntimeError(('source drift',drift))
results=[json.loads(p.read_text()) for p in OUT.glob('*/result.json')]
if len(results)!=96:raise RuntimeError(('case count',len(results)))
rows=list(csv.DictReader((OUT/'per_case.csv').open()))
if len(rows)!=576:raise RuntimeError(('row count',len(rows)))
for result in results:
    if result['failures']:raise RuntimeError(result['failures'])
    if len(result['rows'])!=6:raise RuntimeError('missing variant/cache measurement')
    for row in result['rows']:
        samples=result['samples_us'][row['variant']+'_'+row['cache']]
        if len(samples)!=15 or statistics.median(samples)!=row['runtime_us']:raise RuntimeError('raw samples do not reproduce median')
        source=OUT/row['case']/(row['variant']+'.py')
        if hashlib.sha256(source.read_bytes()).hexdigest()!=row['source_sha256']:raise RuntimeError('generated source drift')
        if row['variant']=='optimized_triton':
            baseline=OUT/row['case']/'triton.py'
            def bodies(path):
                sources=[node.value for node in ast.walk(ast.parse(path.read_text())) if isinstance(node,ast.Constant) and isinstance(node.value,str) and 'def triton_' in node.value]
                return [ast.dump(node) for source in sources for tree in [ast.parse(source)] for fn in tree.body if isinstance(fn,ast.FunctionDef) for node in fn.body]
            same=bodies(source)==bodies(baseline)
            for r in rows:
                if r['case']==row['case'] and r['variant']==row['variant']:r['math_body_changed']=not same
for row in rows:row.setdefault('math_body_changed','')
with (OUT/'per_case_annotated.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
svg=list((OUT/'graphs').glob('*.svg'))
if len(svg)!=34:raise RuntimeError(('figure count',len(svg)))
for p in svg:ElementTree.parse(p)
code_tests=(ROOT/'test_amd_kernel_optimizations_final.log').read_text();cache_tests=(ROOT/'test_backend_selection_cache.log').read_text()
if 'Ran 27 tests' not in code_tests or '\nOK\n' not in code_tests:raise RuntimeError('code tests missing')
if 'Ran 2 tests' not in cache_tests or '\nOK\n' not in cache_tests:raise RuntimeError('cache tests missing')
tracked=subprocess.run(['git','diff','--binary'],cwd=BRANCH,text=True,capture_output=True,check=True).stdout
untracked=subprocess.run(['git','ls-files','--others','--exclude-standard'],cwd=BRANCH,text=True,capture_output=True,check=True).stdout.splitlines()
for p in untracked:
    r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',p],cwd=BRANCH,text=True,capture_output=True)
    if r.returncode not in [0,1]:raise RuntimeError(r.stderr)
    tracked+=r.stdout
(ROOT/'branch_changes.patch').write_text(tracked)
check=subprocess.run(['git','diff','--check'],cwd=BRANCH,text=True,capture_output=True)
if check.returncode:raise RuntimeError(check.stdout+check.stderr)
report=dict(completed_utc=datetime.now(timezone.utc).isoformat(),branch='flydsl/triton-hillclimb',worktree=str(BRANCH),uncommitted=True,source_fingerprint_valid=True,cases=96,variants_per_case=3,cache_modes=2,timing_rows=576,variant_failures=0,correctness_seeds=[2026,1701,2027],timing_seed=2027,timing_rounds=15,invocations_per_round=5,figures=34,codegen_tests=27,cache_tests=2,gpu='MI355X gfx950 GPU0',compiler_threads=1,production_default_enabled=False,approximate_math_added=False,full_model_training_rerun=False,asynchronous_compilation='not validated; source-overlay worker pool failed during exploratory runs',lint='spin unavailable in existing .venv; not run',source_sha256=fp['sources'],additional_source_hashes={str(p.relative_to(BRANCH)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [BRANCH/'benchmarks/inductor_backends/plot_amd_kernel_hillclimb.py',BRANCH/'test/inductor/test_amd_kernel_optimizations.py',BRANCH/'test/inductor/test_flydsl_backend_selection_cache.py']},interpretation='compiled operation graph runtimes on random inputs; no full-model speedup or universal kernel win claim. GELU pointwise control has unchanged math body; independent tuning and timing can vary. Regressions preserved.')
(ROOT/'VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['source_sha256','additional_source_hashes']},indent=2))
