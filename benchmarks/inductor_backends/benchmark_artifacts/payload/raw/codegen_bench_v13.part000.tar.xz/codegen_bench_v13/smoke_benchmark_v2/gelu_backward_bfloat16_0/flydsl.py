# AOT ID: ['44_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/ij/cijr5j42glp73ohxl2o4t6e63j5nu624j4p5mkqfnqenrdz5gy5w.flydsl_fused_gelu_backward_901db5ad.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/fi/cfiizf6zprcz2vtmy2bxupk6y5soopkdv6jvvdy6dqxiiqcnuj6w.py
# Topologically Sorted Source Nodes: [gelu_backward], Original ATen: [aten.gelu_backward]
# Source node to ATen node mapping:
#   gelu_backward => add, add_1, convert_element_type, convert_element_type_1, convert_element_type_2, erf, exp, mul, mul_1, mul_2, mul_3, mul_4, mul_5, mul_6
# Graph fragment:
#   %arg0_1 : Tensor "bf16[4099][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[4099][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %convert_element_type : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[4099][1]cuda:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg1_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, 0.7071067811865476), kwargs = {})
#   %erf : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.erf.default](args = (%mul,), kwargs = {})
#   %add : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%erf, 1), kwargs = {})
#   %mul_1 : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add, 0.5), kwargs = {})
#   %mul_2 : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %convert_element_type_1), kwargs = {})
#   %mul_3 : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_2, -0.5), kwargs = {})
#   %exp : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%mul_3,), kwargs = {})
#   %mul_4 : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%exp, 0.3989422804014327), kwargs = {})
#   %mul_5 : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %mul_4), kwargs = {})
#   %add_1 : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_1, %mul_5), kwargs = {})
#   %mul_6 : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %add_1), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_6, torch.bfloat16), kwargs = {})
#   return %convert_element_type_2
flydsl_fused_gelu_backward_901db5ad = fdp_rt.compiled(async_compile, 'flydsl_fused_gelu_backward_901db5ad', r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused_gelu_backward_901db5ad_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=4099 ept=1 unroll=1
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8198)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 8198)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 8198)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(1):
        xindex = _b * 64 + (_j // 1) * 64 + _t * 1 + _j % 1
        xmask = xindex < 4099
        x0 = xindex
        tmp0 = fdp.load(_r_in_ptr0, x0, 'bf16', mask=xmask)
        tmp2 = fdp.load(_r_in_ptr1, x0, 'bf16', mask=xmask)
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.const(0.7071067811865476, 'f32')
        tmp5 = fdp.mul(tmp3, tmp4)
        tmp6 = fdp.erf(tmp5)
        tmp7 = fdp.const(1.0, 'f32')
        tmp8 = fdp.add(tmp6, tmp7)
        tmp9 = fdp.const(0.5, 'f32')
        tmp10 = fdp.mul(tmp8, tmp9)
        tmp11 = fdp.mul(tmp3, tmp3)
        tmp12 = fdp.const(-0.5, 'f32')
        tmp13 = fdp.mul(tmp11, tmp12)
        tmp14 = fdp.exp(tmp13)
        tmp15 = fdp.const(0.3989422804014327, 'f32')
        tmp16 = fdp.mul(tmp14, tmp15)
        tmp17 = fdp.mul(tmp3, tmp16)
        tmp18 = fdp.add(tmp10, tmp17)
        tmp19 = fdp.mul(tmp1, tmp18)
        tmp20 = fdp.to(tmp19, 'f32')
        fdp.store(_r_out_ptr0, x0, tmp20, 'bf16', mask=xmask)


def flydsl_fused_gelu_backward_901db5ad_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_gelu_backward_901db5ad_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused_gelu_backward_901db5ad_launch = None


def flydsl_fused_gelu_backward_901db5ad_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_gelu_backward_901db5ad_kernel, flydsl_fused_gelu_backward_901db5ad_launch
    if flydsl_fused_gelu_backward_901db5ad_launch is None:
        flydsl_fused_gelu_backward_901db5ad_kernel = flyc.kernel(flydsl_fused_gelu_backward_901db5ad_kernel)
        flydsl_fused_gelu_backward_901db5ad_launch = flyc.jit(flydsl_fused_gelu_backward_901db5ad_launch_fn)
        flydsl_fused_gelu_backward_901db5ad_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused_gelu_backward_901db5ad_launch


flydsl_fused_gelu_backward_901db5ad_compiled = None
flydsl_fused_gelu_backward_901db5ad_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_gelu_backward_901db5ad.hsaco"


def flydsl_fused_gelu_backward_901db5ad_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused_gelu_backward_901db5ad_compiled
    if flydsl_fused_gelu_backward_901db5ad_compiled is None:
        flydsl_fused_gelu_backward_901db5ad_compiled = fdp.load_binary(
            flydsl_fused_gelu_backward_901db5ad_binary, "flydsl_fused_gelu_backward_901db5ad_kernel_0", 64, 'OOO'
        )
        if flydsl_fused_gelu_backward_901db5ad_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_gelu_backward_901db5ad_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 65, 0 if stream is None else stream)
            flydsl_fused_gelu_backward_901db5ad_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_gelu_backward_901db5ad_compiled(65, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused_gelu_backward_901db5ad_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_gelu_backward_901db5ad_binary):
        return
    launch = flydsl_fused_gelu_backward_901db5ad_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_gelu_backward_901db5ad_binary, "flydsl_fused_gelu_backward_901db5ad_kernel_0")
''', '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/ij/cijr5j42glp73ohxl2o4t6e63j5nu624j4p5mkqfnqenrdz5gy5w.flydsl_fused_gelu_backward_901db5ad.hsaco', precompile_metadata={})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1), ((4099, ), (4099, )), ((1, ), (1, )), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf0 = empty_strided_cuda((4099, ), (1, ), torch.bfloat16)
            # Topologically Sorted Source Nodes: [gelu_backward], Original ATen: [aten.gelu_backward]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused_gelu_backward_901db5ad.run(arg0_1, arg1_1, buf0, stream=raw_stream0)
            del arg0_1
            del arg1_1
        return (buf0, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((4099, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((4099, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
