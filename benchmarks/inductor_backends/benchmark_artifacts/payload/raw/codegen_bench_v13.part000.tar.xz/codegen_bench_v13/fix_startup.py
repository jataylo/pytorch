from pathlib import Path
p=Path(__file__).with_name('run_overlay.py');s=p.read_text().replace("startup=str(ROOT.parent/'codegen_startup_v13')","startup=str(ROOT.parent/'codegen_startup_v13')\nsys.path.insert(0,startup)");p.write_text(s)
