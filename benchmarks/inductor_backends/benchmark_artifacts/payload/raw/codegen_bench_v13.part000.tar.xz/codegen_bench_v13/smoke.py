import json
import torch
from torch._inductor import config
from torch._inductor.utils import run_and_get_code
from torch.testing._internal.common_utils import TestCase

x=torch.randn(3,5,37,64,device='cuda',dtype=torch.bfloat16)
s=torch.tensor(.7,device='cuda')
for kind,fn,args in [('transpose',lambda x:x.permute(0,2,1,3).contiguous(),(x,)),('broadcast',lambda x,s:((s*(1./x.numel()))*(x.float()*2)).to(x.dtype),(x,s)),('mean',lambda x:x.float().square().mean(),(x,)),('add',lambda x,y:x.float()+y.float(),(x,x))]:
    torch._dynamo.reset()
    with config.patch({'triton.amd_kernel_optimizations':True,'max_autotune_pointwise':True}):
        compiled=torch.compile(fn,fullgraph=True);out,codes=run_and_get_code(compiled,*args)
        TestCase().assertEqual(out,fn(*args),atol=.02,rtol=.02)
        print(kind,'OK','gluon' in '\n'.join(codes),'amd_reduction_tuning' in '\n'.join(codes),flush=True)
        open(__file__+'.'+kind+'.py','w').write('\n'.join(codes))
