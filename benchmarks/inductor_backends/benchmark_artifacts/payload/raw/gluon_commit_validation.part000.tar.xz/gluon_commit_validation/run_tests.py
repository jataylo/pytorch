from pathlib import Path
import os,re,subprocess,json
h=Path(__file__).resolve().parent;r=h.parent;b=r/'pytorch_gluon_commit'
env=os.environ|{'AMD_CODEGEN_SOURCE_ROOT':str(b),'CUDA_VISIBLE_DEVICES':'1','TORCHINDUCTOR_COMPILE_THREADS':'1','TRITON_DEFAULT_FP_FUSION':'1'}
results={}
for name in ['test_amd_kernel_optimizations','test_amd_kernel_autotune','test_amd_extended_kernel_optimizations','test_amd_further_kernel_optimizations','test_amd_kernel_hardware','test_amd_hardware_configs','test_amd_benchmark_protocol','test_flydsl_backend_selection_cache']:
 with (h/(name+'.log')).open('w') as log:
  result=subprocess.run(['bash',str(r/'run_env.sh'),str(r/'run_source_overlay.py'),str(b/'test/inductor'/(name+'.py'))],env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(h/(name+'.log')).read_text()
 count=re.search(r'Ran (\d+) tests?',text)
 results[name]=dict(returncode=result.returncode,tests=int(count.group(1)) if count else 0,passed=result.returncode==0 and '\nOK' in text)
 (h/'test_results.json').write_text(json.dumps(results,indent=2))
 print(name,results[name],flush=True)
 if result.returncode:raise RuntimeError('Test failed: '+name)
print('TOTAL',sum(row['tests'] for row in results.values()),flush=True)
