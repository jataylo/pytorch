import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def triton_per_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_5(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK: tl.constexpr):
    xnumel = 16384
    r0_numel = 128
    R0_BLOCK: tl.constexpr = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_3 = r0_index
    x4 = xindex
    x0 = xindex % 128
    x2 = xindex // 2048
    tmp0 = tl.load(in_ptr0 + (r0_3 + 128 * x4), None, eviction_policy='evict_first')
    tmp1 = tl.load(in_ptr1 + (r0_3 + 128 * x0 + 16384 * x2), None, eviction_policy='evict_last')
    tmp2 = tl.full([1, 1], 0.0, tl.float32)
    tmp3 = tl.full([1, 1], float('-inf'), tl.float32)
    tmp4 = tl.where(tmp1, tmp2, tmp3)
    tmp5 = tmp4.to(tl.float32)
    tmp6 = tmp0 + tmp5
    tmp7 = tl.broadcast_to(tmp6, [XBLOCK, R0_BLOCK])
    tmp9 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
    tmp11 = triton_helpers.fmax2(tmp9, 1)[:, None].to(tl.float32)
    tmp12 = tmp7 - tmp11
    tmp13 = libdevice.exp(tmp12)
    tmp14 = tl.broadcast_to(tmp13, [XBLOCK, R0_BLOCK])
    tmp16 = tl.sum(tmp14, 1)[:, None].to(tl.float32)
    tmp17 = tmp6 == tmp3
    tmp18 = tmp17 == 0
    tmp19 = tmp18.to(tl.int64)
    tmp20 = tmp19 != 0
    tmp21 = tl.broadcast_to(tmp20, [XBLOCK, R0_BLOCK])
    tmp23 = triton_helpers.any(tmp21, 1)[:, None].to(tl.int1)
    tmp24 = tmp23 == 0
    tmp25 = tmp6 - tmp11
    tmp26 = libdevice.exp(tmp25)
    tmp27 = tmp26 / tmp16
    tmp28 = tl.where(tmp24, tmp2, tmp27)
    tl.store(in_out_ptr0 + x4, tmp24, None)
    tl.store(out_ptr2 + (r0_3 + 128 * x4), tmp28, None)
    tl.store(out_ptr0 + x4, tmp11, None)
    tl.store(out_ptr1 + x4, tmp16, None)
