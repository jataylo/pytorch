import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def triton_poi_fused_gelu_gelu_backward_view_3(in_out_ptr0, in_ptr0, xnumel, XBLOCK: tl.constexpr):
    xnumel = 41943040
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_out_ptr0 + x0, None).to(tl.float32)
    tmp2 = tl.load(in_ptr0 + x0, None).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tl.full([1], 0.7071067811865476, tl.float32)
    tmp5 = tmp3 * tmp4
    tmp6 = libdevice.erf(tmp5)
    tmp7 = tl.full([1], 1.0, tl.float32)
    tmp8 = tmp6 + tmp7
    tmp9 = tl.full([1], 0.5, tl.float32)
    tmp10 = tmp8 * tmp9
    tmp11 = tmp3 * tmp3
    tmp12 = tl.full([1], -0.5, tl.float32)
    tmp13 = tmp11 * tmp12
    tmp14 = libdevice.exp(tmp13)
    tmp15 = tl.full([1], 0.3989422804014327, tl.float32)
    tmp16 = tmp14 * tmp15
    tmp17 = tmp3 * tmp16
    tmp18 = tmp10 + tmp17
    tmp19 = tmp1 * tmp18
    tmp20 = tmp19.to(tl.float32)
    tl.store(in_out_ptr0 + x0, tmp20, None)
