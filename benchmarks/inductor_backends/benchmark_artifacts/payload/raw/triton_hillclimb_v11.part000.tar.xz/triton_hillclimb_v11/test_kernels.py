import torch
import torch.nn.functional as F
import triton

from torch.testing._internal.common_utils import TestCase, run_tests, parametrize
from torch.testing._internal.common_device_type import instantiate_device_type_tests, onlyCUDA
from kernels import pointwise, softmax_gl, softmax_tl


def softmax_inputs(m, r, device, special=False, seed=2026):
    torch.manual_seed(seed)
    x = torch.randn((m, r), device=device)
    mask = torch.rand((triton.cdiv(m, 2048), 128, r), device=device) > 0.2
    mask[:, 0] = False
    if special:
        x[1, 0] = float('nan')
        x[2, 0] = float('inf')
        x[3] = -float('inf')
    idx = torch.arange(m, device=device)
    masked = x + torch.where(mask[idx//2048, idx%128], 0.0, -float('inf'))
    maximum = torch.nan_to_num(masked, nan=-float('inf'), posinf=float('inf'), neginf=-float('inf')).amax(-1)
    maximum = torch.where(torch.isnan(masked).all(-1), float('nan'), maximum)
    ex = torch.exp(masked - maximum[:, None])
    total = ex.sum(-1)
    invalid = (masked == -float('inf')).all(-1)
    probability = torch.where(invalid[:, None], 0.0, ex / total[:, None])
    outputs = [torch.empty((m,), device=device, dtype=torch.bool), torch.empty_like(maximum), torch.empty_like(total), torch.empty_like(x)]
    return x, mask, outputs, [invalid, maximum, total, probability]


class TestHillclimbKernels(TestCase):
    @onlyCUDA
    @parametrize('special', [False, True])
    def test_softmax_layout_and_math(self, device, special):
        for m, r in [(37, 64), (256, 128), (67, 256)]:
            x, mask, outs, expected = softmax_inputs(m, r, device, special)
            for math_mode in [0, 1, 2]:
                softmax_tl[(triton.cdiv(m, 4),)](outs[0], x, mask, outs[1], outs[2], outs[3], m, r, 4, math_mode, num_warps=4)
                for actual, ref in zip(outs, expected):
                    self.assertEqual(actual, ref, atol=2e-5, rtol=2e-5, equal_nan=True)
                for lanes, vec, warps, rows in [(16, 4, 1, 4), (32, 4, 2, 8)]:
                    softmax_gl[(triton.cdiv(m, rows),)](outs[0], x, mask, outs[1], outs[2], outs[3], m, r, rows, lanes, vec, warps, math_mode, num_warps=warps)
                    for actual, ref in zip(outs, expected):
                        self.assertEqual(actual, ref, atol=2e-5, rtol=2e-5, equal_nan=True)

    @onlyCUDA
    @parametrize('dtype', [torch.bfloat16, torch.float32])
    def test_gelu_backward_accuracy(self, device, dtype):
        x = torch.linspace(-10, 10, 4099, device=device, dtype=dtype).requires_grad_(True)
        grad = torch.randn_like(x)
        ref = torch.autograd.grad(F.gelu(x, approximate='none'), x, grad)[0]
        out = torch.empty_like(x)
        for mode in [0, 1, 2, 3]:
            pointwise[(triton.cdiv(x.numel(), 2048),)](grad, x, out, x.numel(), 512, 4, 1, mode, num_warps=2)
            self.assertEqual(out, ref, atol=0.003 if dtype==torch.bfloat16 else 2e-6, rtol=0.02 if dtype==torch.bfloat16 else 2e-5)

    @onlyCUDA
    def test_gelu_nonfinite_and_sensitive_points(self, device):
        for dtype in [torch.float32,torch.bfloat16]:
            x=torch.tensor([-float('inf'),float('inf'),float('nan'),-12.,-6.,-.7517915,0.,1.,12.],device=device,dtype=dtype).requires_grad_(True)
            grad=torch.ones_like(x)
            expected=torch.autograd.grad(F.gelu(x),x,grad)[0]
            out=torch.empty_like(x)
            pointwise[(1,)](grad,x,out,x.numel(),512,1,1,3,num_warps=1)
            self.assertEqual(out,expected,atol=.003 if dtype==torch.bfloat16 else 2e-6,rtol=.02 if dtype==torch.bfloat16 else 2e-5,equal_nan=True)

    @onlyCUDA
    def test_cast_add_exact_and_tail(self, device):
        a = torch.randn(4099, device=device, dtype=torch.bfloat16)
        b = torch.randn_like(a)
        out = torch.empty_like(a, dtype=torch.float32)
        pointwise[(triton.cdiv(a.numel(), 2048),)](a, b, out, a.numel(), 256, 8, 0, 0, num_warps=1)
        self.assertEqual(out, a.float()+b.float(), atol=0, rtol=0)


instantiate_device_type_tests(TestHillclimbKernels, globals(), only_for='cuda')
if __name__=='__main__':
    run_tests()
