import fcntl
import json
import os
from pathlib import Path

import torch
import torch.nn.functional as F
import triton
from torch.testing._internal.common_device_type import instantiate_device_type_tests, onlyCUDA
from torch.testing._internal.common_utils import TestCase, run_tests, parametrize

from kernels import pointwise, softmax_tl, softmax_gl
from test_kernels import softmax_inputs

ROOT = Path(os.environ.get('HILLCLIMB_RESULTS', str(Path(__file__).resolve().parent / 'matched_context')))


def configs(case):
    data=json.loads((ROOT/case/'FINAL.json').read_text())
    ordered=sorted([entry for entry in data['finalists'] if 'config' in entry],key=lambda entry:entry['median_us'])
    result=[ordered[0]['config']]
    strict=next((entry['config'] for entry in ordered if entry['config']['math']==0),None)
    if strict and strict not in result:
        result.append(strict)
    return result


class TestHillclimbWinners(TestCase):
    checks=[]

    def save(self,record):
        self.checks.append(record)
        (ROOT/'holdout_accuracy.json').write_text(json.dumps(self.checks,indent=2)+'\n')

    @onlyCUDA
    def test_softmax_holdout_shapes(self,device):
        for cfg in configs('softmax'):
            for m,r in [(37,64),(67,128),(257,256),(31,1024)]:
                for special in [False,True]:
                    x,mask,outs,expected=softmax_inputs(m,r,device,special)
                    common=dict(M=m,R=r,ROWS=cfg['rows'],MATH=cfg['math'],num_warps=cfg['warps'])
                    if cfg['kind']=='gl':
                        softmax_gl[(triton.cdiv(m,cfg['rows']),)](outs[0],x,mask,outs[1],outs[2],outs[3],LANES=cfg['lanes'],VEC=cfg['vec'],WARPS=cfg['warps'],**common)
                    else:
                        softmax_tl[(triton.cdiv(m,cfg['rows']),)](outs[0],x,mask,outs[1],outs[2],outs[3],**common)
                    for actual,ref in zip(outs,expected):
                        self.assertEqual(actual,ref,atol=2e-5,rtol=2e-5,equal_nan=True)
                    self.save(dict(case='softmax',config=cfg,shape=[m,r],special=special,status='pass'))

    @onlyCUDA
    def test_gelu_holdout_precision_and_tails(self,device):
        for cfg in configs('gelu'):
            for dtype in [torch.bfloat16,torch.float32]:
                for n in [4099,65537]:
                    x=torch.linspace(-12,12,n,device=device,dtype=dtype).requires_grad_(True)
                    grad=torch.randn_like(x)
                    ref=torch.autograd.grad(F.gelu(x),x,grad)[0]
                    out=torch.empty_like(x)
                    pointwise[(triton.cdiv(n,cfg['block']*cfg['unroll']),)](grad,x,out,n,cfg['block'],cfg['unroll'],1,cfg['math'],num_warps=cfg['warps'],waves_per_eu=cfg['waves'])
                    self.assertEqual(out,ref,atol=.003 if dtype==torch.bfloat16 else 2e-6,rtol=.02 if dtype==torch.bfloat16 else 2e-5,equal_nan=True)
                    self.save(dict(case='gelu',config=cfg,n=n,dtype=str(dtype),status='pass',max_abs_error=(out.float()-ref.float()).abs().max().item()))

    @onlyCUDA
    def test_cast_holdout_exact(self,device):
        for cfg in configs('cast_add'):
            for n in [4099,65537,1048577]:
                a=torch.randn(n,device=device,dtype=torch.bfloat16)
                b=torch.randn_like(a)
                out=torch.empty(n,device=device)
                pointwise[(triton.cdiv(n,cfg['block']*cfg['unroll']),)](a,b,out,n,cfg['block'],cfg['unroll'],0,cfg['math'],num_warps=cfg['warps'],waves_per_eu=cfg['waves'])
                self.assertEqual(out,a.float()+b.float(),atol=0,rtol=0)
                self.save(dict(case='cast_add',config=cfg,n=n,status='pass'))


instantiate_device_type_tests(TestHillclimbWinners,globals(),only_for='cuda')
if __name__=='__main__':
    with Path('/dev/shm/pytorch-simd-v2-entry.lock').open('a') as entry,Path('/dev/shm/pytorch-simd-v2-benchmark.lock').open('a') as timing:
        fcntl.flock(entry,fcntl.LOCK_EX);fcntl.flock(timing,fcntl.LOCK_EX)
        run_tests()
