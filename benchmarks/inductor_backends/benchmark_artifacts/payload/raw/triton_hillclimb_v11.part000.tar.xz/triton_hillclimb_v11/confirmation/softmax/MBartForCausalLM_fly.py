
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 16
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 4 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, None))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 16, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 16, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 4096, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_compiled(4096, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 16
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 4 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_m, _acc1_s = fdp.online_softmax_default()
        _acc2 = fdp.default('any', 'b1')
        for _ro in range(fx.Int32(0), fx.Int32(128), fx.Int32(128)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_vc, ('in_ptr0', 'r0_3 + 128*x4', 0), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_vc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', 0), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, None))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12)
            _acc1_m, _acc1_s = fdp.online_softmax_block(_acc1_m, _acc1_s, _acc1_items)
        tmp7, tmp8 = fdp.group_online_softmax(_acc1_m, _acc1_s, 16, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        tmp13 = fdp.group_reduce('any', _acc2, 16, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        for _ro in range(fx.Int32(0), fx.Int32(128), fx.Int32(128)):
            r0_offset = fdp.idx(_ro)
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_vc, ('in_ptr0', 'r0_3 + 128*x4', 1), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_vc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', 1), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 4096, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_compiled(4096, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=2 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 16
    _lane0 = _rl == 0
    _caches = []
    for _xr in range_constexpr(2):
        _vc, _sc, _lc = {}, {}, {}
        xindex = _b * 8 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        _caches.append((_vc, _sc, _lc))
    for _xr in range_constexpr(2):
        _vc, _sc, _lc = _caches[_xr]
        xindex = _b * 8 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, None))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 16, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 16, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 2048, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_compiled(2048, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=4 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 16
    _lane0 = _rl == 0
    _caches = []
    for _xr in range_constexpr(4):
        _vc, _sc, _lc = {}, {}, {}
        xindex = _b * 16 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        _caches.append((_vc, _sc, _lc))
    for _xr in range_constexpr(4):
        _vc, _sc, _lc = _caches[_xr]
        xindex = _b * 16 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, None))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 16, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 16, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 1024, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_compiled(1024, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=8 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 16
    _lane0 = _rl == 0
    _caches = []
    for _xr in range_constexpr(8):
        _vc, _sc, _lc = {}, {}, {}
        xindex = _b * 32 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        _caches.append((_vc, _sc, _lc))
    for _xr in range_constexpr(8):
        _vc, _sc, _lc = _caches[_xr]
        xindex = _b * 32 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, None))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 16, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 16, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 128):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 128 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 512, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_compiled(512, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=8 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 8
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 8 + _xr * 8 + _t // 8
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 64 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 64 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 64 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, None))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 8, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 8, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 64 + _rl * 8 + _j % 8
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 2048, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_compiled(2048, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=32 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 32
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 2 + _xr * 2 + _t // 32
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 256):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 256 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 128, 256):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 256 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 128, 256):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 256 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, r0_mask))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12, mask=r0_mask)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 32, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 32, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 256):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 256 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', mask=r0_mask, seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 8192, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_compiled(8192, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=64 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 64
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 512):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 512 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 128, 512):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 512 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 128, 512):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 512 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, r0_mask))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12, mask=r0_mask)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 64, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 64, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 512):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 512 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', mask=r0_mask, seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 16384, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_compiled(16384, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=128 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 128
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 2 + _xr * 2 + _t // 128
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 1024):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1024 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 128, 1024):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1024 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 128, 1024):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1024 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, r0_mask))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12, mask=r0_mask)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 128, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 128, _smem, 256, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 1024):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1024 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', mask=r0_mask, seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_kernel_0", 256, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 8192, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_compiled(8192, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=256 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 256
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 2048):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 2048 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 128, 2048):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 2048 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 128, 2048):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 2048 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, r0_mask))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12, mask=r0_mask)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 256, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 256, _smem, 256, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 2048):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 2048 + _rl * 8 + _j % 8
                r0_mask = r0_index < 128
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1', mask=r0_mask)
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', mask=r0_mask, seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_kernel_0", 256, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 16384, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_compiled(16384, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=1 unroll=1 tpr=64 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 64
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 64 + _rl * 1 + _j % 1
                r0_3 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_3 + 128*x4, 'f32'))
                tmp1 = fdp.memo(_lc, (('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_3 + 128*x0 + 16384*x2, 'b1'))
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 64 + _rl * 1 + _j % 1
                r0_3 = r0_index
                tmp15 = fdp.memo(_lc, (('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_3 + 128*x4, 'f32'))
                tmp16 = fdp.memo(_lc, (('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_3 + 128*x0 + 16384*x2, 'b1'))
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 64 + _rl * 1 + _j % 1
                r0_3 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_3 + 128*x4, 'f32'))
                tmp1 = fdp.memo(_lc, (('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_3 + 128*x0 + 16384*x2, 'b1'))
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, None))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 64, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 64, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 64 + _rl * 1 + _j % 1
                r0_3 = r0_index
                tmp15 = fdp.memo(_lc, (('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_3 + 128*x4, 'f32'))
                tmp16 = fdp.memo(_lc, (('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_3 + 128*x0 + 16384*x2, 'b1'))
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.store(_r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32')
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 16384, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_compiled(16384, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=16384 rnumel=128 ept=4 unroll=1 tpr=16 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 16384)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 8388608)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 131072)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 65536)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 65536)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 8388608)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 16
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 4 + _xr * 4 + _t // 16
        x4 = xindex
        x0 = fdp.imod(xindex, 128)
        x2 = fdp.idiv(xindex, 2048)
        _acc1_items = []
        _acc2 = fdp.default('any', 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 64 + _rl * 4 + _j % 4
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 64 + _rl * 4 + _j % 4
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 64 + _rl * 4 + _j % 4
                r0_3 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp1 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp2 = fdp.const(0.0, 'f32')
                tmp3 = fdp.const(float('-inf'), 'f32')
                tmp4 = fdp.where(tmp1, tmp2, tmp3)
                tmp5 = fdp.to(tmp4, 'f32')
                tmp6 = fdp.add(tmp0, tmp5)
                _acc1_items.append((tmp6, None))
                tmp9 = fdp.eq(tmp6, tmp3)
                tmp10 = fdp.logical_not(tmp9)
                tmp11 = fdp.to(tmp10, 'i64')
                tmp12 = fdp.to(tmp11, 'b1')
                _acc2 = fdp.combine('any', _acc2, tmp12)
        tmp7, tmp8 = fdp.group_softmax_twopass(_acc1_items, 16, None, 64, 1)
        fdp.store(_r_out_ptr0, x4, tmp7, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        fdp.store(_r_out_ptr1, x4, tmp8, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')
        tmp13 = fdp.group_reduce('any', _acc2, 16, None, 64, 1)
        tmp14 = fdp.logical_not(tmp13)
        fdp.store(_r_in_out_ptr0, x4, tmp14, 'b1', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')
        for r0_offset in range_constexpr(0, 128, 64):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 64 + _rl * 4 + _j % 4
                r0_3 = r0_index
                tmp15 = fdp.vload(_lc, ('in_ptr0', 'r0_3 + 128*x4', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_3 + 128*x4, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr1', 'r0_3 + 128*x0 + 16384*x2', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_3 + 128*x0 + 16384*x2, 'b1')
                tmp17 = fdp.const(0.0, 'f32')
                tmp18 = fdp.const(float('-inf'), 'f32')
                tmp19 = fdp.where(tmp16, tmp17, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp21 = fdp.add(tmp15, tmp20)
                tmp22 = fdp.sub(tmp21, tmp7)
                tmp23 = fdp.exp(tmp22)
                tmp24 = fdp.truediv(tmp23, tmp8)
                tmp25 = fdp.where(tmp14, tmp17, tmp24)
                fdp.vstore(_sc, 'st8_out_ptr2', _j, 4, _r_out_ptr2, r0_3 + 128*x4, tmp25, 'f32', seed=(_lc, ('out_ptr2', 'r0_3 + 128*x4', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_kernel(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_launch = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_kernel, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_launch
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_launch is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_kernel = flyc.kernel(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_kernel)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_launch = flyc.jit(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_launch_fn)
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_launch


flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_compiled = None
flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11.hsaco"


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_compiled
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_compiled is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_compiled = fdp.load_binary(
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_kernel_0", 64, 'OOOOOO'
        )
        if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), out_ptr2.data_ptr(), 4096, 0 if stream is None else stream)
            flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_compiled(4096, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, )


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_binary):
        return
    launch = flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_binary, "flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_kernel_0")

flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_best = None


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_main(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=None):
    global flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_best
    if flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_best is None:
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_best = fdp.pick_fastest(
            [flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_main, flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_main], (in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2,), (0, 3, 4, 5), stream,
            warm=(1,), metadata={'kernel_name': 'flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3', 'stage': 'norm', 'candidate_descriptions': ["row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=2 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=4 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=16 stride=1 xunroll=8 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=8 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=32 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=64 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=128 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=8 unroll=1 tpr=256 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=1 unroll=1 tpr=64 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=16384 rnumel=128 ept=4 unroll=1 tpr=16 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}"]},
        )
        return
    flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_best(in_out_ptr0, in_ptr0, in_ptr1, out_ptr0, out_ptr1, out_ptr2, stream=stream)


def flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_precompile(only=None, **kw):
    if only in (None, 0):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c0_precompile(**kw)
    if only in (None, 1):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c1_precompile(**kw)
    if only in (None, 2):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c2_precompile(**kw)
    if only in (None, 3):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c3_precompile(**kw)
    if only in (None, 4):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c4_precompile(**kw)
    if only in (None, 5):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c5_precompile(**kw)
    if only in (None, 6):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c6_precompile(**kw)
    if only in (None, 7):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c7_precompile(**kw)
    if only in (None, 8):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c8_precompile(**kw)
    if only in (None, 9):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c9_precompile(**kw)
    if only in (None, 10):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c10_precompile(**kw)
    if only in (None, 11):
        flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3_c11_precompile(**kw)
