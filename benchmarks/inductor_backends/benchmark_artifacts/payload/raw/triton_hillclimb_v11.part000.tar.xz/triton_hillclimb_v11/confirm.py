import csv
import fcntl
import hashlib
import json
from pathlib import Path
import random
import statistics
import torch

from search import CASES,Case,prepare_baselines,measure,resources

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'confirmation'


def percentile(values,p):
    values=sorted(values);index=(len(values)-1)*p;lo=int(index);hi=min(lo+1,len(values)-1)
    return values[lo]+(values[hi]-values[lo])*(index-lo)


def confidence(reference,candidate):
    values=[100*(a-b)/a for a,b in zip(reference,candidate)]
    rng=random.Random(2026)
    boot=[statistics.median(rng.choices(values,k=len(values))) for _ in range(3000)]
    return dict(paired_median_time_saved_percent=statistics.median(values),bootstrap95_low=percentile(boot,.025),
                bootstrap95_high=percentile(boot,.975),paired_rounds=len(values))


if __name__=='__main__':
    OUT.mkdir(exist_ok=True)
    with Path('/dev/shm/pytorch-simd-v2-entry.lock').open('a') as entry,Path('/dev/shm/pytorch-simd-v2-benchmark.lock').open('a') as timing:
        fcntl.flock(entry,fcntl.LOCK_EX);fcntl.flock(timing,fcntl.LOCK_EX)
        rows=[]
        for name,model,fly_name,tri_name,selected in CASES:
            folder=OUT/name;folder.mkdir(exist_ok=True)
            prior=json.loads((ROOT/'matched_context'/name/'FINAL.json').read_text())
            configs=sorted([value for value in prior['finalists'] if 'config' in value],key=lambda value:value['median_us'])
            chosen=[('best',configs[0]['config'])]
            strict=next((value['config'] for value in configs if value['config']['math']==0),None)
            if strict and strict!=chosen[0][1]:
                chosen.append(('unchanged_math',strict))
            fly,native=prepare_baselines(model,fly_name,tri_name,selected,folder)
            case=Case(name,fly,native)
            entries=[dict(label='original',fn=case.native),dict(label='flydsl',fn=case.fly)]
            for label,cfg in chosen:
                entries.append(dict(label=label,config=cfg,fn=case.callable(cfg)))
            samples={value['label']:[] for value in entries}
            validation={value['label']:[] for value in entries}
            input_hashes=[]
            for seed in [999,1337]:
                case.refresh(seed)
                values=case.args[1] if name=='softmax' else case.x
                input_hashes.append(hashlib.sha256(values.flatten()[:2048].cpu().float().numpy().tobytes()).hexdigest())
                for value in entries:
                    compiled,error=case.validate(value['fn'])
                    validation[value['label']].append(error)
                    value['resources']=resources(compiled,folder,value['label'])
                measured=measure(case,entries,15,5)
                for value,result in zip(entries,measured):
                    samples[value['label']]+=result['samples_us']
            if len(set(input_hashes))!=2:
                raise RuntimeError('Confirmation inputs did not change across seeds')
            native_us=statistics.median(samples['original']);fly_us=statistics.median(samples['flydsl'])
            for value in entries:
                label=value['label'];median=statistics.median(samples[label])
                row=dict(case=name,model=model,label=label,config=json.dumps(value.get('config')),
                    median_us=median,original_triton_us=native_us,flydsl_us=fly_us,
                    time_saved_vs_original_percent=100*(native_us-median)/native_us,
                    time_saved_vs_flydsl_percent=100*(fly_us-median)/fly_us,
                    approximate_math=bool(value.get('config',{}).get('math',0)),
                    max_abs_error=max(validation[label]),**confidence(samples['original'],samples[label]))
                rows.append(row)
            report=dict(case=name,rows=[row for row in rows if row['case']==name],samples_us=samples,
                input_sample_hashes=input_hashes,validation_errors=validation,entries=[{k:v for k,v in entry.items() if k!='fn'} for entry in entries])
            (folder/'confirmation.json').write_text(json.dumps(report,indent=2)+'\n')
            print(json.dumps(report['rows'],indent=2),flush=True)
        with (OUT/'summary.csv').open('w',newline='') as output:
            writer=csv.DictWriter(output,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
        (OUT/'SUMMARY.json').write_text(json.dumps(rows,indent=2)+'\n')
