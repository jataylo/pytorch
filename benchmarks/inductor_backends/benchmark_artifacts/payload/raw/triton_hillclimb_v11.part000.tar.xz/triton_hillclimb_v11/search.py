import argparse
import ast
import csv
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import time

import torch
import torch.nn.functional as F
import triton
from torch._inductor.runtime import triton_heuristics
from kernels import pointwise, softmax_gl, softmax_tl
from test_kernels import softmax_inputs

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent
EVIDENCE = TASK / 'triton_flydsl_codegen_comparison_v10'
CASES = [
    ('softmax', 'MBartForCausalLM', 'flydsl_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_260867f3', 'triton_per_fused__safe_softmax_add_prepare_softmax_online_scalar_tensor_view_where_5', 11),
    ('gelu', 'BlenderbotForCausalLM', 'flydsl_fused_gelu_gelu_backward_view_2631963e', 'triton_poi_fused_gelu_gelu_backward_view_3', 1),
    ('cast_add', 'openai_whisper-tiny', 'flydsl_fused__to_copy_add_view_f3e09529', 'triton_poi_fused__to_copy_add_view_13', 9),
]


def load_module(path):
    spec=importlib.util.spec_from_file_location(path.stem,path)
    module=importlib.util.module_from_spec(spec)
    import sys
    sys.modules[path.stem]=module
    spec.loader.exec_module(module)
    return module


def prepare_baselines(model,fly_name,tri_name,selected,destination):
    fly_ast=ast.parse((EVIDENCE/(model+'--'+fly_name+'.py')).read_text())
    source=next(node.value for node in ast.walk(fly_ast) if isinstance(node,ast.Constant) and isinstance(node.value,str) and 'def '+fly_name+'_c0_kernel' in node.value)
    path=destination/(model.replace('-','_')+'_fly.py')
    path.write_text(source)
    fly_module=load_module(path)
    fly=getattr(fly_module,fly_name+f'_c{selected}_main')
    tri_ast=ast.parse((EVIDENCE/(model+'--'+tri_name+'.py')).read_text())
    source=next(node.value for node in ast.walk(tri_ast) if isinstance(node,ast.Constant) and isinstance(node.value,str) and 'def '+tri_name+'(' in node.value)
    tree=ast.parse(source)
    for node in tree.body:
        if isinstance(node,ast.FunctionDef):
            decorator=next(value for value in node.decorator_list if isinstance(value,ast.Call))
            keywords={value.arg:value.value for value in decorator.keywords}
            block=4 if model=='MBartForCausalLM' else 4096 if model=='BlenderbotForCausalLM' else 1024
            config=ast.parse(f"triton.Config({{'XBLOCK':{block}}},num_warps=4,num_stages=1)",mode='eval').body
            kind='PERSISTENT_REDUCTION' if model=='MBartForCausalLM' else 'POINTWISE'
            replacement=ast.Call(func=ast.parse('triton_heuristics.cached_autotune',mode='eval').body,args=[],keywords=[
                ast.keyword(arg='size_hints',value=keywords['size_hints']),
                ast.keyword(arg='configs',value=ast.List(elts=[config],ctx=ast.Load())),
                ast.keyword(arg='triton_meta',value=keywords['triton_meta']),
                ast.keyword(arg='inductor_meta',value=keywords['inductor_meta']),
                ast.keyword(arg='heuristic_type',value=ast.parse('triton_heuristics.HeuristicType.'+kind,mode='eval').body),
                ast.keyword(arg='filename',value=ast.Name(id='__file__',ctx=ast.Load()))])
            node.decorator_list=[replacement,*[value for value in node.decorator_list if isinstance(value,ast.Attribute) and value.attr=='jit']]
            ast.fix_missing_locations(node)
    path=destination/(model.replace('-','_')+'_native.py')
    path.write_text(ast.unparse(tree)+'\n')
    return fly,getattr(load_module(path),tri_name)


class Case:
    def __init__(self,name,fly,native):
        self.name=name
        torch.manual_seed(2026)
        if name=='softmax':
            self.m,self.r=16384,128
            x,mask,outputs,expected=softmax_inputs(self.m,self.r,'cuda')
            self.args=(outputs[0],x,mask,outputs[1],outputs[2],outputs[3])
            self.outputs=outputs
            self.expected=expected
            self.native=lambda:native.run(*self.args,self.m,self.r,stream=torch.cuda.current_stream().cuda_stream)
            self.fly=lambda:fly(*self.args)
            self.reset=lambda:None
            self.warm=[x.view(torch.uint8)]
            self.flush_mb=256
        else:
            self.n=41943040 if name=='gelu' else 4608000
            self.x=torch.randn(self.n,device='cuda',dtype=torch.bfloat16)
            self.a=torch.randn_like(self.x)
            if name=='gelu':
                self.work=self.a.clone()
                self.args=(self.work,self.x,self.work)
                self.outputs=[self.work]
                xv=self.x.detach().requires_grad_(True)
                self.expected=[torch.autograd.grad(F.gelu(xv),xv,self.a)[0].detach()]
                self.reset=lambda:self.work.copy_(self.a)
                self.native=lambda:native.run(self.work,self.x,self.n,stream=torch.cuda.current_stream().cuda_stream)
                self.fly=lambda:fly(self.work,self.x)
            else:
                out=torch.empty_like(self.x,dtype=torch.float32)
                self.args=(self.a,self.x,out)
                self.outputs=[out]
                self.expected=[self.a.float()+self.x.float()]
                self.reset=lambda:None
                self.native=lambda:native.run(self.a,self.x,out,self.n,stream=torch.cuda.current_stream().cuda_stream)
                self.fly=lambda:fly(self.a,self.x,out)
            self.warm=[self.work.view(torch.uint8)] if name=='gelu' else [self.a.view(torch.uint8),self.x.view(torch.uint8)]
            self.flush_mb=256

    def refresh(self,seed):
        torch.manual_seed(seed)
        if self.name=='softmax':
            x,mask,_,expected=softmax_inputs(self.m,self.r,'cuda',seed=seed)
            self.args[1].copy_(x);self.args[2].copy_(mask)
            self.expected=expected
        else:
            self.x.normal_();self.a.normal_()
            if self.name=='gelu':
                x=self.x.detach().requires_grad_(True)
                self.expected=[torch.autograd.grad(F.gelu(x),x,self.a)[0].detach()]
            else:
                self.expected=[self.a.float()+self.x.float()]

    def validate(self,fn):
        self.reset()
        compiled=fn()
        torch.cuda.synchronize()
        errors=[]
        for actual,expected in zip(self.outputs,self.expected):
            if self.name=='cast_add':
                torch.testing.assert_close(actual,expected,atol=0,rtol=0)
            elif self.name=='gelu':
                torch.testing.assert_close(actual,expected,atol=.003,rtol=.02,equal_nan=True)
            else:
                torch.testing.assert_close(actual,expected,atol=2e-5,rtol=2e-5,equal_nan=True)
            if actual.dtype!=torch.bool:
                errors.append((actual.float()-expected.float()).abs().nan_to_num().max().item())
        return compiled,max(errors,default=0)

    def callable(self,cfg):
        if self.name=='softmax':
            common=dict(M=self.m,R=self.r,ROWS=cfg['rows'],MATH=cfg['math'],num_warps=cfg['warps'],enable_fp_fusion=True)
            if cfg['kind']=='gl':
                return lambda:softmax_gl[(triton.cdiv(self.m,cfg['rows']),)](*self.args,LANES=cfg['lanes'],VEC=cfg['vec'],WARPS=cfg['warps'],**common)
            return lambda:softmax_tl[(triton.cdiv(self.m,cfg['rows']),)](*self.args,**common)
        return lambda:pointwise[(triton.cdiv(self.n,cfg['block']*cfg['unroll']),)](*self.args,self.n,cfg['block'],cfg['unroll'],int(self.name=='gelu'),cfg['math'],num_warps=cfg['warps'],waves_per_eu=cfg['waves'],enable_fp_fusion=True)


def measure(case,entries,rounds,reps):
    flush=torch.empty(case.flush_mb<<20,device='cuda',dtype=torch.uint8)
    pairs=[[[torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)] for _ in range(reps)] for _ in entries]
    samples=[[] for _ in entries]
    for round_index in range(rounds):
        torch.cuda._sleep(40_000_000)
        for j in range(len(entries)):
            i=(round_index+j)%len(entries)
            for a,b in pairs[i]:
                flush.zero_()
                case.reset()
                for value in case.warm:
                    value.add_(0)
                a.record();entries[i]['fn']();b.record()
        torch.cuda.synchronize()
        for i,events in enumerate(pairs):
            samples[i].append(statistics.mean(a.elapsed_time(b) for a,b in events)*1000)
    return [dict(median_us=statistics.median(values),samples_us=values,spread_percent=100*(max(values)/min(values)-1)) for values in samples]


def key(cfg):
    return json.dumps(cfg,sort_keys=True)


def neighbors(case,cfg):
    options={'rows':[1,2,4,8,16,32],'warps':[1,2,4,8],'math':[0,1,2]}
    if case.name=='softmax':
        if cfg['kind']=='gl':
            options.update(lanes=[8,16,32,64],vec=[1,2,4,8])
    else:
        options={'block':[256,512,1024,2048,4096,8192],'unroll':[1,2,4,8],'warps':[1,2,4,8],
                 'waves':[0,1,2,4],'math':[0,1,2,3] if case.name=='gelu' else [0]}
    result=[]
    for name,values in options.items():
        index=values.index(cfg[name])
        for adjacent in [index-1,index+1]:
            if 0<=adjacent<len(values):
                candidate=dict(cfg);candidate[name]=values[adjacent]
                if case.name!='softmax' and candidate['block']*candidate['unroll']/(candidate['warps']*64)>128:
                    continue
                result.append(candidate)
    return result


def resources(compiled,destination,label):
    if compiled is None or not hasattr(compiled,'asm'):
        return {}
    result={key:getattr(compiled,key,None) for key in ['n_regs','n_spills']}
    result['shared']=getattr(compiled.metadata,'shared',None)
    for kind in ['ttgir','amdgcn']:
        text=compiled.asm.get(kind)
        if text:
            (destination/(label+'.'+kind)).write_text(text)
    return result


def run_case(info,args,destination):
    name,model,fly_name,tri_name,selected=info
    folder=destination/name;folder.mkdir(exist_ok=True)
    fly,native=prepare_baselines(model,fly_name,tri_name,selected,folder)
    case=Case(name,fly,native)
    baselines=[]
    for label,fn in [('original_triton',case.native),('selected_flydsl',case.fly)]:
        compiled,error=case.validate(fn)
        entry=dict(label=label,fn=fn,error=error,resources=resources(compiled,folder,label))
        baselines.append(entry)
    if name=='softmax':
        seeds=[dict(kind='tl',rows=4,warps=4,math=0),dict(kind='gl',rows=4,warps=1,math=0,lanes=16,vec=4)]
    else:
        seeds=[dict(block=4096 if name=='gelu' else 1024,warps=4,unroll=1,math=0,waves=0),
               dict(block=1024 if name=='gelu' else 256,warps=2 if name=='gelu' else 1,unroll=1 if name=='gelu' else 8,math=0,waves=0)]
    if name=='gelu':
        seeds.append(dict(block=1024,warps=2,unroll=1,math=2,waves=0))
        seeds.append(dict(block=1024,warps=2,unroll=1,math=3,waves=0))
    tried={};history=[];frontier=seeds
    for step in range(args.steps):
        configurations={key(cfg):cfg for seed in frontier for cfg in [seed,*neighbors(case,seed)] if key(cfg) not in tried}
        entries=[]
        for cfg_key,cfg in list(configurations.items())[:args.max_candidates-len(tried)]:
            fn=case.callable(cfg);entry=dict(label=cfg_key,config=cfg,fn=fn)
            started=time.time()
            try:
                compiled,error=case.validate(fn)
                entry.update(error=error,resources=resources(compiled,folder,'candidate_'+hashlib.sha256(cfg_key.encode()).hexdigest()[:10]),compile_validation_seconds=time.time()-started)
                entries.append(entry)
            except Exception as exc:
                tried[cfg_key]=dict(config=cfg,status='rejected',error=str(exc)[:2000])
        if entries:
            batch=[*baselines,*entries]
            timings=measure(case,batch,3,3)
            for entry,timing in zip(batch,timings):
                entry.update(timing)
                if 'config' in entry:
                    tried[entry['label']]={k:v for k,v in entry.items() if k!='fn'}
                    tried[entry['label']].update(status='measured',search_step=step,
                        speedup_vs_original_percent=100*(timings[0]['median_us']-entry['median_us'])/timings[0]['median_us'])
            history.append(dict(step=step,original_us=timings[0]['median_us'],flydsl_us=timings[1]['median_us'],new_candidates=len(entries)))
        winners=sorted([value for value in tried.values() if value['status']=='measured'],key=lambda value:value['median_us'])[:2]
        frontier=[winner['config'] for winner in winners]
        for math_mode in ([0,1,2,3] if case.name=='gelu' else [0,1,2]):
            options=[value for value in tried.values() if value['status']=='measured' and value['config']['math']==math_mode]
            if options:
                candidate=min(options,key=lambda value:value['median_us'])['config']
                if candidate not in frontier:
                    frontier.append(candidate)
        snapshot=dict(case=name,history=history,trials=list(tried.values()))
        (folder/'search.json').write_text(json.dumps(snapshot,indent=2)+'\n')
        print(json.dumps(dict(case=name,step=step,trials=len(tried),best=winners[0]['config'] if winners else None,best_us=winners[0]['median_us'] if winners else None)),flush=True)
        if not frontier or len(tried)>=args.max_candidates:
            break
    winners=sorted([value for value in tried.values() if value['status']=='measured'],key=lambda value:value['median_us'])[:5]
    strict=[value for value in tried.values() if value['status']=='measured' and value['config']['math']==0]
    if strict:
        extra=min(strict,key=lambda value:value['median_us'])
        if all(value['label']!=extra['label'] for value in winners):
            winners.append(extra)
    finals=[*baselines]
    for winner in winners:
        fn=case.callable(winner['config']);compiled,error=case.validate(fn)
        finals.append(dict(label=winner['label'],config=winner['config'],fn=fn,error=error,resources=resources(compiled,folder,'final_'+str(len(finals)-2))))
    timings=measure(case,finals,9,5)
    for entry,timing in zip(finals,timings):
        entry.update(timing)
    case.refresh(606)
    for entry in finals:
        _,error=case.validate(entry['fn'])
        entry['fresh_input_max_abs_error']=error
    heldout=measure(case,finals,9,5)
    for entry,repeat in zip(finals,heldout):
        entry['heldout_samples_us']=repeat['samples_us']
        entry['median_us']=statistics.median(entry['samples_us']+repeat['samples_us'])
    native_us,fly_us=finals[0]['median_us'],finals[1]['median_us']
    for entry in finals:
        entry.update(time_saved_vs_original_percent=100*(native_us-entry['median_us'])/native_us,
                     time_saved_vs_flydsl_percent=100*(fly_us-entry['median_us'])/fly_us)
    summary=dict(case=name,model=model,original_triton_us=native_us,selected_flydsl_us=fly_us,
                 finalists=[{k:v for k,v in entry.items() if k!='fn'} for entry in finals],trials=len(tried),history=history)
    (folder/'FINAL.json').write_text(json.dumps(summary,indent=2)+'\n')
    return summary


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--case',choices=[x[0] for x in CASES],action='append')
    parser.add_argument('--steps',type=int,default=4);parser.add_argument('--max-candidates',type=int,default=55)
    parser.add_argument('--output',type=Path,default=ROOT/'results')
    args=parser.parse_args();args.output.mkdir(exist_ok=True)
    with Path('/dev/shm/pytorch-simd-v2-entry.lock').open('a') as entry, Path('/dev/shm/pytorch-simd-v2-benchmark.lock').open('a') as timing:
        fcntl.flock(entry,fcntl.LOCK_EX);fcntl.flock(timing,fcntl.LOCK_EX)
        from torch._inductor.codegen.flydsl import flydsl_simd_runtime
        if 'fallback_fixes_v4' not in flydsl_simd_runtime.__file__:
            raise RuntimeError('Launch through the validated v4 source overlay')
        provenance=dict(torch_version=torch.__version__,triton_version=triton.__version__,
                        runtime_file=flydsl_simd_runtime.__file__,runtime_sha256=hashlib.sha256(Path(flydsl_simd_runtime.__file__).read_bytes()).hexdigest(),
                        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                        kernels_sha256=hashlib.sha256((ROOT/'kernels.py').read_bytes()).hexdigest())
        (args.output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
        torch.cuda.set_device(0)
        summaries=[]
        for info in CASES:
            if args.case and info[0] not in args.case:
                continue
            summaries.append(run_case(info,args,args.output))
        (args.output/'SUMMARY.json').write_text(json.dumps(summaries,indent=2)+'\n')
        print(json.dumps([dict(case=x['case'],original_us=x['original_triton_us'],fly_us=x['selected_flydsl_us'],best=min(x['finalists'],key=lambda value:value['median_us'])) for x in summaries],indent=2),flush=True)
