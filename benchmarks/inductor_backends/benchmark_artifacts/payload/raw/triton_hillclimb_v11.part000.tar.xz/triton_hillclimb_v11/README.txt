TRITON HILL CLIMB: EXPERIMENTAL KERNEL CANDIDATES

Results: hillclimb_results.csv. Independent confirmation: confirmation_cdf/SUMMARY.json and per-case confirmation.json, TTGIR and AMD ISA. Matched search records: matched_context/*/search.json, plus GELU formulation search gelu_cdf/gelu/search.json. Source/validation proof: VALIDATION.json.

Targets are exact model-derived shapes: MBart16384x128 masked softmax with max/sum/invalid outputs; Blenderbot41943040-element BF16 GELU backward; Whisper4608000-element BF16+BF16->FP32 cast/add. Random Gaussian replay inputs, not saved model activations. All comparisons use the same inputs per trial.

Two earlier exploratory searches (results/, confirmed/) used simpler direct-JIT native launch and approximate cache settings. They are archived and are NOT the accepted numbers. matched_context and confirmation_cdf preserve the original Inductor native metadata and selector cache context.

Accepted findings are kernel-level: softmax13.0% time saving with unchanged math functions,23.5% with approximate exp/reciprocal+explicit subwave Gluon layout; GELU27.6% with a shared-Gaussian CDF approximation,while unchanged-math scheduling has no clear gain; cast/add18.7% in latest confirmation,15.2% in prior independent confirmation,exact numerical outputs. Latest confirmations beat FlyDSL for GELU(17.1%) and approximately tie cast/add(~1.4% faster),while softmax remains~2.2%slower than FlyDSL. All percentages are time saved versus each named baseline, not throughput percentages.

These candidates are standalone Triton/Gluon kernels; they are not integrated into default Inductor lowering. Softmax/GELU approximation modes have an explicit accuracy distinction. All tested FP32/BF16 checks pass stated tolerances, including holdout shapes/tails; this does not establish bitwise equivalence or a global error bound. Full models have not been rerun with these candidates. Empirical paired-round bootstrap bounds describe timing noise in this replay, not universal performance.

Run tests with the existing run_env.sh. Run search through fallback_fixes_v4/agent_space/run_overlay.py to preserve the validated FlyDSL runtime. Use a new --output directory when rerunning. All GPU scripts take the existing benchmark entry/timing locks, except the initial small unit script run only in a verified idle window. No production sources or frozen full-model source fingerprints were modified.

Earlier full three-backend model report also finished; files are in ../three_backend_report_v7/. One earlier mixed GPT120 timed RCCL fault remains separately documented and is excluded from validated headlines.
