import triton
import triton.language as tl
from triton.language.extra import libdevice
from triton.experimental import gluon
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language.extra import libdevice as gdev


@triton.jit
def erf_candidate(x):
    ax = tl.abs(x)
    z = ax * ax
    small = 1.1283791065216064 + z * (-0.37612324953079224 + z * (0.11280179768800735 + z * (-0.02671131119132042 + z * (0.00491755036637187 + z * -0.000563141773454845))))
    t = tl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[1.0 + 0.3275911 * ax], dtype=tl.float32, is_pure=True, pack=1)
    poly = t * (0.254829592 + t * (-0.284496736 + t * (1.421413741 + t * (-1.453152027 + t * 1.061405429))))
    big = 1.0 - poly * tl.exp(-z)
    result = tl.where(ax < 1.0, ax * small, big)
    return libdevice.copysign(result, x)


@triton.jit
def pointwise(in_out, x, y, N: tl.constexpr, BLOCK: tl.constexpr, UNROLL: tl.constexpr, KIND: tl.constexpr, MATH: tl.constexpr):
    for u in tl.static_range(UNROLL):
        i = tl.program_id(0) * (BLOCK * UNROLL) + u * BLOCK + tl.arange(0, BLOCK)
        mask = i < N
        a = tl.load(in_out + i, mask, other=0).to(tl.float32)
        b = tl.load(x + i, mask, other=0).to(tl.float32)
        if KIND == 0:
            value = a + b
        else:
            if MATH == 2:
                erf = erf_candidate(b * 0.7071067811865476)
            else:
                erf = libdevice.erf(b * 0.7071067811865476)
            if MATH == 0:
                ex = libdevice.exp(-0.5 * b * b)
            else:
                ex = tl.exp(-0.5 * b * b)
            value = a * (0.5 * (1.0 + erf) + b * (0.3989422804014327 * ex))
        tl.store(y + i, value, mask)


@triton.jit
def softmax_tl(mask_out, x, mask, maxima, sums, output, M: tl.constexpr, R: tl.constexpr, ROWS: tl.constexpr, MATH: tl.constexpr):
    row = tl.program_id(0) * ROWS + tl.arange(0, ROWS)
    col = tl.arange(0, R)
    v = tl.load(x + row[:, None] * R + col[None, :], row[:, None] < M, other=-float('inf'))
    valid = tl.load(mask + (row[:, None] % 128) * R + (row[:, None] // 2048) * (128*R) + col[None, :], row[:, None] < M, other=0)
    v = v + tl.where(valid, 0.0, -float('inf'))
    maxval = tl.max(v, 1)
    if MATH == 0:
        e = libdevice.exp(v - maxval[:, None])
    else:
        e = tl.exp(v - maxval[:, None])
    total = tl.sum(e, 1)
    all_invalid = tl.sum((v != -float('inf')).to(tl.int32), 1) == 0
    if MATH == 2:
        reciprocal = tl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[total], dtype=tl.float32, is_pure=True, pack=1)
        p = e * reciprocal[:, None]
    else:
        p = e / total[:, None]
    p = tl.where(all_invalid[:, None], 0.0, p)
    tl.store(output + row[:, None]*R + col[None, :], p, row[:, None] < M)
    tl.store(maxima + row, maxval, row < M)
    tl.store(sums + row, total, row < M)
    tl.store(mask_out + row, all_invalid, row < M)


@gluon.jit
def softmax_gl(mask_out, x, mask, maxima, sums, output, M: gl.constexpr, R: gl.constexpr,
               ROWS: gl.constexpr, LANES: gl.constexpr, VEC: gl.constexpr, WARPS: gl.constexpr, MATH: gl.constexpr):
    layout: gl.constexpr = gl.BlockedLayout([1, VEC], [64//LANES, LANES], [WARPS, 1], [1, 0])
    row = gl.program_id(0)*ROWS + gl.arange(0, ROWS, layout=gl.SliceLayout(1, layout))
    col = gl.arange(0, R, layout=gl.SliceLayout(0, layout))
    v = gl.load(x + row[:, None]*R + col[None, :], row[:, None] < M, other=-float('inf'))
    valid = gl.load(mask + (row[:, None] % 128)*R + (row[:, None]//2048)*(128*R) + col[None, :], row[:, None] < M, other=0)
    v = v + gl.where(valid, 0.0, -float('inf'))
    maxval = gl.max(v, 1)
    if MATH == 0:
        e = gdev.exp(v - maxval[:, None])
    else:
        e = gl.exp(v - maxval[:, None])
    total = gl.sum(e, 1)
    all_invalid = gl.sum((v != -float('inf')).to(gl.int32), 1) == 0
    if MATH == 2:
        reciprocal = gl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[total], dtype=gl.float32, is_pure=True, pack=1)
        p = e*reciprocal[:, None]
    else:
        p = e/total[:, None]
    p = gl.where(all_invalid[:, None], 0.0, p)
    gl.store(output + row[:, None]*R + col[None, :], p, row[:, None] < M)
    gl.store(maxima + row, maxval, row < M)
    gl.store(sums + row, total, row < M)
    gl.store(mask_out + row, all_invalid, row < M)
