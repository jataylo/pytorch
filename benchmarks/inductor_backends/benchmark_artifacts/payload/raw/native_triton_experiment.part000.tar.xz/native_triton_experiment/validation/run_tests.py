import json
import os
import re
import subprocess
from pathlib import Path

output = Path(__file__).resolve().parent
scratch = output.parent.parent
source = scratch / 'pytorch_triton_only'
environment = os.environ | {
    'AMD_CODEGEN_SOURCE_ROOT': str(source),
    'CUDA_VISIBLE_DEVICES': '2',
    'TORCHINDUCTOR_COMPILE_THREADS': '1',
    'TRITON_DEFAULT_FP_FUSION': '1',
}
results = {}
for name in [
    'test_amd_kernel_optimizations',
    'test_amd_kernel_autotune',
    'test_amd_extended_kernel_optimizations',
    'test_amd_further_kernel_optimizations',
    'test_amd_kernel_hardware',
    'test_amd_hardware_configs',
    'test_amd_benchmark_protocol',
    'test_flydsl_backend_selection_cache',
    'test_amd_native_triton',
]:
    log_path = output / (name + '.log')
    with log_path.open('w') as log:
        result = subprocess.run(
            ['bash', str(scratch / 'run_env.sh'), str(scratch / 'run_source_overlay.py'),
             str(source / 'test/inductor' / (name + '.py'))],
            env=environment, stdout=log, stderr=subprocess.STDOUT,
        )
    text = log_path.read_text()
    count = re.search(r'Ran (\d+) tests?', text)
    results[name] = {
        'returncode': result.returncode,
        'tests': int(count.group(1)) if count else 0,
        'passed': result.returncode == 0 and '\nOK' in text,
    }
    (output / 'test_results.json').write_text(json.dumps(results, indent=2))
    print(name, results[name], flush=True)
    if result.returncode:
        raise RuntimeError('Test failed: ' + name)
print('TOTAL', sum(row['tests'] for row in results.values()), flush=True)
