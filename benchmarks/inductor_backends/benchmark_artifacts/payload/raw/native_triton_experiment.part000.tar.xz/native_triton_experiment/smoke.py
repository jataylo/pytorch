import torch
from torch._inductor import config
from torch._inductor.utils import run_and_get_code
x=torch.randn(128,1024,device='cuda')
for name,fn,args in [('softmax',lambda x:torch.softmax(x,-1),(x,)),('cast',lambda x:x.to(torch.bfloat16),(x.flatten(),)),('nanmax',lambda x:torch.maximum(x,torch.zeros_like(x)).sum(-1),(x,))]:
    torch._dynamo.reset()
    with config.patch({'triton.amd_kernel_optimizations':True,'triton.amd_extended_kernel_optimizations':True,'triton.amd_further_kernel_optimizations':True,'triton.amd_use_gluon':False,'triton.cudagraphs':False}):
        y,code=run_and_get_code(torch.compile(fn,fullgraph=True),*args)
        torch.testing.assert_close(y,fn(*args))
        source='\n'.join(code)
        print(name,'native',source.count("'amd_native_family'"),'gluon',source.count('gluon'),flush=True)
        if 'gluon.jit' in source or 'triton.experimental.gluon' in source:raise RuntimeError('unexpected Gluon')
