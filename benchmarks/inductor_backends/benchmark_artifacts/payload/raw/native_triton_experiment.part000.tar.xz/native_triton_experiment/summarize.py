"""Summarize completed native Triton experiment cases without starting GPU work."""

import argparse
import csv
import html
import json
import math
from pathlib import Path
import statistics

FAMILIES = (
    'cast_add', 'broadcast', 'transpose', 'softmax', 'softmax_backward',
    'norm_backward', 'cross_entropy_backward', 'cumsum',
)
CASES = tuple(f'{family}_{dtype}' for family in FAMILIES for dtype in ('bfloat16', 'float32'))
VARIANTS = ('triton', 'gluon', 'native_triton')
CACHES = ('cold', 'warm')
PROTOCOLS = {
    'direct': dict(measured_invocation='captured_gpu_kernel_sequence', host_overhead_included=False),
    'graph_replay': dict(measured_invocation='inline_graph_replay_events', host_overhead_included=True),
}
LABELS = {'triton': 'Stock Triton', 'gluon': 'Gluon', 'native_triton': 'Native Triton'}
COLORS = {'triton': '#3877bb', 'gluon': '#c98226', 'native_triton': '#19866c'}


def geomean(values):
    return math.exp(statistics.mean(math.log(value) for value in values)) if values else None


def write_csv(path, rows):
    if not rows:
        path.write_text('')
        return
    with path.open('w', newline='') as target:
        writer = csv.DictWriter(target, fieldnames=list(dict.fromkeys(key for row in rows for key in row)))
        writer.writeheader()
        writer.writerows(rows)


def load_results(directory):
    rows, failures, completed = [], [], []
    for path in sorted(directory.glob('*/result.json')):
        report = json.loads(path.read_text())
        case = report['case']['case']
        if case not in CASES:
            raise RuntimeError(f'Unexpected experiment case: {case}')
        completed.append(case)
        rows.extend(report['rows'])
        failures.extend(dict(case=case, **failure) for failure in report['failures'])
    # The runner owns failures.json. Preserve any records it has already exported.
    failure_file = directory / 'failures.json'
    if failure_file.exists():
        try:
            failures.extend(json.loads(failure_file.read_text()))
        except json.JSONDecodeError:
            pass  # The runner may be rewriting its export; completed reports remain authoritative.
    failures = list({json.dumps(item, sort_keys=True): item for item in failures}.values())
    lookup = {}
    for row in rows:
        key = (row['case'], row['invocation'], row['cache'], row['variant'])
        if key in lookup:
            raise RuntimeError(f'Duplicate measurement: {key}')
        runtime = float(row['runtime_us'])
        if not math.isfinite(runtime) or runtime <= 0:
            raise RuntimeError(f'Invalid runtime for {key}: {runtime}')
        lookup[key] = row
    return lookup, failures, completed


def aggregate(lookup, cases, invocation, cache):
    caches = CACHES if cache == 'combined' else (cache,)
    complete = [
        case for case in cases
        if all((case, invocation, mode, variant) in lookup for mode in CACHES for variant in VARIANTS)
    ]
    result = dict(
        invocation=invocation, **PROTOCOLS[invocation], cache=cache,
        common_cases=len(complete), observations=len(complete) * len(caches),
        expected_cases=len(cases), coverage='complete' if len(complete) == len(cases) else 'partial',
    )
    for variant in VARIANTS:
        result[f'{variant}_runtime_us_geomean'] = geomean([
            float(lookup[case, invocation, mode, variant]['runtime_us'])
            for case in complete for mode in caches
        ])
    for baseline in ('triton', 'gluon'):
        factor = geomean([
            float(lookup[case, invocation, mode, baseline]['runtime_us'])
            / float(lookup[case, invocation, mode, 'native_triton']['runtime_us'])
            for case in complete for mode in caches
        ])
        result[f'native_vs_{baseline}_speedup_factor'] = factor
        result[f'native_vs_{baseline}_speedup_percent'] = 100 * (factor - 1) if factor is not None else None
    return result, complete


def chart(directory, lookup, invocation, coverage, completed):
    width, left, right = 1500, 410, 1260
    height = 180 + 83 * len(CASES)
    runtimes = {}
    for case in CASES:
        for variant in VARIANTS:
            if all((case, invocation, cache, variant) in lookup for cache in CACHES):
                runtimes[case, variant] = geomean([
                    float(lookup[case, invocation, cache, variant]['runtime_us']) for cache in CACHES
                ])
    maximum = max([1, *runtimes.values()]) * 1.3

    def xpos(value):
        return left + (right - left) * (math.log10(max(value, 0.1)) + 1) / (math.log10(maximum) + 1)

    def text(x, y, value, size=13, anchor='start', fill='#253445'):
        escaped = html.escape(str(value), quote=True)
        return (
            f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" '
            f'text-anchor="{anchor}" fill="{fill}">{escaped}</text>'
        )

    title = (
        'Captured GPU kernel sequences: host overhead excluded' if invocation == 'direct'
        else 'Inline graph replay: host launch gaps may contribute'
    )
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/><g font-family="Arial,sans-serif">',
        text(24, 30, title, 22),
        text(24, 55, f'{coverage}/16 common three-variant cases | equal-weight geometric mean of cold/warm runtimes | lower is faster'),
    ]
    for index, variant in enumerate(VARIANTS):
        x = 30 + index * 250
        parts.extend([
            f'<rect x="{x}" y="76" width="15" height="13" fill="{COLORS[variant]}"/>',
            text(x + 23, 88, LABELS[variant]),
        ])
    for exponent in range(-1, math.ceil(math.log10(maximum)) + 1):
        for factor in (1, 3):
            tick = 10 ** exponent * factor
            if tick > maximum:
                continue
            x = xpos(tick)
            parts.extend([
                f'<path d="M{x:.2f},108 V{height - 45}" stroke="#dde3e9"/>',
                text(x, height - 25, f'{tick:g}', 11, 'middle'),
            ])
    for index, case in enumerate(CASES):
        y = 125 + index * 83
        label = case.replace('_bfloat16', ' / BF16').replace('_float32', ' / FP32')
        parts.append(text(left - 15, y + 24, label, 12, 'end'))
        for offset, variant in enumerate(VARIANTS):
            value = runtimes.get((case, variant))
            bar_y = y + offset * 22
            if value is None:
                status = 'failed / unavailable' if case in completed else 'pending'
                parts.append(text(left + 8, bar_y + 13, status, 11, fill=COLORS[variant]))
                continue
            end = xpos(value)
            parts.extend([
                f'<rect x="{left}" y="{bar_y}" width="{max(0.5, end - left):.2f}" height="16" fill="{COLORS[variant]}"/>',
                text(end + 7, bar_y + 13, f'{value:.3f} us', 11),
            ])
    parts.extend([
        text((left + right) / 2, height - 5, 'Runtime (microseconds, log scale; bars start at 0.1 us)', 12, 'middle'),
        '</g></svg>',
    ])
    stem = 'runtime_chart' if invocation == 'direct' else 'graph_replay_runtime_chart'
    (directory / f'{stem}.svg').write_text('\n'.join(parts) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, default=Path(__file__).resolve().parent / 'results')
    parser.add_argument('--skip-plots', action='store_true')
    args = parser.parse_args()
    directory = args.results
    lookup, failures, completed = load_results(directory)
    per_case = []
    for case in CASES:
        for invocation in PROTOCOLS:
            for cache in CACHES:
                measurements = {variant: lookup.get((case, invocation, cache, variant)) for variant in VARIANTS}
                row = dict(
                    case=case, family=case.rsplit('_', 1)[0], dtype=case.rsplit('_', 1)[1],
                    invocation=invocation, **PROTOCOLS[invocation], cache=cache,
                    status='complete' if all(measurements.values()) else 'incomplete',
                )
                for variant, measurement in measurements.items():
                    row[f'{variant}_runtime_us'] = measurement['runtime_us'] if measurement else None
                    row[f'{variant}_p10_us'] = measurement['p10_us'] if measurement else None
                    row[f'{variant}_p90_us'] = measurement['p90_us'] if measurement else None
                for baseline in ('triton', 'gluon'):
                    base, native = measurements[baseline], measurements['native_triton']
                    factor = float(base['runtime_us']) / float(native['runtime_us']) if base and native else None
                    row[f'native_vs_{baseline}_speedup_factor'] = factor
                    row[f'native_vs_{baseline}_speedup_percent'] = 100 * (factor - 1) if factor is not None else None
                per_case.append(row)
    write_csv(directory / 'per_case.csv', per_case)
    per_op = []
    for family in FAMILIES:
        cases = [case for case in CASES if case.rsplit('_', 1)[0] == family]
        for invocation in PROTOCOLS:
            for cache in (*CACHES, 'combined'):
                result, _ = aggregate(lookup, cases, invocation, cache)
                per_op.append(dict(family=family, **result))
    write_csv(directory / 'per_op.csv', per_op)
    summaries = {}
    for invocation in PROTOCOLS:
        combined, common = aggregate(lookup, CASES, invocation, 'combined')
        summaries[invocation] = dict(
            **combined, common_case_names=common,
            excluded_case_names=[case for case in CASES if case not in common],
            by_cache={cache: aggregate(lookup, CASES, invocation, cache)[0] for cache in CACHES},
        )
        if not args.skip_plots:
            chart(directory, lookup, invocation, len(common), completed)
    summary = dict(
        source='completed per-case result.json snapshots; runner exports are not modified',
        expected_cases=16, completed_cases=len(completed), completed_case_names=completed,
        headline='direct', headline_eligible=summaries['direct']['common_cases'] == 16,
        speedup_definition='100 * (geomean(baseline_runtime_us / native_runtime_us) - 1)',
        cache_weighting='Equal weights for cold and warm within each case, then equal weights across common cases',
        common_case_policy='All three variants and both cache modes must exist; the same common cases are used for both comparisons',
        summaries=summaries, failure_count=len(failures), failures=failures,
    )
    (directory / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(dict(
        summary=str(directory / 'summary.json'), common_cases=summaries['direct']['common_cases'],
        headline_eligible=summary['headline_eligible'], failures=len(failures),
        native_vs_stock_percent=summaries['direct']['native_vs_triton_speedup_percent'],
        native_vs_gluon_percent=summaries['direct']['native_vs_gluon_speedup_percent'],
    ), indent=2))


if __name__ == '__main__':
    main()
