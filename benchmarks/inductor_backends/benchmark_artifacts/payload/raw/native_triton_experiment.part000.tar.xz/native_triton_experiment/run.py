import importlib.util, os, json, csv, math, statistics
from pathlib import Path
from contextlib import contextmanager
import torch
from torch._inductor import config
r=Path(__file__).resolve().parent.parent
root=Path(os.environ['AMD_CODEGEN_SOURCE_ROOT'])
spec=importlib.util.spec_from_file_location('experiment',r/'inductor_hillclimb_v16/benchmark.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
base=b.base
base.VARIANTS=('triton','gluon','native_triton')
@contextmanager
def patch(variant,path):
    with b.patch('optimized_triton' if variant!='triton' else 'triton',path):
        with config.patch({'triton.amd_use_gluon': variant=='gluon'}):
            yield
base.patch=patch
out=Path(__file__).resolve().parent/'results';out.mkdir(exist_ok=True)
cases=[]
for family,shape in [('cast_add',(4608000,)),('broadcast',(4608000,)),('transpose',(16,32,128,80)),('softmax',(4096,1024)),('softmax_backward',(1024,8192)),('norm_backward',(4096,1024)),('cross_entropy_backward',(256,1024)),('cumsum',(64,32768))]:
    for dtype in ['bfloat16','float32']:
        cases.append(dict(family=family,shape=shape,dtype=dtype,case=f'{family}_{dtype}'))
rows=[];failures=[]
for case in cases:
    result=base.run_case(case,out,5,5)
    rows.extend(result['rows']);failures.extend(dict(case=case['case'],**x) for x in result['failures'])
    (out/'failures.json').write_text(json.dumps(failures,indent=2))
    if rows:
        with (out/'raw.csv').open('w') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(case['case'], 'failures',len(result['failures']),flush=True)
print('DONE',len(rows),'rows',len(failures),'failures',flush=True)
