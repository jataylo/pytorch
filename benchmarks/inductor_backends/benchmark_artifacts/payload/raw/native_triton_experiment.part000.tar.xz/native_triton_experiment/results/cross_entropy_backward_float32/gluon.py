# AOT ID: ['40_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/native_probe_cache/inductor/e6/ce6fnbpcms7xxoqvz5whjel5b37po3pmiea5enx3v2lacgia32zi.py
# Topologically Sorted Source Nodes: [one_hot], Original ATen: [aten.ge, aten.all, aten._assert_async, aten.lt]
# Source node to ATen node mapping:
#   one_hot => _assert_async, _assert_async_1, any_1, any_2, ge, logical_not, logical_not_1, logical_not_2, logical_not_3, lt
# Graph fragment:
#   %arg1_1 : Tensor "i64[256][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %any_1 : Tensor "b8[][]cuda:0" = PlaceHolder[target=any_1]
#   %logical_not_1 : Tensor "b8[][]cuda:0" = PlaceHolder[target=logical_not_1]
#   %any_2 : Tensor "b8[][]cuda:0" = PlaceHolder[target=any_2]
#   %logical_not_3 : Tensor "b8[][]cuda:0" = PlaceHolder[target=logical_not_3]
#   %ge : Tensor "b8[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.ge.Scalar](args = (%arg1_1, 0), kwargs = {})
#   %logical_not : Tensor "b8[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%ge,), kwargs = {})
#   %any_1 : Tensor "b8[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.any.dims](args = (%logical_not,), kwargs = {})
#   %logical_not_1 : Tensor "b8[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %_assert_async : [num_users=0] = call_function[target=torch.ops.aten._assert_async.msg](args = (%logical_not_1, one_hot: Class values must be non-negative.), kwargs = {})
#   %lt : Tensor "b8[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.lt.Scalar](args = (%arg1_1, 1024), kwargs = {})
#   %logical_not_2 : Tensor "b8[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%lt,), kwargs = {})
#   %any_2 : Tensor "b8[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.any.dims](args = (%logical_not_2,), kwargs = {})
#   %logical_not_3 : Tensor "b8[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_2,), kwargs = {})
#   %_assert_async_1 : [num_users=0] = call_function[target=torch.ops.aten._assert_async.msg](args = (%logical_not_3, one_hot: Class values must be smaller than num_classes.), kwargs = {})
#   return %any_1,%any_2,%logical_not_1,%_assert_async,%logical_not_3,%_assert_async_1
triton_per_fused__assert_async_all_ge_lt_0 = async_compile.triton('triton_per_fused__assert_async_all_ge_lt_0', '''
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()
from triton.experimental import gluon
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language.extra import libdevice

@gluon.jit
def _amd_maximum(a, b):
    return gl.where((a > b) | (a != a), a, b)

@gluon.jit
def _amd_max2(value, axis: gl.constexpr):
    return gl.reduce(value, axis, _amd_maximum)

@gluon.jit
def _amd_any(value, axis: gl.constexpr):
    return gl.sum((value != 0).to(gl.int32), axis) != 0

@gluon.jit
def _amd_reciprocal(value):
    return gl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[value], dtype=gl.float32, is_pure=True, pack=1)

@triton_heuristics.persistent_reduction(size_hints={'x': 1, 'r0_': 256}, reduction_hint=ReductionHint.INNER, filename=__file__, triton_meta={'signature': {'in_ptr0': '*i64', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'AMD_LANES': 'constexpr', 'AMD_VEC': 'constexpr', 'AMD_WARPS': 'constexpr', 'AMD_SPLIT_WARPS': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16]]}]}, inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__assert_async_all_ge_lt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': -2, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'r0_': 2048}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': False, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_warp_size': 64, 'amd_max_threads_per_block': 1024, 'amd_reduction_tuning': True, 'amd_kernel_autotune': True, 'amd_kernel_tuning_version': 5, 'amd_autotune_diagnostics_path': '/dockerx/pytorch-flex/agent_space/simd_bench/native_triton_experiment/results/cross_entropy_backward_float32/gluon.tuning.jsonl', 'amd_warm_arg_names': (), 'amd_confirm_tuning': True, 'amd_graph_tuning': True, 'amd_allow_atomic_tuning': False, 'use_gluon': True, 'amd_gluon_family': 'row_reduction', 'amd_reduction_extent': 256, 'amd_row_count': 1, 'amd_approximate_math': False, 'amd_cache_policy': 'balanced'})
@gluon.jit
def triton_per_fused__assert_async_all_ge_lt_0(in_ptr0, xnumel, r0_numel, XBLOCK: tl.constexpr, AMD_LANES: gl.constexpr, AMD_VEC: gl.constexpr, AMD_WARPS: gl.constexpr, AMD_SPLIT_WARPS: gl.constexpr):
    _amd_layout: gl.constexpr = gl.BlockedLayout([1, AMD_VEC], [64 // AMD_LANES, AMD_LANES], [1, AMD_WARPS] if AMD_SPLIT_WARPS else [AMD_WARPS, 1], [1, 0])
    xnumel = 1
    r0_numel = 256
    R0_BLOCK: gl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: gl.constexpr = R0_BLOCK
    xoffset = gl.program_id(0) * XBLOCK
    xindex = xoffset + gl.arange(0, XBLOCK, layout=gl.SliceLayout(1, _amd_layout))[:, None]
    xmask = gl.full([XBLOCK], True, gl.int1, layout=gl.SliceLayout(1, _amd_layout))[:, None]
    r0_index = gl.arange(0, R0_BLOCK, layout=gl.SliceLayout(0, _amd_layout))[None, :]
    r0_offset = 0
    r0_mask = gl.full([R0_BLOCK], True, gl.int1, layout=gl.SliceLayout(0, _amd_layout))[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = gl.load(in_ptr0 + r0_0, None, eviction_policy='evict_first')
    tmp1 = gl.full([1, 1], 0, gl.int64, layout=_amd_layout)
    tmp2 = tmp0 >= tmp1
    tmp3 = tmp2 == 0
    tmp4 = gl.broadcast(tmp3, gl.full([XBLOCK, R0_BLOCK], 0, tmp3.dtype, layout=_amd_layout))[0]
    tmp6 = _amd_any(tmp4, 1)[:, None].to(gl.int1)
    tmp7 = gl.full([1, 1], 1024, gl.int64, layout=_amd_layout)
    tmp8 = tmp0 < tmp7
    tmp9 = tmp8 == 0
    tmp10 = gl.broadcast(tmp9, gl.full([XBLOCK, R0_BLOCK], 0, tmp9.dtype, layout=_amd_layout))[0]
    tmp12 = _amd_any(tmp10, 1)[:, None].to(gl.int1)
    tmp13 = tmp6 == 0
    gl.device_assert(tmp13, 'one_hot: Class values must be non-negative.')
    tmp14 = tmp12 == 0
    gl.device_assert(tmp14, 'one_hot: Class values must be smaller than num_classes.')
''', device_str='cuda')


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/native_probe_cache/inductor/e3/ce3z2ohdddh7bjams4f74azbim2an6dgh67syfibp5gzntusrk6l.py
# Topologically Sorted Source Nodes: [softmax, one_hot, float_2, sub], Original ATen: [prims.prepare_softmax_online, aten._softmax, aten.unsqueeze, aten.arange, aten.eq, aten._to_copy, aten.sub]
# Source node to ATen node mapping:
#   float_2 => convert_element_type_1
#   one_hot => convert_element_type, eq, iota, unsqueeze
#   softmax => div, exp_default, sub_tensor
#   sub => sub_1
# Graph fragment:
#   %arg0_1 : Tensor "f32[256, 1024][1024, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %getitem : Tensor "f32[256, 1][1, 256]cuda:0" = PlaceHolder[target=getitem]
#   %getitem_1 : Tensor "f32[256, 1][1, 256]cuda:0" = PlaceHolder[target=getitem_1]
#   %arg1_1 : Tensor "i64[256][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %prepare_softmax_online_default : [num_users=2] = call_function[target=torch.ops.prims.prepare_softmax_online.default](args = (%arg0_1, -1), kwargs = {})
#   %sub_tensor : Tensor "f32[256, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%arg0_1, %getitem), kwargs = {})
#   %exp_default : Tensor "f32[256, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%sub_tensor,), kwargs = {})
#   %div : Tensor "f32[256, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_default, %getitem_1), kwargs = {})
#   %unsqueeze : Tensor "i64[256, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg1_1, -1), kwargs = {})
#   %iota : Tensor "i64[1024][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1024,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %eq : Tensor "b8[256, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%unsqueeze, %iota), kwargs = {})
#   %convert_element_type : Tensor "i64[256, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%eq, torch.int64), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[256, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type, torch.float32), kwargs = {})
#   %sub_1 : Tensor "f32[256, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%div, %convert_element_type_1), kwargs = {})
#   return %getitem,%getitem_1,%sub_1
triton_per_fused__softmax__to_copy_arange_eq_prepare_softmax_online_sub_unsqueeze_1 = async_compile.triton('triton_per_fused__softmax__to_copy_arange_eq_prepare_softmax_online_sub_unsqueeze_1', '''
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()
from triton.experimental import gluon
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language.extra import libdevice

@gluon.jit
def _amd_maximum(a, b):
    return gl.where((a > b) | (a != a), a, b)

@gluon.jit
def _amd_max2(value, axis: gl.constexpr):
    return gl.reduce(value, axis, _amd_maximum)

@gluon.jit
def _amd_any(value, axis: gl.constexpr):
    return gl.sum((value != 0).to(gl.int32), axis) != 0

@gluon.jit
def _amd_reciprocal(value):
    return gl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[value], dtype=gl.float32, is_pure=True, pack=1)

@triton_heuristics.persistent_reduction(size_hints={'x': 256, 'r0_': 1024}, reduction_hint=ReductionHint.INNER, filename=__file__, triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i64', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'AMD_LANES': 'constexpr', 'AMD_VEC': 'constexpr', 'AMD_WARPS': 'constexpr', 'AMD_SPLIT_WARPS': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]}, inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__softmax__to_copy_arange_eq_prepare_softmax_online_sub_unsqueeze_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 4, 'autotune_hints': set(), 'tiling_scores': {'x': 2048, 'r0_': 3145728}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': False, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_warp_size': 64, 'amd_max_threads_per_block': 1024, 'amd_reduction_tuning': True, 'amd_kernel_autotune': True, 'amd_kernel_tuning_version': 5, 'amd_autotune_diagnostics_path': '/dockerx/pytorch-flex/agent_space/simd_bench/native_triton_experiment/results/cross_entropy_backward_float32/gluon.tuning.jsonl', 'amd_warm_arg_names': ('in_ptr1',), 'amd_confirm_tuning': True, 'amd_graph_tuning': True, 'amd_allow_atomic_tuning': False, 'use_gluon': True, 'amd_gluon_family': 'row_reduction', 'amd_reduction_extent': 1024, 'amd_row_count': 256, 'amd_approximate_math': False, 'amd_cache_policy': 'balanced'})
@gluon.jit
def triton_per_fused__softmax__to_copy_arange_eq_prepare_softmax_online_sub_unsqueeze_1(in_ptr0, in_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK: tl.constexpr, AMD_LANES: gl.constexpr, AMD_VEC: gl.constexpr, AMD_WARPS: gl.constexpr, AMD_SPLIT_WARPS: gl.constexpr):
    _amd_layout: gl.constexpr = gl.BlockedLayout([1, AMD_VEC], [64 // AMD_LANES, AMD_LANES], [1, AMD_WARPS] if AMD_SPLIT_WARPS else [AMD_WARPS, 1], [1, 0])
    xnumel = 256
    r0_numel = 1024
    R0_BLOCK: gl.constexpr = 1024
    rnumel = r0_numel
    RBLOCK: gl.constexpr = R0_BLOCK
    xoffset = gl.program_id(0) * XBLOCK
    xindex = xoffset + gl.arange(0, XBLOCK, layout=gl.SliceLayout(1, _amd_layout))[:, None]
    xmask = xindex < xnumel
    r0_index = gl.arange(0, R0_BLOCK, layout=gl.SliceLayout(0, _amd_layout))[None, :]
    r0_offset = 0
    r0_mask = gl.full([R0_BLOCK], True, gl.int1, layout=gl.SliceLayout(0, _amd_layout))[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = gl.load(in_ptr0 + (r0_1 + 1024 * x0), xmask, eviction_policy='evict_first', other=0.0)
    tmp16 = gl.load(in_ptr1 + x0, xmask, eviction_policy='evict_last')
    tmp1 = gl.broadcast(tmp0, gl.full([XBLOCK, R0_BLOCK], 0, tmp0.dtype, layout=_amd_layout))[0]
    tmp3 = gl.broadcast(tmp1, gl.full([XBLOCK, R0_BLOCK], 0, tmp1.dtype, layout=_amd_layout))[0]
    tmp5 = gl.where(xmask, tmp3, float('-inf'))
    tmp6 = gl.max(tmp5, 1)[:, None].to(gl.float32)
    tmp7 = tmp1 - tmp6
    tmp8 = libdevice.exp(tmp7)
    tmp9 = gl.broadcast(tmp8, gl.full([XBLOCK, R0_BLOCK], 0, tmp8.dtype, layout=_amd_layout))[0]
    tmp11 = gl.where(xmask, tmp9, 0)
    tmp12 = gl.sum(tmp11, 1)[:, None].to(gl.float32)
    tmp13 = tmp0 - tmp6
    tmp14 = libdevice.exp(tmp13)
    tmp15 = tmp14 / tmp12
    tmp17 = r0_1.to(gl.int64)
    tmp18 = tmp17.to(gl.int64)
    tmp19 = tmp16 == tmp18
    tmp20 = tmp19.to(gl.int64)
    tmp21 = tmp20.to(gl.float32)
    tmp22 = tmp15 - tmp21
    gl.store(out_ptr2 + (r0_1 + 1024 * x0), tmp22, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride(arg1_1, (256, ), (1, ), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            # Topologically Sorted Source Nodes: [one_hot], Original ATen: [aten.ge, aten.all, aten._assert_async, aten.lt]
            raw_stream0 = get_raw_stream(0)
            triton_per_fused__assert_async_all_ge_lt_0.run(arg1_1, 1, 256, stream=raw_stream0)
            assert_size_stride(arg0_1, (256, 1024), (1024, 1), 'input')
            arg0_1 = copy_if_misaligned(arg0_1)
            buf8 = empty_strided_cuda((256, 1024), (1024, 1), torch.float32)
            # Topologically Sorted Source Nodes: [softmax, one_hot, float_2, sub], Original ATen: [prims.prepare_softmax_online, aten._softmax, aten.unsqueeze, aten.arange, aten.eq, aten._to_copy, aten.sub]
            raw_stream0 = get_raw_stream(0)
            triton_per_fused__softmax__to_copy_arange_eq_prepare_softmax_online_sub_unsqueeze_1.run(arg0_1, arg1_1, buf8, 256, 1024, stream=raw_stream0)
            del arg0_1
            del arg1_1
        return (buf8, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((256, 1024), (1024, 1), device='cuda:0', dtype=torch.float32)
    arg1_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.int64)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
