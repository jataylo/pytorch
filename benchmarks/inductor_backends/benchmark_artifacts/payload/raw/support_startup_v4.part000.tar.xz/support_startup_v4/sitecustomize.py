import importlib.abc
import importlib.util
import os
from pathlib import Path
import sys


class _SupportSourceFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        source_root = os.environ.get('BENCHMARK_SUPPORT_SOURCE_ROOT')
        if source_root and fullname in {
            'torch._inductor.scheduler',
            'torch._inductor.codegen.simd',
            'torch._inductor.codegen.flydsl.flydsl_simd',
            'torch._inductor.codegen.flydsl.flydsl_simd_runtime',
        }:
            source = Path(source_root).joinpath(*fullname.split('.')).with_suffix('.py')
            return importlib.util.spec_from_file_location(fullname, source)
        return None


sys.meta_path.insert(0, _SupportSourceFinder())

import triton
