
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 16384, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_sum_unsqueeze_zeros_like_68', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 81920, 'r0_': 1761280}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_sum_unsqueeze_zeros_like_68(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 10240
    r0_numel = 40
    R0_BLOCK: tl.constexpr = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = r0_index < r0_numel
    roffset = r0_offset
    rindex = r0_index
    r0_2 = r0_index
    x1 = xindex // 40
    x3 = xindex
    tmp11 = tl.load(in_ptr0 + (2624 + r0_2 + 4096*x1), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
    tmp13 = tl.load(in_ptr0 + (2560 + r0_2 + 4096*x1), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
    tmp44 = tl.load(in_ptr3 + (r0_2 + 40*x3), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
    tmp0 = tl.full([1, 1], 40, tl.int32)
    tmp1 = tl.full([1, 1], 41, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (r0_2).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1, 1], 41, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.full([1, 1], 0.0, tl.float32)
    tmp9 = tl.full(tmp8.shape, 0.0, tmp8.dtype)
    tmp10 = tl.where(tmp7, tmp8, tmp9)
    tmp12 = tl.where(tmp6, tmp10, tmp11)
    tmp14 = tl.where(tmp2, tmp12, tmp13)
    tmp15 = tl.full([1, 1], 40, tl.int64)
    tmp16 = tmp15 < tmp5
    tmp17 = tmp16.to(tl.int1)
    tmp18 = (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])).to(tl.int64)
    tmp19 = (tmp18).to(tl.int64)
    tmp20 = tl.full([1, 1], 41, tl.int64)
    tmp21 = tmp19 < tmp20
    tmp22 = tmp21.to(tl.int1)
    tmp23 = tmp22 & tmp17
    tmp24 = tl.load(in_ptr0 + (2624 + r0_2 + 4096*x1), r0_mask & tmp23 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.load(in_ptr1 + (tl.broadcast_to(40 + 4096*x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp23 & xmask, eviction_policy='evict_last', other=0.0)
    tmp26 = tmp24 * tmp25
    tmp27 = tl.full(tmp26.shape, 0.0, tmp26.dtype)
    tmp28 = tl.where(tmp23, tmp26, tmp27)
    tmp29 = tl.full([1, 1], 0.0, tl.float32)
    tmp30 = tl.where(tmp21, tmp28, tmp29)
    tmp31 = tl.full(tmp30.shape, 0.0, tmp30.dtype)
    tmp32 = tl.where(tmp17, tmp30, tmp31)
    tmp33 = tl.full([1, 1], 0.0, tl.float32)
    tmp34 = tl.where(tmp16, tmp32, tmp33)
    tmp35 = tmp14 + tmp34
    tmp36 = tl.load(in_ptr0 + (2624 + r0_2 + 4096*x1), r0_mask & tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp37 = tl.load(in_ptr2 + (r0_2 + 41*x1), r0_mask & tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp38 = tmp36 + tmp37
    tmp39 = tl.full(tmp38.shape, 0.0, tmp38.dtype)
    tmp40 = tl.where(tmp7, tmp38, tmp39)
    tmp41 = tl.where(tmp6, tmp40, tmp33)
    tmp42 = tl.where(tmp2, tmp41, tmp33)
    tmp43 = tmp35 + tmp42
    tmp45 = tmp43 * tmp44
    tmp46 = tl.broadcast_to(tmp45, [XBLOCK, R0_BLOCK])
    tmp48 = tl.where(r0_mask & xmask, tmp46, 0)
    tmp49 = tl.sum(tmp48, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp49, xmask)
