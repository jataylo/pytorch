
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=5, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_arange_cat_cos_div_exp_mul_sin_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2048}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_arange_cat_cos_div_exp_mul_sin_unsqueeze_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 128, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.load(in_ptr0 + (0)).to(tl.float32)
    tmp9 = tl.broadcast_to(tmp8, [XBLOCK])
    tmp10 = tl.where(tmp7, tmp9, 0.0)
    tmp11 = tmp10.to(tl.float32)
    tmp12 = (x0).to(tl.float32)
    tmp13 = (tmp12).to(tl.float32)
    tmp14 = tl.full([1], -9.210340371976184, tl.float32)
    tmp15 = tmp13 * tmp14
    tmp16 = tl.full([1], 0.0078125, tl.float32)
    tmp17 = tmp15 * tmp16
    tmp18 = libdevice.exp(tmp17)
    tmp19 = tmp11 * tmp18
    tmp20 = tl.full([1], 1000.0, tl.float32)
    tmp21 = tmp19 * tmp20
    tmp22 = tl_math.sin(tmp21)
    tmp23 = tl.full(tmp22.shape, 0.0, tmp22.dtype)
    tmp24 = tl.where(tmp7, tmp22, tmp23)
    tmp25 = tmp0 >= tmp5
    tmp26 = tl.full([1], 256, tl.int64)
    tmp27 = tmp0 < tmp26
    tmp28 = tmp25.to(tl.int1)
    tmp29 = tl.load(in_ptr0 + (0)).to(tl.float32)
    tmp30 = tl.broadcast_to(tmp29, [XBLOCK])
    tmp31 = tl.where(tmp28, tmp30, 0.0)
    tmp32 = tmp31.to(tl.float32)
    tmp33 = ((-128) + x0).to(tl.float32)
    tmp34 = (tmp33).to(tl.float32)
    tmp35 = tl.full([1], -9.210340371976184, tl.float32)
    tmp36 = tmp34 * tmp35
    tmp37 = tl.full([1], 0.0078125, tl.float32)
    tmp38 = tmp36 * tmp37
    tmp39 = libdevice.exp(tmp38)
    tmp40 = tmp32 * tmp39
    tmp41 = tl.full([1], 1000.0, tl.float32)
    tmp42 = tmp40 * tmp41
    tmp43 = tl_math.cos(tmp42)
    tmp44 = tl.full(tmp43.shape, 0.0, tmp43.dtype)
    tmp45 = tl.where(tmp28, tmp43, tmp44)
    tmp46 = tl.where(tmp6, tmp24, tmp45)
    tl.store(out_ptr0 + (x0), tmp46, xmask)
