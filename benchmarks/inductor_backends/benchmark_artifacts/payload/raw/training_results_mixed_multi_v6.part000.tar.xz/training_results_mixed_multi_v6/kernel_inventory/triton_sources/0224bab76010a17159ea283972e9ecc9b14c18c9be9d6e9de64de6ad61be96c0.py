
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2097152}, 
    filename=__file__,
    triton_meta={'signature': {'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=7, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_clone_expand_sin_unsqueeze_view_5', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 0, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 14376960}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_clone_expand_sin_unsqueeze_view_5(out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1797120
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = xindex // 128
    x2 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 16, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = (x1 // 1560).to(tl.int32)
    tmp9 = tl.full([1], 0, tl.int64)
    tmp10 = tmp8 >= tmp9
    tmp11 = (x1 // 1560).to(tl.int64)
    tmp12 = (tmp11).to(tl.int64)
    tmp13 = tl.full([1], 9, tl.int64)
    tmp14 = tmp12 < tmp13
    tmp15 = tmp14.to(tl.int1)
    tmp16 = tmp15 & tmp7
    tmp17 = (x1 // 1560).to(tl.float32)
    tmp18 = (tmp17).to(tl.float32)
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp12 >= tmp13
    tmp22 = tl.full([1], 18, tl.int64)
    tmp23 = tmp12 < tmp22
    tmp24 = tmp21 & tmp23
    tmp25 = tmp24.to(tl.int1)
    tmp26 = tmp25 & tmp7
    tmp27 = (((x2 // 6656) % 30)).to(tl.float32)
    tmp28 = (tmp27).to(tl.float32)
    tmp29 = tl.full(tmp28.shape, 0.0, tmp28.dtype)
    tmp30 = tl.where(tmp26, tmp28, tmp29)
    tmp31 = tmp8 >= tmp22
    tmp32 = tl.full([1], 27, tl.int64)
    tmp33 = tmp8 < tmp32
    tmp34 = tmp31.to(tl.int1)
    tmp35 = tmp34 & tmp7
    tmp36 = (((x2 // 128) % 52)).to(tl.float32)
    tmp37 = (tmp36).to(tl.float32)
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp35, tmp37, tmp38)
    tmp40 = tl.where(tmp24, tmp30, tmp39)
    tmp41 = tl.where(tmp14, tmp20, tmp40)
    tmp42 = (2*((((x0) // 2) % 8))).to(tl.float32)
    tmp43 = (tmp42).to(tl.float32)
    tmp44 = tl.full([1], 0.0625, tl.float32)
    tmp45 = tmp43 * tmp44
    tmp46 = tl.full([1], 256.0, tl.float32)
    tmp47 = libdevice.pow(tmp46, tmp45)
    tmp48 = tl.full([1], 1.0, tl.float32)
    tmp49 = (tmp48 / tmp47)
    tmp50 = tmp41 * tmp49
    tmp51 = tl_math.sin(tmp50)
    tmp52 = tl.full(tmp51.shape, 0.0, tmp51.dtype)
    tmp53 = tl.where(tmp7, tmp51, tmp52)
    tmp54 = tmp4 >= tmp5
    tmp55 = tl.full([1], 72, tl.int64)
    tmp56 = tmp4 < tmp55
    tmp57 = tmp54 & tmp56
    tmp58 = tmp57.to(tl.int1)
    tmp59 = (9 + (x1 // 1560)).to(tl.int32)
    tmp60 = tl.full([1], 0, tl.int64)
    tmp61 = tmp59 >= tmp60
    tmp62 = (9 + (x1 // 1560)).to(tl.int64)
    tmp63 = (tmp62).to(tl.int64)
    tmp64 = tl.full([1], 9, tl.int64)
    tmp65 = tmp63 < tmp64
    tmp66 = tmp65.to(tl.int1)
    tmp67 = tmp66 & tmp58
    tmp68 = (9 + (x1 // 1560)).to(tl.float32)
    tmp69 = (tmp68).to(tl.float32)
    tmp70 = tl.full(tmp69.shape, 0.0, tmp69.dtype)
    tmp71 = tl.where(tmp67, tmp69, tmp70)
    tmp72 = tmp63 >= tmp64
    tmp73 = tl.full([1], 18, tl.int64)
    tmp74 = tmp63 < tmp73
    tmp75 = tmp72 & tmp74
    tmp76 = tmp75.to(tl.int1)
    tmp77 = tmp76 & tmp58
    tmp78 = (((x2 // 6656) % 30)).to(tl.float32)
    tmp79 = (tmp78).to(tl.float32)
    tmp80 = tl.full(tmp79.shape, 0.0, tmp79.dtype)
    tmp81 = tl.where(tmp77, tmp79, tmp80)
    tmp82 = tmp59 >= tmp73
    tmp83 = tl.full([1], 27, tl.int64)
    tmp84 = tmp59 < tmp83
    tmp85 = tmp82.to(tl.int1)
    tmp86 = tmp85 & tmp58
    tmp87 = (((x2 // 128) % 52)).to(tl.float32)
    tmp88 = (tmp87).to(tl.float32)
    tmp89 = tl.full(tmp88.shape, 0.0, tmp88.dtype)
    tmp90 = tl.where(tmp86, tmp88, tmp89)
    tmp91 = tl.where(tmp75, tmp81, tmp90)
    tmp92 = tl.where(tmp65, tmp71, tmp91)
    tmp93 = (2*(((((-16) + x0) // 2) % 28))).to(tl.float32)
    tmp94 = (tmp93).to(tl.float32)
    tmp95 = tl.full([1], 0.017857142857142856, tl.float32)
    tmp96 = tmp94 * tmp95
    tmp97 = tl.full([1], 256.0, tl.float32)
    tmp98 = libdevice.pow(tmp97, tmp96)
    tmp99 = tl.full([1], 1.0, tl.float32)
    tmp100 = (tmp99 / tmp98)
    tmp101 = tmp92 * tmp100
    tmp102 = tl_math.sin(tmp101)
    tmp103 = tl.full(tmp102.shape, 0.0, tmp102.dtype)
    tmp104 = tl.where(tmp58, tmp102, tmp103)
    tmp105 = tmp0 >= tmp55
    tmp106 = tl.full([1], 128, tl.int64)
    tmp107 = tmp0 < tmp106
    tmp108 = tmp105.to(tl.int1)
    tmp109 = (18 + (x1 // 1560)).to(tl.int32)
    tmp110 = tl.full([1], 0, tl.int64)
    tmp111 = tmp109 >= tmp110
    tmp112 = (18 + (x1 // 1560)).to(tl.int64)
    tmp113 = (tmp112).to(tl.int64)
    tmp114 = tl.full([1], 9, tl.int64)
    tmp115 = tmp113 < tmp114
    tmp116 = tmp115.to(tl.int1)
    tmp117 = tmp116 & tmp108
    tmp118 = (18 + (x1 // 1560)).to(tl.float32)
    tmp119 = (tmp118).to(tl.float32)
    tmp120 = tl.full(tmp119.shape, 0.0, tmp119.dtype)
    tmp121 = tl.where(tmp117, tmp119, tmp120)
    tmp122 = tmp113 >= tmp114
    tmp123 = tl.full([1], 18, tl.int64)
    tmp124 = tmp113 < tmp123
    tmp125 = tmp122 & tmp124
    tmp126 = tmp125.to(tl.int1)
    tmp127 = tmp126 & tmp108
    tmp128 = (((x2 // 6656) % 30)).to(tl.float32)
    tmp129 = (tmp128).to(tl.float32)
    tmp130 = tl.full(tmp129.shape, 0.0, tmp129.dtype)
    tmp131 = tl.where(tmp127, tmp129, tmp130)
    tmp132 = tmp109 >= tmp123
    tmp133 = tl.full([1], 27, tl.int64)
    tmp134 = tmp109 < tmp133
    tmp135 = tmp132.to(tl.int1)
    tmp136 = tmp135 & tmp108
    tmp137 = (((x2 // 128) % 52)).to(tl.float32)
    tmp138 = (tmp137).to(tl.float32)
    tmp139 = tl.full(tmp138.shape, 0.0, tmp138.dtype)
    tmp140 = tl.where(tmp136, tmp138, tmp139)
    tmp141 = tl.where(tmp125, tmp131, tmp140)
    tmp142 = tl.where(tmp115, tmp121, tmp141)
    tmp143 = (2*(((((-72) + x0) // 2) % 28))).to(tl.float32)
    tmp144 = (tmp143).to(tl.float32)
    tmp145 = tl.full([1], 0.017857142857142856, tl.float32)
    tmp146 = tmp144 * tmp145
    tmp147 = tl.full([1], 256.0, tl.float32)
    tmp148 = libdevice.pow(tmp147, tmp146)
    tmp149 = tl.full([1], 1.0, tl.float32)
    tmp150 = (tmp149 / tmp148)
    tmp151 = tmp142 * tmp150
    tmp152 = tl_math.sin(tmp151)
    tmp153 = tl.full(tmp152.shape, 0.0, tmp152.dtype)
    tmp154 = tl.where(tmp108, tmp152, tmp153)
    tmp155 = tl.where(tmp57, tmp104, tmp154)
    tmp156 = tl.where(tmp6, tmp53, tmp155)
    tl.store(out_ptr0 + (x2), tmp156, xmask)
