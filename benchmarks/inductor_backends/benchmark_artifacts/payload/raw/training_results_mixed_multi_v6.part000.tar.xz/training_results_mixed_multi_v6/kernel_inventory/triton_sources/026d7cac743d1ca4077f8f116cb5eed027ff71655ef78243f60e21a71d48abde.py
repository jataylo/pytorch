
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*i1', 'in_ptr2': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'out_ptr4': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_exp_masked_fill_mul_select_sub_unsqueeze_view_32', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 16, 'num_store': 5, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 24088576}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_exp_masked_fill_mul_select_sub_unsqueeze_view_32(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, out_ptr2, out_ptr3, out_ptr4, xnumel, XBLOCK : tl.constexpr):
    xnumel = 786432
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex // 4096
    x3 = (xindex % 4096)
    x1 = ((xindex // 64) % 64)
    x0 = (xindex % 64)
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x3 + 36864*x2), None).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x3), None, eviction_policy='evict_last')
    tmp3 = tl.load(in_ptr2 + (x1 + 576*x2), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr2 + (x0 + 576*x2), None, eviction_policy='evict_last')
    tmp11 = tl.load(in_ptr0 + (4096 + x3 + 36864*x2), None).to(tl.float32)
    tmp13 = tl.load(in_ptr2 + (64 + x1 + 576*x2), None, eviction_policy='evict_last')
    tmp14 = tl.load(in_ptr2 + (64 + x0 + 576*x2), None, eviction_policy='evict_last')
    tmp20 = tl.load(in_ptr0 + (8192 + x3 + 36864*x2), None).to(tl.float32)
    tmp22 = tl.load(in_ptr2 + (128 + x1 + 576*x2), None, eviction_policy='evict_last')
    tmp23 = tl.load(in_ptr2 + (128 + x0 + 576*x2), None, eviction_policy='evict_last')
    tmp29 = tl.load(in_ptr0 + (12288 + x3 + 36864*x2), None).to(tl.float32)
    tmp31 = tl.load(in_ptr2 + (192 + x1 + 576*x2), None, eviction_policy='evict_last')
    tmp32 = tl.load(in_ptr2 + (192 + x0 + 576*x2), None, eviction_policy='evict_last')
    tmp38 = tl.load(in_ptr0 + (16384 + x3 + 36864*x2), None).to(tl.float32)
    tmp40 = tl.load(in_ptr2 + (256 + x1 + 576*x2), None, eviction_policy='evict_last')
    tmp41 = tl.load(in_ptr2 + (256 + x0 + 576*x2), None, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp5 = tmp3 - tmp4
    tmp6 = tl.full([1], float("-inf"), tl.float32)
    tmp7 = tl.where(tmp2, tmp6, tmp5)
    tmp8 = libdevice.exp(tmp7)
    tmp9 = tmp1 * tmp8
    tmp10 = tmp9.to(tl.float32)
    tmp12 = tmp11.to(tl.float32)
    tmp15 = tmp13 - tmp14
    tmp16 = tl.where(tmp2, tmp6, tmp15)
    tmp17 = libdevice.exp(tmp16)
    tmp18 = tmp12 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp21 = tmp20.to(tl.float32)
    tmp24 = tmp22 - tmp23
    tmp25 = tl.where(tmp2, tmp6, tmp24)
    tmp26 = libdevice.exp(tmp25)
    tmp27 = tmp21 * tmp26
    tmp28 = tmp27.to(tl.float32)
    tmp30 = tmp29.to(tl.float32)
    tmp33 = tmp31 - tmp32
    tmp34 = tl.where(tmp2, tmp6, tmp33)
    tmp35 = libdevice.exp(tmp34)
    tmp36 = tmp30 * tmp35
    tmp37 = tmp36.to(tl.float32)
    tmp39 = tmp38.to(tl.float32)
    tmp42 = tmp40 - tmp41
    tmp43 = tl.where(tmp2, tmp6, tmp42)
    tmp44 = libdevice.exp(tmp43)
    tmp45 = tmp39 * tmp44
    tmp46 = tmp45.to(tl.float32)
    tl.store(out_ptr0 + (x4), tmp10, None)
    tl.store(out_ptr1 + (x4), tmp19, None)
    tl.store(out_ptr2 + (x4), tmp28, None)
    tl.store(out_ptr3 + (x4), tmp37, None)
    tl.store(out_ptr4 + (x4), tmp46, None)
