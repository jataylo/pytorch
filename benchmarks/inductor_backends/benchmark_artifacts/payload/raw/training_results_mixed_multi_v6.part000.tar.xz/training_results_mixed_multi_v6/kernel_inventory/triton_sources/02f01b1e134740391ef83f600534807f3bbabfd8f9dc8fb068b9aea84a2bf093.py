
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 8192, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*i1', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*bf16', 'in_ptr6': '*bf16', 'in_ptr7': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*fp32', 'out_ptr2': '*bf16', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (10,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (11,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (12,): [['tt.divisibility', 16]], (13,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy_add_exp_masked_fill_mul_neg_select_backward_sub_sum_tril_triu_unsqueeze_view_23', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 9, 'num_store': 4, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 98304, 'r0_': 13668352}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy_add_exp_masked_fill_mul_neg_select_backward_sub_sum_tril_triu_unsqueeze_view_23(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, in_ptr7, out_ptr0, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 8192
    r0_numel = 64
    R0_BLOCK: tl.constexpr = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    x1 = ((xindex // 64) % 2)
    r0_3 = r0_index
    x0 = (xindex % 64)
    x2 = xindex // 128
    x5 = xindex
    x4 = xindex // 64
    tmp3 = tl.load(in_ptr0 + (r0_3 + 64*x0 + 4096*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp9 = tl.load(in_ptr1 + (r0_3 + 64*x0 + 4096*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp13 = tl.load(in_ptr2 + (r0_3 + 64*x0), None, eviction_policy='evict_last')
    tmp14 = tl.load(in_ptr3 + (x5), None, eviction_policy='evict_last')
    tmp15 = tl.load(in_ptr3 + (r0_3 + 64*x4), None, eviction_policy='evict_last')
    tmp22 = tl.load(in_ptr4 + (r0_3 + 64*x5), None, eviction_policy='evict_first').to(tl.float32)
    tmp29 = tl.load(in_ptr5 + (r0_3 + 64*x5), None, eviction_policy='evict_first').to(tl.float32)
    tmp33 = tl.load(in_ptr6 + (r0_3 + 64*x5), None, eviction_policy='evict_first').to(tl.float32)
    tmp38 = tl.load(in_ptr7 + (r0_3 + 64*x5), None, eviction_policy='evict_first').to(tl.float32)
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1, 1], 1, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp4 = tmp3.to(tl.float32)
    tmp5 = tl.full([1, 1], 0.0, tl.float32)
    tmp6 = tl.where(tmp2, tmp4, tmp5)
    tmp7 = tl.full([1, 1], 0, tl.int32)
    tmp8 = tmp0 == tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.where(tmp8, tmp10, tmp5)
    tmp12 = tmp6 + tmp11
    tmp16 = tmp14 - tmp15
    tmp17 = tl.full([1, 1], float("-inf"), tl.float32)
    tmp18 = tl.where(tmp13, tmp17, tmp16)
    tmp19 = libdevice.exp(tmp18)
    tmp20 = tmp12 * tmp19
    tmp21 = tmp20.to(tl.float32)
    tmp23 = tmp22.to(tl.float32)
    tmp24 = tmp12 * tmp23
    tmp25 = (r0_3 + ((-1)*x0)).to(tl.int64)
    tmp26 = (tmp25).to(tl.int64)
    tmp27 = tl.full([1, 1], -1, tl.int64)
    tmp28 = tmp26 <= tmp27
    tmp30 = -tmp29
    tmp31 = tl.where(tmp28, tmp30, tmp5)
    tmp32 = tmp31.to(tl.float32)
    tmp34 = -tmp33
    tmp35 = tl.where(tmp28, tmp34, tmp5)
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tmp32 + tmp36
    tmp39 = tmp38.to(tl.float32)
    tmp40 = tmp37 * tmp39
    tmp41 = tmp24 + tmp40
    tmp42 = tmp37 * tmp19
    tmp43 = tmp42.to(tl.float32)
    tmp44 = tmp41 * tmp19
    tmp45 = tl.where(tmp13, tmp5, tmp44)
    tmp46 = tl.broadcast_to(tmp45, [XBLOCK, R0_BLOCK])
    tmp48 = tl.sum(tmp46, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (r0_3 + 64*x5), tmp21, None)
    tl.store(out_ptr1 + (r0_3 + 64*x5), tmp41, None)
    tl.store(out_ptr2 + (r0_3 + 64*x5), tmp43, None)
    tl.store(out_ptr3 + (x5), tmp48, None)
