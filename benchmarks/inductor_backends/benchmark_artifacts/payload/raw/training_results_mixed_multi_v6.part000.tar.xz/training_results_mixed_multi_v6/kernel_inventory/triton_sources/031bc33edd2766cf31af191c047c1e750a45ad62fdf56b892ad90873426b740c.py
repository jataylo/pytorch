
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 16384, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'in_ptr6': '*bf16', 'in_ptr7': '*fp32', 'in_ptr8': '*fp32', 'in_ptr9': '*bf16', 'in_ptr10': '*bf16', 'in_ptr11': '*fp32', 'out_ptr2': '*fp32', 'out_ptr3': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (10,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (11,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (12,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (13,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (14,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (15,): [['tt.divisibility', 16]], (16,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy__unsafe_view_add_clone_div_exp_mul_neg_select_backward_sigmoid_sigmoid_backward_squeeze_sum_transpose_unsqueeze_view_162', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 13, 'num_store': 3, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 2293760, 'r0_': 71303168}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy__unsafe_view_add_clone_div_exp_mul_neg_select_backward_sigmoid_sigmoid_backward_squeeze_sum_transpose_unsqueeze_view_162(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, in_ptr7, in_ptr8, in_ptr9, in_ptr10, in_ptr11, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 16384
    r0_numel = 128
    R0_BLOCK: tl.constexpr = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    x2 = (xindex % 128)
    x5 = xindex // 128
    x3 = ((xindex // 128) % 32)
    x4 = xindex // 4096
    tmp0 = tl.load(in_ptr0 + (r0_1 + 128*x0), None, eviction_policy='evict_first').to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (r0_1 + 128*x0), None, eviction_policy='evict_first').to(tl.float32)
    tmp11 = tl.load(in_ptr2 + (r0_1 + 128*((x2 % 64)) + 8192*x5), None, eviction_policy='evict_first')
    tmp16 = tl.load(in_ptr3 + (64*r0_1 + 8192*x5 + ((x2 % 64))), None, eviction_policy='evict_first').to(tl.float32)
    tmp18 = tl.load(in_ptr4 + (r0_1 + 128*((x2 % 64)) + 8192*x5), None, eviction_policy='evict_first')
    tmp20 = tl.load(in_ptr5 + (r0_1 + 128*((x2 % 64)) + 8192*x5), None, eviction_policy='evict_first')
    tmp24 = tl.load(in_out_ptr0 + (r0_1 + 128*x0), None, eviction_policy='evict_first')
    tmp26 = tl.load(in_ptr6 + (r0_1 + 128*x0), None, eviction_policy='evict_first').to(tl.float32)
    tmp28 = tl.load(in_ptr7 + (r0_1 + 128*x0), None, eviction_policy='evict_first')
    tmp31 = tl.load(in_ptr8 + (r0_1 + 128*x0), None, eviction_policy='evict_first')
    tmp33 = tl.load(in_ptr9 + (x3 + 32*x2 + 4096*x4), None, eviction_policy='evict_last').to(tl.float32)
    tmp38 = tl.load(in_ptr10 + (r0_1 + 128*x0), None, eviction_policy='evict_first').to(tl.float32)
    tmp40 = tl.load(in_ptr11 + (x0), None, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl.broadcast_to(tmp4, [XBLOCK, R0_BLOCK])
    tmp7 = tl.sum(tmp5, 1)[:, None].to(tl.float32)
    tmp8 = (x2 // 64).to(tl.int32)
    tmp9 = tl.full([1, 1], 1, tl.int32)
    tmp10 = tmp8 == tmp9
    tmp12 = tl.full([1, 1], 0.0, tl.float32)
    tmp13 = tl.where(tmp10, tmp11, tmp12)
    tmp14 = tl.full([1, 1], 0, tl.int32)
    tmp15 = tmp8 == tmp14
    tmp17 = tmp16.to(tl.float32)
    tmp19 = tmp17 * tmp18
    tmp21 = tmp19 + tmp20
    tmp22 = tl.where(tmp15, tmp21, tmp12)
    tmp23 = tmp13 + tmp22
    tmp25 = tmp23 + tmp24
    tmp27 = tmp26.to(tl.float32)
    tmp29 = libdevice.exp(tmp28)
    tmp30 = tmp27 * tmp29
    tmp32 = tmp30 + tmp31
    tmp34 = tl.sigmoid(tmp33)
    tmp35 = tmp34.to(tl.float32)
    tmp36 = tmp32 * tmp35
    tmp37 = tmp25 + tmp36
    tmp39 = tmp38.to(tl.float32)
    tmp41 = (tmp39 / tmp40)
    tmp42 = tmp32 * tmp41
    tmp43 = tl.broadcast_to(tmp42, [XBLOCK, R0_BLOCK])
    tmp45 = tl.sum(tmp43, 1)[:, None].to(tl.float32)
    tmp46 = -tmp37
    tmp47 = (tmp41 / tmp40)
    tmp48 = tmp46 * tmp47
    tmp49 = tl.broadcast_to(tmp48, [XBLOCK, R0_BLOCK])
    tmp51 = tl.sum(tmp49, 1)[:, None].to(tl.float32)
    tmp52 = tmp45 + tmp7
    tmp53 = tmp52.to(tl.float32)
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tl.full([1, 1], 1.0, tl.float32)
    tmp56 = tmp55 - tmp35
    tmp57 = tmp35 * tmp56
    tmp58 = tmp54 * tmp57
    tmp59 = tmp58.to(tl.float32)
    tl.store(in_out_ptr0 + (r0_1 + 128*x0), tmp37, None)
    tl.store(out_ptr3 + (x3 + 32*x2 + 4096*x4), tmp59, None)
    tl.store(out_ptr2 + (x0), tmp51, None)
