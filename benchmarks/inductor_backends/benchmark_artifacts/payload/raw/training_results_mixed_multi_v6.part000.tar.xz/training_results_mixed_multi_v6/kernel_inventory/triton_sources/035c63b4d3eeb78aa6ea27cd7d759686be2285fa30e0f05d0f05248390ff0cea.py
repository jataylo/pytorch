
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_unsqueeze_zeros_like_52', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 13, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 16089088}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_unsqueeze_zeros_like_52(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1048576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 64) % 64)
    x0 = (xindex % 64)
    x2 = xindex // 4096
    x3 = xindex
    x4 = (xindex % 4096)
    tmp11 = tl.load(in_ptr0 + (3072 + x0 + 4096*x2), None, eviction_policy='evict_last')
    tmp21 = tl.load(in_ptr2 + (x0 + 64*x2), None, eviction_policy='evict_last')
    tmp25 = tl.load(in_ptr0 + (x3), None)
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 48, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 48, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.full([1], 0.0, tl.float32)
    tmp9 = tl.full(tmp8.shape, 0.0, tmp8.dtype)
    tmp10 = tl.where(tmp7, tmp8, tmp9)
    tmp12 = tl.full([1], 49, tl.int64)
    tmp13 = tmp5 < tmp12
    tmp14 = tmp13.to(tl.int1)
    tmp15 = tl.load(in_ptr1 + (3072 + x0 + 3136*x2), tmp14, eviction_policy='evict_last', other=0.0)
    tmp16 = tl.full([1], 0.0, tl.float32)
    tmp17 = tl.where(tmp13, tmp15, tmp16)
    tmp18 = tmp11 + tmp17
    tmp19 = tl.full([1], 49, tl.int32)
    tmp20 = tmp1 == tmp19
    tmp22 = tl.where(tmp20, tmp21, tmp16)
    tmp23 = tmp18 + tmp22
    tmp24 = tl.where(tmp6, tmp10, tmp23)
    tmp26 = (x1).to(tl.int64)
    tmp27 = (tmp26).to(tl.int64)
    tmp28 = tmp27 < tmp12
    tmp29 = tmp28.to(tl.int1)
    tmp30 = tl.load(in_ptr1 + (x4 + 3136*x2), tmp29, other=0.0)
    tmp31 = tl.where(tmp28, tmp30, tmp16)
    tmp32 = tmp25 + tmp31
    tmp33 = tmp0 == tmp19
    tmp34 = tl.where(tmp33, tmp21, tmp16)
    tmp35 = tmp32 + tmp34
    tmp36 = tl.where(tmp2, tmp24, tmp35)
    tmp37 = tmp27 < tmp5
    tmp38 = tmp37.to(tl.int1)
    tmp39 = (x0).to(tl.int64)
    tmp40 = (tmp39).to(tl.int64)
    tmp41 = tl.full([1], 48, tl.int64)
    tmp42 = tmp40 < tmp41
    tmp43 = tmp42.to(tl.int1)
    tmp44 = tmp43 & tmp38
    tmp45 = tl.load(in_ptr0 + (3072 + x0 + 4096*x2), tmp44, eviction_policy='evict_last', other=0.0)
    tmp46 = tl.full([1], 48, tl.int64)
    tmp47 = tl.full([1], 49, tl.int64)
    tmp48 = tmp46 < tmp47
    tmp49 = tmp48.to(tl.int1)
    tmp50 = tmp49 & tmp44
    tmp51 = tl.load(in_ptr1 + (3072 + x0 + 3136*x2), tmp50, eviction_policy='evict_last', other=0.0)
    tmp52 = tl.full([1], 0.0, tl.float32)
    tmp53 = tl.where(tmp48, tmp51, tmp52)
    tmp54 = tmp45 + tmp53
    tmp55 = tl.full([1], 48, tl.int32)
    tmp56 = tl.full([1], 49, tl.int32)
    tmp57 = tmp55 == tmp56
    tmp58 = tl.load(in_ptr2 + (x0 + 64*x2), tmp44, eviction_policy='evict_last', other=0.0)
    tmp59 = tl.where(tmp57, tmp58, tmp52)
    tmp60 = tmp54 + tmp59
    tmp61 = tl.load(in_ptr3 + (x1 + 4096*x2), tmp44, eviction_policy='evict_last', other=0.0)
    tmp62 = tmp60 * tmp61
    tmp63 = tl.full(tmp62.shape, 0.0, tmp62.dtype)
    tmp64 = tl.where(tmp44, tmp62, tmp63)
    tmp65 = tl.full([1], 0.0, tl.float32)
    tmp66 = tl.where(tmp42, tmp64, tmp65)
    tmp67 = tl.full(tmp66.shape, 0.0, tmp66.dtype)
    tmp68 = tl.where(tmp38, tmp66, tmp67)
    tmp69 = tl.where(tmp37, tmp68, tmp16)
    tmp70 = tmp36 + tmp69
    tmp71 = tl.load(in_ptr0 + (3072 + x0 + 4096*x2), tmp7, eviction_policy='evict_last', other=0.0)
    tmp72 = tl.full([1], 48, tl.int64)
    tmp73 = tl.full([1], 49, tl.int64)
    tmp74 = tmp72 < tmp73
    tmp75 = tmp74.to(tl.int1)
    tmp76 = tmp75 & tmp7
    tmp77 = tl.load(in_ptr1 + (3072 + x0 + 3136*x2), tmp76, eviction_policy='evict_last', other=0.0)
    tmp78 = tl.where(tmp74, tmp77, tmp8)
    tmp79 = tmp71 + tmp78
    tmp80 = tl.full([1], 48, tl.int32)
    tmp81 = tl.full([1], 49, tl.int32)
    tmp82 = tmp80 == tmp81
    tmp83 = tl.load(in_ptr2 + (x0 + 64*x2), tmp7, eviction_policy='evict_last', other=0.0)
    tmp84 = tl.where(tmp82, tmp83, tmp8)
    tmp85 = tmp79 + tmp84
    tmp86 = tl.load(in_ptr4 + (x0 + 48*x2), tmp7, eviction_policy='evict_last', other=0.0)
    tmp87 = tmp85 + tmp86
    tmp88 = tl.full(tmp87.shape, 0.0, tmp87.dtype)
    tmp89 = tl.where(tmp7, tmp87, tmp88)
    tmp90 = tl.where(tmp6, tmp89, tmp16)
    tmp91 = tl.where(tmp2, tmp90, tmp16)
    tmp92 = tmp70 + tmp91
    tl.store(in_out_ptr0 + (x3), tmp92, None)
