
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 256, 'x': 8192}, tile_hint=TileHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=3, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_clone_convolution_split_with_sizes_squeeze_transpose_unsqueeze_view_6', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 8388608, 'x': 25165824}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_clone_convolution_split_with_sizes_squeeze_transpose_unsqueeze_view_6(in_ptr0, out_ptr0, out_ptr1, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 256
    xnumel = 8192
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = tl.full([XBLOCK], True, tl.int1)[None, :]
    x2 = xindex
    y3 = yindex
    y0 = (yindex % 128)
    y1 = yindex // 128
    tmp0 = (x2).to(tl.int32)
    tmp1 = tl.full([1, 1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x2).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1, 1], 2048, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.load(in_ptr0 + (768*((((x2) // 128) % 16)) + 12288*y3 + (((x2) % 128))), tmp7 & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp9 = tmp4 >= tmp5
    tmp10 = tl.full([1, 1], 4096, tl.int64)
    tmp11 = tmp4 < tmp10
    tmp12 = tmp9 & tmp11
    tmp13 = tmp12.to(tl.int1)
    tmp14 = tl.load(in_ptr0 + (128 + 768*(((((-2048) + x2) // 128) % 16)) + 12288*y3 + ((((-2048) + x2) % 128))), tmp13 & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp0 >= tmp10
    tmp16 = tl.full([1, 1], 8192, tl.int64)
    tmp17 = tmp0 < tmp16
    tmp18 = tmp15.to(tl.int1)
    tmp19 = tl.load(in_ptr0 + (256 + 768*((((128*(((((-4096) + x2) // 128) % 32)) + 4096*y0 + 524288*y1 + ((((-4096) + x2) % 128))) // 256) % 4096)) + (((128*(((((-4096) + x2) // 128) % 32)) + 4096*y0 + 524288*y1 + ((((-4096) + x2) % 128))) % 256))), tmp18 & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp20 = tl.where(tmp12, tmp14, tmp19)
    tmp21 = tl.where(tmp6, tmp8, tmp20)
    tl.store(out_ptr0 + (x2 + 8192*y3), tmp21, ymask)
    tl.store(out_ptr1 + (128*x2 + 1048576*(y3 // 128) + ((y3 % 128))), tmp21, ymask)
