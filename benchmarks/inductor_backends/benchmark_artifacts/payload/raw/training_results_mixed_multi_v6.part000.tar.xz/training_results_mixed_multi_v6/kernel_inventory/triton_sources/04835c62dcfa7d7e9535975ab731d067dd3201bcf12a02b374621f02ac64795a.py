
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 8192, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*bf16', 'out_ptr2': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=5, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy__unsafe_view_add_clone_div_expand_mul_neg_pow_slice_slice_backward_sum_transpose_unsqueeze_view_15', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 9, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 32768, 'r0_': 16875776}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy__unsafe_view_add_clone_div_expand_mul_neg_pow_slice_slice_backward_sum_transpose_unsqueeze_view_15(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 8192
    r0_numel = 128
    R0_BLOCK: tl.constexpr = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_2 = r0_index
    x0 = (xindex % 64)
    x1 = xindex // 64
    x3 = xindex
    tmp30 = tl.load(in_ptr0 + (r0_2 + 128*x1 + 16384*x0), None, eviction_policy='evict_first').to(tl.float32)
    tmp35 = tl.load(in_ptr2 + (r0_2 + 128*x1), None, eviction_policy='evict_last').to(tl.float32)
    tmp38 = tl.load(in_ptr3 + (r0_2), None, eviction_policy='evict_last').to(tl.float32)
    tmp41 = tl.load(in_ptr4 + (r0_2 + 128*x3), None, eviction_policy='evict_first').to(tl.float32)
    tmp47 = tl.load(in_ptr5 + (x3), None, eviction_policy='evict_last')
    tmp0 = (r0_2).to(tl.int64)
    tmp1 = (tmp0).to(tl.int64)
    tmp2 = tl.full([1, 1], 64, tl.int64)
    tmp3 = tmp1 >= tmp2
    tmp4 = tmp3.to(tl.int1)
    tmp5 = tl.load(in_ptr0 + ((-64) + r0_2 + 128*x1 + 16384*x0), tmp4, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp6 = tmp5.to(tl.float32)
    tmp7 = tl.full([1, 1], 0.29730177875068026, tl.float32)
    tmp8 = tmp6 * tmp7
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tl.load(in_ptr1 + ((-64) + r0_2 + 128*x1), tmp4, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp11 = tmp9 * tmp10
    tmp12 = -tmp11
    tmp13 = tl.full(tmp12.shape, 0.0, tmp12.dtype)
    tmp14 = tl.where(tmp4, tmp12, tmp13)
    tmp15 = tl.full([1, 1], 0.0, tl.float32)
    tmp16 = tl.where(tmp3, tmp14, tmp15)
    tmp17 = tmp1 < tmp2
    tmp18 = tmp17.to(tl.int1)
    tmp19 = tl.load(in_ptr0 + (64 + r0_2 + 128*x1 + 16384*x0), tmp18, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tl.full([1, 1], 0.29730177875068026, tl.float32)
    tmp22 = tmp20 * tmp21
    tmp23 = tmp22.to(tl.float32)
    tmp24 = tl.load(in_ptr1 + (64 + r0_2 + 128*x1), tmp18, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp25 = tmp23 * tmp24
    tmp26 = tl.full(tmp25.shape, 0.0, tmp25.dtype)
    tmp27 = tl.where(tmp18, tmp25, tmp26)
    tmp28 = tl.where(tmp17, tmp27, tmp15)
    tmp29 = tmp16 + tmp28
    tmp31 = tmp30.to(tl.float32)
    tmp32 = tl.full([1, 1], 0.29730177875068026, tl.float32)
    tmp33 = tmp31 * tmp32
    tmp34 = tmp33.to(tl.float32)
    tmp36 = tmp34 * tmp35
    tmp37 = tmp29 + tmp36
    tmp39 = tmp37 * tmp38
    tmp40 = tmp39.to(tl.float32)
    tmp42 = tmp41.to(tl.float32)
    tmp43 = tmp40 * tmp42
    tmp44 = tl.broadcast_to(tmp43, [XBLOCK, R0_BLOCK])
    tmp46 = tl.sum(tmp44, 1)[:, None].to(tl.float32)
    tmp48 = tmp40 * tmp47
    tmp49 = tl.full([1, 1], -0.5, tl.float32)
    tmp50 = tmp46 * tmp49
    tmp51 = tmp47 * tmp47
    tmp52 = tmp51 * tmp47
    tmp53 = tmp50 * tmp52
    tmp54 = tl.full([1, 1], 0.0078125, tl.float32)
    tmp55 = tmp53 * tmp54
    tmp56 = tl.full([1, 1], 2.0, tl.float32)
    tmp57 = tmp42 * tmp56
    tmp58 = tmp55 * tmp57
    tmp59 = tmp48 + tmp58
    tmp60 = tmp59.to(tl.float32)
    tl.store(out_ptr0 + (r0_2 + 128*x1 + 16384*x0), tmp37, None)
    tl.store(out_ptr2 + (r0_2 + 128*x3), tmp60, None)
