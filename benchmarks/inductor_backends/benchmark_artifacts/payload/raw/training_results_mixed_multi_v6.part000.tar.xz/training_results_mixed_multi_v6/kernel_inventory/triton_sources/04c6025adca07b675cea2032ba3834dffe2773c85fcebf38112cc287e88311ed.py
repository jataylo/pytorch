
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 524288, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_out_ptr1': '*fp32', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=3, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy_add_mean_mul_neg_pow_rsqrt_stack_unbind_unsqueeze_view_5', 'mutated_arg_names': ['in_out_ptr0', 'in_out_ptr1'], 'optimize_mem': False, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 14, 'num_store': 4, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 5391360, 'r0_': 1222043136}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mul_neg_pow_rsqrt_stack_unbind_unsqueeze_view_5(in_out_ptr0, in_out_ptr1, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 336960
    r0_numel = 128
    R0_BLOCK: tl.constexpr = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    x3 = xindex // 24
    tmp0 = tl.load(in_ptr0 + (r0_1 + 128*x0), xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp12 = tl.load(in_ptr1 + (r0_1 + 128*x0), xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp24 = tl.load(in_ptr2 + (r0_1), None, eviction_policy='evict_last').to(tl.float32)
    tmp27 = tl.load(in_ptr3 + (r0_1 + 128*x3), xmask, eviction_policy='evict_last', other=0.0)
    tmp60 = tl.load(in_ptr4 + (r0_1 + 128*x3), xmask, eviction_policy='evict_last', other=0.0)
    tmp65 = tl.load(in_ptr5 + (r0_1), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tmp1 * tmp1
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp5 = tl.where(xmask, tmp3, 0)
    tmp6 = tl.sum(tmp5, 1)[:, None].to(tl.float32)
    tmp7 = tl.full([1, 1], 128.0, tl.float32)
    tmp8 = (tmp6 / tmp7)
    tmp9 = tl.full([1, 1], 1e-06, tl.float32)
    tmp10 = tmp8 + tmp9
    tmp11 = tl.rsqrt(tmp10)
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tmp13 * tmp13
    tmp15 = tl.broadcast_to(tmp14, [XBLOCK, R0_BLOCK])
    tmp17 = tl.where(xmask, tmp15, 0)
    tmp18 = tl.sum(tmp17, 1)[:, None].to(tl.float32)
    tmp19 = (tmp18 / tmp7)
    tmp20 = tmp19 + tmp9
    tmp21 = tl.rsqrt(tmp20)
    tmp22 = tmp1 * tmp11
    tmp23 = tmp22.to(tl.float32)
    tmp25 = tmp23 * tmp24
    tmp26 = tmp25.to(tl.float32)
    tmp28 = tmp26 * tmp27
    tmp29 = ((r0_1 % 2)).to(tl.int32)
    tmp30 = tl.full([1, 1], 0, tl.int64)
    tmp31 = tmp29 >= tmp30
    tmp32 = ((r0_1 % 2)).to(tl.int64)
    tmp33 = (tmp32).to(tl.int64)
    tmp34 = tl.full([1, 1], 1, tl.int64)
    tmp35 = tmp33 < tmp34
    tmp36 = tmp35.to(tl.int1)
    tmp37 = tl.load(in_ptr0 + (1 + 2*(r0_1 // 2) + 128*x0), tmp36 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp38 = tmp37.to(tl.float32)
    tmp39 = tmp38 * tmp11
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tl.load(in_ptr2 + (tl.broadcast_to(1 + 2*(r0_1 // 2), [XBLOCK, R0_BLOCK])), tmp36 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp42 = tmp40 * tmp41
    tmp43 = -tmp42
    tmp44 = tl.full(tmp43.shape, 0.0, tmp43.dtype)
    tmp45 = tl.where(tmp36, tmp43, tmp44)
    tmp46 = tmp29 >= tmp34
    tmp47 = tl.full([1, 1], 2, tl.int64)
    tmp48 = tmp29 < tmp47
    tmp49 = tmp46.to(tl.int1)
    tmp50 = tl.load(in_ptr0 + (2*(r0_1 // 2) + 128*x0), tmp49 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp51 = tmp50.to(tl.float32)
    tmp52 = tmp51 * tmp11
    tmp53 = tmp52.to(tl.float32)
    tmp54 = tl.load(in_ptr2 + (tl.broadcast_to(2*(r0_1 // 2), [XBLOCK, R0_BLOCK])), tmp49 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp55 = tmp53 * tmp54
    tmp56 = tl.full(tmp55.shape, 0.0, tmp55.dtype)
    tmp57 = tl.where(tmp49, tmp55, tmp56)
    tmp58 = tl.where(tmp35, tmp45, tmp57)
    tmp59 = tmp58.to(tl.float32)
    tmp61 = tmp59 * tmp60
    tmp62 = tmp28 + tmp61
    tmp63 = tmp13 * tmp21
    tmp64 = tmp63.to(tl.float32)
    tmp66 = tmp64 * tmp65
    tmp67 = tmp66.to(tl.float32)
    tmp68 = tmp67 * tmp27
    tmp69 = tl.load(in_ptr1 + (1 + 2*(r0_1 // 2) + 128*x0), tmp36 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp70 = tmp69.to(tl.float32)
    tmp71 = tmp70 * tmp21
    tmp72 = tmp71.to(tl.float32)
    tmp73 = tl.load(in_ptr5 + (tl.broadcast_to(1 + 2*(r0_1 // 2), [XBLOCK, R0_BLOCK])), tmp36 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp74 = tmp72 * tmp73
    tmp75 = -tmp74
    tmp76 = tl.full(tmp75.shape, 0.0, tmp75.dtype)
    tmp77 = tl.where(tmp36, tmp75, tmp76)
    tmp78 = tl.load(in_ptr1 + (2*(r0_1 // 2) + 128*x0), tmp49 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp79 = tmp78.to(tl.float32)
    tmp80 = tmp79 * tmp21
    tmp81 = tmp80.to(tl.float32)
    tmp82 = tl.load(in_ptr5 + (tl.broadcast_to(2*(r0_1 // 2), [XBLOCK, R0_BLOCK])), tmp49 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp83 = tmp81 * tmp82
    tmp84 = tl.full(tmp83.shape, 0.0, tmp83.dtype)
    tmp85 = tl.where(tmp49, tmp83, tmp84)
    tmp86 = tl.where(tmp35, tmp77, tmp85)
    tmp87 = tmp86.to(tl.float32)
    tmp88 = tmp87 * tmp60
    tmp89 = tmp68 + tmp88
    tl.store(in_out_ptr0 + (x0), tmp11, xmask)
    tl.store(in_out_ptr1 + (x0), tmp21, xmask)
    tl.store(out_ptr0 + (r0_1 + 128*x0), tmp62, xmask)
    tl.store(out_ptr1 + (r0_1 + 128*x0), tmp89, xmask)
