
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2097152, 'r0_': 64},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i1', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'in_ptr4': '*fp32', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (10,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (11,): [['tt.divisibility', 16]], (12,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy__unsafe_view_clone_div_exp_expand_masked_fill_mul_neg_sigmoid_sub_sum_transpose_unsqueeze_view_161', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 11, 'num_store': 4, 'num_reduction': 4, 'autotune_hints': set(), 'tiling_scores': {'x': 1161822208, 'r0_': 4263936}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy__unsafe_view_clone_div_exp_expand_masked_fill_mul_neg_sigmoid_sub_sum_transpose_unsqueeze_view_161(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 2097152
    r0_numel = 64
    R0_BLOCK: tl.constexpr = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_3 = r0_index
    x7 = xindex // 128
    x1 = ((xindex // 128) % 64)
    x8 = xindex
    x0 = (xindex % 128)
    x2 = xindex // 8192
    x4 = ((xindex // 8192) % 2)
    x5 = ((xindex // 16384) % 32)
    x6 = xindex // 524288
    x9 = (xindex % 8192)
    tmp0 = tl.load(in_ptr0 + (r0_3 + 64*x7), None, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (r0_3 + 64*x1), None, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x8), None, eviction_policy='evict_last')
    tmp3 = tl.load(in_ptr2 + (x0 + 128*r0_3 + 8192*x2), None, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr3 + (x0 + 128*r0_3 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp11 = tl.load(in_ptr4 + (r0_3 + 64*x2), None, eviction_policy='evict_last')
    tmp17 = tl.load(in_ptr0 + (x1 + 64*r0_3 + 4096*x2), None, eviction_policy='evict_last')
    tmp18 = tl.load(in_ptr1 + (x1 + 64*r0_3), None, eviction_policy='evict_last')
    tmp23 = tl.load(in_ptr5 + (x5 + 32*r0_3 + 2048*x4 + 4096*x6), None, eviction_policy='evict_last').to(tl.float32)
    tmp31 = tl.load(in_ptr6 + (x0 + 128*r0_3 + 8192*x7), None, eviction_policy='evict_last')
    tmp37 = tl.load(in_ptr6 + (x9 + 8192*r0_3 + 524288*x2), None, eviction_policy='evict_first')
    tmp4 = tmp2 - tmp3
    tmp5 = tl.full([1, 1], float("-inf"), tl.float32)
    tmp6 = tl.where(tmp1, tmp5, tmp4)
    tmp7 = libdevice.exp(tmp6)
    tmp8 = tmp0 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp12 = (tmp10 / tmp11)
    tmp13 = tmp8 * tmp12
    tmp14 = tl.broadcast_to(tmp13, [XBLOCK, R0_BLOCK])
    tmp16 = tl.sum(tmp14, 1)[:, None].to(tl.float32)
    tmp19 = tmp3 - tmp2
    tmp20 = tl.where(tmp18, tmp5, tmp19)
    tmp21 = libdevice.exp(tmp20)
    tmp22 = tmp17 * tmp21
    tmp24 = tl.sigmoid(tmp23)
    tmp25 = tmp24.to(tl.float32)
    tmp26 = tmp12 * tmp25
    tmp27 = tmp22 * tmp26
    tmp28 = tl.broadcast_to(tmp27, [XBLOCK, R0_BLOCK])
    tmp30 = tl.sum(tmp28, 1)[:, None].to(tl.float32)
    tmp32 = tl.full([1, 1], 0.0, tl.float32)
    tmp33 = tl.where(tmp1, tmp32, tmp31)
    tmp34 = tl.broadcast_to(tmp33, [XBLOCK, R0_BLOCK])
    tmp36 = tl.sum(tmp34, 1)[:, None].to(tl.float32)
    tmp38 = tl.where(tmp18, tmp32, tmp37)
    tmp39 = -tmp38
    tmp40 = tl.broadcast_to(tmp39, [XBLOCK, R0_BLOCK])
    tmp42 = tl.sum(tmp40, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x8), tmp16, None)
    tl.store(out_ptr1 + (x8), tmp30, None)
    tl.store(out_ptr2 + (x8), tmp36, None)
    tl.store(out_ptr3 + (x8), tmp42, None)
