
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_sum_unsqueeze_zeros_like_158', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 12650496}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_sum_unsqueeze_zeros_like_158(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1048576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 64) % 64)
    x0 = (xindex % 64)
    x2 = xindex // 4096
    x3 = xindex
    tmp11 = tl.load(in_ptr0 + (128 + x0 + 4096*x2), None, eviction_policy='evict_last')
    tmp13 = tl.load(in_ptr0 + (x3), None)
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 2, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 2, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.full([1], 0.0, tl.float32)
    tmp9 = tl.full(tmp8.shape, 0.0, tmp8.dtype)
    tmp10 = tl.where(tmp7, tmp8, tmp9)
    tmp12 = tl.where(tmp6, tmp10, tmp11)
    tmp14 = tl.where(tmp2, tmp12, tmp13)
    tmp15 = (x1).to(tl.int64)
    tmp16 = (tmp15).to(tl.int64)
    tmp17 = tmp16 < tmp5
    tmp18 = tmp17.to(tl.int1)
    tmp19 = (x0).to(tl.int64)
    tmp20 = (tmp19).to(tl.int64)
    tmp21 = tl.full([1], 2, tl.int64)
    tmp22 = tmp20 < tmp21
    tmp23 = tmp22.to(tl.int1)
    tmp24 = tmp23 & tmp18
    tmp25 = tl.load(in_ptr0 + (128 + x0 + 4096*x2), tmp24, eviction_policy='evict_last', other=0.0)
    tmp26 = tl.load(in_ptr1 + (x1 + 4096*x2), tmp24, eviction_policy='evict_last', other=0.0)
    tmp27 = tmp25 * tmp26
    tmp28 = tl.full(tmp27.shape, 0.0, tmp27.dtype)
    tmp29 = tl.where(tmp24, tmp27, tmp28)
    tmp30 = tl.full([1], 0.0, tl.float32)
    tmp31 = tl.where(tmp22, tmp29, tmp30)
    tmp32 = tl.full(tmp31.shape, 0.0, tmp31.dtype)
    tmp33 = tl.where(tmp18, tmp31, tmp32)
    tmp34 = tl.full([1], 0.0, tl.float32)
    tmp35 = tl.where(tmp17, tmp33, tmp34)
    tmp36 = tmp14 + tmp35
    tmp37 = tl.load(in_ptr0 + (128 + x0 + 4096*x2), tmp7, eviction_policy='evict_last', other=0.0)
    tmp38 = tl.load(in_ptr0 + (128 + 4096*x2), tmp7, eviction_policy='evict_last', other=0.0)
    tmp39 = tl.load(in_ptr2 + (2*x0 + 4*x2), tmp7, eviction_policy='evict_last', other=0.0)
    tmp40 = tmp38 * tmp39
    tmp41 = tl.load(in_ptr0 + (129 + 4096*x2), tmp7, eviction_policy='evict_last', other=0.0)
    tmp42 = tl.load(in_ptr2 + (1 + 2*x0 + 4*x2), tmp7, eviction_policy='evict_last', other=0.0)
    tmp43 = tmp41 * tmp42
    tmp44 = tmp40 + tmp43
    tmp45 = tmp37 + tmp44
    tmp46 = tl.full(tmp45.shape, 0.0, tmp45.dtype)
    tmp47 = tl.where(tmp7, tmp45, tmp46)
    tmp48 = tl.where(tmp6, tmp47, tmp34)
    tmp49 = tl.where(tmp2, tmp48, tmp34)
    tmp50 = tmp36 + tmp49
    tl.store(out_ptr0 + (x3), tmp50, None)
