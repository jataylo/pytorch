
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=3, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mul_slice_split_transpose_unsqueeze_view_6', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 11043328}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mul_slice_split_transpose_unsqueeze_view_6(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1048576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 256)
    x5 = xindex // 256
    x2 = ((xindex // 4096) % 128)
    x4 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 64, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.load(in_ptr0 + (512*x5 + (x0)), tmp7, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tl.load(in_ptr1 + (x5), tmp7, eviction_policy='evict_last', other=0.0)
    tmp11 = tmp9 * tmp10
    tmp12 = tl.load(in_ptr2 + (x0), tmp7, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tl.full([1], 1.0, tl.float32)
    tmp15 = tmp13 + tmp14
    tmp16 = tmp11 * tmp15
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tl.load(in_ptr3 + (64*x2 + (x0)), tmp7, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp19 = tmp17 * tmp18
    tmp20 = tl.load(in_ptr4 + (64*x5 + (x0)), tmp7, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp21 = tmp19 + tmp20
    tmp22 = tl.full(tmp21.shape, 0.0, tmp21.dtype)
    tmp23 = tl.where(tmp7, tmp21, tmp22)
    tmp24 = tmp0 >= tmp5
    tmp25 = tl.full([1], 256, tl.int64)
    tmp26 = tmp0 < tmp25
    tmp27 = tmp24.to(tl.int1)
    tmp28 = tl.load(in_ptr0 + (64 + 512*x5 + ((-64) + x0)), tmp27, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tl.load(in_ptr1 + (x5), tmp27, eviction_policy='evict_last', other=0.0)
    tmp31 = tmp29 * tmp30
    tmp32 = tl.load(in_ptr2 + (64 + ((-64) + x0)), tmp27, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp33 = tmp32.to(tl.float32)
    tmp34 = tl.full([1], 1.0, tl.float32)
    tmp35 = tmp33 + tmp34
    tmp36 = tmp31 * tmp35
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp27, tmp37, tmp38)
    tmp40 = tl.where(tmp6, tmp23, tmp39)
    tmp41 = tmp40.to(tl.float32)
    tmp42 = tl.full([1], 0.25, tl.float32)
    tmp43 = tmp41 * tmp42
    tl.store(out_ptr1 + (256*(((x4 // 4096) % 128)) + 32768*(((x4 // 256) % 16)) + 524288*(x4 // 524288) + ((x4 % 256))), tmp43, None)
