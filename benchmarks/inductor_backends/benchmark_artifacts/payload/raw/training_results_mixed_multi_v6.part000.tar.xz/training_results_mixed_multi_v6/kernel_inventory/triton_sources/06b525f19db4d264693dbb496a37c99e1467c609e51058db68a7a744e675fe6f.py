
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2048}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_clone_expand_mul_select_slice_sum_unsqueeze_158', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 10240}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_clone_expand_mul_select_slice_sum_unsqueeze_158(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1280
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 5
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (320 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (5*x2), xmask, eviction_policy='evict_last')
    tmp3 = tl.load(in_ptr0 + (321 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr1 + (1 + 5*x2), xmask, eviction_policy='evict_last')
    tmp7 = tl.load(in_ptr0 + (322 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp8 = tl.load(in_ptr1 + (2 + 5*x2), xmask, eviction_policy='evict_last')
    tmp11 = tl.load(in_ptr0 + (323 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp12 = tl.load(in_ptr1 + (3 + 5*x2), xmask, eviction_policy='evict_last')
    tmp15 = tl.load(in_ptr0 + (324 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp16 = tl.load(in_ptr1 + (4 + 5*x2), xmask, eviction_policy='evict_last')
    tmp2 = tmp0 * tmp1
    tmp5 = tmp3 * tmp4
    tmp6 = tmp2 + tmp5
    tmp9 = tmp7 * tmp8
    tmp10 = tmp6 + tmp9
    tmp13 = tmp11 * tmp12
    tmp14 = tmp10 + tmp13
    tmp17 = tmp15 * tmp16
    tmp18 = tmp14 + tmp17
    tl.store(out_ptr0 + (x2), tmp18, xmask)
