
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3587104}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 218496
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex // 72832
    x0 = (xindex % 32)
    x1 = ((xindex // 32) % 2276)
    x3 = xindex // 32
    x4 = xindex
    tmp20 = tl.load(in_ptr0 + (x1), xmask, eviction_policy='evict_last')
    tmp22 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last')
    tmp26 = tl.load(in_ptr0 + (x3), xmask, eviction_policy='evict_last')
    tmp0 = (x2).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp8 = (tmp7).to(tl.int64)
    tmp9 = tl.full([1], 0, tl.int64)
    tmp10 = tmp8 == tmp9
    tmp11 = tmp6 & tmp10
    tmp12 = tmp11.to(tl.int1)
    tmp13 = tl.load(in_ptr0 + (2276 + x1), tmp12 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp12 & xmask, eviction_policy='evict_last', other=0.0)
    tmp16 = tmp14 * tmp15
    tmp17 = tl_math.sin(tmp16)
    tmp18 = tl.full(tmp17.shape, 0.0, tmp17.dtype)
    tmp19 = tl.where(tmp12, tmp17, tmp18)
    tmp21 = tmp20.to(tl.float32)
    tmp23 = tmp21 * tmp22
    tmp24 = tl_math.sin(tmp23)
    tmp25 = tl.where(tmp11, tmp19, tmp24)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tmp27 * tmp22
    tmp29 = tl_math.sin(tmp28)
    tmp30 = tl.where(tmp2, tmp25, tmp29)
    tmp31 = tl_math.cos(tmp16)
    tmp32 = tl.full(tmp31.shape, 0.0, tmp31.dtype)
    tmp33 = tl.where(tmp12, tmp31, tmp32)
    tmp34 = tl_math.cos(tmp23)
    tmp35 = tl.where(tmp11, tmp33, tmp34)
    tmp36 = tl_math.cos(tmp28)
    tmp37 = tl.where(tmp2, tmp35, tmp36)
    tl.store(out_ptr0 + (x4), tmp30, xmask)
    tl.store(out_ptr1 + (x4), tmp37, xmask)
