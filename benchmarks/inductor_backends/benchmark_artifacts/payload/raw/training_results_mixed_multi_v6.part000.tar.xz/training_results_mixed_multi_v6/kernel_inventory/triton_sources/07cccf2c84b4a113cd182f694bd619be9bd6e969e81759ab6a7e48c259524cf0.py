
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 524288, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*i1', 'in_ptr5': '*fp32', 'in_ptr6': '*i1', 'out_ptr1': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_div_exp_masked_fill_mul_ones_select_sub_sum_triu_unsqueeze_view_141', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 14, 'num_store': 2, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 4268032, 'r0_': 25165824}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_red_fused__to_copy_div_exp_masked_fill_mul_ones_select_sub_sum_triu_unsqueeze_view_141(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr1, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 524288
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x1 = ((xindex // 64) % 64)
    x2 = xindex // 4096
    tmp2 = tl.load(in_ptr1 + (x1 + 128*x2), None, eviction_policy='evict_last')
    x0 = (xindex % 64)
    tmp8 = tl.load(in_ptr3 + (x0 + 128*x2), None, eviction_policy='evict_last')
    x4 = (xindex % 4096)
    tmp11 = tl.load(in_ptr4 + (x4), None, eviction_policy='evict_last')
    _tmp20 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    x5 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_3 + 128*x1 + 16384*x2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp6 = tl.load(in_ptr2 + (r0_3 + 128*x0 + 16384*x2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp12 = tl.load(in_ptr5 + (r0_3 + 128*x1 + 16384*x2), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp13 = tl.load(in_ptr5 + (r0_3 + 128*x0 + 16384*x2), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = (tmp1 / tmp2)
        tmp4 = tl.full([1, 1], 0.08838834764831843, tl.float32)
        tmp5 = tmp3 * tmp4
        tmp7 = tmp6.to(tl.float32)
        tmp9 = (tmp7 / tmp8)
        tmp10 = tmp5 * tmp9
        tmp14 = tmp12 - tmp13
        tmp15 = tl.full([1, 1], float("-inf"), tl.float32)
        tmp16 = tl.where(tmp11, tmp15, tmp14)
        tmp17 = libdevice.exp(tmp16)
        tmp18 = tmp10 * tmp17
        tmp19 = tl.broadcast_to(tmp18, [XBLOCK, R0_BLOCK])
        tmp21 = _tmp20 + tmp19
        _tmp20 = tl.where(r0_mask, tmp21, _tmp20)
    tmp20 = tl.sum(_tmp20, 1)[:, None]
    tmp22 = tl.load(in_ptr6 + (x4), None, eviction_policy='evict_last')
    tmp23 = tl.full([1, 1], 0.0, tl.float32)
    tmp24 = tl.where(tmp22, tmp23, tmp20)
    tmp25 = tmp24.to(tl.float32)
    tl.store(out_ptr1 + (x5), tmp25, None)
    tmp28 = tl.load(in_ptr1 + (64 + x1 + 128*x2), None, eviction_policy='evict_last')
    tmp34 = tl.load(in_ptr3 + (64 + x0 + 128*x2), None, eviction_policy='evict_last')
    _tmp45 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp26 = tl.load(in_ptr0 + (8192 + r0_3 + 128*x1 + 16384*x2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp32 = tl.load(in_ptr2 + (8192 + r0_3 + 128*x0 + 16384*x2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp37 = tl.load(in_ptr5 + (8192 + r0_3 + 128*x1 + 16384*x2), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp38 = tl.load(in_ptr5 + (8192 + r0_3 + 128*x0 + 16384*x2), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp27 = tmp26.to(tl.float32)
        tmp29 = (tmp27 / tmp28)
        tmp30 = tl.full([1, 1], 0.08838834764831843, tl.float32)
        tmp31 = tmp29 * tmp30
        tmp33 = tmp32.to(tl.float32)
        tmp35 = (tmp33 / tmp34)
        tmp36 = tmp31 * tmp35
        tmp39 = tmp37 - tmp38
        tmp40 = tl.full([1, 1], float("-inf"), tl.float32)
        tmp41 = tl.where(tmp11, tmp40, tmp39)
        tmp42 = libdevice.exp(tmp41)
        tmp43 = tmp36 * tmp42
        tmp44 = tl.broadcast_to(tmp43, [XBLOCK, R0_BLOCK])
        tmp46 = _tmp45 + tmp44
        _tmp45 = tl.where(r0_mask, tmp46, _tmp45)
    tmp45 = tl.sum(_tmp45, 1)[:, None]
    tmp47 = tl.full([1, 1], 0.0, tl.float32)
    tmp48 = tl.where(tmp22, tmp47, tmp45)
    tmp49 = tmp48.to(tl.float32)
    tl.store(out_ptr3 + (x5), tmp49, None)
