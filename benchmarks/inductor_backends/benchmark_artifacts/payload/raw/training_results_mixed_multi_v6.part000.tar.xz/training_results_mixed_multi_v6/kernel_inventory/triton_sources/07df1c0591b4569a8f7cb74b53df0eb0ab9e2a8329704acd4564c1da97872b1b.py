
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_sum_unsqueeze_zeros_like_152', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 28, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 8192}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_sum_unsqueeze_zeros_like_152(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 4
    x2 = xindex
    tmp10 = tl.load(in_ptr0 + (320 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp12 = tl.load(in_ptr0 + (256 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp42 = tl.load(in_ptr3 + (4*x2), xmask, eviction_policy='evict_last')
    tmp50 = tl.load(in_ptr0 + (321 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp52 = tl.load(in_ptr0 + (257 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp76 = tl.load(in_ptr3 + (1 + 4*x2), xmask, eviction_policy='evict_last')
    tmp85 = tl.load(in_ptr0 + (322 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp87 = tl.load(in_ptr0 + (258 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp111 = tl.load(in_ptr3 + (2 + 4*x2), xmask, eviction_policy='evict_last')
    tmp120 = tl.load(in_ptr0 + (323 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp122 = tl.load(in_ptr0 + (259 + 4096*x1), xmask, eviction_policy='evict_last')
    tmp146 = tl.load(in_ptr3 + (3 + 4*x2), xmask, eviction_policy='evict_last')
    tmp0 = tl.full([1], 4, tl.int32)
    tmp1 = tl.full([1], 5, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = tl.full([1], 0, tl.int64)
    tmp4 = tl.full([1], 5, tl.int64)
    tmp5 = tmp3 < tmp4
    tmp6 = tmp5.to(tl.int1)
    tmp7 = tl.full([1], 0.0, tl.float32)
    tmp8 = tl.full(tmp7.shape, 0.0, tmp7.dtype)
    tmp9 = tl.where(tmp6, tmp7, tmp8)
    tmp11 = tl.where(tmp5, tmp9, tmp10)
    tmp13 = tl.where(tmp2, tmp11, tmp12)
    tmp14 = tl.full([1], 4, tl.int64)
    tmp15 = tmp14 < tmp4
    tmp16 = tmp15.to(tl.int1)
    tmp17 = tl.full([1], 0, tl.int64)
    tmp18 = tl.full([1], 5, tl.int64)
    tmp19 = tmp17 < tmp18
    tmp20 = tmp19.to(tl.int1)
    tmp21 = tmp20 & tmp16
    tmp22 = tl.load(in_ptr0 + (320 + 4096*x1), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp23 = tl.load(in_ptr1 + (4 + 4096*x1), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp24 = tmp22 * tmp23
    tmp25 = tl.full(tmp24.shape, 0.0, tmp24.dtype)
    tmp26 = tl.where(tmp21, tmp24, tmp25)
    tmp27 = tl.full([1], 0.0, tl.float32)
    tmp28 = tl.where(tmp19, tmp26, tmp27)
    tmp29 = tl.full(tmp28.shape, 0.0, tmp28.dtype)
    tmp30 = tl.where(tmp16, tmp28, tmp29)
    tmp31 = tl.full([1], 0.0, tl.float32)
    tmp32 = tl.where(tmp15, tmp30, tmp31)
    tmp33 = tmp13 + tmp32
    tmp34 = tl.load(in_ptr0 + (320 + 4096*x1), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp35 = tl.load(in_ptr2 + (5*x1), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp36 = tmp34 + tmp35
    tmp37 = tl.full(tmp36.shape, 0.0, tmp36.dtype)
    tmp38 = tl.where(tmp6, tmp36, tmp37)
    tmp39 = tl.where(tmp5, tmp38, tmp31)
    tmp40 = tl.where(tmp2, tmp39, tmp31)
    tmp41 = tmp33 + tmp40
    tmp43 = tmp41 * tmp42
    tmp44 = tl.full([1], 1, tl.int64)
    tmp45 = tmp44 < tmp4
    tmp46 = tmp45.to(tl.int1)
    tmp47 = tl.full([1], 0.0, tl.float32)
    tmp48 = tl.full(tmp47.shape, 0.0, tmp47.dtype)
    tmp49 = tl.where(tmp46, tmp47, tmp48)
    tmp51 = tl.where(tmp45, tmp49, tmp50)
    tmp53 = tl.where(tmp2, tmp51, tmp52)
    tmp54 = tl.full([1], 1, tl.int64)
    tmp55 = tmp54 < tmp18
    tmp56 = tmp55.to(tl.int1)
    tmp57 = tmp56 & tmp16
    tmp58 = tl.load(in_ptr0 + (321 + 4096*x1), tmp57 & xmask, eviction_policy='evict_last', other=0.0)
    tmp59 = tl.load(in_ptr1 + (4 + 4096*x1), tmp57 & xmask, eviction_policy='evict_last', other=0.0)
    tmp60 = tmp58 * tmp59
    tmp61 = tl.full(tmp60.shape, 0.0, tmp60.dtype)
    tmp62 = tl.where(tmp57, tmp60, tmp61)
    tmp63 = tl.where(tmp55, tmp62, tmp27)
    tmp64 = tl.full(tmp63.shape, 0.0, tmp63.dtype)
    tmp65 = tl.where(tmp16, tmp63, tmp64)
    tmp66 = tl.where(tmp15, tmp65, tmp31)
    tmp67 = tmp53 + tmp66
    tmp68 = tl.load(in_ptr0 + (321 + 4096*x1), tmp46 & xmask, eviction_policy='evict_last', other=0.0)
    tmp69 = tl.load(in_ptr2 + (1 + 5*x1), tmp46 & xmask, eviction_policy='evict_last', other=0.0)
    tmp70 = tmp68 + tmp69
    tmp71 = tl.full(tmp70.shape, 0.0, tmp70.dtype)
    tmp72 = tl.where(tmp46, tmp70, tmp71)
    tmp73 = tl.where(tmp45, tmp72, tmp31)
    tmp74 = tl.where(tmp2, tmp73, tmp31)
    tmp75 = tmp67 + tmp74
    tmp77 = tmp75 * tmp76
    tmp78 = tmp43 + tmp77
    tmp79 = tl.full([1], 2, tl.int64)
    tmp80 = tmp79 < tmp4
    tmp81 = tmp80.to(tl.int1)
    tmp82 = tl.full([1], 0.0, tl.float32)
    tmp83 = tl.full(tmp82.shape, 0.0, tmp82.dtype)
    tmp84 = tl.where(tmp81, tmp82, tmp83)
    tmp86 = tl.where(tmp80, tmp84, tmp85)
    tmp88 = tl.where(tmp2, tmp86, tmp87)
    tmp89 = tl.full([1], 2, tl.int64)
    tmp90 = tmp89 < tmp18
    tmp91 = tmp90.to(tl.int1)
    tmp92 = tmp91 & tmp16
    tmp93 = tl.load(in_ptr0 + (322 + 4096*x1), tmp92 & xmask, eviction_policy='evict_last', other=0.0)
    tmp94 = tl.load(in_ptr1 + (4 + 4096*x1), tmp92 & xmask, eviction_policy='evict_last', other=0.0)
    tmp95 = tmp93 * tmp94
    tmp96 = tl.full(tmp95.shape, 0.0, tmp95.dtype)
    tmp97 = tl.where(tmp92, tmp95, tmp96)
    tmp98 = tl.where(tmp90, tmp97, tmp27)
    tmp99 = tl.full(tmp98.shape, 0.0, tmp98.dtype)
    tmp100 = tl.where(tmp16, tmp98, tmp99)
    tmp101 = tl.where(tmp15, tmp100, tmp31)
    tmp102 = tmp88 + tmp101
    tmp103 = tl.load(in_ptr0 + (322 + 4096*x1), tmp81 & xmask, eviction_policy='evict_last', other=0.0)
    tmp104 = tl.load(in_ptr2 + (2 + 5*x1), tmp81 & xmask, eviction_policy='evict_last', other=0.0)
    tmp105 = tmp103 + tmp104
    tmp106 = tl.full(tmp105.shape, 0.0, tmp105.dtype)
    tmp107 = tl.where(tmp81, tmp105, tmp106)
    tmp108 = tl.where(tmp80, tmp107, tmp31)
    tmp109 = tl.where(tmp2, tmp108, tmp31)
    tmp110 = tmp102 + tmp109
    tmp112 = tmp110 * tmp111
    tmp113 = tmp78 + tmp112
    tmp114 = tl.full([1], 3, tl.int64)
    tmp115 = tmp114 < tmp4
    tmp116 = tmp115.to(tl.int1)
    tmp117 = tl.full([1], 0.0, tl.float32)
    tmp118 = tl.full(tmp117.shape, 0.0, tmp117.dtype)
    tmp119 = tl.where(tmp116, tmp117, tmp118)
    tmp121 = tl.where(tmp115, tmp119, tmp120)
    tmp123 = tl.where(tmp2, tmp121, tmp122)
    tmp124 = tl.full([1], 3, tl.int64)
    tmp125 = tmp124 < tmp18
    tmp126 = tmp125.to(tl.int1)
    tmp127 = tmp126 & tmp16
    tmp128 = tl.load(in_ptr0 + (323 + 4096*x1), tmp127 & xmask, eviction_policy='evict_last', other=0.0)
    tmp129 = tl.load(in_ptr1 + (4 + 4096*x1), tmp127 & xmask, eviction_policy='evict_last', other=0.0)
    tmp130 = tmp128 * tmp129
    tmp131 = tl.full(tmp130.shape, 0.0, tmp130.dtype)
    tmp132 = tl.where(tmp127, tmp130, tmp131)
    tmp133 = tl.where(tmp125, tmp132, tmp27)
    tmp134 = tl.full(tmp133.shape, 0.0, tmp133.dtype)
    tmp135 = tl.where(tmp16, tmp133, tmp134)
    tmp136 = tl.where(tmp15, tmp135, tmp31)
    tmp137 = tmp123 + tmp136
    tmp138 = tl.load(in_ptr0 + (323 + 4096*x1), tmp116 & xmask, eviction_policy='evict_last', other=0.0)
    tmp139 = tl.load(in_ptr2 + (3 + 5*x1), tmp116 & xmask, eviction_policy='evict_last', other=0.0)
    tmp140 = tmp138 + tmp139
    tmp141 = tl.full(tmp140.shape, 0.0, tmp140.dtype)
    tmp142 = tl.where(tmp116, tmp140, tmp141)
    tmp143 = tl.where(tmp115, tmp142, tmp31)
    tmp144 = tl.where(tmp2, tmp143, tmp31)
    tmp145 = tmp137 + tmp144
    tmp147 = tmp145 * tmp146
    tmp148 = tmp113 + tmp147
    tl.store(out_ptr0 + (x2), tmp148, xmask)
