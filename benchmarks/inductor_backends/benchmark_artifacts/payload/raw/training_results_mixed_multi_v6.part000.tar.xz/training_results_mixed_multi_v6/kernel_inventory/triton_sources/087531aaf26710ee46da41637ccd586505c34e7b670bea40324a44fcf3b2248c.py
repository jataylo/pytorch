
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 262144, 'r0_': 8192},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i1', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=6, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__safe_softmax_add_cat_ones_prepare_softmax_online_scalar_tensor_unsqueeze_view_where_8', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 15775143200}, 'add_persistent_rblock': True, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_red_fused__safe_softmax_add_cat_ones_prepare_softmax_online_scalar_tensor_unsqueeze_view_where_8(in_ptr0, in_ptr1, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 177624
    r0_numel = 7401
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x3 = xindex
    _tmp24_max = tl.full([XBLOCK, R0_BLOCK], float('-inf'), tl.float32)
    _tmp24_sum = tl.zeros([XBLOCK, R0_BLOCK], tl.float32)
    x0 = (xindex % 7401)
    x1 = xindex // 7401
    _tmp31 = tl.full([XBLOCK, R0_BLOCK], False, tl.int1)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2 + 7401*x3), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = (r0_2).to(tl.int32)
        tmp2 = tl.full([1, 1], 0, tl.int64)
        tmp3 = tmp1 >= tmp2
        tmp4 = (r0_2).to(tl.int64)
        tmp5 = (tmp4).to(tl.int64)
        tmp6 = tl.full([1, 1], 512, tl.int64)
        tmp7 = tmp5 < tmp6
        tmp8 = tmp7.to(tl.int1)
        tmp9 = tl.load(in_ptr1 + (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp8 & xmask, eviction_policy='evict_last', other=0.0)
        tmp10 = tmp1 >= tmp6
        tmp11 = tl.full([1, 1], 7401, tl.int64)
        tmp12 = tmp1 < tmp11
        tmp13 = tmp10.to(tl.int1)
        tmp14 = tl.full([1, 1], True, tl.int1)
        tmp15 = tl.full(tmp14.shape, False, tmp14.dtype)
        tmp16 = tl.where(tmp13, tmp14, tmp15)
        tmp17 = tl.where(tmp7, tmp9, tmp16)
        tmp18 = tl.full([1, 1], 0.0, tl.float32)
        tmp19 = tl.full([1, 1], float("-inf"), tl.float32)
        tmp20 = tl.where(tmp17, tmp18, tmp19)
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp0 + tmp21
        tmp23 = tl.broadcast_to(tmp22, [XBLOCK, R0_BLOCK])

        _tmp24_max_next, _tmp24_sum_next = triton_helpers.online_softmax_combine(
            _tmp24_max, _tmp24_sum, tmp23, False
        )

        _tmp24_max = tl.where(r0_mask & xmask, _tmp24_max_next, _tmp24_max)
        _tmp24_sum = tl.where(r0_mask & xmask, _tmp24_sum_next, _tmp24_sum)
        tmp26 = tmp22 == tmp19
        tmp27 = tmp26 == 0
        tmp28 = tmp27.to(tl.int64)
        tmp29 = (tmp28 != 0)
        tmp30 = tl.broadcast_to(tmp29, [XBLOCK, R0_BLOCK])
        tmp32 = _tmp31 | tmp30
        _tmp31 = tl.where(r0_mask & xmask, tmp32, _tmp31)

    tmp24, tmp25 = triton_helpers.online_softmax_reduce(
        _tmp24_max, _tmp24_sum, 1, False)
    tmp24 = tmp24[:, None]
    tmp25 = tmp25[:, None]
    tmp33 = _tmp31.to(tl.int8)
    tmp31 = triton_helpers.any(tmp33, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp35 = tl.load(in_ptr0 + (r0_2 + 7401*x3), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp34 = tmp31 == 0
        tmp36 = (r0_2).to(tl.int32)
        tmp37 = tl.full([1, 1], 0, tl.int64)
        tmp38 = tmp36 >= tmp37
        tmp39 = (r0_2).to(tl.int64)
        tmp40 = (tmp39).to(tl.int64)
        tmp41 = tl.full([1, 1], 512, tl.int64)
        tmp42 = tmp40 < tmp41
        tmp43 = tmp42.to(tl.int1)
        tmp44 = tl.load(in_ptr1 + (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0)
        tmp45 = tmp36 >= tmp41
        tmp46 = tl.full([1, 1], 7401, tl.int64)
        tmp47 = tmp36 < tmp46
        tmp48 = tmp45.to(tl.int1)
        tmp49 = tl.full([1, 1], True, tl.int1)
        tmp50 = tl.full(tmp49.shape, False, tmp49.dtype)
        tmp51 = tl.where(tmp48, tmp49, tmp50)
        tmp52 = tl.where(tmp42, tmp44, tmp51)
        tmp53 = tl.full([1, 1], 0.0, tl.float32)
        tmp54 = tl.full([1, 1], float("-inf"), tl.float32)
        tmp55 = tl.where(tmp52, tmp53, tmp54)
        tmp56 = tmp55.to(tl.float32)
        tmp57 = tmp35 + tmp56
        tmp58 = tmp57 - tmp24
        tmp59 = libdevice.exp(tmp58)
        tmp60 = (tmp59 / tmp25)
        tmp61 = tl.where(tmp34, tmp53, tmp60)
        tl.store(out_ptr3 + (r0_2 + 7424*x3), tmp61, r0_mask & xmask)
