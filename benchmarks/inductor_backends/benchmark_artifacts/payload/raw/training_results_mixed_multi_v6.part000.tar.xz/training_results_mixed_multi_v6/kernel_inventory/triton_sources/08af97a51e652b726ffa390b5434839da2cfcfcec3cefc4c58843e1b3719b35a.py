
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'y': 32, 'x': 16, 'r0_': 256},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'r0_numel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_constant_pad_nd_exp_flip_mul_neg_softplus_softplus_backward_sum_transpose_view_50', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'y': 145792, 'x': 2304, 'r0_': 0}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_constant_pad_nd_exp_flip_mul_neg_softplus_softplus_backward_sum_transpose_view_50(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, ynumel, xnumel, r0_numel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    ynumel = 32
    xnumel = 9
    r0_numel = 253
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, None, :]
    rbase = r0_base
    x1 = xindex
    y0 = yindex
    _tmp31 = tl.full([YBLOCK, XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = (r0_2 + 253*x1).to(tl.int32)
        tmp1 = tl.full([1, 1, 1], 2276, tl.int32)
        tmp2 = tmp0 < tmp1
        tmp3 = tmp2.to(tl.int1)
        tmp4 = tl.load(in_ptr0 + (y0 + 32*(((r0_2 + 253*x1) % 2276))), r0_mask & tmp3 & xmask & ymask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tl.load(in_ptr1 + (tl.broadcast_to(y0, [YBLOCK, XBLOCK, R0_BLOCK])), r0_mask & tmp3 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp5 + tmp7
        tmp9 = tl.full([1, 1, 1], 20.0, tl.float32)
        tmp10 = tmp8 > tmp9
        tmp11 = (tl.broadcast_to(((r0_2 + 253*x1) % 569), [YBLOCK, XBLOCK, R0_BLOCK])).to(tl.int32)
        tmp12 = tl.full([1, 1, 1], 576, tl.int64)
        tmp13 = tmp11 < tmp12
        tmp14 = tmp13.to(tl.int1)
        tmp15 = tmp14 & tmp3
        tmp16 = tl.load(in_ptr2 + (63 + (-1)*(((((r0_2 + 253*x1) % 569)) % 64)) + 64*((((r0_2 + 253*x1) % 569)) // 64) + 576*y0 + 18432*((((r0_2 + 253*x1) // 569) % 4))), r0_mask & tmp15 & xmask & ymask, eviction_policy='evict_last', other=0.0)
        tmp17 = tl.load(in_ptr3 + (tl.broadcast_to(y0, [YBLOCK, XBLOCK, R0_BLOCK])), r0_mask & tmp3 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = libdevice.exp(tmp18)
        tmp20 = -tmp19
        tmp21 = tmp16 * tmp20
        tmp22 = libdevice.exp(tmp8)
        tmp23 = tmp21 * tmp22
        tmp24 = tl.full([1, 1, 1], 1.0, tl.float32)
        tmp25 = tmp22 + tmp24
        tmp26 = (tmp23 / tmp25)
        tmp27 = tl.where(tmp10, tmp21, tmp26)
        tmp28 = tl.full(tmp27.shape, 0, tmp27.dtype)
        tmp29 = tl.where(tmp3, tmp27, tmp28)
        tmp30 = tl.broadcast_to(tmp29, [YBLOCK, XBLOCK, R0_BLOCK])
        tmp32 = _tmp31 + tmp30
        _tmp31 = tl.where(r0_mask & xmask & ymask, tmp32, _tmp31)
    tmp31 = tl.sum(_tmp31, 2)[:, :, None]
    tl.store(out_ptr0 + (x1 + 9*y0), tmp31, xmask & ymask)
