
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def _triton_helper_fn_add0(arg0_0, arg1_0):
    tmp0 = arg0_0 + arg1_0
    return tmp0

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2048, 'r0_': 64},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy__unsafe_view_constant_pad_nd_cumsum_exp_mul_neg_softplus_softplus_backward_transpose_view_4', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 218688, 'r0_': 884736}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy__unsafe_view_constant_pad_nd_cumsum_exp_mul_neg_softplus_softplus_backward_transpose_view_4(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1728
    r0_numel = 64
    R0_BLOCK: tl.constexpr = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_3 = r0_index
    x1 = ((xindex // 48) % 9)
    x0 = (xindex % 48)
    x2 = xindex // 432
    tmp0 = (r0_3 + 64*x1).to(tl.int32)
    tmp1 = tl.full([1, 1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (r0_3 + 64*x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1, 1], 569, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.load(in_ptr0 + (tl.broadcast_to(x0, [XBLOCK, R0_BLOCK])), tmp7 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = libdevice.exp(tmp9)
    tmp11 = -tmp10
    tmp12 = tl.load(in_ptr1 + (x0 + 48*(r0_3 + 64*x1) + 27312*x2), tmp7 & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tl.load(in_ptr2 + (tl.broadcast_to(x0, [XBLOCK, R0_BLOCK])), tmp7 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp13 + tmp15
    tmp17 = tl.full([1, 1], 20.0, tl.float32)
    tmp18 = tmp16 > tmp17
    tmp19 = libdevice.exp(tmp16)
    tmp20 = libdevice.log1p(tmp19)
    tmp21 = tl.where(tmp18, tmp16, tmp20)
    tmp22 = tmp11 * tmp21
    tmp23 = tl.full(tmp22.shape, 0.0, tmp22.dtype)
    tmp24 = tl.where(tmp7, tmp22, tmp23)
    tmp25 = tmp0 >= tmp5
    tmp26 = tl.full([1, 1], 576, tl.int64)
    tmp27 = tmp0 < tmp26
    tmp28 = tmp25.to(tl.int1)
    tmp29 = tl.full([1, 1], 0.0, tl.float32)
    tmp30 = tl.full(tmp29.shape, 0.0, tmp29.dtype)
    tmp31 = tl.where(tmp28, tmp29, tmp30)
    tmp32 = tl.where(tmp6, tmp24, tmp31)
    tmp33 = tmp32.to(tl.float32)
    tmp34 = tl.broadcast_to(tmp33, [XBLOCK, R0_BLOCK])
    tmp35, = tl.associative_scan((tmp34,), 1, _triton_helper_fn_add0)
    tl.store(out_ptr0 + (r0_3 + 64*x1 + 576*x0 + 27648*x2), tmp35, xmask)
