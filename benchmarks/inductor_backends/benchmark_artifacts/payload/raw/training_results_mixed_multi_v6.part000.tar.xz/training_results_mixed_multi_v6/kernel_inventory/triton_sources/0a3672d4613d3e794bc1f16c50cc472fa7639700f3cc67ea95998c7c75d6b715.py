
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4096}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr0': '*i64', 'out_ptr1': '*i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_arange_floor_divide_index_put_11', 'mutated_arg_names': ['out_ptr1'], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 98304}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_arange_floor_divide_index_put_11(in_ptr0, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 4096
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = tl.full([1], 8, tl.int64)
    tmp2 = tl.full([1], 0, tl.int32)
    tmp3 = tl.full([1], 1, tl.int32)
    tmp4 = tmp1 == tmp2
    tmp5 = tl.where(tmp4, tmp3, tmp1)
    tmp6 = tmp5 < tmp2
    tmp7 = tmp2 - tmp0
    tmp8 = tl.where(tmp6, tmp7, tmp0)
    tmp9 = tmp2 - tmp5
    tmp10 = tl.where(tmp6, tmp9, tmp5)
    tmp11 = tmp8 < tmp2
    tmp12 = ~tmp8
    tmp13 = tl.where(tmp11, tmp12, tmp8)
    tmp14 = tmp13 // tmp10
    tmp15 = ~tmp14
    tmp16 = tl.where(tmp11, tmp15, tmp14)
    tmp17 = tl.where(tmp4, tmp2, tmp16)
    tmp18 = (tl.full([XBLOCK], 4096, tl.int32)).to(tl.int32)
    tmp19 = tmp0 + tmp18
    tmp20 = tmp0 < 0
    tmp21 = tl.where(tmp20, tmp19, tmp0)
    tl.device_assert(((0 <= tmp21) & (tmp21 < 4096)) | ~(xmask), "index out of bounds: 0 <= tmp21 < 4096")
    tmp23 = (x0).to(tl.int64)
    tmp24 = (tmp23).to(tl.int64)
    tl.store(out_ptr0 + (x0), tmp17, xmask)
    tl.store(out_ptr1 + (tl.broadcast_to(tmp21, [XBLOCK])), tmp24, xmask)
