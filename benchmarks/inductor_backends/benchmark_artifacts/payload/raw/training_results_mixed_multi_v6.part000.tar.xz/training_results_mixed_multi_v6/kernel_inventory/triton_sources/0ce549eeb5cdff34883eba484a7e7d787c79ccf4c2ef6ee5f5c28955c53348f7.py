
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=2, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_arange_cat_cos_div_exp_mul_sin_slice_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1024}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_arange_cat_cos_div_exp_mul_sin_slice_unsqueeze_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 128, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = (128 + (x0)).to(tl.int32)
    tmp9 = tl.full([1], 0, tl.int64)
    tmp10 = tmp8 >= tmp9
    tmp11 = (128 + (x0)).to(tl.int64)
    tmp12 = (tmp11).to(tl.int64)
    tmp13 = tl.full([1], 128, tl.int64)
    tmp14 = tmp12 < tmp13
    tmp15 = tmp14.to(tl.int1)
    tmp16 = tmp15 & tmp7
    tmp17 = tl.load(in_ptr0 + (0))
    tmp18 = tl.broadcast_to(tmp17, [XBLOCK])
    tmp19 = tl.where(tmp16, tmp18, 0)
    tmp20 = tmp19.to(tl.float32)
    tmp21 = (128 + (x0)).to(tl.float32)
    tmp22 = (tmp21).to(tl.float32)
    tmp23 = tl.full([1], -9.210340371976184, tl.float32)
    tmp24 = tmp22 * tmp23
    tmp25 = tl.full([1], 0.0078125, tl.float32)
    tmp26 = tmp24 * tmp25
    tmp27 = libdevice.exp(tmp26)
    tmp28 = tmp20 * tmp27
    tmp29 = tl_math.sin(tmp28)
    tmp30 = tl.full(tmp29.shape, 0.0, tmp29.dtype)
    tmp31 = tl.where(tmp16, tmp29, tmp30)
    tmp32 = tmp8 >= tmp13
    tmp33 = tl.full([1], 256, tl.int64)
    tmp34 = tmp8 < tmp33
    tmp35 = tmp32.to(tl.int1)
    tmp36 = tmp35 & tmp7
    tmp37 = tl.load(in_ptr0 + (0))
    tmp38 = tl.broadcast_to(tmp37, [XBLOCK])
    tmp39 = tl.where(tmp36, tmp38, 0)
    tmp40 = tmp39.to(tl.float32)
    tmp41 = (x0).to(tl.float32)
    tmp42 = (tmp41).to(tl.float32)
    tmp43 = tl.full([1], -9.210340371976184, tl.float32)
    tmp44 = tmp42 * tmp43
    tmp45 = tl.full([1], 0.0078125, tl.float32)
    tmp46 = tmp44 * tmp45
    tmp47 = libdevice.exp(tmp46)
    tmp48 = tmp40 * tmp47
    tmp49 = tl_math.cos(tmp48)
    tmp50 = tl.full(tmp49.shape, 0.0, tmp49.dtype)
    tmp51 = tl.where(tmp36, tmp49, tmp50)
    tmp52 = tl.where(tmp14, tmp31, tmp51)
    tmp53 = tl.full(tmp52.shape, 0.0, tmp52.dtype)
    tmp54 = tl.where(tmp7, tmp52, tmp53)
    tmp55 = tmp0 >= tmp5
    tmp56 = tl.full([1], 256, tl.int64)
    tmp57 = tmp0 < tmp56
    tmp58 = tmp55.to(tl.int1)
    tmp59 = ((-128) + x0).to(tl.int32)
    tmp60 = tl.full([1], 0, tl.int64)
    tmp61 = tmp59 >= tmp60
    tmp62 = ((-128) + x0).to(tl.int64)
    tmp63 = (tmp62).to(tl.int64)
    tmp64 = tl.full([1], 128, tl.int64)
    tmp65 = tmp63 < tmp64
    tmp66 = tmp65.to(tl.int1)
    tmp67 = tmp66 & tmp58
    tmp68 = tl.load(in_ptr0 + (0))
    tmp69 = tl.broadcast_to(tmp68, [XBLOCK])
    tmp70 = tl.where(tmp67, tmp69, 0)
    tmp71 = tmp70.to(tl.float32)
    tmp72 = ((-128) + x0).to(tl.float32)
    tmp73 = (tmp72).to(tl.float32)
    tmp74 = tl.full([1], -9.210340371976184, tl.float32)
    tmp75 = tmp73 * tmp74
    tmp76 = tl.full([1], 0.0078125, tl.float32)
    tmp77 = tmp75 * tmp76
    tmp78 = libdevice.exp(tmp77)
    tmp79 = tmp71 * tmp78
    tmp80 = tl_math.sin(tmp79)
    tmp81 = tl.full(tmp80.shape, 0.0, tmp80.dtype)
    tmp82 = tl.where(tmp67, tmp80, tmp81)
    tmp83 = tmp59 >= tmp64
    tmp84 = tl.full([1], 256, tl.int64)
    tmp85 = tmp59 < tmp84
    tmp86 = tmp83.to(tl.int1)
    tmp87 = tmp86 & tmp58
    tmp88 = tl.load(in_ptr0 + (0))
    tmp89 = tl.broadcast_to(tmp88, [XBLOCK])
    tmp90 = tl.where(tmp87, tmp89, 0)
    tmp91 = tmp90.to(tl.float32)
    tmp92 = ((-128) + ((-128) + x0)).to(tl.float32)
    tmp93 = (tmp92).to(tl.float32)
    tmp94 = tl.full([1], -9.210340371976184, tl.float32)
    tmp95 = tmp93 * tmp94
    tmp96 = tl.full([1], 0.0078125, tl.float32)
    tmp97 = tmp95 * tmp96
    tmp98 = libdevice.exp(tmp97)
    tmp99 = tmp91 * tmp98
    tmp100 = tl_math.cos(tmp99)
    tmp101 = tl.full(tmp100.shape, 0.0, tmp100.dtype)
    tmp102 = tl.where(tmp87, tmp100, tmp101)
    tmp103 = tl.where(tmp65, tmp82, tmp102)
    tmp104 = tl.full(tmp103.shape, 0.0, tmp103.dtype)
    tmp105 = tl.where(tmp58, tmp103, tmp104)
    tmp106 = tl.where(tmp6, tmp54, tmp105)
    tmp107 = tmp106.to(tl.float32)
    tmp108 = tmp107.to(tl.bfloat16)
    tmp109 = tmp108.to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp109, xmask)
