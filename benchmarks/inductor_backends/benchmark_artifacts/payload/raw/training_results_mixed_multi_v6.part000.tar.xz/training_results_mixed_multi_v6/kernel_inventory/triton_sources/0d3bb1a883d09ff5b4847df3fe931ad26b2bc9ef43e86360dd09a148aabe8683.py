
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 16384, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy_add_div_exp_mul_neg_select_select_backward_squeeze_sum_view_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 196608, 'r0_': 50331648}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy_add_div_exp_mul_neg_select_select_backward_squeeze_sum_view_14(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 16384
    r0_numel = 128
    R0_BLOCK: tl.constexpr = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    x0 = (xindex % 128)
    r0_2 = r0_index
    x1 = xindex // 128
    x3 = xindex
    tmp3 = tl.load(in_ptr0 + (r0_2 + 128*((x0 % 64)) + 8192*x1), None, eviction_policy='evict_first')
    tmp4 = tl.load(in_ptr1 + (r0_2 + 128*((x0 % 64)) + 8192*x1), None, eviction_policy='evict_first').to(tl.float32)
    tmp6 = tl.load(in_ptr2 + (8192 + r0_2 + 128*((x0 % 64)) + 16384*x1), None, eviction_policy='evict_last')
    tmp14 = tl.load(in_ptr3 + (r0_2 + 128*((x0 % 64)) + 8192*x1), None, eviction_policy='evict_first')
    tmp15 = tl.load(in_ptr4 + (r0_2 + 128*((x0 % 64)) + 8192*x1), None, eviction_policy='evict_first').to(tl.float32)
    tmp17 = tl.load(in_ptr2 + (r0_2 + 128*((x0 % 64)) + 16384*x1), None, eviction_policy='evict_first')
    tmp26 = tl.load(in_ptr5 + (r0_2 + 128*x3), None, eviction_policy='evict_first').to(tl.float32)
    tmp28 = tl.load(in_ptr6 + (x3), None, eviction_policy='evict_last')
    tmp0 = (x0 // 64).to(tl.int32)
    tmp1 = tl.full([1, 1], 1, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp5 = tmp4.to(tl.float32)
    tmp7 = libdevice.exp(tmp6)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp3 + tmp8
    tmp10 = tl.full([1, 1], 0.0, tl.float32)
    tmp11 = tl.where(tmp2, tmp9, tmp10)
    tmp12 = tl.full([1, 1], 0, tl.int32)
    tmp13 = tmp0 == tmp12
    tmp16 = tmp15.to(tl.float32)
    tmp18 = libdevice.exp(tmp17)
    tmp19 = tmp16 * tmp18
    tmp20 = tmp14 + tmp19
    tmp21 = tl.where(tmp13, tmp20, tmp10)
    tmp22 = tmp11 + tmp21
    tmp23 = tl.full([1, 1], 0.08838834764831843, tl.float32)
    tmp24 = tmp22 * tmp23
    tmp25 = -tmp24
    tmp27 = tmp26.to(tl.float32)
    tmp29 = (tmp27 / tmp28)
    tmp30 = (tmp29 / tmp28)
    tmp31 = tmp25 * tmp30
    tmp32 = tl.broadcast_to(tmp31, [XBLOCK, R0_BLOCK])
    tmp34 = tl.sum(tmp32, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (r0_2 + 128*x3), tmp24, None)
    tl.store(out_ptr1 + (x3), tmp34, None)
