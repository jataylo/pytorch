
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_unsqueeze_zeros_like_28', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 12839936}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_unsqueeze_zeros_like_28(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1048576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 64) % 64)
    x0 = (xindex % 64)
    x2 = xindex // 4096
    x4 = xindex
    tmp19 = tl.load(in_ptr0 + (3776 + x0 + 4096*x2), None, eviction_policy='evict_last')
    tmp21 = tl.load(in_ptr0 + (3712 + x0 + 4096*x2), None, eviction_policy='evict_last')
    tmp53 = tl.load(in_ptr0 + (x4), None)
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 58, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 58, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.full([1], 0.0, tl.float32)
    tmp9 = tl.full(tmp8.shape, 0.0, tmp8.dtype)
    tmp10 = tl.where(tmp7, tmp8, tmp9)
    tmp11 = tl.full([1], 59, tl.int32)
    tmp12 = tmp1 == tmp11
    tmp13 = tl.full([1], 59, tl.int64)
    tmp14 = tmp4 < tmp13
    tmp15 = tmp14.to(tl.int1)
    tmp16 = tl.full([1], 0.0, tl.float32)
    tmp17 = tl.full(tmp16.shape, 0.0, tmp16.dtype)
    tmp18 = tl.where(tmp15, tmp16, tmp17)
    tmp20 = tl.where(tmp14, tmp18, tmp19)
    tmp22 = tl.where(tmp12, tmp20, tmp21)
    tmp23 = tmp5 < tmp13
    tmp24 = tmp23.to(tl.int1)
    tmp25 = (x0).to(tl.int64)
    tmp26 = (tmp25).to(tl.int64)
    tmp27 = tl.full([1], 59, tl.int64)
    tmp28 = tmp26 < tmp27
    tmp29 = tmp28.to(tl.int1)
    tmp30 = tmp29 & tmp24
    tmp31 = tl.load(in_ptr0 + (3776 + x0 + 4096*x2), tmp30, eviction_policy='evict_last', other=0.0)
    tmp32 = tl.load(in_ptr1 + (3834 + 4096*x2), tmp30, eviction_policy='evict_last', other=0.0)
    tmp33 = tmp31 * tmp32
    tmp34 = tl.full(tmp33.shape, 0.0, tmp33.dtype)
    tmp35 = tl.where(tmp30, tmp33, tmp34)
    tmp36 = tl.full([1], 0.0, tl.float32)
    tmp37 = tl.where(tmp28, tmp35, tmp36)
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp24, tmp37, tmp38)
    tmp40 = tl.full([1], 0.0, tl.float32)
    tmp41 = tl.where(tmp23, tmp39, tmp40)
    tmp42 = tmp22 + tmp41
    tmp43 = tl.load(in_ptr0 + (3776 + x0 + 4096*x2), tmp15, eviction_policy='evict_last', other=0.0)
    tmp44 = tl.load(in_ptr2 + (x0 + 59*x2), tmp15, eviction_policy='evict_last', other=0.0)
    tmp45 = tmp43 + tmp44
    tmp46 = tl.full(tmp45.shape, 0.0, tmp45.dtype)
    tmp47 = tl.where(tmp15, tmp45, tmp46)
    tmp48 = tl.where(tmp14, tmp47, tmp40)
    tmp49 = tl.where(tmp12, tmp48, tmp40)
    tmp50 = tmp42 + tmp49
    tmp51 = tl.where(tmp6, tmp10, tmp50)
    tmp52 = tmp0 == tmp11
    tmp54 = tl.where(tmp52, tmp20, tmp53)
    tmp55 = (x1).to(tl.int64)
    tmp56 = (tmp55).to(tl.int64)
    tmp57 = tmp56 < tmp13
    tmp58 = tmp57.to(tl.int1)
    tmp59 = (x0).to(tl.int64)
    tmp60 = (tmp59).to(tl.int64)
    tmp61 = tl.full([1], 59, tl.int64)
    tmp62 = tmp60 < tmp61
    tmp63 = tmp62.to(tl.int1)
    tmp64 = tmp63 & tmp58
    tmp65 = tl.load(in_ptr0 + (3776 + x0 + 4096*x2), tmp64, eviction_policy='evict_last', other=0.0)
    tmp66 = tl.load(in_ptr1 + (3776 + x1 + 4096*x2), tmp64, eviction_policy='evict_last', other=0.0)
    tmp67 = tmp65 * tmp66
    tmp68 = tl.full(tmp67.shape, 0.0, tmp67.dtype)
    tmp69 = tl.where(tmp64, tmp67, tmp68)
    tmp70 = tl.full([1], 0.0, tl.float32)
    tmp71 = tl.where(tmp62, tmp69, tmp70)
    tmp72 = tl.full(tmp71.shape, 0.0, tmp71.dtype)
    tmp73 = tl.where(tmp58, tmp71, tmp72)
    tmp74 = tl.where(tmp57, tmp73, tmp40)
    tmp75 = tmp54 + tmp74
    tmp76 = tl.where(tmp52, tmp48, tmp40)
    tmp77 = tmp75 + tmp76
    tmp78 = tl.where(tmp2, tmp51, tmp77)
    tl.store(out_ptr0 + (x4), tmp78, None)
