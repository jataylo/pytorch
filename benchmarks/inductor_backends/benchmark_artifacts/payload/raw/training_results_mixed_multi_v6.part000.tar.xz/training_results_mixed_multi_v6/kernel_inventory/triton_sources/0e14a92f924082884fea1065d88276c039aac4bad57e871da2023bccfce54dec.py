
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 4096, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy_add_div_expand_mul_pow_slice_slice_backward_sum_transpose_view_18', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 13107712}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy_add_div_expand_mul_pow_slice_slice_backward_sum_transpose_view_18(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 4096
    r0_numel = 256
    R0_BLOCK: tl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_3 = r0_index
    x4 = xindex
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 16)
    x2 = xindex // 2048
    tmp20 = tl.load(in_ptr2 + (r0_3), None, eviction_policy='evict_last').to(tl.float32)
    tmp25 = tl.load(in_ptr3 + (r0_3 + 512*x1 + 8192*x0 + 1048576*x2), xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
    tmp32 = tl.load(in_ptr4 + (x1 + 16*x0 + 2048*x2), xmask, eviction_policy='evict_last')
    tmp0 = (r0_3).to(tl.int64)
    tmp1 = (tmp0).to(tl.int64)
    tmp2 = tl.full([1, 1], 64, tl.int64)
    tmp3 = tmp1 >= tmp2
    tmp4 = tmp3.to(tl.int1)
    tmp5 = tl.load(in_ptr0 + (r0_3 + 256*x4), tmp4 & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
    tmp6 = tmp5.to(tl.float32)
    tmp7 = tl.full([1, 1], 0.25, tl.float32)
    tmp8 = tmp6 * tmp7
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tl.full(tmp9.shape, 0.0, tmp9.dtype)
    tmp11 = tl.where(tmp4, tmp9, tmp10)
    tmp12 = tl.full([1, 1], 0.0, tl.float32)
    tmp13 = tl.where(tmp3, tmp11, tmp12)
    tmp14 = tmp1 < tmp2
    tmp15 = tmp14.to(tl.int1)
    tmp16 = tl.load(in_ptr1 + (r0_3 + 64*x4), tmp15 & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
    tmp17 = tl.where(tmp14, tmp16, tmp12)
    tmp18 = tmp13 + tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp21 = tmp20.to(tl.float32)
    tmp22 = tl.full([1, 1], 1.0, tl.float32)
    tmp23 = tmp21 + tmp22
    tmp24 = tmp19 * tmp23
    tmp26 = tmp25.to(tl.float32)
    tmp27 = tmp24 * tmp26
    tmp28 = tl.broadcast_to(tmp27, [XBLOCK, R0_BLOCK])
    tmp30 = tl.where(xmask, tmp28, 0)
    tmp31 = tl.sum(tmp30, 1)[:, None].to(tl.float32)
    tmp33 = tmp24 * tmp32
    tmp34 = tl.full([1, 1], -0.5, tl.float32)
    tmp35 = tmp31 * tmp34
    tmp36 = tmp32 * tmp32
    tmp37 = tmp36 * tmp32
    tmp38 = tmp35 * tmp37
    tmp39 = tl.full([1, 1], 0.00390625, tl.float32)
    tmp40 = tmp38 * tmp39
    tmp41 = tl.full([1, 1], 2.0, tl.float32)
    tmp42 = tmp26 * tmp41
    tmp43 = tmp40 * tmp42
    tmp44 = tmp33 + tmp43
    tl.store(out_ptr1 + (r0_3 + 256*x4), tmp44, xmask)
