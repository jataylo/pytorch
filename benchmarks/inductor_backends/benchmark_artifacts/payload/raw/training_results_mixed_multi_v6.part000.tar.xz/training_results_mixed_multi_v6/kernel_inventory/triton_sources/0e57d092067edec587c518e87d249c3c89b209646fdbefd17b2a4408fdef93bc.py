
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16777216}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'in_ptr5': '*bf16', 'in_ptr6': '*bf16', 'in_ptr7': '*bf16', 'in_ptr8': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_select_backward_view_34', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 94371840}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_select_backward_view_34(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, in_ptr7, in_ptr8, xnumel, XBLOCK : tl.constexpr):
    xnumel = 9437184
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 8192) % 9)
    x0 = (xindex % 8192)
    x2 = xindex // 73728
    x3 = xindex
    tmp3 = tl.load(in_ptr0 + (x0 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp9 = tl.load(in_ptr1 + (x0 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp15 = tl.load(in_ptr2 + (x0 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp21 = tl.load(in_ptr3 + (x0 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp27 = tl.load(in_ptr4 + (x0 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp33 = tl.load(in_ptr5 + (x0 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp39 = tl.load(in_ptr6 + (x0 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp45 = tl.load(in_ptr7 + (x0 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp51 = tl.load(in_ptr8 + (x0 + 8192*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 8, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp4 = tmp3.to(tl.float32)
    tmp5 = tl.full([1], 0.0, tl.float32)
    tmp6 = tl.where(tmp2, tmp4, tmp5)
    tmp7 = tl.full([1], 7, tl.int32)
    tmp8 = tmp0 == tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.where(tmp8, tmp10, tmp5)
    tmp12 = tmp6 + tmp11
    tmp13 = tl.full([1], 6, tl.int32)
    tmp14 = tmp0 == tmp13
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tl.where(tmp14, tmp16, tmp5)
    tmp18 = tmp12 + tmp17
    tmp19 = tl.full([1], 5, tl.int32)
    tmp20 = tmp0 == tmp19
    tmp22 = tmp21.to(tl.float32)
    tmp23 = tl.where(tmp20, tmp22, tmp5)
    tmp24 = tmp18 + tmp23
    tmp25 = tl.full([1], 4, tl.int32)
    tmp26 = tmp0 == tmp25
    tmp28 = tmp27.to(tl.float32)
    tmp29 = tl.where(tmp26, tmp28, tmp5)
    tmp30 = tmp24 + tmp29
    tmp31 = tl.full([1], 3, tl.int32)
    tmp32 = tmp0 == tmp31
    tmp34 = tmp33.to(tl.float32)
    tmp35 = tl.where(tmp32, tmp34, tmp5)
    tmp36 = tmp30 + tmp35
    tmp37 = tl.full([1], 2, tl.int32)
    tmp38 = tmp0 == tmp37
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tl.where(tmp38, tmp40, tmp5)
    tmp42 = tmp36 + tmp41
    tmp43 = tl.full([1], 1, tl.int32)
    tmp44 = tmp0 == tmp43
    tmp46 = tmp45.to(tl.float32)
    tmp47 = tl.where(tmp44, tmp46, tmp5)
    tmp48 = tmp42 + tmp47
    tmp49 = tl.full([1], 0, tl.int32)
    tmp50 = tmp0 == tmp49
    tmp52 = tmp51.to(tl.float32)
    tmp53 = tl.where(tmp50, tmp52, tmp5)
    tmp54 = tmp48 + tmp53
    tl.store(in_out_ptr0 + (x3), tmp54, None)
