
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def _triton_helper_fn_add0(arg0_0, arg1_0):
    tmp0 = arg0_0 + arg1_0
    return tmp0

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2048, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'in_ptr6': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused_add_cumsum_exp_flip_mul_select_backward_squeeze_41', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4608, 'r0_': 589824}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused_add_cumsum_exp_flip_mul_select_backward_squeeze_41(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1152
    r0_numel = 64
    R0_BLOCK: tl.constexpr = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (63 + ((-1)*r0_1) + 64*x0), xmask, eviction_policy='evict_last', other=0.0)
    tmp10 = tl.load(in_ptr2 + (63 + ((-1)*r0_1) + 64*x0), xmask, eviction_policy='evict_last', other=0.0)
    tmp11 = tl.load(in_ptr3 + (63 + ((-1)*r0_1) + 64*x0), xmask, eviction_policy='evict_last', other=0.0)
    tmp15 = tl.load(in_ptr4 + (63 + ((-1)*r0_1) + 64*x0), xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = tl.load(in_ptr5 + (63 + ((-1)*r0_1) + 64*x0), xmask, eviction_policy='evict_last', other=0.0)
    tmp20 = tl.load(in_ptr6 + (63 + ((-1)*r0_1) + 64*x0), xmask, eviction_policy='evict_last', other=0.0)
    tmp1 = (63 + ((-1)*r0_1)).to(tl.int64)
    tmp2 = (tmp1).to(tl.int64)
    tmp3 = tl.full([1, 1], 63, tl.int64)
    tmp4 = tmp2 >= tmp3
    tmp5 = tmp4.to(tl.int1)
    tmp6 = tl.load(in_ptr1 + (tl.broadcast_to(x0, [XBLOCK, R0_BLOCK])), tmp5 & xmask, eviction_policy='evict_last', other=0.0)
    tmp7 = tl.full([1, 1], 0.0, tl.float32)
    tmp8 = tl.where(tmp4, tmp6, tmp7)
    tmp9 = tmp0 + tmp8
    tmp12 = libdevice.exp(tmp11)
    tmp13 = tmp10 * tmp12
    tmp14 = tmp9 + tmp13
    tmp16 = tmp15 * tmp12
    tmp17 = tmp14 + tmp16
    tmp19 = tmp17 + tmp18
    tmp21 = tmp19 + tmp20
    tmp22 = tmp21.to(tl.float32)
    tmp23 = tl.broadcast_to(tmp22, [XBLOCK, R0_BLOCK])
    tmp24, = tl.associative_scan((tmp23,), 1, _triton_helper_fn_add0)
    tl.store(out_ptr0 + (r0_1 + 64*x0), tmp24, xmask)
