
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 131072, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'in_ptr5': '*bf16', 'in_ptr6': '*bf16', 'in_ptr7': '*bf16', 'in_ptr8': '*bf16', 'in_ptr9': '*fp32', 'in_ptr10': '*fp32', 'in_ptr11': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (10,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (11,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (12,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (13,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (14,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (15,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (16,): [['tt.divisibility', 16]], (17,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mul_select_backward_sum_transpose_unsqueeze_view_23', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 12, 'num_store': 4, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 200392704, 'r0_': 113246208}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mul_select_backward_sum_transpose_unsqueeze_view_23(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, in_ptr7, in_ptr8, in_ptr9, in_ptr10, in_ptr11, out_ptr0, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 110592
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x1 = ((xindex // 64) % 9)
    x0 = (xindex % 64)
    x2 = xindex // 576
    x4 = xindex // 64
    x5 = xindex
    _tmp60 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    tmp62 = tl.load(in_ptr11 + (x5), xmask, eviction_policy='evict_last')
    _tmp66 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp3 = tl.load(in_ptr0 + (x0 + 64*r0_3 + 8192*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp9 = tl.load(in_ptr1 + (x0 + 64*r0_3 + 8192*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tl.load(in_ptr2 + (x0 + 64*r0_3 + 8192*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr3 + (x0 + 64*r0_3 + 8192*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp27 = tl.load(in_ptr4 + (x0 + 64*r0_3 + 8192*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp33 = tl.load(in_ptr5 + (x0 + 64*r0_3 + 8192*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp39 = tl.load(in_ptr6 + (x0 + 64*r0_3 + 8192*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp45 = tl.load(in_ptr7 + (x0 + 64*r0_3 + 8192*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp51 = tl.load(in_ptr8 + (x0 + 64*r0_3 + 8192*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp55 = tl.load(in_ptr9 + (x0 + 64*r0_3 + 8192*x4), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp57 = tl.load(in_ptr10 + (r0_3 + 128*x5), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp0 = (x1).to(tl.int32)
        tmp1 = tl.full([1, 1], 8, tl.int32)
        tmp2 = tmp0 == tmp1
        tmp4 = tmp3.to(tl.float32)
        tmp5 = tl.full([1, 1], 0.0, tl.float32)
        tmp6 = tl.where(tmp2, tmp4, tmp5)
        tmp7 = tl.full([1, 1], 7, tl.int32)
        tmp8 = tmp0 == tmp7
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tl.where(tmp8, tmp10, tmp5)
        tmp12 = tmp6 + tmp11
        tmp13 = tl.full([1, 1], 6, tl.int32)
        tmp14 = tmp0 == tmp13
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.where(tmp14, tmp16, tmp5)
        tmp18 = tmp12 + tmp17
        tmp19 = tl.full([1, 1], 5, tl.int32)
        tmp20 = tmp0 == tmp19
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tl.where(tmp20, tmp22, tmp5)
        tmp24 = tmp18 + tmp23
        tmp25 = tl.full([1, 1], 4, tl.int32)
        tmp26 = tmp0 == tmp25
        tmp28 = tmp27.to(tl.float32)
        tmp29 = tl.where(tmp26, tmp28, tmp5)
        tmp30 = tmp24 + tmp29
        tmp31 = tl.full([1, 1], 3, tl.int32)
        tmp32 = tmp0 == tmp31
        tmp34 = tmp33.to(tl.float32)
        tmp35 = tl.where(tmp32, tmp34, tmp5)
        tmp36 = tmp30 + tmp35
        tmp37 = tl.full([1, 1], 2, tl.int32)
        tmp38 = tmp0 == tmp37
        tmp40 = tmp39.to(tl.float32)
        tmp41 = tl.where(tmp38, tmp40, tmp5)
        tmp42 = tmp36 + tmp41
        tmp43 = tl.full([1, 1], 1, tl.int32)
        tmp44 = tmp0 == tmp43
        tmp46 = tmp45.to(tl.float32)
        tmp47 = tl.where(tmp44, tmp46, tmp5)
        tmp48 = tmp42 + tmp47
        tmp49 = tl.full([1, 1], 0, tl.int32)
        tmp50 = tmp0 == tmp49
        tmp52 = tmp51.to(tl.float32)
        tmp53 = tl.where(tmp50, tmp52, tmp5)
        tmp54 = tmp48 + tmp53
        tmp56 = tmp55.to(tl.float32)
        tmp58 = tmp54 * tmp57
        tmp59 = tl.broadcast_to(tmp58, [XBLOCK, R0_BLOCK])
        tmp61 = _tmp60 + tmp59
        _tmp60 = tl.where(r0_mask & xmask, tmp61, _tmp60)
        tmp63 = tmp57 * tmp62
        tmp64 = tmp55 * tmp63
        tmp65 = tl.broadcast_to(tmp64, [XBLOCK, R0_BLOCK])
        tmp67 = _tmp66 + tmp65
        _tmp66 = tl.where(r0_mask & xmask, tmp67, _tmp66)
        tl.store(in_out_ptr0 + (x0 + 64*r0_3 + 8192*x4), tmp54, r0_mask & xmask)
        tl.store(out_ptr0 + (r0_3 + 128*x5), tmp56, r0_mask & xmask)
    tmp60 = tl.sum(_tmp60, 1)[:, None]
    tmp66 = tl.sum(_tmp66, 1)[:, None]
    tl.store(out_ptr1 + (x5), tmp60, xmask)
    tl.store(out_ptr2 + (x5), tmp66, xmask)
