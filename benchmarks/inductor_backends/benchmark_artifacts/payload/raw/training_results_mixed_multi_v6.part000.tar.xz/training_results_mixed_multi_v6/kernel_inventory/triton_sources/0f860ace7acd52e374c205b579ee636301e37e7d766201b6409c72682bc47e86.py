
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_unsqueeze_view_zeros_like_24', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 12778496}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_unsqueeze_view_zeros_like_24(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1048576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 64) % 64)
    x0 = (xindex % 64)
    x2 = xindex // 4096
    x3 = xindex
    tmp11 = tl.load(in_ptr0 + (4032 + x0 + 4096*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp13 = tl.load(in_ptr1 + (4032 + x0 + 4096*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp17 = tl.load(in_ptr0 + (x3), None).to(tl.float32)
    tmp19 = tl.load(in_ptr1 + (x3), None).to(tl.float32)
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 63, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 63, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.full([1], 0.0, tl.float32)
    tmp9 = tl.full(tmp8.shape, 0.0, tmp8.dtype)
    tmp10 = tl.where(tmp7, tmp8, tmp9)
    tmp12 = tmp11.to(tl.float32)
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tmp12 + tmp14
    tmp16 = tl.where(tmp6, tmp10, tmp15)
    tmp18 = tmp17.to(tl.float32)
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 + tmp20
    tmp22 = tl.where(tmp2, tmp16, tmp21)
    tmp23 = (x1).to(tl.int64)
    tmp24 = (tmp23).to(tl.int64)
    tmp25 = tmp24 < tmp5
    tmp26 = tmp25.to(tl.int1)
    tmp27 = (x0).to(tl.int64)
    tmp28 = (tmp27).to(tl.int64)
    tmp29 = tl.full([1], 63, tl.int64)
    tmp30 = tmp28 < tmp29
    tmp31 = tmp30.to(tl.int1)
    tmp32 = tmp31 & tmp26
    tmp33 = tl.load(in_ptr0 + (4032 + x0 + 4096*x2), tmp32, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp34 = tmp33.to(tl.float32)
    tmp35 = tl.load(in_ptr1 + (4032 + x0 + 4096*x2), tmp32, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tmp34 + tmp36
    tmp38 = tl.load(in_ptr2 + (4032 + x1 + 4096*x2), tmp32, eviction_policy='evict_last', other=0.0)
    tmp39 = tmp37 * tmp38
    tmp40 = tl.full(tmp39.shape, 0.0, tmp39.dtype)
    tmp41 = tl.where(tmp32, tmp39, tmp40)
    tmp42 = tl.full([1], 0.0, tl.float32)
    tmp43 = tl.where(tmp30, tmp41, tmp42)
    tmp44 = tl.full(tmp43.shape, 0.0, tmp43.dtype)
    tmp45 = tl.where(tmp26, tmp43, tmp44)
    tmp46 = tl.full([1], 0.0, tl.float32)
    tmp47 = tl.where(tmp25, tmp45, tmp46)
    tmp48 = tmp22 + tmp47
    tmp49 = tl.load(in_ptr0 + (4032 + x0 + 4096*x2), tmp7, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp50 = tmp49.to(tl.float32)
    tmp51 = tl.load(in_ptr1 + (4032 + x0 + 4096*x2), tmp7, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp52 = tmp51.to(tl.float32)
    tmp53 = tmp50 + tmp52
    tmp54 = tl.load(in_ptr3 + (x0 + 63*x2), tmp7, eviction_policy='evict_last', other=0.0)
    tmp55 = tmp53 + tmp54
    tmp56 = tl.full(tmp55.shape, 0.0, tmp55.dtype)
    tmp57 = tl.where(tmp7, tmp55, tmp56)
    tmp58 = tl.where(tmp6, tmp57, tmp46)
    tmp59 = tl.where(tmp2, tmp58, tmp46)
    tmp60 = tmp48 + tmp59
    tl.store(out_ptr0 + (x3), tmp60, None)
