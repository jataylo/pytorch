
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_unsqueeze_zeros_like_112', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3060736}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_clone_copy_expand_mul_select_slice_slice_backward_squeeze_unsqueeze_zeros_like_112(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 360448
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x2 = xindex // 1408
    x1 = ((xindex // 64) % 22)
    x4 = xindex
    tmp0 = (x0).to(tl.int64)
    tmp1 = (tmp0).to(tl.int64)
    tmp2 = tl.full([1], 22, tl.int64)
    tmp3 = tmp1 < tmp2
    tmp4 = tmp3.to(tl.int1)
    tmp5 = tl.full([1], 22, tl.int32)
    tmp6 = tl.full([1], 23, tl.int32)
    tmp7 = tmp5 == tmp6
    tmp8 = (x0).to(tl.int64)
    tmp9 = (tmp8).to(tl.int64)
    tmp10 = tl.full([1], 23, tl.int64)
    tmp11 = tmp9 < tmp10
    tmp12 = tmp11.to(tl.int1)
    tmp13 = tmp12 & tmp4
    tmp14 = tl.full([1], 0.0, tl.float32)
    tmp15 = tl.full(tmp14.shape, 0.0, tmp14.dtype)
    tmp16 = tl.where(tmp13, tmp14, tmp15)
    tmp17 = tl.load(in_ptr0 + (1472 + x0 + 4096*x2), tmp4, eviction_policy='evict_last', other=0.0)
    tmp18 = tl.where(tmp11, tmp16, tmp17)
    tmp19 = tl.load(in_ptr0 + (1408 + x0 + 4096*x2), tmp4, eviction_policy='evict_last', other=0.0)
    tmp20 = tl.where(tmp7, tmp18, tmp19)
    tmp21 = tl.full([1], 22, tl.int64)
    tmp22 = tmp21 < tmp10
    tmp23 = tmp22.to(tl.int1)
    tmp24 = tmp23 & tmp4
    tmp25 = (x0).to(tl.int64)
    tmp26 = (tmp25).to(tl.int64)
    tmp27 = tl.full([1], 23, tl.int64)
    tmp28 = tmp26 < tmp27
    tmp29 = tmp28.to(tl.int1)
    tmp30 = tmp29 & tmp24
    tmp31 = tl.load(in_ptr0 + (1472 + x0 + 4096*x2), tmp30, eviction_policy='evict_last', other=0.0)
    tmp32 = tl.load(in_ptr1 + (22 + 4096*x2), tmp30, eviction_policy='evict_last', other=0.0)
    tmp33 = tmp31 * tmp32
    tmp34 = tl.full(tmp33.shape, 0.0, tmp33.dtype)
    tmp35 = tl.where(tmp30, tmp33, tmp34)
    tmp36 = tl.full([1], 0.0, tl.float32)
    tmp37 = tl.where(tmp28, tmp35, tmp36)
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp24, tmp37, tmp38)
    tmp40 = tl.full([1], 0.0, tl.float32)
    tmp41 = tl.where(tmp22, tmp39, tmp40)
    tmp42 = tmp20 + tmp41
    tmp43 = tl.load(in_ptr0 + (1472 + x0 + 4096*x2), tmp13, eviction_policy='evict_last', other=0.0)
    tmp44 = tl.load(in_ptr2 + (x0 + 23*x2), tmp13, eviction_policy='evict_last', other=0.0)
    tmp45 = tmp43 + tmp44
    tmp46 = tl.full(tmp45.shape, 0.0, tmp45.dtype)
    tmp47 = tl.where(tmp13, tmp45, tmp46)
    tmp48 = tl.where(tmp11, tmp47, tmp40)
    tmp49 = tl.where(tmp7, tmp48, tmp40)
    tmp50 = tmp42 + tmp49
    tmp51 = tl.load(in_ptr3 + (x1 + 4096*x2), tmp4, eviction_policy='evict_last', other=0.0)
    tmp52 = tmp50 * tmp51
    tmp53 = tl.full(tmp52.shape, 0.0, tmp52.dtype)
    tmp54 = tl.where(tmp4, tmp52, tmp53)
    tmp55 = tl.full([1], 0.0, tl.float32)
    tmp56 = tl.where(tmp3, tmp54, tmp55)
    tl.store(out_ptr0 + (x4), tmp56, None)
