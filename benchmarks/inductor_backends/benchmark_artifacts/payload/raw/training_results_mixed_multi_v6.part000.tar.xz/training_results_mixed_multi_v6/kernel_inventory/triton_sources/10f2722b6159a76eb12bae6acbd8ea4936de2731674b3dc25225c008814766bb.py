
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2097152}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=1, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_clone_copy_select_slice_backward_transpose_view_zeros_like_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 9437184}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_clone_copy_select_slice_backward_transpose_view_zeros_like_7(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1572864
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 128) % 64)
    x0 = (xindex % 128)
    x2 = ((xindex // 8192) % 48)
    x3 = xindex // 393216
    x5 = xindex
    tmp0 = tl.full([1], 4, tl.int32)
    tmp1 = tl.full([1], 5, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = tl.full([1], 6, tl.int32)
    tmp4 = tmp0 == tmp3
    tmp5 = tl.full([1], 7, tl.int32)
    tmp6 = tmp0 == tmp5
    tmp7 = tl.full([1], 8, tl.int32)
    tmp8 = tmp0 == tmp7
    tmp9 = (256 + x1).to(tl.int64)
    tmp10 = (tmp9).to(tl.int64)
    tmp11 = tl.full([1], 569, tl.int64)
    tmp12 = tmp10 < tmp11
    tmp13 = tmp12.to(tl.int1)
    tmp14 = tl.load(in_ptr0 + (1572864 + x0 + 128*x2 + 6144*x1 + 3495936*x3), tmp13, other=0.0).to(tl.float32)
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tl.full(tmp15.shape, 0.0, tmp15.dtype)
    tmp17 = tl.where(tmp13, tmp15, tmp16)
    tmp18 = tl.full([1], 0.0, tl.float32)
    tmp19 = tl.where(tmp12, tmp17, tmp18)
    tmp20 = tl.where(tmp8, tmp18, tmp19)
    tmp21 = tl.where(tmp6, tmp18, tmp20)
    tmp22 = tl.where(tmp4, tmp18, tmp21)
    tmp23 = tl.where(tmp2, tmp18, tmp22)
    tmp24 = tmp23.to(tl.float32)
    tl.store(out_ptr0 + (x5), tmp24, None)
