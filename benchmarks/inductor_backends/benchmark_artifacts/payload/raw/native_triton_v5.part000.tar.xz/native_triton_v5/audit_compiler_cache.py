"""Recheck that seeded compiler artifacts in prior datasets remain unchanged."""

import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    reports = sorted((args.output / 'runs').glob('*/*/compiler_cache_provenance.json'))
    expected = {}
    conflicts, noncompiler_reuse = [], []
    source_roots = {}
    rewrites = 0
    copied = 0
    for report in reports:
        data = json.loads(report.read_text())
        root = data.get('source')
        if root:
            source_roots[root] = source_roots.get(root, 0) + 1
        rewrites += len(data.get('group_path_rewrites', []))
        copied += data.get('artifact_count', 0)
        if data.get('inductor_cache_seeded') is not False or data.get('autotune_results_seeded') is not False:
            noncompiler_reuse.append(str(report))
        for name, digest in data.get('source_artifacts', {}).items():
            if name in expected and expected[name] != digest:
                conflicts.append(name)
            expected[name] = digest
    mismatches = []
    for name, digest in expected.items():
        path = Path(name)
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            mismatches.append(name)
    result = dict(
        provenance_reports=len(reports), copied_artifact_records=copied,
        unique_original_artifacts=len(expected), copied_group_path_rewrites=rewrites,
        source_roots=source_roots, original_artifact_hash_mismatches=mismatches,
        conflicting_original_hashes=conflicts, noncompiler_cache_reuse_reports=noncompiler_reuse,
        passed=bool(reports) and not mismatches and not conflicts and not noncompiler_reuse,
        scope='Original V3/V4 artifacts are hashed after use. Path rewrites affected copied JSON only. Destination caches may gain fresh compiler artifacts during execution.',
    )
    (args.output / 'compiler_cache_audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'source_roots'}, indent=2))


if __name__ == '__main__':
    main()
