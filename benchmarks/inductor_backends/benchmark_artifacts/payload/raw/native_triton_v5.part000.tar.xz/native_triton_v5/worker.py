"""Run one case and variant under a verified frozen source overlay."""

import argparse
import importlib
import json
import hashlib
import os
from pathlib import Path
import sys
import time
import traceback
from contextlib import contextmanager


def verify(fingerprint):
    for name, expected in fingerprint['sources'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Frozen source changed: ' + name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--variant', choices=('stock', 'previous_native', 'new_native'), required=True)
    parser.add_argument('--case-file', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--fingerprint', type=Path, required=True)
    parser.add_argument('--rounds', type=int, required=True)
    parser.add_argument('--repeats', type=int, required=True)
    args = parser.parse_args()
    fingerprint = json.loads(args.fingerprint.read_text())
    verify(fingerprint)
    args.output.mkdir(parents=True, exist_ok=True)
    case = json.loads(args.case_file.read_text())
    sys.path.insert(0, os.environ['NATIVE_BENCHMARK_HARNESS_ROOT'])
    import amd_next_kernel_hillclimb as benchmark
    import torch
    from torch._inductor import config

    torch.set_num_threads(8)
    loaded = {}
    source_root = Path(os.environ['AMD_CODEGEN_SOURCE_ROOT']).resolve()
    for name in fingerprint['overlay_modules']:
        module = importlib.import_module(name)
        actual = Path(module.__file__).resolve()
        expected = source_root / (name.replace('.', '/') + '.py')
        if actual != expected:
            raise RuntimeError(f'Wrong compiler overlay: {name}: {actual} != {expected}')
        loaded[name] = str(actual)
    original_workload = benchmark.base.workload

    def workload(case, seed):
        if case.get('transpose_mode') != 'matrix':
            return original_workload(case, seed)
        torch.manual_seed(seed)
        value = torch.randn(case['shape'], device='cuda', dtype=getattr(torch, case['dtype']))
        return lambda x: x.transpose(-2, -1).contiguous(), (value,)

    @contextmanager
    def patch(variant, path):
        tier = 'triton' if variant == 'stock' else 'optimized_triton'
        with benchmark.patch(tier, path):
            with config.patch({'triton.amd_use_gluon': False}):
                yield

    benchmark.base.workload = workload
    benchmark.base.patch = patch
    benchmark.base.VARIANTS = (args.variant,)
    started = time.monotonic()
    try:
        report = benchmark.base.run_case(case, args.output, args.rounds, args.repeats)
        for row in report['rows']:
            invocation = row['invocation']
            row['measured_invocation'] = benchmark.gpu_protocol.INVOCATION_PROTOCOL[invocation]
            row['host_overhead_included'] = benchmark.gpu_protocol.HOST_OVERHEAD_INCLUDED[invocation]
        report.update(status='ok' if not report['failures'] else 'variant_failure')
    except Exception:
        report = dict(case=case, rows=[], failures=[dict(variant=args.variant, error=traceback.format_exc())], status='case_failure')
    properties = torch.cuda.get_device_properties(0)
    report.update(
        variant=args.variant, wall_seconds=time.monotonic() - started,
        source_fingerprint=fingerprint, loaded_overlay_modules=loaded,
        measurement_protocol=benchmark.gpu_protocol.MEASUREMENT_PROTOCOL,
        torch_version=torch.__version__, torch_git=torch.version.git_version,
        gpu=properties.name, gpu_uuid=str(properties.uuid), architecture=properties.gcnArchName,
    )
    diagnostics = []
    for path in sorted(args.output.rglob('*.tuning.jsonl')):
        for index, line in enumerate(path.read_text().splitlines(), 1):
            if line.strip():
                diagnostics.append(dict(path=str(path), line=index, record=json.loads(line)))
    report['tuning_diagnostics'] = diagnostics
    report['reference_policy'] = dict(
        definition='FP64 accumulation of exact input values, cast to eager operation output dtype' if case['family'] == 'cumsum' else 'eager operation output',
        input_seeds=[2026, 1701, 2027], fp64_in_compiled_or_timed_function=False,
        tolerance_changed=False, cumsum_atol=2e-4, cumsum_rtol=1e-4,
    )
    from torch._inductor.codecache import PyCodeCache
    from torch._inductor.runtime.triton_heuristics import CachingAutotuner
    from torch._inductor.codegen.multi_kernel import MultiKernelCall

    choices = []
    selected = {}
    for module in PyCodeCache.modules:
        for name, kernel in vars(module).items():
            if isinstance(kernel, MultiKernelCall):
                members = kernel.kernels
                chosen = kernel.picked_kernel
                choices.append(dict(
                    module=str(getattr(module, "__file__", None)), name=name, picked_kernel=chosen,
                    kernel_names=[item.inductor_meta.get("kernel_name") for item in members],
                ))
                for index, member in enumerate(members):
                    selected[id(member)] = index == chosen if chosen is not None else None
    report["multi_kernel_choices"] = choices

    kernels = []
    seen = set()
    for module in PyCodeCache.modules:
        for name, kernel in vars(module).items():
            if not isinstance(kernel, CachingAutotuner) or id(kernel) in seen:
                continue
            seen.add(id(kernel))
            for launcher in kernel.launchers:
                initial_compile = getattr(kernel, 'precompile_time_taken_ns', None)
                autotune_total = getattr(kernel, 'autotune_time_taken_ns', None)
                kernels.append(dict(
                    module=str(getattr(module, '__file__', None)), kernel_name=name,
                    selected_for_execution=selected.get(id(kernel), True),
                    family=kernel.inductor_meta.get('amd_native_family', kernel.inductor_meta.get('amd_gluon_family')),
                    config=dict(launcher.config.kwargs, num_warps=launcher.config.num_warps, num_stages=launcher.config.num_stages),
                    n_regs=getattr(launcher, 'n_regs', None), n_spills=getattr(launcher, 'n_spills', None),
                    shared=getattr(launcher, 'shared', None), initial_precompile_time_ns=initial_compile,
                    autotune_total_time_ns=autotune_total,
                    benchmark_and_neighbor_compile_time_ns=(autotune_total - initial_compile)
                    if initial_compile is not None and autotune_total is not None else None,
                ))
    report['kernel_launcher_profiles'] = kernels
    verify(fingerprint)
    (args.output / 'worker_result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(case=case['case'], variant=args.variant, status=report['status'], rows=len(report['rows']))), flush=True)


if __name__ == '__main__':
    main()
