"""Aggregate frozen native-v2 runs, kernel resources, and compile/tuning costs."""

import argparse
import csv
import html
import json
import math
from pathlib import Path
import statistics


VARIANTS = ('stock', 'previous_native', 'new_native')
CACHES = ('cold', 'warm')
PROTOCOLS = {
    'direct': dict(measured_invocation='captured_gpu_kernel_sequence', host_overhead_included=False),
    'graph_replay': dict(measured_invocation='inline_graph_replay_events', host_overhead_included=True),
}


def geomean(values):
    return math.exp(statistics.mean(math.log(value) for value in values)) if values else None


def write_csv(path, rows):
    if not rows:
        path.write_text('')
        return
    with path.open('w', newline='') as target:
        writer = csv.DictWriter(target, fieldnames=list(dict.fromkeys(key for row in rows for key in row)))
        writer.writeheader()
        writer.writerows(rows)



def runtime_chart(output, cases, lookup, invocation):
    colors = {'stock': '#3976bd', 'previous_native': '#8793a0', 'new_native': '#15966a'}
    labels = {'stock': 'Stock Triton', 'previous_native': 'Previous native', 'new_native': 'New native'}
    width, left, right = 1780, 680, 1510
    height = 185 + 80 * len(cases)
    values = {}
    for case in cases:
        for variant in VARIANTS:
            keys = [(case['case'], variant, cache, invocation) for cache in CACHES]
            if all(key in lookup for key in keys):
                values[case['case'], variant] = geomean([lookup[key]['runtime_us'] for key in keys])
    maximum = max([1, *values.values()]) * 1.3

    def xpos(value):
        return left + (right - left) * (math.log10(max(value, 0.1)) + 1) / (math.log10(maximum) + 1)

    def text(x, y, value, size=12, anchor='start', fill='#253445'):
        return (f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" text-anchor="{anchor}" '
                f'fill="{fill}">{html.escape(str(value))}</text>')

    title = ('Captured GPU kernel sequences: host overhead excluded' if invocation == 'direct'
             else 'Inline graph replay: host launch gaps may contribute')
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/><g font-family="Arial,sans-serif">',
        text(24, 30, title, 22),
        text(24, 55, 'Per-case runtime: geometric mean of cold/warm input contexts; lower is faster'),
    ]
    for index, variant in enumerate(VARIANTS):
        x = 30 + index * 260
        parts.extend([f'<rect x="{x}" y="76" width="15" height="13" fill="{colors[variant]}"/>',
                      text(x + 23, 88, labels[variant])])
    for exponent in range(-1, math.ceil(math.log10(maximum)) + 1):
        for factor in (1, 3):
            tick = 10 ** exponent * factor
            if tick <= maximum:
                x = xpos(tick)
                parts.extend([f'<path d="M{x:.2f},108 V{height - 45}" stroke="#dde3e9"/>',
                              text(x, height - 25, f'{tick:g}', 11, 'middle')])
    for index, case in enumerate(cases):
        y = 125 + 80 * index
        parts.append(text(left - 15, y + 23, case['case'], 11, 'end'))
        for offset, variant in enumerate(VARIANTS):
            value = values.get((case['case'], variant))
            yy = y + 21 * offset
            if value is None:
                parts.append(text(left + 8, yy + 13, 'pending / unavailable', 11, fill=colors[variant]))
            else:
                end = xpos(value)
                parts.extend([
                    f'<rect x="{left}" y="{yy}" width="{max(0.5, end - left):.2f}" height="15" fill="{colors[variant]}"/>',
                    text(end + 7, yy + 12, f'{value:.3f} us', 11),
                ])
    parts.extend([text((left + right) / 2, height - 5, 'Runtime (microseconds, log scale; bars start at 0.1 us)', 12, 'middle'), '</g></svg>'])
    name = 'runtime_chart.svg' if invocation == 'direct' else 'graph_replay_runtime_chart.svg'
    (output / name).write_text('\n'.join(parts) + '\n')


def per_op_chart(output, rows, invocation):
    selected = [row for row in rows if row['split'] == 'all' and row['invocation'] == invocation]
    colors = {'stock': '#3976bd', 'previous_native': '#8793a0', 'new_native': '#15966a'}
    labels = {'stock': 'Stock Triton', 'previous_native': 'Previous native', 'new_native': 'New native'}
    width, left, right = 1500, 430, 1230
    height = 180 + 82 * len(selected)
    values = {}
    for index, row in enumerate(selected):
        stock_factor = row['new_vs_stock_speedup_factor']
        previous_factor = row['new_vs_previous_native_speedup_factor']
        if stock_factor is not None:
            values[index, 'stock'] = 100
            values[index, 'new_native'] = 100 / stock_factor
            values[index, 'previous_native'] = 100 * previous_factor / stock_factor
    maximum = max([125, *values.values()]) * 1.15

    def xpos(value):
        return left + (right - left) * value / maximum

    def text(x, y, value, size=12, anchor='start'):
        return (f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" text-anchor="{anchor}" '
                f'fill="#253445">{html.escape(str(value))}</text>')

    title = 'Captured GPU sequences' if invocation == 'direct' else 'Inline graph replay: host-inclusive'
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">',
        '<rect width="100%" height="100%" fill="white"/><g font-family="Arial,sans-serif">',
        text(24, 30, title + ': per-operation geometric mean', 22),
        text(24, 55, 'Same successful cases across all three variants; equal case and cache-mode weights; stock = 100%; lower is faster'),
    ]
    for index, variant in enumerate(VARIANTS):
        x = 30 + 260 * index
        parts.extend([f'<rect x="{x}" y="76" width="15" height="13" fill="{colors[variant]}"/>', text(x + 23, 88, labels[variant])])
    for value in range(0, math.ceil(maximum), 25):
        x = xpos(value)
        parts.extend([f'<path d="M{x:.2f},108 V{height - 45}" stroke="#dde3e9"/>', text(x, height - 25, value, 11, 'middle')])
    for index, row in enumerate(selected):
        y = 125 + 82 * index
        parts.append(text(left - 15, y + 22, f"{row['family']} (n={row['common_cases']}/{row['expected_cases']})", 12, 'end'))
        for offset, variant in enumerate(VARIANTS):
            value = values.get((index, variant))
            yy = y + 21 * offset
            if value is None:
                parts.append(text(left + 8, yy + 13, 'pending / unavailable', 11))
            else:
                end = xpos(value)
                parts.extend([f'<rect x="{left}" y="{yy}" width="{end - left:.2f}" height="15" fill="{colors[variant]}"/>', text(end + 7, yy + 12, f'{value:.1f}%', 11)])
    parts.extend([text((left + right) / 2, height - 5, 'Normalized runtime (%)', 12, 'middle'), '</g></svg>'])
    name = 'per_op_chart.svg' if invocation == 'direct' else 'graph_replay_per_op_chart.svg'
    (output / name).write_text('\n'.join(parts) + '\n')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output
    manifest = json.loads((output / 'manifest.json').read_text())
    cases = manifest['protocol']['cases']
    lookup, failures, kernels, candidates, costs, choices = {}, [], [], [], [], []
    completed_workers = 0
    for case in cases:
        for variant in VARIANTS:
            path = output / 'runs' / case['case'] / variant / 'worker_result.json'
            if not path.exists():
                continue
            report = json.loads(path.read_text())
            completed_workers += 1
            for failure in report.get('failures', []):
                failures.append(dict(case=case['case'], **failure))
            for row in report.get('rows', []):
                key = (case['case'], variant, row['cache'], row['invocation'])
                value = float(row['runtime_us'])
                if key in lookup or not math.isfinite(value) or value <= 0:
                    raise RuntimeError(f'Duplicate or invalid measurement: {key}')
                lookup[key] = row
            profiles = report.get('kernel_launcher_profiles', [])
            for profile in profiles:
                kernels.append(dict(
                    profile, case=case['case'], variant=variant,
                    config=json.dumps(profile['config'], sort_keys=True),
                ))
            for choice in report.get('multi_kernel_choices', []):
                choices.append(dict(case=case['case'], variant=variant, **choice))
            diagnostics = [item['record'] for item in report.get('tuning_diagnostics', [])]
            for index, record in enumerate(diagnostics):
                for candidate in record.get('candidates', []):
                    candidates.append(dict(
                        case=case['case'], variant=variant, diagnostic_index=index,
                        kernel_name=record.get('kernel_name'), family=record.get('family'),
                        selected=candidate.get('config') == record.get('selected_config'),
                        config=json.dumps(candidate.get('config'), sort_keys=True),
                        median_ms=candidate.get('median_ms'), confirmed=candidate.get('confirmed'),
                        n_regs=candidate.get('n_regs'), n_spills=candidate.get('n_spills'), shared=candidate.get('shared'),
                    ))
            compile_wall = next((row['compile_seconds'] for row in report.get('rows', [])), None)
            phase_available = bool(diagnostics) and all(
                ('accounted_compile_time_ns' in item or 'compile_time_ns' in item) and 'tuning_time_ns' in item
                for item in diagnostics
            )
            costs.append(dict(
                case=case['case'], variant=variant, status=report['status'],
                compile_validate_capture_wall_seconds=compile_wall, case_wall_seconds=report.get('wall_seconds'),
                subprocess_wall_seconds=report.get('subprocess_wall_seconds'),
                generated_kernel_count=len(profiles), execution_kernel_count=sum(item.get('selected_for_execution') is True for item in profiles),
                initial_precompile_seconds=sum(item.get('initial_precompile_time_ns') or 0 for item in profiles) / 1e9 if profiles else None,
                autotune_total_seconds=sum(item.get('autotune_total_time_ns') or 0 for item in profiles) / 1e9 if profiles else None,
                benchmark_and_neighbor_compile_seconds=sum(item.get('benchmark_and_neighbor_compile_time_ns') or 0 for item in profiles) / 1e9 if profiles else None,
                separated_compile_tune_available=phase_available,
                diagnostic_accounted_compile_seconds=sum(item.get('accounted_compile_time_ns', item.get('compile_time_ns', 0)) for item in diagnostics) / 1e9 if phase_available else None,
                reported_precompile_seconds=sum(item['reported_precompile_time_ns'] for item in diagnostics) / 1e9 if diagnostics and all('reported_precompile_time_ns' in item for item in diagnostics) else None,
                neighbor_compile_seconds=sum(item['neighbor_compile_time_ns'] for item in diagnostics) / 1e9 if diagnostics and all('neighbor_compile_time_ns' in item for item in diagnostics) else None,
                compile_time_accounting='; '.join(sorted({item.get('compile_time_accounting', 'legacy accounted counter may exclude async initial compilation') for item in diagnostics})) if phase_available else None,
                diagnostic_tuning_seconds=sum(item['tuning_time_ns'] for item in diagnostics) / 1e9 if phase_available else None,
                diagnostic_kernel_count=len(diagnostics),
                initial_candidates=sum(item['initial_candidates'] for item in diagnostics) if diagnostics and all('initial_candidates' in item for item in diagnostics) else None,
                measured_candidates=sum(item.get('measured_candidates', len(item.get('candidates', []))) for item in diagnostics) if diagnostics else None,
                neighbor_compile_attempts=sum(item.get('neighbor_compile_attempts', 0) for item in diagnostics) if phase_available else None,
                neighbor_compile_failures=sum(item.get('neighbor_compile_failures', 0) for item in diagnostics) if phase_available else None,
            ))
    per_case = []
    for case in cases:
        for invocation, protocol in PROTOCOLS.items():
            for cache in CACHES:
                row = dict(case=case['case'], family=case['family'], dtype=case['dtype'], split=case.get('split'),
                           cache=cache, invocation=invocation, **protocol)
                for variant in VARIANTS:
                    measurement = lookup.get((case['case'], variant, cache, invocation))
                    row[variant + '_runtime_us'] = measurement['runtime_us'] if measurement else None
                row['complete'] = all(row[variant + '_runtime_us'] is not None for variant in VARIANTS)
                for baseline in ('stock', 'previous_native'):
                    value, new = row[baseline + '_runtime_us'], row['new_native_runtime_us']
                    row['new_vs_' + baseline + '_speedup_percent'] = 100 * (value / new - 1) if value and new else None
                per_case.append(row)

    def aggregate(selected, invocation):
        common = [case for case in selected if all(
            (case['case'], variant, cache, invocation) in lookup for variant in VARIANTS for cache in CACHES
        )]
        result = dict(invocation=invocation, **PROTOCOLS[invocation], common_cases=len(common), expected_cases=len(selected),
                      case_names=[case['case'] for case in common], complete=len(common) == len(selected))
        for baseline in ('stock', 'previous_native'):
            ratios = [lookup[case['case'], baseline, cache, invocation]['runtime_us'] /
                      lookup[case['case'], 'new_native', cache, invocation]['runtime_us']
                      for case in common for cache in CACHES]
            factor = geomean(ratios)
            result['new_vs_' + baseline + '_speedup_factor'] = factor
            result['new_vs_' + baseline + '_speedup_percent'] = 100 * (factor - 1) if factor is not None else None
        return result

    per_op = []
    for family in sorted({case['family'] for case in cases}):
        for split in ('all', 'anchor', 'heldout'):
            selected = [case for case in cases if case['family'] == family and (split == 'all' or case.get('split') == split)]
            if not selected:
                continue
            for invocation in PROTOCOLS:
                row = aggregate(selected, invocation)
                row['case_names'] = json.dumps(row['case_names'])
                per_op.append(dict(family=family, split=split, **row))
    write_csv(output / 'failures.csv', failures)
    write_csv(output / 'per_case.csv', per_case)
    write_csv(output / 'per_op.csv', per_op)
    write_csv(output / 'per_kernel.csv', kernels)
    write_csv(output / 'per_candidate.csv', candidates)
    write_csv(output / 'compile_tune_costs.csv', costs)
    summary = dict(
        headline_protocol='direct', headline=aggregate(cases, 'direct'),
        graph_replay=aggregate(cases, 'graph_replay'),
        by_split={split: aggregate([case for case in cases if case.get('split') == split], 'direct') for split in ('anchor', 'heldout')},
        speedup_definition='100 * (geomean(baseline_runtime / new_native_runtime) - 1)',
        weighting='Equal cache-mode weights within each case, then equal weights across common cases; both comparisons use identical cases',
        compile_timing_notes=(
            'compile_validate_capture_wall_seconds includes compile/autotune, correctness validation and capture setup. '
            'case_wall_seconds starts after compiler imports and includes run_case; subprocess_wall_seconds also covers interpreter startup/imports/profiling when recorded. '
            'initial_precompile_seconds and autotune_total_seconds are selected-config tuner object counters available for all tiers; '
            'benchmark_and_neighbor_compile_seconds includes candidate benchmarking, neighbor compilation and validation. '
            'Diagnostic accounted compilation costs may exclude asynchronous initial compilation, as identified by compile_time_accounting. '
            'Separated diagnostic accounted-compile/tuning costs are null for previous sources without that instrumentation. '
            'per_kernel.csv profiles compiled Triton CachingAutotuner launchers; it does not provide resource counters for ATen/library calls. '
            'selected_for_execution identifies MultiKernel winners.'
        ),
        source_manifests=manifest['sources'], failure_count=len(failures), failures=failures,
        multi_kernel_choices=choices, compile_tune_costs=costs,
    )
    summary['numerical_all_pass'] = completed_workers == len(cases) * len(VARIANTS) and not failures
    summary['completed_workers'] = completed_workers
    summary['expected_workers'] = len(cases) * len(VARIANTS)
    summary['run_state'] = ('paused' if (output / 'PAUSED.json').exists() else
                            'complete' if completed_workers == summary['expected_workers'] else 'running')
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    for invocation in PROTOCOLS:
        runtime_chart(output, cases, lookup, invocation)
        per_op_chart(output, per_op, invocation)
    print(json.dumps(dict(summary=str(output / 'summary.json'), headline=summary['headline'], failures=len(failures)), indent=2))


if __name__ == '__main__':
    main()
