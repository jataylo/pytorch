from pathlib import Path
import ast
import difflib
import json
import sys
import tempfile
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

D = Path(__file__).resolve().parent
R = D.parent
source = R / 'fallback_fixes_v4/torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py'
old = source.read_text()
before = '''        with open(path) as f:
            best = next(m for m in mains if m.__name__ == f.read().strip())
'''
after = '''        with open(path) as f:
            winner = f.read().strip()
        best = next(m for m in mains if m.__name__ == winner)
'''
if old.count(before) != 1:
    raise RuntimeError('Unexpected cache loader source')
new = old.replace(before, after)
(D / 'flydsl_simd_runtime.cache_read_once.py').write_text(new)

def load(text, path, events):
    node = next(item for item in ast.parse(text).body if isinstance(item, ast.FunctionDef) and item.name == 'pick_fastest')
    tree = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
    namespace = {'__package__': '_cache_regression_fixture', '_pick_path': lambda mains: path}
    exec(compile(tree, str(source), 'exec'), namespace)
    return namespace['pick_fastest']

outcomes = []
for label, text in [('original', old), ('isolated_fixed', new)]:
    for winner in [0, 1]:
        calls, events = [], []
        def first(*args, stream=None):
            calls.append(0)
        def second(*args, stream=None):
            calls.append(1)
        mains = [first, second]
        torch_stub = ModuleType('torch')
        torch_stub.cuda = SimpleNamespace(is_current_stream_capturing=lambda: False)
        torch_stub.Tensor = type('NoRealTensor', (), {})
        package = ModuleType('_cache_regression_fixture')
        package.__path__ = []
        diagnostics = ModuleType('_cache_regression_fixture.flydsl_diagnostics')
        diagnostics.record_kernel_decision = events.append
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'choice'
            path.write_text(mains[winner].__name__ + '\n')
            fn = load(text, str(path), events)
            with patch.dict(sys.modules, {'torch': torch_stub, package.__name__: package, diagnostics.__name__: diagnostics}):
                try:
                    selected = fn(mains, (), (), metadata={'category': 'backend_selection', 'backends': ['flydsl', 'triton']})
                    passed = selected is mains[winner] and calls == [winner] and events[-1]['cache_hit'] is True
                    outcome = dict(source=label, winner=winner, passed=passed, calls=calls, events=events)
                except Exception as error:
                    outcome = dict(source=label, winner=winner, passed=False, exception=type(error).__name__, calls=calls)
        outcomes.append(outcome)
if [item['passed'] for item in outcomes] != [True, False, True, True]:
    raise RuntimeError(f'Unexpected control outcomes: {outcomes}')
(D / 'cache_read_once_cpu_controls.json').write_text(json.dumps(outcomes, indent=2) + '\n')
test = '''import ast
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

from torch.testing._internal.common_utils import TestCase, instantiate_parametrized_tests, parametrize, run_tests


@instantiate_parametrized_tests
class TestFlyDSLBackendSelectionCache(TestCase):
    @parametrize("winner", [0, 1])
    def test_cached_candidate_is_honored(self, winner):
        source = Path(__file__).resolve().parents[2] / "torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py"
        node = next(item for item in ast.parse(source.read_text()).body
                    if isinstance(item, ast.FunctionDef) and item.name == "pick_fastest")
        tree = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
        calls, events = [], []

        def first(*args, stream=None):
            calls.append(0)

        def second(*args, stream=None):
            calls.append(1)

        mains = [first, second]
        torch_stub = ModuleType("torch")
        torch_stub.cuda = SimpleNamespace(is_current_stream_capturing=lambda: False)
        torch_stub.Tensor = type("NoRealTensor", (), {})
        package = ModuleType("_flydsl_cache_fixture")
        package.__path__ = []
        diagnostics = ModuleType("_flydsl_cache_fixture.flydsl_diagnostics")
        diagnostics.record_kernel_decision = events.append
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "choice"
            path.write_text(mains[winner].__name__ + "\\n")
            namespace = {"__package__": package.__name__, "_pick_path": lambda candidates: str(path)}
            exec(compile(tree, str(source), "exec"), namespace)
            with patch.dict(sys.modules, {"torch": torch_stub, package.__name__: package,
                                          diagnostics.__name__: diagnostics}):
                actual = namespace["pick_fastest"](mains, (), (), metadata={
                    "category": "backend_selection", "backends": ["flydsl", "triton"]})
        self.assertIs(actual, mains[winner])
        self.assertEqual(calls, [winner])
        self.assertEqual(len(events), 1)
        self.assertTrue(events[0]["cache_hit"])
        self.assertEqual(events[0]["selected_backend"], ["flydsl", "triton"][winner])


if __name__ == "__main__":
    run_tests()
'''
(D / 'test_flydsl_backend_selection_cache.py').write_text(test)
patch_text = ''.join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
    fromfile='a/torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py',
    tofile='b/torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py'))
patch_text += ''.join(difflib.unified_diff([], test.splitlines(keepends=True), fromfile='/dev/null',
    tofile='b/test/inductor/test_flydsl_backend_selection_cache.py'))
(D / 'cache_read_once.patch').write_text(patch_text)
print(json.dumps({'controls':[{key:item[key] for key in ['source','winner','passed']} for item in outcomes],
                  'patch':str(D / 'cache_read_once.patch'), 'applied':False}, indent=2))
