from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import ast
import hashlib
import json
import struct

R = Path(__file__).resolve().parents[1]
D = Path(__file__).resolve().parent
RAW = R / 'training_results_mixed_multi_v6/raw/priority--openai_gpt-oss-120b--bs8'
source = R / 'fallback_fixes_v4'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record_summary(path):
    value = json.loads(path.read_text())
    keys = ['backend', 'autotune', 'rank', 'status', 'phase', 'attempt_id', 'world_size', 'physical_gpu',
            'model_config_sha256', 'parameters', 'dtype', 'inputs', 'local_batch_size', 'effective_global_batch_size',
            'first_compiled_step_seconds', 'timing_warmup', 'timing_graphs_before', 'timing_recompiles',
            'timing_begin_ns', 'timing_end_ns', 'milliseconds', 'repeat_ms', 'subprocess_seconds', 'returncode',
            'inductor_cache', 'compiled_artifact_cache', 'triton_binary_cache']
    return dict(path=str(path), sha256=digest(path), **{key: value.get(key) for key in keys})


summaries = [record_summary(path) for path in sorted(RAW.glob('*.json'))]
summaries += [record_summary(path) for path in sorted((RAW / 'ranks').glob('flydsl_autotune0*.json'))]
diag = []
for path in sorted((RAW / 'kernels').glob('flydsl_autotune0*.jsonl')):
    with path.open() as stream:
        events = [json.loads(line) for line in stream]
    candidates = {event['kernel_name']: event for event in events if event.get('category') == 'backend_candidates'}
    choices = {event['kernel_name']: event for event in events if event.get('category') == 'backend_selection'}
    diag.append(dict(path=str(path), sha256=digest(path), events=len(events),
        phases=dict(Counter(event.get('phase') for event in events)),
        categories=dict(Counter(event.get('category') for event in events)),
        unique_candidate_names=len(candidates), unique_selected_names=len(choices),
        unselected_candidate_names=sorted(set(candidates) - set(choices)),
        selected_backends=dict(Counter(event['selected_backend'] for event in choices.values())),
        selected_triton=[dict(kernel_name=name, triton_kernel=candidates[name]['triton_kernel'],
            stage=event.get('stage'), graph_id=candidates[name].get('graph_id'),
            is_backward=candidates[name].get('is_backward'), cache_hit=event.get('cache_hit'),
            candidate_times_ms=event.get('candidate_times_ms'))
            for name, event in choices.items() if event['selected_backend'] == 'triton'],
        tail=[{key: event.get(key) for key in ['category', 'kernel_name', 'phase', 'selected_backend', 'reason']}
              for event in events[-4:]]))
wrapper_evidence = []
root_record = json.loads((RAW / 'flydsl_autotune0.json').read_text())
for path in sorted(Path(root_record['inductor_cache']).rglob('*.py')):
    text = path.read_text(errors='replace')
    if '# AOT ID:' not in text:
        continue
    tree = ast.parse(text)
    selectors = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and ast.unparse(node.func) == 'fdp_rt.BackendSelector':
            alternatives = node.args[0].elts
            selectors.append(dict(line=node.lineno, alternatives=[ast.unparse(item.body) for item in alternatives],
                                  arguments=[ast.unparse(item.args) for item in alternatives],
                                  mutated=ast.unparse(node.args[1]), warm=ast.unparse(node.args[2]),
                                  label=ast.literal_eval(node.args[3])))
    wrapper_evidence.append(dict(path=str(path), sha256=digest(path),
        aot=next(line for line in text.splitlines() if '# AOT ID:' in line), selectors=selectors,
        raw_stream_lines=[line.strip() for line in text.splitlines() if 'get_raw_stream(' in line]))
log = RAW / 'flydsl_autotune0.log'
lines = log.read_text().splitlines()
important = []
for number, line in enumerate(lines, 1):
    if any(word in line for word in ['allocation failed with OOM', 'HSA_STATUS_ERROR_MEMORY_FAULT',
                                    'Memory Fault Error', 'Memory access fault', 'WorkNCCL(SeqNum=6089',
                                    'train_worker_mixed_multi_v6.py:470']):
        important.append(dict(line=number, text=line))
core = next(R.glob('gpucore.3897880.gpu'), None)
if core is None:
    matches = list(R.rglob('gpucore.3897880.gpu'))
    core = matches[0] if matches else None
core_info = None
if core is not None:
    stat = core.stat()
    with core.open('rb') as stream:
        header = stream.read(65536)
    core_info = dict(path=str(core), size=stat.st_size, mtime_ns=stat.st_mtime_ns,
                     first64KiB_sha256=hashlib.sha256(header).hexdigest(), magic=header[:16].hex(),
                     full_hash_not_computed='Avoid reading 185GB during active benchmark; file preserved unchanged')
source_paths = [source / 'torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py',
                source / 'torch/_inductor/codegen/flydsl/flydsl_simd.py',
                R / 'train_worker_mixed_multi_v6.py', R / 'run_suite_mixed_multi_v6.py',
                R / 'source_fingerprint_mixed_multi_v6.json',
                R / 'pytorch/torch/distributed/fsdp/_runtime_utils.py',
                R / 'pytorch/torch/distributed/fsdp/_flat_param.py',
                R / 'pytorch/c10/hip/HIPCachingAllocator.cpp']
result = dict(captured_utc=datetime.now(timezone.utc).isoformat(), scope='CPU read-only; no GPU APIs/compilers/runtimes invoked',
              records=summaries, diagnostics=diag, wrappers=wrapper_evidence,
              crash_log=dict(path=str(log), sha256=digest(log), important_lines=important), core=core_info,
              source_hashes={str(path): digest(path) for path in source_paths})
(D / 'evidence.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'records':len(summaries), 'rank_diagnostics':len(diag), 'rank0_wrappers':len(wrapper_evidence),
                  'selector_definitions':sum(len(item['selectors']) for item in wrapper_evidence),
                  'core':core_info, 'output':str(D / 'evidence.json')}, indent=2))
