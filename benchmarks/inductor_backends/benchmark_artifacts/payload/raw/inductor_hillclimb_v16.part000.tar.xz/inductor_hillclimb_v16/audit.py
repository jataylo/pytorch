import fcntl
from pathlib import Path
import csv,difflib,hashlib,json,math,re,statistics,subprocess,sys
import xml.etree.ElementTree as ET
h=Path(__file__).resolve().parent;b=h.parent/'pytorch_codegen_v13'
report_lock=(h/'report.lock').open('a')
fcntl.flock(report_lock,fcntl.LOCK_EX)
def check(value,message):
 if not value:raise RuntimeError(message)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
fp=json.loads((h/'source_fingerprint.json').read_text())
for name,expected in fp['sources'].items():
 path=Path(name);check(sha(path)==expected,'Source changed: '+name)
 relative=path.relative_to(b) if path.is_relative_to(b) else Path('environment')/path.relative_to(h.parent)
 check(sha(h/'accepted_source'/relative)==expected,'Snapshot differs: '+name)
counts={};protocol_counts={};routes=0
for suite,count in [('new_ops_final',80),('reference_final',18),('legacy_final',62)]:
 root=h/suite;manifest=json.loads((root/'manifest.json').read_text())
 check(json.loads((root/'failures.json').read_text())==[],'Failures: '+suite)
 cases=list(root.glob('*/result.json'));check(len(cases)==count,'Case count: '+suite)
 rows=list(csv.DictReader((root/'per_case.csv').open()));check(len(rows)==count*16,'CSV row count: '+suite)
 for path in cases:
  data=json.loads(path.read_text());check(data['failures']==[],'Case failed')
  check(data['frozen_backend_callbacks']==[1,1,1,1],'Backend isolation')
  check(len(data['rows'])==16,'Incomplete case')
  for name,expected in data['source_fingerprint'].items():check(sha(Path(name))==expected,'Case source changed: '+name)
  for row in data['rows']:
   key='_'.join(row[k] for k in ['variant','cache','invocation']);samples=data['samples_us'][key]
   check(len(samples)==15,'Missing round samples')
   check(abs(statistics.median(samples)-row['runtime_us'])<1e-8,'Median differs')
   check(row['runtime_us']>0,'Nonpositive runtime')
   check(sha(path.parent/(row['variant']+'.py'))==row['source_sha256'],'Generated source differs')
   expected_protocol='captured_gpu_kernel_sequence' if row['invocation']=='direct' else 'inline_graph_replay_events'
   check(row['measured_invocation']==expected_protocol,'Invocation protocol mislabelled')
   check(row['host_overhead_included']==(row['invocation']=='graph_replay'),'Host boundary mislabelled')
  for log in path.parent.glob('*.tuning.jsonl'):
   for line in log.read_text().splitlines():
    record=json.loads(line);routes+=1
    protocol=record.get('timing_protocol','inline_gpu_events');protocol_counts[protocol]=protocol_counts.get(protocol,0)+1
    finite=[]
    for candidate in record['candidates']:
     if candidate['median_ms'] is None:continue
     samples=candidate['samples_ms'];contexts=candidate['cache_samples_ms']
     check(len(samples) in (5,9),'Unexpected tuner round count')
     check(all(len(values)==len(samples) for values in contexts.values()),'Missing tuner cache samples')
     for index,value in enumerate(samples):
      expected=math.exp(statistics.mean(math.log(max(values[index],1e-9)) for values in contexts.values()))
      check(abs(expected-value)<1e-10,'Tuner cache score differs')
     check(abs(statistics.median(samples)-candidate['median_ms'])<1e-10,'Tuner median differs')
     if not record.get('confirmed_candidates') or candidate['confirmed']:finite.append(candidate)
    selected=dict(record['selected_config']);selected.pop('num_stages',None)
    check(any(candidate['config']==selected for candidate in finite),'Selected config not eligible')
 counts[suite]=dict(cases=len(cases),timing_rows=len(rows))
tests=json.loads((h/'test_results.json').read_text());check(len(tests)==8 and all(value['passed'] for value in tests.values()),'Test failures')
for name,result in tests.items():
 log=(h/(name+'.log')).read_text();check(f"Ran {result['tests']} tests" in log and '\nOK' in log,'Test log mismatch')
model_fp=json.loads((h/'model_source_fingerprint.json').read_text())
for name,expected in model_fp['sources'].items():check(sha(Path(name))==expected,'Model source changed: '+name)
models=json.loads((h/'model_manifest.json').read_text())['models'];model_statuses={};model_results=[];pending=[]
allow_pending='--allow-pending-models' in sys.argv
for model in models:
 tag=f"{model['suite']}--{model['model']}--bs{model['batch_size']}".replace('/','_')
 for variant in ('regular','v15','v16'):
  path=h/'models_final'/tag/(variant+'.json')
  if not path.exists() or json.loads(path.read_text()).get('status')=='started':
   pending.append(str(path))
   check(allow_pending,'Model incomplete: '+str(path))
   continue
  data=json.loads(path.read_text())
  check(data['source_fingerprint']==model_fp,'Model fingerprint differs')
  check(data.get('checkpoint',data.get('benchmark_protocol',{}).get('checkpoint')) is False,'Checkpoint enabled')
  if data.get('milliseconds'):
   check(len(data['repeat_ms'])==7,'Model samples missing')
   check(abs(statistics.median(data['repeat_ms'])-data['milliseconds'])<1e-8,'Model median differs')
  model_statuses[data['status']]=model_statuses.get(data['status'],0)+1
  model_results.append(data)
svg_paths=list(h.glob('*.svg'))
for name in counts:svg_paths.extend((h/name).rglob('*.svg'))
for path in svg_paths:ET.parse(path)
subprocess.run(['git','diff','--check'],cwd=b,check=True)
full=subprocess.run(['git','diff','--binary'],cwd=b,check=True,capture_output=True).stdout
untracked=subprocess.run(['git','ls-files','--others','--exclude-standard'],cwd=b,check=True,capture_output=True,text=True).stdout.splitlines()
for name in untracked:
 result=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=b,capture_output=True);check(result.returncode in (0,1),'Patch failed: '+name);full+=result.stdout
(h/'branch_changes.patch').write_bytes(full)
old_root=h/'v15_source';names=set(untracked)|set(subprocess.run(['git','diff','--name-only'],cwd=b,check=True,capture_output=True,text=True).stdout.splitlines());delta=[]
for name in sorted(names):
 p=b/name
 if not p.is_file():continue
 old=(old_root/name).read_text() if (old_root/name).exists() else '';new=p.read_text()
 if old!=new:
  delta.append('diff --git a/'+name+' b/'+name+'\n')
  delta.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
(h/'v16_vs_v15.patch').write_text(''.join(delta))
subprocess.run(['git','apply','--check','--reverse',str(h/'v16_vs_v15.patch')],cwd=b,check=True)
validation=dict(status='operations_passed_models_pending' if pending else 'passed',pending_model_runs=len(pending),operation_suites=counts,operation_cases=160,operation_timing_rows=2560,variants_per_case=4,accuracy_seeds=[2026,1701,2027],rounds=15,repeats=5,tests_passed=sum(value['tests'] for value in tests.values()),tests=tests,models_requested=len(models),model_runs=len(model_results),model_statuses=model_statuses,tuner_records=routes,tuner_protocols=protocol_counts,svg_files_parsed=len(svg_paths),frozen_sources=len(fp['sources']),git_diff_check='passed',incremental_patch_reverse_check='passed',limits=['MI355X GPU validation only; other AMD wave32/wave64 devices have CPU structural coverage.','All optimization tiers default off; approximate math disabled in this comparison.','Direct measurements capture GPU kernel sequences; inline graph replay may include host launch gaps.','Long FP32 scans use absolute2e-4/relative1e-4 tolerance, with original/FP64 regression tests.','Representative 12-model training cohort, not the full original manifest; synthetic objective and SGD retained; no checkpoint.','Linter not run: spin would initialize missing lint tooling/regenerate sources.','Exploratory broad-policy trial and nested-graph probe excluded.'])
(h/'VALIDATION.json').write_text(json.dumps(validation,indent=2)+'\n');print(json.dumps(validation,indent=2))
