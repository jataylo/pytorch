# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/rt/crt4u5ekjafbqxr4qzlcfwuvrjx4i3hljbqyztvp4sdwfi6fus7w.py
# Topologically Sorted Source Nodes: [mul, mul_1, mul_2, add, mul_3, mul_4, square, mul_5, add_1, sqrt, add_2, truediv, sub, mul_6, mul_7, add_3, mul_8, square_1, mul_9, add_4], Original ATen: [aten.mul, aten.add, aten.pow, aten.sqrt, aten.div, aten.sub]
# Source node to ATen node mapping:
#   add => add
#   add_1 => add_1
#   add_2 => add_2
#   add_3 => add_3
#   add_4 => add_4
#   mul => mul
#   mul_1 => mul_1
#   mul_2 => mul_2
#   mul_3 => mul_3
#   mul_4 => mul_4
#   mul_5 => mul_5
#   mul_6 => mul_6
#   mul_7 => mul_7
#   mul_8 => mul_8
#   mul_9 => mul_9
#   sqrt => sqrt
#   square => pow_1
#   square_1 => pow_2
#   sub => sub
#   truediv => div
# Graph fragment:
#   %arg0_1 : Tensor "f32[4096, 128][128, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "f32[4096, 128][128, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[4096, 128][128, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg3_1 : Tensor "f32[4096, 128][128, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %mul : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg0_1, 0.9999), kwargs = {})
#   %mul_1 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, 0.9), kwargs = {})
#   %mul_2 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg2_1, 0.1), kwargs = {})
#   %add : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_1, %mul_2), kwargs = {})
#   %mul_3 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add, 0.001), kwargs = {})
#   %mul_4 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg3_1, 0.999), kwargs = {})
#   %pow_1 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%arg2_1, 2), kwargs = {})
#   %mul_5 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%pow_1, 0.001), kwargs = {})
#   %add_1 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %sqrt : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sqrt.default](args = (%add_1,), kwargs = {})
#   %add_2 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sqrt, 1e-08), kwargs = {})
#   %div : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%mul_3, %add_2), kwargs = {})
#   %sub : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%mul, %div), kwargs = {})
#   %mul_6 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, 0.9), kwargs = {})
#   %mul_7 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg2_1, 0.1), kwargs = {})
#   %add_3 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_6, %mul_7), kwargs = {})
#   %mul_8 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg3_1, 0.999), kwargs = {})
#   %pow_2 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%arg2_1, 2), kwargs = {})
#   %mul_9 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%pow_2, 0.001), kwargs = {})
#   %add_4 : Tensor "f32[4096, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_8, %mul_9), kwargs = {})
#   return %sub,%add_3,%add_4
triton_poi_fused_add_div_mul_pow_sqrt_sub_0 = async_compile.triton('triton_poi_fused_add_div_mul_pow_sqrt_sub_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_div_mul_pow_sqrt_sub_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 3, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 20971520}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_reduction_tuning': True, 'amd_kernel_autotune': True, 'amd_kernel_tuning_version': 4, 'amd_autotune_diagnostics_path': None, 'amd_warm_arg_names': ()},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_div_mul_pow_sqrt_sub_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, out_ptr1, out_ptr2, xnumel, XBLOCK : tl.constexpr):
    xnumel = 524288
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None)
    tmp3 = tl.load(in_ptr1 + (x0), None)
    tmp6 = tl.load(in_ptr2 + (x0), None)
    tmp12 = tl.load(in_ptr3 + (x0), None)
    tmp1 = tl.full([1], 0.9999, tl.float32)
    tmp2 = tmp0 * tmp1
    tmp4 = tl.full([1], 0.9, tl.float32)
    tmp5 = tmp3 * tmp4
    tmp7 = tl.full([1], 0.1, tl.float32)
    tmp8 = tmp6 * tmp7
    tmp9 = tmp5 + tmp8
    tmp10 = tl.full([1], 0.001, tl.float32)
    tmp11 = tmp9 * tmp10
    tmp13 = tl.full([1], 0.999, tl.float32)
    tmp14 = tmp12 * tmp13
    tmp15 = tmp6 * tmp6
    tmp16 = tmp15 * tmp10
    tmp17 = tmp14 + tmp16
    tmp18 = tl.sqrt_rn(tmp17)
    tmp19 = tl.full([1], 1e-08, tl.float32)
    tmp20 = tmp18 + tmp19
    tmp21 = (tmp11 / tmp20)
    tmp22 = tmp2 - tmp21
    tl.store(out_ptr0 + (x0), tmp22, None)
    tl.store(out_ptr1 + (x0), tmp9, None)
    tl.store(out_ptr2 + (x0), tmp17, None)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1, arg2_1, arg3_1), ((4096, 128), (4096, 128), (4096, 128), (4096, 128)), ((128, 1), (128, 1), (128, 1), (128, 1)), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg1_1 = copy_if_misaligned(arg1_1)
            arg2_1 = copy_if_misaligned(arg2_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            buf0 = empty_strided_cuda((4096, 128), (128, 1), torch.float32)
            buf1 = empty_strided_cuda((4096, 128), (128, 1), torch.float32)
            buf2 = empty_strided_cuda((4096, 128), (128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [mul, mul_1, mul_2, add, mul_3, mul_4, square, mul_5, add_1, sqrt, add_2, truediv, sub, mul_6, mul_7, add_3, mul_8, square_1, mul_9, add_4], Original ATen: [aten.mul, aten.add, aten.pow, aten.sqrt, aten.div, aten.sub]
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_add_div_mul_pow_sqrt_sub_0.run(arg0_1, arg1_1, arg2_1, arg3_1, buf0, buf1, buf2, 524288, stream=raw_stream0)
            del arg0_1
            del arg1_1
            del arg2_1
            del arg3_1
        return (buf0, buf1, buf2, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((4096, 128), (128, 1), device='cuda:0', dtype=torch.float32)
    arg1_1 = rand_strided((4096, 128), (128, 1), device='cuda:0', dtype=torch.float32)
    arg2_1 = rand_strided((4096, 128), (128, 1), device='cuda:0', dtype=torch.float32)
    arg3_1 = rand_strided((4096, 128), (128, 1), device='cuda:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1, arg3_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
