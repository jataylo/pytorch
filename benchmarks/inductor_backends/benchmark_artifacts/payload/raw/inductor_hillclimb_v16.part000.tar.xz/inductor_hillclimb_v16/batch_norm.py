# AOT ID: ['6_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/jt/cjt3jycavl4obiufv4r245egguutrwfalrzzfw53iqeg7jir6aw7.py
# Topologically Sorted Source Nodes: [native_batch_norm], Original ATen: [aten._native_batch_norm_legit]
# Source node to ATen node mapping:
#   native_batch_norm => add, mul, rsqrt, sub, var_mean
# Graph fragment:
#   %arg0_1 : Tensor "f32[8, 128, 32, 32][131072, 1024, 32, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %buf1 : Tensor "f32[1, 128, 1, 1][128, 1, 128, 128]cuda:0" = PlaceHolder[target=buf1]
#   %getitem_1 : Tensor "f32[1, 128, 1, 1][128, 1, 128, 128]cuda:0" = PlaceHolder[target=getitem_1]
#   %var_mean : [num_users=2] = call_function[target=torch.ops.aten.var_mean.correction](args = (%arg0_1, [0, 2, 3]), kwargs = {correction: 0, keepdim: True})
#   %sub : Tensor "f32[8, 128, 32, 32][131072, 1024, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%arg0_1, %getitem_1), kwargs = {})
#   %add : Tensor "f32[1, 128, 1, 1][128, 1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%getitem, 1e-05), kwargs = {})
#   %rsqrt : Tensor "f32[1, 128, 1, 1][128, 1, 1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[8, 128, 32, 32][131072, 1024, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %rsqrt), kwargs = {})
#   return %getitem_1,%buf1,%rsqrt,%mul
triton_per_fused__native_batch_norm_legit_0 = async_compile.triton('triton_per_fused__native_batch_norm_legit_0', '''
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()
from triton.experimental import gluon
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language.extra import libdevice

@gluon.jit
def _amd_maximum(a, b):
    return gl.where((a > b) | (a != a), a, b)

@gluon.jit
def _amd_max2(value, axis: gl.constexpr):
    return gl.reduce(value, axis, _amd_maximum)

@gluon.jit
def _amd_any(value, axis: gl.constexpr):
    return gl.sum((value != 0).to(gl.int32), axis) != 0

@gluon.jit
def _amd_reciprocal(value):
    return gl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[value], dtype=gl.float32, is_pure=True, pack=1)

@triton_heuristics.persistent_reduction(size_hints={'x': 128, 'r0_': 8192}, reduction_hint=ReductionHint.INNER, filename=__file__, triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'AMD_LANES': 'constexpr', 'AMD_VEC': 'constexpr', 'AMD_WARPS': 'constexpr', 'AMD_SPLIT_WARPS': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]}, inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__native_batch_norm_legit_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 3, 'num_reduction': 4, 'autotune_hints': set(), 'tiling_scores': {'x': 2048, 'r0_': 12582912}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_reduction_tuning': True, 'amd_kernel_autotune': True, 'amd_kernel_tuning_version': 4, 'amd_autotune_diagnostics_path': None, 'amd_warm_arg_names': (), 'use_gluon': True, 'amd_gluon_family': 'row_reduction', 'amd_reduction_extent': 8192, 'amd_row_count': 128, 'amd_approximate_math': False, 'amd_cache_policy': 'balanced'})
@gluon.jit
def triton_per_fused__native_batch_norm_legit_0(in_ptr0, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK: tl.constexpr, AMD_LANES: gl.constexpr, AMD_VEC: gl.constexpr, AMD_WARPS: gl.constexpr, AMD_SPLIT_WARPS: gl.constexpr):
    _amd_layout: gl.constexpr = gl.BlockedLayout([1, AMD_VEC], [64 // AMD_LANES, AMD_LANES], [1, AMD_WARPS] if AMD_SPLIT_WARPS else [AMD_WARPS, 1], [1, 0])
    xnumel = 128
    r0_numel = 8192
    R0_BLOCK: gl.constexpr = 8192
    rnumel = r0_numel
    RBLOCK: gl.constexpr = R0_BLOCK
    xoffset = gl.program_id(0) * XBLOCK
    xindex = xoffset + gl.arange(0, XBLOCK, layout=gl.SliceLayout(1, _amd_layout))[:, None]
    xmask = xindex < xnumel
    r0_index = gl.arange(0, R0_BLOCK, layout=gl.SliceLayout(0, _amd_layout))[None, :]
    r0_offset = 0
    r0_mask = gl.full([R0_BLOCK], True, gl.int1, layout=gl.SliceLayout(0, _amd_layout))[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index % 1024
    r0_2 = r0_index // 1024
    x0 = xindex
    tmp0 = gl.load(in_ptr0 + (r0_1 + 1024 * x0 + 131072 * r0_2), xmask, eviction_policy='evict_first', other=0.0)
    tmp1 = gl.broadcast(tmp0, gl.full([XBLOCK, R0_BLOCK], 0, tmp0.dtype, layout=_amd_layout))[0]
    tmp3 = gl.where(xmask, tmp1, 0)
    tmp4 = gl.broadcast(tmp1, gl.full([XBLOCK, R0_BLOCK], 0, tmp1.dtype, layout=_amd_layout))[0]
    tmp6 = gl.where(xmask, tmp4, 0)
    tmp7 = gl.sum(tmp6, 1)[:, None].to(gl.float32)
    tmp8 = gl.full([1, 1], 8192, gl.int32, layout=_amd_layout).to(gl.float32)
    tmp9 = tmp7 / tmp8
    tmp10 = tmp1 - tmp9
    tmp11 = tmp10 * tmp10
    tmp12 = gl.broadcast(tmp11, gl.full([XBLOCK, R0_BLOCK], 0, tmp11.dtype, layout=_amd_layout))[0]
    tmp14 = gl.where(xmask, tmp12, 0)
    tmp15 = gl.sum(tmp14, 1)[:, None].to(gl.float32)
    tmp16 = gl.full([1, 1], 8192.0, gl.float32, layout=_amd_layout)
    tmp17 = tmp15 / tmp16
    tmp18 = gl.full([1, 1], 1e-05, gl.float32, layout=_amd_layout)
    tmp19 = tmp17 + tmp18
    tmp20 = gl.rsqrt(tmp19)
    tmp21 = tmp0 - tmp9
    tmp22 = tmp21 * tmp20
    gl.store(out_ptr2 + x0, tmp20, xmask)
    gl.store(out_ptr3 + (r0_1 + 1024 * x0 + 131072 * r0_2), tmp22, xmask)
    gl.store(out_ptr0 + x0, tmp9, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, = args
        args.clear()
        assert_size_stride(arg0_1, (8, 128, 32, 32), (131072, 1024, 32, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf0 = empty_strided_cuda((1, 128, 1, 1), (128, 1, 128, 128), torch.float32)
            buf4 = empty_strided_cuda((1, 128, 1, 1), (128, 1, 128, 128), torch.float32)
            buf3 = empty_strided_cuda((8, 128, 32, 32), (131072, 1024, 32, 1), torch.float32)
            # Topologically Sorted Source Nodes: [native_batch_norm], Original ATen: [aten._native_batch_norm_legit]
            raw_stream0 = get_raw_stream(0)
            triton_per_fused__native_batch_norm_legit_0.run(arg0_1, buf0, buf4, buf3, 128, 8192, stream=raw_stream0)
            del arg0_1
        return (buf3, reinterpret_tensor(buf0, (128, ), (1, ), 0), reinterpret_tensor(buf4, (128, ), (1, ), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((8, 128, 32, 32), (131072, 1024, 32, 1), device='cuda:0', dtype=torch.float32)
    return [arg0_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
