import importlib.abc
import importlib.util
import os
import sys
from pathlib import Path

root = os.environ.get('AMD_CODEGEN_SOURCE_ROOT')
if root:
    names = {'torch._inductor.config', 'torch._inductor.scheduler', 'torch._inductor.codegen.simd', 'torch._inductor.codegen.triton', 'torch._inductor.runtime.triton_heuristics', 'torch._inductor.runtime.hints','torch._inductor.runtime.amd_autotune', 'torch._inductor.codegen.amd_kernel_optimizations'}
    class CodegenFinder(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname in names or fullname.startswith('torch._inductor.codegen.flydsl.'):
                source = Path(root) / (fullname.replace('.', '/') + '.py')
                if source.exists():
                    return importlib.util.spec_from_file_location(fullname, source)
    sys.meta_path.insert(0, CodegenFinder())
