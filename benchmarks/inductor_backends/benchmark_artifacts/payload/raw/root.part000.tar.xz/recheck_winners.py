import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
while True:
    try:
        os.kill(3725559, 0)
    except ProcessLookupError:
        break
    time.sleep(5)
for repeat in [1, 2]:
    for model in ['twins_pcpvt_base', 'ese_vovnet19b_dw']:
        print(json.dumps({'repeat': repeat, 'model': model, 'gpu': '6'}), flush=True)
        subprocess.run([sys.executable, str(ROOT / 'run_suite.py'), '--results', f'outlier_recheck_{repeat}',
                        '--models', model, '--gpus', '6', '--autotune-modes', '0'], cwd=ROOT, check=True)
rows = json.loads((ROOT / 'training_results/outlier_rechecks.json').read_text())
for model in ['twins_pcpvt_base', 'ese_vovnet19b_dw']:
    for backend in ['triton', 'flydsl']:
        sources = []
        for directory in ['training_results', 'outlier_recheck_1', 'outlier_recheck_2']:
            for path in (ROOT / directory / 'raw').glob(f'*/{backend}_autotune0.json'):
                record = json.loads(path.read_text())
                if record['model'] == model:
                    sources.append({'source': str(path.relative_to(ROOT)), 'status': record['status'],
                                    'milliseconds': record.get('milliseconds'), 'physical_gpu': record.get('physical_gpu')})
        rows.append({'model': model, 'backend': backend, 'autotune': 0, 'runs': sources})
(ROOT / 'training_results/outlier_rechecks.json').write_text(json.dumps(rows, indent=2) + '\n')
print('Positive-outlier rechecks complete; primary results preserved unchanged.', flush=True)
