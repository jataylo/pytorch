import csv
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'training_results_mixed_single_v5'
MANIFEST = 'model_manifest_mixed_single_v5.json'
FINGERPRINT = 'source_fingerprint_mixed_single_v5.json'
RESULTS.mkdir(exist_ok=True)


def state(phase, **details):
    record = dict(phase=phase, timestamp=time.time(), **details)
    (RESULTS / 'pipeline.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


def run(script, *arguments):
    state('running', script=script)
    subprocess.run([sys.executable, str(ROOT / script), *arguments], cwd=ROOT, check=True)


def verify_sources():
    fingerprint = json.loads((ROOT / FINGERPRINT).read_text())
    for group, base in [('sources', Path(fingerprint['source_root'])), ('harness', ROOT)]:
        for name, expected in fingerprint[group].items():
            if hashlib.sha256((base / name).read_bytes()).hexdigest() != expected:
                raise RuntimeError(f'Source drift: {base / name}')


# The original controller is frozen in the benchmark fingerprint. Preserve it
# and resume only its known report precondition failure after all workers exit.
while True:
    pipeline = json.loads((RESULTS / 'pipeline.json').read_text())
    if pipeline['phase'] == 'measurements_complete_manual_review_required':
        raise SystemExit(0)
    if pipeline['phase'] == 'needs_review':
        if 'build_common_comparison_mixed_single_v5.py' not in pipeline.get('error', ''):
            raise RuntimeError(f'Unexpected pipeline failure: {pipeline}')
        (RESULTS / 'initial_postprocessing_failure.json').write_text(json.dumps(pipeline, indent=2) + '\n')
        break
    time.sleep(5)

try:
    verify_sources()
    state('resuming_postprocessing_after_completion_marker_order_fix')
    verify_sources()
    records = [json.loads(path.read_text()) for path in (RESULTS / 'raw').glob('*/*.json')]
    expected = len(json.loads((ROOT / MANIFEST).read_text())['models']) * 4
    if len(records) != expected or any(record['status'] == 'started' for record in records):
        raise RuntimeError('Incomplete matrix')
    for record in records:
        if str(record['physical_gpu']) != '0' or record.get('world_size', 1) != 1 or record.get('fsdp'):
            raise RuntimeError('Single GPU policy violated')
        config = record.get('inductor_config')
        if config and config['flydsl.simd_autotune_backend'] != (record['backend'] == 'flydsl'):
            raise RuntimeError('Wrong selector setting')
    run('final_audit_v2.py', '--results', RESULTS.name, '--fingerprint', FINGERPRINT)
    audit = json.loads((RESULTS / 'final_audit.json').read_text())
    for key in ['source_drift', 'external_source_drift', 'optional_dependency_drift', 'input_metadata_mismatches',
                'unexpected_triton_matrix_templates', 'codegen_collection_errors', 'checkpoint_files']:
        if audit[key]:
            raise RuntimeError(f'Audit failed: {key}')
    run('analyze_mixed_single_v5.py', '--results', RESULTS.name, '--manifest', MANIFEST)
    summary = json.loads((RESULTS / 'summary.json').read_text())
    if summary['timing_overlaps'] or summary['aten_policy_errors'] or summary['malformed_diagnostics']:
        raise RuntimeError('Timing/configuration/diagnostic audit failed')
    run('merge_mixed_single_v5.py', '--results', RESULTS.name, '--steady', 'training_results_mixed_single_v5_no_rechecks',
        '--manifest', MANIFEST, '--support-sweep')
    (RESULTS / 'COMPLETE.json').write_text(json.dumps(summary, indent=2) + '\n')
    run('build_common_comparison_mixed_single_v5.py')
    selections = []
    categories = Counter()
    with (RESULTS / 'all_kernel_decisions.jsonl').open() as source:
        for line in source:
            event = json.loads(line)
            if event.get('category') in {'backend_selection', 'selection_skipped', 'backend_candidates'}:
                selections.append(event)
                categories[event['category'], event.get('selected_backend', event.get('reason', 'eligible'))] += 1
    (RESULTS / 'backend_selection_events.jsonl').write_text(''.join(json.dumps(event) + '\n' for event in selections))
    fields = ['model', 'suite', 'autotune', 'phase', 'category', 'kernel_name', 'stage', 'selected_backend', 'reason',
              'candidate_times_ms', 'selected_candidate', 'cache_hit']
    with (RESULTS / 'backend_selection_events.csv').open('w') as output:
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for event in selections:
            writer.writerow(event)
    (RESULTS / 'backend_selection_summary.json').write_text(json.dumps([
        dict(category=key[0], outcome=key[1], count=count) for key, count in categories.items()], indent=2) + '\n')
    run('collect_fallback_worklist_v2.py', '--results', RESULTS.name)
    run('collect_kernel_inventory_v3.py', '--results', str(RESULTS), '--output', str(RESULTS / 'kernel_inventory'))
    verify_sources()
    (RESULTS / 'COMPLETE.json').write_text(json.dumps(summary, indent=2) + '\n')
    state('measurements_complete_manual_review_required', results=str(RESULTS), runs=len(records),
          backend_selection_events=len(selections))
except Exception as error:
    state('needs_review', error=f'{type(error).__name__}: {error}')
    raise
