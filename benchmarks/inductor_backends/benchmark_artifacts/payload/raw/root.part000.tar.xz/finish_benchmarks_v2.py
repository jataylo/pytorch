import json
import os
from pathlib import Path
import subprocess
import sys
import time


root = Path(__file__).resolve().parent
controller = int(sys.argv[1])
while not (root / 'training_results_v2/COMPLETE.json').exists():
    try:
        os.kill(controller, 0)
    except ProcessLookupError:
        raise RuntimeError('Primary controller exited without a successful completion marker') from None
    time.sleep(5)

steps = [
    ['final_audit_v2.py'],
    ['prepare_steady_v2.py'],
    ['run_steady_v2.py'],
    ['final_audit_v2.py', '--results', 'training_results_v2_steady',
     '--fingerprint', 'source_fingerprint_v2_steady.json'],
    ['merge_steady_v2.py'],
]
for step in steps:
    print(json.dumps({'step': step, 'started': time.time()}), flush=True)
    subprocess.run([sys.executable, str(root / step[0]), *step[1:]], cwd=root, check=True)
print('Post-run audits and steady-state rechecks finished; final human-readable review remains.', flush=True)
