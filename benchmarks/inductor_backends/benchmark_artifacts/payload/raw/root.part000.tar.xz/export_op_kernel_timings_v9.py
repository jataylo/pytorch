import csv
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DIRECTORY = ROOT / 'kernel_routes_v9'
ALIASES = {
    '_safe_softmax': 'softmax', '_softmax': 'softmax',
    '_softmax_backward_data': 'softmax_backward',
    'native_dropout': 'dropout', 'native_dropout_backward': 'dropout_backward',
    'native_layer_norm': 'layer_norm', 'native_layer_norm_backward': 'layer_norm_backward',
    '_native_batch_norm_legit_functional': 'batch_norm',
    'native_batch_norm_backward': 'batch_norm_backward', '_to_copy': 'cast/copy',
}
FIELDS = ['op', 'model', 'kernel_name', 'triton_speed_us', 'flydsl_speed_us', 'flydsl_speedup_percent',
          'tuning', 'stage', 'dtypes', 'shape_summary', 'selected_backend', 'decision_source',
          'timing_status', 'model_status', 'validation_tier', 'world_size', 'gpu_group',
          'is_backward', 'aten_origins', 'diagnostic_file', 'selection_line']


def export(directory=DIRECTORY):
    with (directory / 'per_kernel_routes.csv').open() as source:
        inputs = list(csv.DictReader(source))
    rows, measured = [], []
    for item in inputs:
        labels = []
        for op in item['ops'].split(';'):
            if not op:
                continue
            name = op.removeprefix('aten.')
            label = ALIASES.get(name, name)
            if label not in labels:
                labels.append(label)
        row = {key: item.get(key, '') for key in FIELDS}
        row.update(op='+'.join(labels) or 'unknown_origin',
                   triton_speed_us=item['triton_us'], flydsl_speed_us=item['flydsl_us'],
                   flydsl_speedup_percent=item['flydsl_speedup_percent'],
                   timing_status='measured' if item['triton_us'] and item['flydsl_us'] else item['timing_reason'],
                   aten_origins=item['ops'])
        if row['timing_status'] == 'measured':
            tri, fly = float(row['triton_speed_us']), float(row['flydsl_speed_us'])
            if not (math.isfinite(tri) and math.isfinite(fly) and tri > 0 and fly > 0):
                raise ValueError('Invalid measured timing')
            if not math.isclose(float(row['flydsl_speedup_percent']), 100*(tri-fly)/tri, abs_tol=1e-7):
                raise ValueError('Speedup formula mismatch')
            if item['completed_training'] == 'True' and item['decision_source'] == 'performance_selection':
                measured.append(row)
        rows.append(row)
    for name, selected in [('op_kernel_timings.csv', rows), ('op_kernel_timings_measured.csv', measured)]:
        selected.sort(key=lambda row: (row['op'], row['model'], row['tuning'], row['kernel_name']))
        with (directory / name).open('w', newline='') as output:
            writer = csv.DictWriter(output, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(selected)
    (directory / 'OP_TIMINGS_README.txt').write_text(
        'triton_speed_us and flydsl_speed_us are recorded kernel latency in microseconds, lower is better. '
        'flydsl_speedup_percent=100*(triton-flydsl)/triton; positive favors FlyDSL. '
        'op joins original fused ATen origin labels with + and normalizes common names; it does not specify execution order. '
        'GEMM/conv origins can be ancestry: those operations remain native ATen, not FlyDSL GEMM/conv benchmarks. '
        'op_kernel_timings.csv retains all contexts, including cached/skipped/unexecuted/failed cases with missing times blank. '
        'op_kernel_timings_measured.csv contains only actual two-backend timings from completed successful training, including separately marked training-only validation. '
        'Rows distinguish model, tuning, GPU placement and kernel name. Counts are rank0 unique-name training contexts, not runtime invocations. '
        'Cached choices omit timings, so the measured subset is not representative of overall win rates.\n')
    return dict(all_rows=len(rows), measured_successful_training_rows=len(measured), directory=str(directory))


if __name__ == '__main__':
    print(json.dumps(export(), indent=2))
