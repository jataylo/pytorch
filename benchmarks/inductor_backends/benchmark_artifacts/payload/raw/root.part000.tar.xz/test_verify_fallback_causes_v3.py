import ast
from pathlib import Path
import re

from torch.testing._internal.common_utils import parametrize, run_tests, TestCase
from torch.testing._internal.common_utils import instantiate_parametrized_tests


root = Path(__file__).resolve().parent
tree = ast.parse((root / 'verify_fallback_validation_v3.py').read_text())
nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
namespace = {'re': re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(root / 'verify_fallback_validation_v3.py'), 'exec'), namespace)
baseline = (root / 'test_flydsl_genuine_original.log').read_text()
namespace['baseline_causes'] = namespace['error_excerpts'](baseline)
assignment = next(node for node in tree.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'allowed_causes' for target in node.targets))
exec(compile(ast.Module(body=[assignment], type_ignores=[]), '<allowed_causes>', 'exec'), namespace)
allowed = namespace['allowed_causes']


@instantiate_parametrized_tests
class TestFallbackCauseGate(TestCase):
    def test_original_inventory(self):
        self.assertEqual(len(namespace['baseline_causes']), 8)
        self.assertEqual(len(allowed), 5)

    @parametrize('case', ['five_fnuz', 'one_fnuz', 'no_errors', 'old_eight', 'changed_bitcast',
                         'changed_scan', 'numeric_failure', 'extra_exception', 'wrong_returncode', 'new_name'])
    def test_broad_gate(self, case):
        errors = dict(allowed)
        returncode = 1
        accepted = case in {'five_fnuz', 'one_fnuz', 'no_errors'}
        if case == 'one_fnuz':
            errors = {next(iter(allowed)): next(iter(allowed.values()))}
        elif case == 'no_errors':
            errors, returncode = {}, 0
        elif case == 'old_eight':
            errors = namespace['baseline_causes']
        elif case == 'changed_bitcast':
            name = next(name for name in allowed if name.startswith('test_bitcast '))
            errors = {name: ['RuntimeError: unsupported bitcast']}
        elif case == 'changed_scan':
            name = next(name for name in namespace['baseline_causes'] if name.startswith('test_tuple_scans '))
            errors = {name: ['RuntimeError: unsupported tuple scan']}
        elif case == 'numeric_failure':
            errors = {'numeric': ['AssertionError: tensor mismatch']}
        elif case == 'extra_exception':
            name = next(iter(allowed))
            errors = {name: [*allowed[name], 'RuntimeError: secondary failure']}
        elif case == 'wrong_returncode':
            returncode = 0
        elif case == 'new_name':
            errors = {'test_new': ['RuntimeError: new failure']}
        prefix = 'FAIL' if case == 'numeric_failure' else 'ERROR'
        log = ''.join(f'{prefix}: {name}\n' + '\n'.join(causes) + '\n' for name, causes in errors.items())
        if accepted:
            namespace['check_broad_failures'](log, returncode, allowed)
        else:
            with self.assertRaises(RuntimeError):
                namespace['check_broad_failures'](log, returncode, allowed)


if __name__ == '__main__':
    run_tests()
