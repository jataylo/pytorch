from collections.abc import Iterator

import torch


QWEN_ROPE_MODULE = "diffusers.models.transformers.transformer_qwenimage"
QWEN_ROPE_CLASSES = {"QwenEmbedRope", "QwenEmbedLayer3DRope"}


def _plain_meta_tensors(value, path: str, seen: set[int]) -> Iterator[tuple[str, torch.Tensor]]:
    if isinstance(value, torch.Tensor):
        if value.is_meta:
            yield path, value
        return
    if not isinstance(value, (dict, list, tuple)) or id(value) in seen:
        return
    seen.add(id(value))
    items = value.items() if isinstance(value, dict) else enumerate(value)
    for key, child in items:
        yield from _plain_meta_tensors(child, f"{path}[{key!r}]", seen)


def restore_diffusion_meta_constants(model: torch.nn.Module) -> list[dict]:
    """Restore known deterministic constants before FSDP and the first forward."""
    restored = []
    for path, module in model.named_modules():
        kind = type(module)
        if kind.__module__ != QWEN_ROPE_MODULE or kind.__name__ not in QWEN_ROPE_CLASSES:
            continue
        with torch.device("cpu"):
            reference = kind(theta=module.theta, axes_dim=list(module.axes_dim), scale_rope=module.scale_rope)
        for attribute in ("pos_freqs", "neg_freqs"):
            old, value = getattr(module, attribute), getattr(reference, attribute)
            name = f"{path}.{attribute}" if path else attribute
            if old.shape != value.shape or old.dtype != value.dtype:
                raise RuntimeError(
                    f"Refusing to regenerate {name}: constructor produced {tuple(value.shape)}/{value.dtype}, "
                    f"expected {tuple(old.shape)}/{old.dtype}"
                )
            setattr(module, attribute, value)
            restored.append({
                "attribute": name, "class": kind.__name__, "was_meta": old.is_meta,
                "shape": list(value.shape), "dtype": str(value.dtype), "device": str(value.device),
                "theta": module.theta, "axes_dim": list(module.axes_dim), "scale_rope": module.scale_rope,
            })
    unknown = []
    for path, module in model.named_modules():
        seen = set()
        for attribute, value in vars(module).items():
            if attribute in {"_parameters", "_buffers", "_modules"}:
                continue
            name = f"{path}.{attribute}" if path else attribute
            for name, tensor in _plain_meta_tensors(value, name, seen):
                unknown.append(f"{name}: shape={tuple(tensor.shape)}, dtype={tensor.dtype}")
    if unknown:
        raise RuntimeError(
            "Unregistered meta tensor state remains before FSDP: " + "; ".join(unknown)
            + ". Add a deterministic constructor-based recovery; empty tensors cannot restore these constants."
        )
    return restored
