import argparse
import functools
import hashlib
import json
import os
from pathlib import Path
import sys
import time

if 'torch' in sys.modules:
    raise RuntimeError('Launch this probe directly so rank-local caches are configured before importing Torch')
cache_root = os.environ.get('TORCHINDUCTOR_CACHE_DIR')
if not cache_root:
    raise RuntimeError('Set a fresh TORCHINDUCTOR_CACHE_DIR base before launching this probe')
cache_rank = os.environ['RANK']
os.environ['TORCHINDUCTOR_CACHE_DIR'] = str(Path(cache_root) / f'rank{cache_rank}')
for cache_variable, directory in [('TRITON_CACHE_DIR', 'triton'), ('FLYDSL_RUNTIME_CACHE_DIR', 'flydsl')]:
    base = os.environ.get(cache_variable, str(Path(cache_root).parent / directory))
    os.environ[cache_variable] = str(Path(base) / f'rank{cache_rank}')

import torch
import torch.distributed as dist
from torch._dynamo.utils import counters
from torch._inductor import config
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP, MixedPrecision
from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy

from fsdp_state_init_v3 import initialize_fsdp_state_for_compile


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class StateInitToyModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.output_bias = torch.nn.Parameter(torch.zeros(64))
        self.layers = torch.nn.Sequential(torch.nn.Linear(128, 256), torch.nn.ReLU(), torch.nn.Linear(256, 64))

    def forward(self, x):
        output = self.layers(x)
        return output + self.output_bias.to(output.dtype)


def make_model():
    return StateInitToyModel()


def canonical(name):
    return name.replace('_fsdp_wrapped_module.', '')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    rank = int(os.environ['RANK'])
    local_rank = int(os.environ['LOCAL_RANK'])
    torch.cuda.set_device(local_rank)
    dist.init_process_group('nccl')
    if dist.get_world_size() != 2:
        raise RuntimeError('This correctness probe requires exactly two GPUs')
    if not torch.version.hip:
        raise RuntimeError('This probe requires the actual ROCm FlyDSL runtime')
    from torch._inductor.fx_passes.joint_graph import lazy_init
    lazy_init(torch.device('cuda', local_rank))
    torch.cuda.synchronize()
    dist.barrier()
    from torch._inductor import scheduler
    from torch._inductor.codegen import simd
    from torch._inductor.codegen.flydsl import flydsl_simd, flydsl_simd_runtime
    overlay = os.environ.get('BENCHMARK_SUPPORT_SOURCE_ROOT')
    if overlay and Path(simd.__file__).resolve() != (Path(overlay) / 'torch/_inductor/codegen/simd.py').resolve():
        raise RuntimeError(f'Wrong shared SIMD source in initialization probe: {simd.__file__}')
    source_files = [__file__, str(Path(__file__).with_name('fsdp_state_init_v3.py')),
                    scheduler.__file__, simd.__file__, flydsl_simd.__file__, flydsl_simd_runtime.__file__,
                    str(Path(torch.__file__).parent / 'distributed/fsdp/_runtime_utils.py'),
                    str(Path(torch.__file__).parent / 'distributed/fsdp/fully_sharded_data_parallel.py')]
    source_hashes = {str(Path(path).resolve()): digest(path) for path in source_files}
    results = []
    with config.patch({'max_autotune': False, 'max_autotune_gemm': False,
                       'max_autotune_pointwise': False, 'triton.autotune_pointwise': False,
                       'conv_1x1_as_mm': False,
                       'max_autotune_gemm_backends': 'ATEN', 'max_autotune_conv_backends': 'ATEN',
                       'triton.cudagraphs': False, 'fx_graph_cache': False,
                       'flydsl.simd_strict': True, 'flydsl.simd_autotune_backend': False,
                       'flydsl.simd_autotune_min_numel': 0}):
        for backend in ['triton', 'flydsl']:
            for tune in [0, 1]:
                torch.manual_seed(2026)
                reference = make_model().cuda()
                if rank == 0:
                    torch.manual_seed(2026)
                    raw = make_model()
                else:
                    with torch.device('meta'):
                        raw = make_model()
                model = FSDP(raw, device_id=local_rank, use_orig_params=True, sync_module_states=True,
                             param_init_fn=lambda module: module.to_empty(device=torch.device('cuda', local_rank), recurse=False),
                             auto_wrap_policy=functools.partial(transformer_auto_wrap_policy, transformer_layer_cls={torch.nn.Linear}),
                             mixed_precision=MixedPrecision(param_dtype=torch.bfloat16, reduce_dtype=torch.float32))
                reference_optimizer = torch.optim.SGD(reference.parameters(), lr=0.01)
                optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
                generator = torch.Generator(device='cuda').manual_seed(2048 + rank)
                x = torch.randn((32, 128), device='cuda', generator=generator)
                with torch.autocast('cuda', dtype=torch.bfloat16):
                    reference_loss = reference(x).float().square().mean()
                reference_loss.backward()
                for parameter in reference.parameters():
                    dist.all_reduce(parameter.grad)
                    parameter.grad.div_(dist.get_world_size())
                expected_gradients = {name: parameter.grad.detach().clone() for name, parameter in reference.named_parameters()}
                forward_calls = []
                hook = model.register_forward_pre_hook(lambda *unused: forward_calls.append('forward'))
                initialization = initialize_fsdp_state_for_compile(model)
                if forward_calls:
                    raise RuntimeError('State initialization executed the model')
                config.flydsl.simd = backend == 'flydsl'
                config.max_autotune_pointwise = bool(tune)
                config.triton.autotune_pointwise = bool(tune)
                os.environ['TORCHINDUCTOR_FLYDSL_SIMD_TUNE'] = f'autotune={tune}'
                flydsl_simd._tune_table.cache_clear()
                effective_tuning = flydsl_simd._tune_table().get('autotune')
                if effective_tuning != tune:
                    raise RuntimeError(f'Wrong effective Fly tuning: {effective_tuning}')
                torch._dynamo.reset()
                counters.clear()

                def loss():
                    with torch.autocast('cuda', dtype=torch.bfloat16):
                        return model(x).float().square().mean()

                compiled = torch.compile(loss, backend='inductor')
                actual_loss = compiled()
                actual_loss.backward()
                torch.cuda.synchronize()
                hook.remove()
                if len(forward_calls) != 1:
                    raise RuntimeError(f'Expected one first compiled FSDP forward, observed {len(forward_calls)}')
                torch.testing.assert_close(actual_loss, reference_loss, atol=0.003, rtol=0.03)
                with FSDP.summon_full_params(model, writeback=False, with_grads=True):
                    gradients = {canonical(name): parameter.grad for name, parameter in model.named_parameters()}
                    if gradients.keys() != expected_gradients.keys():
                        raise RuntimeError('Incomplete parameter-gradient coverage')
                    for name, expected in expected_gradients.items():
                        if gradients[name] is None:
                            raise RuntimeError(f'Missing compiled gradient: {name}')
                        torch.testing.assert_close(gradients[name], expected, atol=0.005, rtol=0.05)
                optimizer.step()
                reference_optimizer.step()
                with FSDP.summon_full_params(model, writeback=False):
                    parameters = {canonical(name): parameter for name, parameter in model.named_parameters()}
                    for name, expected in reference.named_parameters():
                        torch.testing.assert_close(parameters[name], expected, atol=5e-5, rtol=5e-4)
                fly_counts = dict(counters['flydsl_simd'])
                if backend == 'flydsl' and (fly_counts.get('flydsl_kernels', 0) <= 0 or fly_counts.get('triton_kernels', 0)):
                    raise RuntimeError(f'FlyDSL path not completely exercised: {fly_counts}')
                if backend == 'flydsl' and tune and fly_counts.get('autotuned_kernels', 0) <= 0:
                    raise RuntimeError(f'FlyDSL autotuning was not exercised: {fly_counts}')
                results.append({'backend': backend, 'autotune': tune, 'effective_flydsl_tuning': effective_tuning,
                                'max_autotune_pointwise': config.max_autotune_pointwise,
                                'triton_autotune_pointwise': config.triton.autotune_pointwise,
                                'initialization': initialization, 'first_fsdp_forward_compiled': True,
                                'prior_eager_fsdp_forward_backward': False, 'loss': actual_loss.detach().item(),
                                'full_gradient_parameter_tensors': len(expected_gradients),
                                'full_optimizer_update_checked': True, 'flydsl_counters': fly_counts})
                optimizer.zero_grad(set_to_none=True)
                dist.barrier()
                del compiled, actual_loss, reference_loss, model, raw, optimizer, reference, reference_optimizer
                torch._dynamo.reset()
                torch.cuda.empty_cache()
    for path, expected in source_hashes.items():
        if digest(path) != expected:
            raise RuntimeError(f'Source changed during the probe: {path}')
    output = args.output.with_name(args.output.stem + f'.rank{rank}.json')
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = {'status': 'passed', 'rank': rank, 'world_size': 2, 'completed': time.time(),
               'variants': results, 'source_hashes': source_hashes,
               'cache_directories': {name: os.environ[name] for name in
                                     ['TORCHINDUCTOR_CACHE_DIR', 'TRITON_CACHE_DIR', 'FLYDSL_RUNTIME_CACHE_DIR']},
               'protocol': 'Correctness only; no performance measurements',
               'config': {'master_dtype': 'float32', 'param_dtype': 'bfloat16', 'reduce_dtype': 'float32',
                          'max_autotune_gemm_backends': 'ATEN', 'max_autotune_conv_backends': 'ATEN',
                          'max_autotune': False, 'max_autotune_gemm': False, 'cudagraphs': False,
                          'conv_1x1_as_mm': False, 'pointwise_tuning_matches_each_variant': True,
                          'fx_graph_cache': False, 'simd_strict': True, 'simd_autotune_backend': False,
                          'simd_autotune_min_numel': 0, 'joint_graph_lazy_init_prewarm': True,
                          'use_orig_params': True, 'seed': 2026, 'input_seed_base': 2048,
                          'batch_size_per_rank': 32, 'optimizer': 'SGD', 'learning_rate': 0.01}}
    payload['config_sha256'] = hashlib.sha256(json.dumps(payload['config'], sort_keys=True).encode()).hexdigest()
    output.write_text(json.dumps(payload, indent=2) + '\n')
    rank_results = [None] * dist.get_world_size()
    dist.all_gather_object(rank_results, payload)
    if rank == 0:
        expected_variants = {(backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]}
        for item in rank_results:
            if item['status'] != 'passed' or {(entry['backend'], entry['autotune']) for entry in item['variants']} != expected_variants:
                raise RuntimeError('Incomplete backend/tuning correctness coverage')
            if item['source_hashes'] != source_hashes or item['config_sha256'] != payload['config_sha256']:
                raise RuntimeError('Inconsistent rank sources or configuration')
        args.output.write_text(json.dumps({**payload, 'ranks': rank_results}, indent=2) + '\n')
        print(json.dumps({'status': 'passed', 'variants': len(results), 'world_size': 2}), flush=True)
    dist.destroy_process_group()


if __name__ == '__main__':
    main()
