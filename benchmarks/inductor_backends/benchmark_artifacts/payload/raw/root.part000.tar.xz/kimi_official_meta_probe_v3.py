"""CPU-only probe of official Kimi loaders with isolated optional dependencies."""
import argparse
import hashlib
import json
import resource
import sys
import types
from pathlib import Path
from unittest.mock import patch

resource.setrlimit(resource.RLIMIT_AS, (64 << 30, 64 << 30))

import torch
import triton

ROOT = Path(__file__).resolve().parent


def unavailable():
    raise RuntimeError('CPU-only probe prohibits GPU target discovery')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('model')
    args = parser.parse_args()
    sys.path.insert(0, str(ROOT / 'optional_model_deps_v3'))
    sys.path.insert(0, '/dockerx/Triton_Conv_Development/scripts')
    # Avoid FLA's import-time device discovery; do not replace model operations.
    with patch.object(triton.runtime.driver, '_active', types.SimpleNamespace(get_current_target=unavailable)), patch.object(
        torch.cuda, '_lazy_init', side_effect=RuntimeError('GPU initialization prohibited')
    ):
        import fla
        from fla.modules import FusedRMSNormGated, ShortConvolution
        from fla.ops.kda import chunk_kda, fused_recurrent_kda
        from fla.ops.utils.index import prepare_cu_seqlens_from_mask, prepare_lens_from_mask
        from fla.utils import tensor_cache
        from common import build_model_from_config

        result = {'model': args.model, 'fla_version': fla.__version__, 'fla_file': fla.__file__}
        with torch.device('meta'):
            model = build_model_from_config(args.model, torch.bfloat16)
        result.update(
            model_class=f'{type(model).__module__}.{type(model).__name__}',
            parameters=sum(p.numel() for p in model.parameters()),
            all_parameters_meta=all(p.is_meta for p in model.parameters()),
            buffers=sum(b.numel() for b in model.buffers()),
            cuda_initialized=torch.cuda.is_initialized(),
            source_sha256=hashlib.sha256(Path(sys.modules[type(model).__module__].__file__).read_bytes()).hexdigest(),
        )
        if not result['all_parameters_meta'] or result['cuda_initialized']:
            raise RuntimeError(f'CPU/meta-only invariant violated: {result}')
        print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
