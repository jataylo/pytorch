import json
from pathlib import Path
import subprocess
import sys
import time


root = Path(__file__).resolve().parent
started = time.time()
steps = [
    ['run_suite_v2.py', '--gpus', '0,1,2,3,4,5,6,7', '--timeout', '3600'],
    ['run_fsdp_v2.py'],
    ['analyze_v2.py'],
]
for step in steps:
    print(json.dumps({'step': step, 'started': time.time()}), flush=True)
    subprocess.run([sys.executable, str(root / step[0]), *step[1:]], cwd=root, check=True)
summary = json.loads((root / 'training_results_v2' / 'summary.json').read_text())
if summary['observed_runs'] != summary['expected_runs']:
    raise RuntimeError('Incomplete benchmark matrix')
if summary['timing_overlaps'] or summary['aten_policy_errors'] or summary['malformed_diagnostics']:
    raise RuntimeError('Benchmark audit failed; inspect summary.json')
(root / 'training_results_v2' / 'COMPLETE.json').write_text(json.dumps({
    'started': started, 'finished': time.time(), 'summary': summary}, indent=2) + '\n')
print('All benchmark attempts and FSDP retries completed; reports generated.', flush=True)
