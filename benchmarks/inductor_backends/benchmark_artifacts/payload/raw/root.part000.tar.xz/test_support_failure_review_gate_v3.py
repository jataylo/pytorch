import ast
import csv
import hashlib
import json
from pathlib import Path
import tempfile

from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


source = Path(__file__).with_name('finish_support_benchmarks_v3.py')
tree = ast.parse(source.read_text())
gate = next(node for node in ast.walk(tree) if isinstance(node, ast.With)
            and 'all_compile_execution_failures.csv' in ast.unparse(node.items[0].context_expr))


@instantiate_parametrized_tests
class TestSupportFailureReview(TestCase):
    @parametrize('case', ['external_unknown', 'external_reviewed', 'known_compiler',
                         'external_with_known_text', 'memory'])
    def test_gate(self, case):
        failure = {'model': 'model', 'phase': 'warmup', 'error': 'worker died',
                   'failure_kind': 'external_termination'}
        if case in {'known_compiler', 'external_with_known_text'}:
            failure['error'] = 'FusedMixOrderReductions'
        if case == 'known_compiler':
            failure['failure_kind'] = 'compiler_or_execution'
        elif case == 'memory':
            failure['failure_kind'] = 'memory'
        reviewed = []
        if case == 'external_reviewed':
            reviewed = [hashlib.sha256(json.dumps(
                {key: failure[key] for key in ['model', 'phase', 'error']}, sort_keys=True).encode()).hexdigest()]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'training_results_v2/all_compile_execution_failures.csv'
            path.parent.mkdir()
            with path.open('w') as stream:
                writer = csv.DictWriter(stream, fieldnames=list(failure))
                writer.writeheader()
                writer.writerow(failure)
            namespace = {'root': root, 'csv': csv, 'hashlib': hashlib, 'json': json,
                         'review': {'reviewed_failure_hashes': reviewed}, 'unknown_failures': []}
            exec(compile(ast.Module(body=[gate], type_ignores=[]), str(source), 'exec'), namespace)
        self.assertEqual(len(namespace['unknown_failures']), int(case in {'external_unknown', 'external_with_known_text'}))


if __name__ == '__main__':
    run_tests()
