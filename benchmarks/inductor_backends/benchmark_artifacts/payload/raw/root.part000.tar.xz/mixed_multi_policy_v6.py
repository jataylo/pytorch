from allocation_failures_v3 import is_terminal_gpu_memory_failure

MODES = {(backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]}


def memory_retry_group(records):
    if {(record['backend'], record['autotune']) for record in records} != MODES or len(records) != 4:
        raise ValueError('Expected a complete four-configuration model group')
    if any(record['status'] == 'started' for record in records):
        raise ValueError('Wait for the single GPU group to finish')
    return any(is_terminal_gpu_memory_failure(record) for record in records)


def retry_worlds(records, free_bytes):
    worlds = [count for count in [2, 4, 8] if count <= len(free_bytes)]
    if not worlds:
        raise ValueError('At least two GPUs are required for retries')
    required = max(record.get('parameter_bytes', 0) * 2 for record in records)
    first = next((count for count in worlds if required < sum(free_bytes[:count]) * 0.8), worlds[-1])
    return [count for count in worlds if count >= first]
