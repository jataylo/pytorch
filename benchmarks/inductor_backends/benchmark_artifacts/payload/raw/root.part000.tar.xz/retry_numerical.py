import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', required=True)
    parser.add_argument('--wait-pid', type=int, required=True)
    args = parser.parse_args()
    while True:
        try:
            os.kill(args.wait_pid, 0)
        except ProcessLookupError:
            break
        time.sleep(5)
    models = set()
    for path in (ROOT / 'training_results/raw').glob('*/*.json'):
        record = json.loads(path.read_text())
        if str(record.get('physical_gpu')) != args.gpu:
            continue
        error = record.get('error', '')
        if record['status'] == 'error' and record.get('phase') == 'compile_validation':
            if error.startswith('AssertionError:') and 'are not close' in error:
                models.add(record['model'])
    print(json.dumps({'gpu': args.gpu, 'numerical_recheck_models': sorted(models)}), flush=True)
    if not models:
        return
    command = [sys.executable, str(ROOT / 'run_suite.py'), '--gpus', args.gpu,
               '--force', '--archive-label', f'numerical_retry_gpu{args.gpu}_{time.time_ns()}',
               '--models', *sorted(models)]
    subprocess.run(command, cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
