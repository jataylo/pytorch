from collections import Counter, defaultdict
import argparse
import csv
import html
import json
from pathlib import Path
import re
import statistics

from analyze_v2 import compatible, MEASURED, summarize, write_csv
from allocation_failures_v3 import is_gpu_allocation_failure


def failure_identity(event):
    return (event.get('measurement_protocol'), event.get('suite'), event.get('model'),
            event.get('requested_backend', event.get('backend')), event.get('autotune'),
            str(event.get('attempt_id')), event.get('world_size'), event.get('rank', 0))


def collect_raw_failures(directory, protocol, failures):
    indexed = {failure_identity(event): event for event in failures}
    paths = list(directory.glob('raw/*/*.json')) + list(directory.glob('raw/*/ranks/*.json'))
    paths += list(directory.glob('archive/**/*.json'))
    snapshot = directory.with_name(directory.name + '_single')
    paths += list(snapshot.glob('raw/*/*.json')) + list(snapshot.glob('raw/*/ranks/*.json'))
    for path in sorted(paths):
        record = json.loads(path.read_text())
        if record.get('status') not in {'error', 'timeout', 'process_failed'} or not all(
            key in record for key in ['suite', 'model', 'backend', 'autotune']
        ):
            continue
        rank = record.get('failed_rank', record.get('rank', 0))
        event = {**record, 'measurement_protocol': protocol, 'rank': rank,
                 'category': 'compile_or_execution_failure',
                 'requested_backend': record['backend']}
        if not record.get('attempt_id'):
            event['attempt_id'] = 'unknown:' + str(path)
        key = failure_identity(event)
        existing = indexed.get(key)
        if existing is None:
            existing = event
            existing['inventory_origin'] = 'raw_terminal_record'
            failures.append(existing)
            indexed[key] = existing
        rank_name = re.fullmatch(r'(.+)\.world\d+\.rank\d+', path.stem)
        log_path = (path.parent.parent / (rank_name[1] + '.log')
                    if path.parent.name == 'ranks' and rank_name else path.with_suffix('.log'))
        provenance = {'source_json': str(path), 'status': record['status'],
                      'returncode': record.get('returncode'), 'phase': record.get('phase'),
                      'log_path': str(log_path)}
        existing.setdefault('raw_failure_records', []).append(provenance)
        if record['status'] in {'timeout', 'process_failed'}:
            existing['external_termination'] = True
            if not existing.get('error'):
                existing['error'] = record.get('error') or f"{record['status']} (returncode={record.get('returncode')}); inspect {log_path}"


root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--results', default='training_results_v2')
parser.add_argument('--steady', default='training_results_v2_steady')
parser.add_argument('--manifest', default='model_manifest_v2.json')
parser.add_argument('--support-sweep', action='store_true')
args = parser.parse_args()
destination = root / args.results
steady = root / args.steady
models = json.loads((root / args.manifest).read_text())['models']


def load_records(directory):
    return {(record['suite'], record['model'], record['backend'], record['autotune']): (path, record)
            for path in directory.glob('raw/*/*.json') for record in [json.loads(path.read_text())]}


def variable(record):
    times = record.get('repeat_ms', [])
    return bool(record.get('timing_recompiles') or (times and
                (max(times) / min(times) > 1.2 or statistics.median(times[:2]) / statistics.median(times[-2:]) > 1.1)))


primary = load_records(destination)
rechecks = load_records(steady) if steady.exists() else {}
selected = dict(primary)
accepted = []
accepted_keys = set()
rejected = []
terminal_recoveries = []
for model in models:
    keys = [(model['suite'], model['model'], backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]]
    if not any(key in rechecks for key in keys):
        continue
    complete = all(key in rechecks and rechecks[key][1]['status'] in MEASURED and
                   rechecks[key][1].get('milliseconds', 0) > 0 for key in keys)
    metadata_match = complete and all(all(rechecks[key][1].get(field) == primary[key][1].get(field) for field in
                                  ['batch_size', 'parameters', 'model_config_sha256']) for key in keys)
    consistent_group = complete and len({(rechecks[key][1].get('physical_gpu'), rechecks[key][1].get('world_size'))
                                         for key in keys}) == 1
    original_group = complete and all(all(rechecks[key][1].get(field) == primary[key][1].get(field)
                                          for field in ['physical_gpu', 'world_size']) for key in keys)
    explicit_retry = complete and all(rechecks[key][1].get('placement_override') for key in keys)
    all_present = all(key in rechecks for key in keys)
    terminal_recovery = all_present and all(primary[key][1]['status'] not in MEASURED for key in keys) and all(
        rechecks[key][1]['status'] != 'started' and rechecks[key][1].get('parameters', 0) > 0 and
        rechecks[key][1].get('batch_size') == primary[key][1].get('batch_size') and
        any(flag in rechecks[key][1].get('launch_environment_overrides', {}) for flag in
            ['BENCHMARK_ADD_MM_TOKEN_TYPES', 'BENCHMARK_EXTRA_MODEL_DEPS', 'BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS', 'BENCHMARK_VERIFY_FSDP_MEMORY_BOUND',
             'BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE', 'TORCHINDUCTOR_MIX_ORDER_REDUCTION',
             'BENCHMARK_FSDP_STATE_INIT_ONLY']) for key in keys)
    if terminal_recovery:
        terminal_recovery = len({(rechecks[key][1].get('physical_gpu'), rechecks[key][1].get('world_size'),
                                 rechecks[key][1].get('parameters'), rechecks[key][1].get('model_config_sha256'),
                                 json.dumps(rechecks[key][1].get('source_fingerprint'), sort_keys=True)) for key in keys}) == 1
    if (metadata_match and consistent_group and (original_group or explicit_retry)) or terminal_recovery:
        selected.update({key: rechecks[key] for key in keys})
        accepted.append(model['model'])
        accepted_keys.add((model['suite'], model['model']))
        if terminal_recovery and not complete:
            terminal_recoveries.append(model['model'])
    else:
        rejected.append(model['model'])
provenance = []
for key, (path, record) in selected.items():
    provenance.append({**{field: record.get(field) for field in ['suite', 'model', 'backend', 'autotune', 'world_size',
                       'physical_gpu', 'status', 'milliseconds', 'repeat_ms', 'timing_warmup',
                       'placement_override', 'launch_environment_overrides']},
                       'timing_source': 'steady_recheck' if key in rechecks and selected[key] == rechecks[key] else 'primary',
                       'variable_samples': variable(record), 'source_json': str(path)})
write_csv(destination / 'final_timing_sources.csv', provenance)
pairs = []
effects = []
for model in models:
    for tune in [0, 1]:
        row = dict(model, autotune=tune)
        runs = [selected.get((model['suite'], model['model'], backend, tune)) for backend in ['triton', 'flydsl']]
        for backend, item in zip(['triton', 'flydsl'], runs):
            record = item[1] if item else {}
            row[f'{backend}_status'] = record.get('status', 'pending')
            row[f'{backend}_ms'] = record.get('milliseconds')
        if all(runs):
            first, second = [item[1] for item in runs]
            row.update(world_size=first.get('world_size'), physical_gpu=first.get('physical_gpu'),
                       local_batch_size=first.get('local_batch_size', first.get('batch_size')),
                       effective_global_batch_size=first.get('effective_global_batch_size', first.get('batch_size')),
                       batch_distribution=first.get('batch_distribution', 'single_gpu'),
                       component=first.get('component'),
                       timing_source='steady_recheck' if (model['suite'], model['model']) in accepted_keys else 'primary',
                       timing_quality='variable' if variable(first) or variable(second) else 'stable',
                       numerically_validated=first['status'] == second['status'] == 'ok',
                       common_config_overrides=first.get('launch_environment_overrides', {}))
            row['eager_validated'] = row['numerically_validated'] and row['timing_quality'] == 'stable'
            if compatible(first, second) and all(record['status'] in MEASURED and record.get('milliseconds', 0) > 0 for record in [first, second]):
                ratio = first['milliseconds'] / second['milliseconds']
                row.update(triton_over_flydsl=ratio, winner='flydsl' if ratio > 1.03 else 'triton' if ratio < 1 / 1.03 else 'within_3_percent')
                if row['timing_quality'] == 'variable':
                    row['winner'] = 'variable_samples'
        pairs.append(row)
    for backend in ['triton', 'flydsl']:
        runs = [selected.get((model['suite'], model['model'], backend, tune)) for tune in [0, 1]]
        if all(runs):
            first, second = [item[1] for item in runs]
            if compatible(first, second) and all(record['status'] in MEASURED and record.get('milliseconds', 0) > 0 for record in [first, second]):
                effects.append(dict(model, backend=backend, no_autotune_ms=first['milliseconds'],
                                    autotune_ms=second['milliseconds'], autotune_speedup=first['milliseconds'] / second['milliseconds'],
                                    stable=not (variable(first) or variable(second)),
                                    numerically_validated=first['status'] == second['status'] == 'ok'))
write_csv(destination / 'comparison_stable.csv', pairs)
write_csv(destination / 'autotune_effect_stable.csv', effects)
summary = {'models': len(models), 'configurations': len(selected), 'accepted_steady_rechecks': accepted,
           'terminal_recoveries_without_four_timings': terminal_recoveries,
           'rejected_steady_rechecks': rejected, 'statuses': dict(Counter(record['status'] for _, record in selected.values())),
           'shared_fusion_recoveries': sorted({record['model'] for _, record in selected.values()
               if record.get('launch_environment_overrides', {}).get('TORCHINDUCTOR_MIX_ORDER_REDUCTION') == '0'}),
           'validation_cache_recoveries': sorted({record['model'] for _, record in selected.values()
               if record.get('launch_environment_overrides', {}).get('BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE') == '1'}),
           'multimodal_input_recoveries': sorted({record['model'] for _, record in selected.values()
               if record.get('launch_environment_overrides', {}).get('BENCHMARK_ADD_MM_TOKEN_TYPES') == '1'}),
           'diffusion_constant_recoveries': sorted({record['model'] for _, record in selected.values()
               if record.get('launch_environment_overrides', {}).get('BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS') == '1'}),
           'verified_fsdp_capacity_checks': sorted({record['model'] for _, record in selected.values()
               if record.get('launch_environment_overrides', {}).get('BENCHMARK_VERIFY_FSDP_MEMORY_BOUND') == '1'}),
           'fsdp_state_initialization_recoveries': sorted({record['model'] for _, record in selected.values()
               if record.get('launch_environment_overrides', {}).get('BENCHMARK_FSDP_STATE_INIT_ONLY') == '1'}),
           'memory_retry_models': sorted({record['model'] for _, record in selected.values() if record.get('placement_override')}),
           'variable_pairs': sum(row.get('timing_quality') == 'variable' for row in pairs), 'comparisons': {}}
for suite in ['all', *sorted({model['suite'] for model in models})]:
    for tune in [0, 1]:
        rows = [row for row in pairs if 'triton_over_flydsl' in row and row['autotune'] == tune and
                row['timing_quality'] == 'stable' and (suite == 'all' or row['suite'] == suite)]
        summary['comparisons'][f'{suite}/autotune{tune}/stable_measured'] = summarize(rows)
        summary['comparisons'][f'{suite}/autotune{tune}/eager_validated'] = summarize([row for row in rows if row['eager_validated']])
        summary['comparisons'][f'{suite}/autotune{tune}/training_only_fsdp'] = summarize([row for row in rows if row['world_size'] > 1 and not row['numerically_validated']])
unsupported = []
failures = []
tuning = []
kernel_names = defaultdict(set)
with (destination / 'all_kernel_decisions.jsonl').open('w') as output:
    for directory, protocol in [(destination, 'support_sweep' if args.support_sweep else 'primary'), (steady, 'steady_recheck')]:
        path = directory / 'kernel_decisions.jsonl'
        if not path.exists():
            continue
        for line in path.open():
            event = dict(json.loads(line), measurement_protocol=protocol)
            key = (event.get('suite'), event.get('model'), event.get('requested_backend', event.get('backend')), event.get('autotune'))
            chosen = selected.get(key)
            event['selected_for_final_timing'] = bool(chosen and chosen[1]['status'] in MEASURED and
                chosen[1].get('milliseconds', 0) > 0 and chosen[1].get('attempt_id') == event.get('attempt_id'))
            scope = (protocol, event.get('attempt_id'), event.get('rank'))
            if event.get('category') == 'lowered' and event.get('kernel_name'):
                kernel_names[scope].add(event['kernel_name'])
            if event.get('category') == 'compile_or_execution_failure':
                failures.append(event)
            if event.get('category') == 'autotune_selection':
                tuning.append({field: event.get(field) for field in [
                    'suite', 'model', 'requested_backend', 'autotune', 'world_size', 'rank', 'phase',
                    'kernel_name', 'selected_candidate', 'reason', 'candidate_times_ms', 'attempt_id',
                    'measurement_protocol', 'selected_for_final_timing']})
            output.write(json.dumps(event) + '\n')
            if event.get('category') == 'lowered' and event.get('backend') == 'triton' and event.get('reason'):
                unsupported.append(event)
write_csv(destination / 'all_unsupported_flydsl_kernels.csv', unsupported)
for directory, protocol in [(destination, 'support_sweep' if args.support_sweep else 'primary'),
                            (steady, 'steady_recheck')]:
    collect_raw_failures(directory, protocol, failures)
for event in failures:
    message = (event.get('error') or '').lower()
    if event.get('external_termination'):
        kind = 'external_termination'
    elif 'out of memory' in message or is_gpu_allocation_failure(event.get('error')) or is_gpu_allocation_failure(event.get('traceback')):
        kind = 'memory'
    elif any(text in message for text in ['gated repo', '401 client', '403 client', 'unauthorized']):
        kind = 'access'
    elif event.get('phase') in ['model_capacity', 'model_load']:
        kind = 'model_setup'
    elif event.get('phase') == 'eager_validation':
        kind = 'eager_reference'
    else:
        kind = 'compiler_or_execution'
    event['failure_kind'] = kind
    scope = (event['measurement_protocol'], event.get('attempt_id'), event.get('rank'))
    text = (event.get('error') or '') + '\n' + (event.get('traceback') or '')
    event['linked_kernel_names'] = [name for name in sorted(kernel_names[scope])
        if kind == 'compiler_or_execution' and re.search(re.escape(name) + r'(?:_[A-Za-z0-9_]+)?(?![A-Za-z0-9_])', text)]
write_csv(destination / 'all_compile_execution_failures.csv', failures)
write_csv(destination / 'all_autotune_selections.csv', tuning)
summary['autotune_selection_events'] = len(tuning)
summary['autotune_selection_reasons'] = dict(Counter(
    item['reason'] or ('candidate timings recorded' if item['candidate_times_ms'] is not None else 'unspecified')
    for item in tuning))
(destination / 'stable_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
page = '<!doctype html><meta charset="utf-8"><title>Steady training comparison</title><style>body{font:15px system-ui;margin:28px}td,th{padding:7px;text-align:left;border-bottom:1px solid #ddd}pre{white-space:pre-wrap}input{padding:10px;width:450px}</style><h1>Full-model training: final comparison</h1>'
method = ('Ratio = Triton time / FlyDSL time; above one favors FlyDSL. Model architectures, batch sizes, GPU groups '
          'and ATen GEMM/conv policy match within each pair. Repeat spread above 20%, a downward trend above 10%, '
          'or timing recompilation marks a result variable. Variable samples and numerical warnings are excluded '
          'from validated comparisons. Training-only FSDP results are reported separately. All attempts are preserved. ')
if args.support_sweep:
    method += ('This complete sweep uses the finalized FlyDSL sources and applies the scheduler fix equally to both backends. '
               'All four variants use the same longer per-model warmup, validation-input recoveries and explicit GPU placements. '
               'The fixed mixed-order scheduler remains enabled for DINOv2. Inspect per-row overrides and raw provenance.')
else:
    method += ('Targeted rechecks use a common per-model warmup of at least 30 steps and approximately 1.5 seconds. '
               'Shared nested-fusion assertion recoveries disable the same fusion in all four variants; overrides are shown.')
page += '<p>' + html.escape(method) + '</p>'
page += '<p><a href="comparison_stable.csv">Final comparison CSV</a> | <a href="final_timing_sources.csv">Timing provenance and samples</a> | <a href="autotune_effect_stable.csv">Autotuning effects</a> | <a href="all_unsupported_flydsl_kernels.csv">All unsupported lowering events</a> | <a href="all_compile_execution_failures.csv">Later failures, classified separately</a> | <a href="all_kernel_decisions.jsonl">All kernel decisions</a> | <a href="final_audit.json">Source/native-call audit</a> | <a href="BENCHMARK_NOTES.txt">Methodology notes</a> | <a href="report.html">Original matrix</a></p>'
page += '<p><a href="kernel_inventory/REPORT.md">Static kernel definitions, launch sites and coverage audit</a></p>'
page += '<p><a href="all_autotune_selections.csv">All autotuning selections and capacity guards</a>. Counts include all attempts, ranks and phases; tuning guards are separate from unsupported lowering events.</p>'
page += '<pre>' + html.escape(json.dumps(summary, indent=2)) + '</pre><input id="filter" placeholder="Filter model, status, source or timing quality"><table><thead><tr>'
fields = ['suite', 'model', 'component', 'autotune', 'world_size', 'local_batch_size', 'effective_global_batch_size',
          'batch_distribution', 'triton_status', 'flydsl_status', 'triton_ms', 'flydsl_ms',
          'triton_over_flydsl', 'winner', 'timing_source', 'timing_quality', 'eager_validated', 'common_config_overrides']
page += ''.join('<th>' + field + '</th>' for field in fields) + '</tr></thead><tbody>'
page += ''.join('<tr>' + ''.join('<td>' + html.escape(str(row.get(field, ''))) + '</td>' for field in fields) + '</tr>' for row in pairs)
page += '</tbody></table><script>document.getElementById("filter").oninput=function(){for(const row of document.querySelectorAll("tbody tr"))row.hidden=!row.textContent.toLowerCase().includes(this.value.toLowerCase())}</script>'
(destination / 'stable_report.html').write_text(page)
print(json.dumps(summary, indent=2))
