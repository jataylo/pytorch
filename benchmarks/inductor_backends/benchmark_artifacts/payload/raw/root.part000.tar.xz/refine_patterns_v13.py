from pathlib import Path
p=Path(__file__).resolve().parent/'pytorch_codegen_v13/torch/_inductor/codegen/amd_kernel_optimizations.py';s=p.read_text();s=s.replace('    if ast.unparse(store.args[0]) not in ("out_ptr0 + x0", "out_ptr0 + x2"):\n        return source', '''    address = store.args[0]
    if not isinstance(address, ast.BinOp) or not isinstance(address.op, ast.Add) or ast.unparse(address.left) != "out_ptr0" or not isinstance(address.right, ast.Name) or ast.unparse(assignments.get(address.right.id, ast.Constant(None))) != "xindex":
        return source''')
needle='    if family is None:\n        return source'
s=s.replace(needle,'''    if family is None and len(loads) == 1 and pointers == ["in_ptr0", "out_ptr0"] and signature[pointers[0]] == signature[pointers[1]] and expression == ast.dump(ast.Name(id="load0", ctx=ast.Load())):
        dims = []
        for name in ("x0", "x1", "x2"):
            node = assignments.get(name)
            if not isinstance(node, ast.BinOp) or not isinstance(node.op, ast.Mod) or not isinstance(node.right, ast.Constant) or not isinstance(node.right.value, int) or node.right.value <= 0:
                break
            dims.append(node.right.value)
        if len(dims) == 3:
            d, h, s = dims
            c = d * h
            expected_indices = {"x0": f"xindex % {d}", "x1": f"(xindex // {d}) % {h}", "x2": f"(xindex // {c}) % {s}", "x3": f"xindex // {s*c}"}
            indices_match = all(ast.dump(assignments.get(key, ast.Constant(None))) == ast.dump(ast.parse(value, mode="eval").body) for key, value in expected_indices.items())
            expected_offset = ast.parse(f"in_ptr0 + (x0 + {d}*x2 + {s*d}*x1 + {s*c}*x3)", mode="eval").body
            if indices_match and n % (s*c) == 0 and ast.dump(loads[0].args[0]) == ast.dump(expected_offset):
                family = "transpose"
                body = f"""
i = gl.program_id(0) * XBLOCK + lane
output = (i // {s*c}) * {s*c} + ((i // {d}) % {s}) * {c} + ((i // {s*d}) % {h}) * {d} + (i % {d})
value = gl.load(in_ptr0 + i, i < {n}, other=0)
gl.store(out_ptr0 + output, value, i < {n})
"""
    if family is None:
        return source''')
p.write_text(s)
