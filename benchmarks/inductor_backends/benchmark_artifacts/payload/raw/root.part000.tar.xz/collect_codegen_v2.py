import ast
import hashlib
import json
from pathlib import Path
import re


def collect_codegen(cache, destination):
    graphs = []
    unexpected = []
    for path in Path(cache).rglob('*.py'):
        source = path.read_text(errors='replace')
        if '# AOT ID:' not in source or 'def call(' not in source:
            continue
        tree = ast.parse(source)
        native = []
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == 'call':
                for call in ast.walk(node):
                    if not isinstance(call, ast.Call):
                        continue
                    name = ast.unparse(call.func)
                    if name.startswith(('extern_kernels.', 'torch.ops.aten.', 'aten.')):
                        native.append({'operation': name, 'call': ast.unparse(call)})
        for name in re.findall(r"async_compile\.triton\(\s*['\"]([^'\"]+)", source):
            if name.startswith('triton_convolution2d') or (name.startswith('triton_tem_') and
                    re.search(r'(^|_)(mm|addmm|bmm|convolution|grouped_mm|scaled_mm)(_|$)', name)):
                unexpected.append({'kernel': name, 'wrapper': str(path)})
        graphs.append({'wrapper': str(path), 'sha256': hashlib.sha256(source.encode()).hexdigest(),
                       'native_calls': native})
    result = {'graphs': graphs, 'unexpected_triton_matrix_templates': unexpected,
              'scope': 'ATen callsites in Inductor wrappers; these are intentional native operations, not unsupported SIMD kernels'}
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, indent=2) + '\n')
    if unexpected:
        raise RuntimeError('Triton GEMM/convolution template found under ATen-only policy')
    return {'graphs': len(graphs), 'native_calls': sum(len(g['native_calls']) for g in graphs),
            'unexpected_triton_matrix_templates': len(unexpected), 'file': str(target)}
