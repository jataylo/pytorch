#!/bin/bash
set -euo pipefail
TASK_ROOT=/dockerx/pytorch-flex/agent_space/simd_bench
unset LD_LIBRARY_PATH ROCM_HOME CMAKE_PREFIX_PATH HIP_VISIBLE_DEVICES
export VIRTUAL_ENV="$TASK_ROOT/.venv"
export PATH="$VIRTUAL_ENV/bin:/dockerx/venvs/flex-build/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export ROCM_PATH=/dockerx/venvs/flex-build/lib/python3.12/site-packages/_rocm_sdk_devel
export PYTHONPATH="$TASK_ROOT/model_deps"
export TMPDIR=/dev/shm/pytorch-simd-937d7fd-tmp
export AMD_COMGR_CACHE_DIR=/dev/shm/pytorch-simd-comgr-cache
export MIOPEN_CUSTOM_CACHE_DIR=/dev/shm/pytorch-simd-miopen-cache
export MIOPEN_USER_DB_PATH=/dev/shm/pytorch-simd-miopen-db
exec "$VIRTUAL_ENV/bin/python" "$@"
