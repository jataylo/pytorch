from collections import Counter, defaultdict
import argparse
import csv
import html
import json
from pathlib import Path
import re


parser = argparse.ArgumentParser()
parser.add_argument('--results', default='training_results_v2')
args = parser.parse_args()
root = Path(__file__).resolve().parent / args.results
events = []
for line in (root / 'all_kernel_decisions.jsonl').open():
    event = json.loads(line)
    if event.get('category') == 'lowered' and event.get('backend') == 'triton' and event.get('reason'):
        events.append(event)

groups = defaultdict(list)
for event in events:
    groups[event['reason']].append(event)
rows = []
model_rows = []
for reason, items in sorted(groups.items(), key=lambda pair: -len(pair[1])):
    selected = [event for event in items if event['selected_for_final_timing']]
    operations = Counter()
    for event in items:
        operations.update(set(re.findall(r'aten\.[A-Za-z0-9_]+', event.get('origins', ''))))
    rows.append(dict(reason=reason, all_scheduled_events=len(items), selected_timing_events=len(selected),
                     all_models=len({(event['suite'], event['model']) for event in items}),
                     selected_models=len({(event['suite'], event['model']) for event in selected}),
                     source_operations=dict(operations.most_common()),
                     example_kernel=items[0]['kernel_name'],
                     example_buffers=items[0].get('buffers', {})))
    by_model = defaultdict(list)
    for event in items:
        by_model[event['suite'], event['model'], event['autotune']].append(event)
    for (suite, model, tune), kernels in sorted(by_model.items()):
        model_rows.append(dict(suite=suite, model=model, autotune=tune, reason=reason,
                               all_scheduled_events=len(kernels),
                               selected_timing_events=sum(event['selected_for_final_timing'] for event in kernels),
                               kernel_names=sorted({event['kernel_name'] for event in kernels})))
for name, records in [('unsupported_summary.csv', rows), ('unsupported_by_model.csv', model_rows)]:
    with (root / name).open('w') as output:
        writer = csv.DictWriter(output, fieldnames=list(records[0]) if records else ['reason'])
        writer.writeheader()
        writer.writerows(records)
page = '<!doctype html><meta charset="utf-8"><title>FlyDSL lowering gaps</title><style>body{font:15px system-ui;margin:28px}td,th{padding:8px;vertical-align:top;text-align:left;border-bottom:1px solid #ddd}input{padding:10px;width:450px}</style><h1>Observed FlyDSL lowering gaps</h1>'
page += '<p>These schedules fell back to a named Triton kernel. Counts represent generated schedules, including backward graphs and repeated attempts, rather than dynamic launches. Selected timing counts identify the attempts used in the final comparison. A reason can depend on layout, dtype or fusion; it does not establish that every listed source operation is unsupported.</p>'
page += '<p><a href="all_unsupported_flydsl_kernels.csv">Complete event details, shapes and source mappings</a> | <a href="unsupported_summary.csv">Summary CSV</a> | <a href="unsupported_by_model.csv">Per-model CSV</a> | <a href="intentional_native_calls.csv">ATen/extern callsites</a> | <a href="all_compile_execution_failures.csv">Later failures</a> | <a href="stable_report.html">Performance comparison</a></p>'
page += '<pre>' + html.escape(json.dumps(rows, indent=2)) + '</pre><input id="filter" placeholder="Filter model, kernel or fallback reason"><table><thead><tr>'
fields = ['suite', 'model', 'autotune', 'reason', 'all_scheduled_events', 'selected_timing_events', 'kernel_names']
page += ''.join('<th>' + field + '</th>' for field in fields) + '</tr></thead><tbody>'
page += ''.join('<tr>' + ''.join('<td>' + html.escape(str(row.get(field, ''))) + '</td>' for field in fields) + '</tr>' for row in model_rows)
page += '</tbody></table><script>document.getElementById("filter").oninput=function(){for(const row of document.querySelectorAll("tbody tr"))row.hidden=!row.textContent.toLowerCase().includes(this.value.toLowerCase())}</script>'
(root / 'unsupported_report.html').write_text(page)
print(json.dumps({'reasons': len(rows), 'fallback_schedule_events': len(events), 'models': len({(event['suite'], event['model']) for event in events})}))
