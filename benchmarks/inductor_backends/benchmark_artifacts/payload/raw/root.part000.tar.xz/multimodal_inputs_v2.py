from collections.abc import Mapping
from numbers import Integral
from typing import Any

import torch


def with_mm_token_type_ids(model: Any, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """Add processor-equivalent text/image/video tags without changing model inputs."""
    result = dict(inputs)
    if result.get('mm_token_type_ids') is not None:
        return result
    config = getattr(model, 'config', None)
    if config is None:
        raise ValueError('Cannot derive mm_token_type_ids without model.config token metadata')
    input_ids = result.get('input_ids')
    if not isinstance(input_ids, torch.Tensor) or input_ids.ndim != 2:
        raise ValueError('Deriving mm_token_type_ids requires a rank-two input_ids tensor')
    if input_ids.dtype not in (torch.int32, torch.int64):
        raise ValueError('Deriving mm_token_type_ids requires integer input_ids')

    token_ids = {}
    for modality in ['image', 'video']:
        names = [f'{modality}_token_id', f'{modality}_token_index']
        values = [getattr(config, name, None) for name in names]
        known = [value for value in values if value is not None]
        if any(not isinstance(value, Integral) or isinstance(value, bool) for value in known):
            raise ValueError(f'{modality} token metadata must be an integer: {dict(zip(names, values))}')
        if len(set(known)) > 1:
            raise ValueError(f'Conflicting {modality} token metadata: {dict(zip(names, values))}')
        token_ids[modality] = int(known[0]) if known else None
    if all(value is None for value in token_ids.values()):
        raise ValueError('model.config must define image_token_id/index or video_token_id/index')
    if token_ids['image'] is not None and token_ids['image'] == token_ids['video']:
        raise ValueError('Image and video token metadata must be distinct to derive modality tags')

    tags = torch.zeros_like(input_ids, dtype=torch.long)
    for modality, value in [('image', 1), ('video', 2)]:
        payload_names = ('pixel_values', 'image_grid_thw') if modality == 'image' else ('pixel_values_videos', 'video_grid_thw')
        has_payload = any(result.get(name) is not None for name in payload_names)
        token_id = token_ids[modality]
        if token_id is None:
            if has_payload:
                raise ValueError(f'{modality} inputs are present but model.config lacks {modality}_token_id/index')
            continue
        mask = input_ids == token_id
        if has_payload and not mask.any().item():
            raise ValueError(f'{modality} inputs are present but input_ids has no {modality} placeholder token {token_id}')
        tags.masked_fill_(mask, value)
    result['mm_token_type_ids'] = tags
    return result
