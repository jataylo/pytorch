import hashlib
import importlib
import inspect
import json
from pathlib import Path

import torch


VERIFIED_SOURCES = {
    'transformers.models.qwen4_exp.modeling_qwen4_exp': 'e57b3617e71e81ecb7e5ae3b420c45b5aee80d76a07aa8c88b797c2642f1f5df',
    'torch.distributed.fsdp._runtime_utils': '35e923ca8d8424d7db1bb71b3e2781ad367d81ccf65e92af7554df09fb95b29c',
    'torch.distributed.fsdp._flat_param': 'ea287f8d6b64f3bf9c1f32bd04a64b156775682fe7b93ec7391909d80d90e98e',
    'torch.nn.modules.sparse': '4897b5402c35e49c830edaee1eacc1b1c3f802ddc8e7ddf4112a71c78bea81f5',
}
EMBEDDING_PATH = 'model.language_model.layers.1.ple.ple_embedding.ngram_embedding'
VERIFIED_CONFIG_SHA256 = 'd6ea711f30719d348cbd790808f78c63f8358abf46f2b3a46b3e958da06519ab'


def fsdp_large_embedding_memory_bound(model, world_size, *, master_dtype=torch.float32,
                               compute_dtype=torch.bfloat16, reduce_dtype=torch.float32,
                               cpu_offload=False, keep_low_precision_grads=False,
                               use_orig_params=True, sharding_strategy='FULL_SHARD',
                               free_bytes_per_rank=None):
    """Return a source-verified dense-embedding lower bound, or None for unknown protocols."""
    kind = type(model)
    module_name = 'transformers.models.qwen4_exp.modeling_qwen4_exp'
    if kind.__module__ != module_name or kind.__name__ != 'Qwen4ExpForConditionalGeneration':
        return None
    if type(world_size) is not int or world_size < 2:
        return None
    if (master_dtype, compute_dtype, reduce_dtype) != (torch.float32, torch.bfloat16, torch.float32):
        return None
    if cpu_offload or keep_low_precision_grads or not use_orig_params or sharding_strategy != 'FULL_SHARD':
        return None
    source_files = {}
    for name, expected in VERIFIED_SOURCES.items():
        module = importlib.import_module(name)
        path = Path(inspect.getsourcefile(module)).resolve()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != expected:
            return None
        source_files[name] = {'path': str(path), 'sha256': digest}
    if kind is not getattr(importlib.import_module(module_name), kind.__name__):
        return None
    config = getattr(model, 'config', None)
    if config is None or not hasattr(config, 'to_dict'):
        return None
    config_hash = hashlib.sha256(json.dumps(config.to_dict(), sort_keys=True, default=str).encode()).hexdigest()
    if config_hash != VERIFIED_CONFIG_SHA256:
        return None
    try:
        language_model = model.get_submodule('model.language_model')
        layers = language_model.layers
    except AttributeError:
        return None
    if type(language_model).__module__ != module_name or type(language_model).__name__ != 'Qwen4ExpTextModel':
        return None
    if language_model.config is not config.text_config or len(layers) != 48:
        return None
    if any(getattr(module, 'gradient_checkpointing', False) for module in model.modules()):
        return None
    try:
        embedding = model.get_submodule(EMBEDDING_PATH)
        decoder = model.get_submodule('model.language_model.layers.1')
        ple = model.get_submodule('model.language_model.layers.1.ple.ple_embedding')
    except AttributeError:
        return None
    if type(decoder).__module__ != module_name or type(decoder).__name__ != 'Qwen4ExpTextDecoderLayer':
        return None
    if type(ple).__module__ != module_name or type(ple).__name__ != 'Qwen4ExpTextNGramEmbedding':
        return None
    if type(embedding) is not torch.nn.Embedding or embedding.sparse or embedding.max_norm is not None:
        return None
    entries = list(model.named_parameters(remove_duplicate=False))
    if sum(value.numel() for _, value in entries) != 177392830576:
        return None
    if len({id(value) for _, value in entries}) != len(entries):
        return None
    if len({value.untyped_storage()._cdata for _, value in entries}) != len(entries):
        return None
    if any(not value.is_meta or value.dtype != torch.float32 for _, value in entries):
        return None
    weight = embedding.weight
    if tuple(weight.shape) != (320001536, 160) or not weight.requires_grad or not weight.is_contiguous() or weight.storage_offset():
        return None
    if dict(entries).get(EMBEDDING_PATH + '.weight') is not weight:
        return None
    n = weight.numel()
    own_master = n // world_size * 4
    bound = n * 6 + own_master
    result = {
        'proof': 'verified_qwen4exp_dense_embedding_bf16_gradient_fp32_cast_own_master_v1',
        'model_class': f'{kind.__module__}.{kind.__name__}', 'world_size': world_size,
        'model_config_sha256': config_hash,
        'unique_parameter_numel': sum(value.numel() for _, value in entries),
        'embedding_path': EMBEDDING_PATH + '.weight', 'embedding_shape': list(weight.shape),
        'embedding_numel': n, 'own_master_shard_lower_bound_bytes': own_master,
        'full_bf16_gradient_bytes': n * 2, 'full_fp32_gradient_cast_bytes': n * 4,
        'per_rank_lower_bound_bytes': bound, 'source_files': source_files,
        'completion_order_assumption': 'none; count only one dense embedding gradient cast',
        'master_shard_condition': 'A flat handle containing n embedding elements has at least floor(n/world_size) persistent FP32 master elements, including when wrapped alone.',
        'gradient_cast_condition': 'Native FSDP retains the dense BF16 autograd gradient while allocating its distinct FP32 reduction cast.',
        'ignored_memory': ['all other master shards', 'all other gradients', 'padding', 'full parameters',
                           'activations', 'buffers', 'allocator and communication workspaces'],
    }
    if free_bytes_per_rank is not None:
        if len(free_bytes_per_rank) != world_size or any(type(value) is not int or value < 0 for value in free_bytes_per_rank):
            raise ValueError('free_bytes_per_rank must contain one nonnegative integer per rank')
        result['free_bytes_per_rank'] = list(free_bytes_per_rank)
        result['insufficient_capacity'] = any(bound > value for value in free_bytes_per_rank)
        if result['insufficient_capacity']:
            result['reason'] = (f'Verified dense-embedding FSDP storage lower bound {bound} bytes per rank exceeds '
                                f'available memory on at least one rank (minimum {min(free_bytes_per_rank)} bytes); '
                                'the BF16 full gradient, FP32 reduction cast and its own FP32 master shard must coexist.')
    return result
