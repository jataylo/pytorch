from collections import defaultdict
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'training_results_purefly_v7'
RESULTS.mkdir(exist_ok=True)
MANIFEST = 'model_manifest_purefly_v7.json'
FINGERPRINT = 'source_fingerprint_purefly_v7.json'


def state(phase, **details):
    payload = dict(phase=phase, timestamp=time.time(), **details)
    (RESULTS / 'pipeline.json').write_text(json.dumps(payload, indent=2) + '\n')
    print(json.dumps(payload), flush=True)


def run(script, *arguments):
    state('running', script=script, arguments=arguments)
    subprocess.run([sys.executable, str(ROOT / script), *arguments], cwd=ROOT, check=True)


def verify_sources(fingerprint):
    for group, base in [('sources', Path(fingerprint['source_root'])), ('harness', ROOT)]:
        for name, expected in fingerprint[group].items():
            if hashlib.sha256((base / name).read_bytes()).hexdigest() != expected:
                raise RuntimeError(f'Source drift: {base / name}')


def load_groups(directory):
    groups = defaultdict(list)
    for path in (directory / 'raw').glob('*/*.json'):
        groups[tuple(json.loads(path.read_text())[key] for key in ['suite', 'model'])].append(path)
    return groups


state('waiting_for_single_and_multi_gpu_mixed_results')
while True:
    try:
        single = json.loads((ROOT / 'training_results_mixed_single_v5/pipeline.json').read_text())
        multi = json.loads((ROOT / 'training_results_mixed_multi_v6/pipeline.json').read_text())
    except (OSError, ValueError):
        time.sleep(5)
        continue
    finished = {'measurements_complete_manual_review_required', 'complete_no_memory_failures'}
    if single['phase'] in finished and multi['phase'] in finished:
        break
    time.sleep(5)

try:
    fingerprint = json.loads((ROOT / 'source_fingerprint_mixed_single_v5.json').read_text())
    verify_sources(fingerprint)
    manifest = json.loads((ROOT / 'model_manifest_mixed_single_v5.json').read_text())
    singles = load_groups(ROOT / 'training_results_mixed_single_v5')
    multis = load_groups(ROOT / 'training_results_mixed_multi_v6')
    multi_manifest_path = ROOT / 'model_manifest_mixed_multi_v6.json'
    multi_models = {(model['suite'], model['model']): model for model in json.loads(multi_manifest_path.read_text())['models']} if multi_manifest_path.exists() else {}
    provenance = {}
    for index, model in enumerate(manifest['models']):
        key = model['suite'], model['model']
        paths = multis.get(key, singles[key])
        records = [json.loads(path.read_text()) for path in paths]
        if len(records) != 4 or any(record['status'] == 'started' for record in records):
            raise RuntimeError(f'Incomplete reference group: {key}')
        placements = {(str(record['physical_gpu']), record['world_size']) for record in records}
        if len(placements) != 1:
            raise RuntimeError(f'Inconsistent placement: {key}')
        gpu, world = placements.pop()
        if key in multi_models:
            model = json.loads(json.dumps(multi_models[key]))
            manifest['models'][index] = model
        model.update(physical_gpu=gpu, world_size=world)
        model['reference_record_hashes'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
        provenance.update(model['reference_record_hashes'])
    manifest['protocol'] = 'Fresh pure FlyDSL arm at each final mixed/Triton GPU placement and original input policy, standard and expanded tuning; full architectures, no checkpoints/offload, ATen GEMM/conv, performance backend selection disabled'
    (ROOT / MANIFEST).write_text(json.dumps(manifest, indent=2) + '\n')
    fingerprint['parent_sha256'] = fingerprint.pop('sha256')
    fingerprint['protocol'] = manifest['protocol']
    for name in [MANIFEST, 'run_purefly_and_report_v7.py', 'run_suite_purefly_v7.py', 'train_worker_purefly_v7.py',
                 'build_three_backend_report_v7.py', 'test_three_backend_report_v7.py']:
        fingerprint['harness'][name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    fingerprint['sha256'] = hashlib.sha256(json.dumps(fingerprint, sort_keys=True).encode()).hexdigest()
    (ROOT / FINGERPRINT).write_text(json.dumps(fingerprint, indent=2) + '\n')
    verify_sources(fingerprint)
    (RESULTS / 'reference_inputs.json').write_text(json.dumps(provenance, indent=2) + '\n')
    (RESULTS / 'BENCHMARK_NOTES.txt').write_text(manifest['protocol'] + '\nPure FlyDSL measured in a separate sequential pass; three-way report retains all timestamps and provenance. No older v4 timings are substituted.\n')
    for model in manifest['models']:
        command = ['--gpus', str(model['physical_gpu']), '--override-placement', '--models', model['model'],
                   '--suites', model['suite'], '--timeout', '5400']
        if model['world_size'] > 1:
            command.append('--fsdp')
        run('run_suite_purefly_v7.py', *command)
        verify_sources(fingerprint)
    records = [json.loads(path.read_text()) for path in (RESULTS / 'raw').glob('*/*.json')]
    if len(records) != len(manifest['models']) * 2 or any(record['status'] == 'started' for record in records):
        raise RuntimeError('Incomplete pure FlyDSL matrix')
    for record in records:
        if record['backend'] != 'flydsl' or record.get('backend_selection') or record.get('inductor_config', {}).get('flydsl.simd_autotune_backend'):
            raise RuntimeError('Pure FlyDSL selector policy violated')
    with (RESULTS / 'kernel_decisions.jsonl').open('w') as output:
        for path in (RESULTS / 'raw').glob('*/kernels/*.jsonl'):
            for number, line in enumerate(path.open(), 1):
                event = json.loads(line)
                event.update(active_configuration=True, diagnostic_file=str(path), line=number)
                output.write(json.dumps(event) + '\n')
    run('final_audit_v2.py', '--results', RESULTS.name, '--fingerprint', FINGERPRINT)
    audit = json.loads((RESULTS / 'final_audit.json').read_text())
    for key in ['source_drift', 'external_source_drift', 'optional_dependency_drift', 'input_metadata_mismatches',
                'unexpected_triton_matrix_templates', 'codegen_collection_errors', 'checkpoint_files']:
        if audit[key]:
            raise RuntimeError(f'Pure FlyDSL audit failed: {key}')
    for path, expected in provenance.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise RuntimeError(f'Reference result changed: {path}')
    verify_sources(fingerprint)
    (RESULTS / 'COMPLETE.json').write_text(json.dumps(dict(models=len(manifest['models']), runs=len(records),
        source_fingerprint=fingerprint['sha256']), indent=2) + '\n')
    run('build_three_backend_report_v7.py')
    state('three_backend_reports_complete_manual_review_required', csv=str(ROOT / 'three_backend_report_v7/per_model_expanded.csv'),
          workbook=str(ROOT / 'three_backend_report_v7/three_backend_comparison.xlsx'))
except Exception as error:
    state('needs_review', error=f'{type(error).__name__}: {error}')
    raise
