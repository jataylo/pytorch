import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time
root = Path(__file__).resolve().parent
manifest = json.loads((root / 'model_manifest_mixed_multi_v6.json').read_text())
if manifest['models']:
    proof_path = root / 'training_results_mixed_multi_v6/fsdp_state_init_validation.json'
    old_probe_files = [path for path in proof_path.parent.glob(proof_path.stem + '*') if path.is_file()]
    if old_probe_files:
        archive = proof_path.parent / 'fsdp_state_init_validation_attempts' / str(time.time_ns())
        archive.mkdir(parents=True)
        for path in old_probe_files:
            shutil.copy2(path, archive / path.name)
    proof_path.unlink(missing_ok=True)
    probe_env = os.environ.copy()
    for name in ['LD_LIBRARY_PATH', 'ROCM_HOME', 'HIP_VISIBLE_DEVICES', 'CMAKE_PREFIX_PATH', 'TORCH_LOGS',
                 'TORCHINDUCTOR_FLYDSL_BASELINE_DIR', 'TORCHINDUCTOR_FLYDSL_SIMD_STAGES',
                 'TORCHINDUCTOR_MIX_ORDER_REDUCTION', 'BENCHMARK_SUPPORT_SOURCE_ROOT']:
        probe_env.pop(name, None)
    cache_tag = proof_path.parent.name + '-' + str(time.time_ns())
    probe_env.update(CUDA_VISIBLE_DEVICES='0,1',
                     PYTHONPATH=str(root / 'model_deps'), OMP_NUM_THREADS='8', MKL_NUM_THREADS='8',
                     TORCHINDUCTOR_COMPILE_THREADS='8',
                     TORCHINDUCTOR_CACHE_DIR=str(Path('/dev/shm') / ('pytorch-simd-state-init-' + cache_tag)),
                     TRITON_CACHE_DIR=str(Path('/dev/shm') / ('pytorch-simd-state-init-triton-' + cache_tag)),
                     FLYDSL_RUNTIME_CACHE_DIR=str(Path('/dev/shm') / ('pytorch-simd-state-init-flydsl-' + cache_tag)),
                     ROCM_PATH='/dockerx/venvs/flex-build/lib/python3.12/site-packages/_rocm_sdk_devel')
    overlay = manifest.get('support_source_root')
    if overlay:
        probe_env['PYTHONPATH'] = os.pathsep.join([str(root / 'support_startup_v4'), str(root / 'model_deps')])
        probe_env['BENCHMARK_SUPPORT_SOURCE_ROOT'] = overlay
    command = [sys.executable, '-m', 'torch.distributed.run', '--standalone', '--nproc_per_node=2',
               str(root / 'probe_fsdp_state_init_mixed_v6.py'), '--output', str(proof_path)]
    with Path('/dev/shm/pytorch-simd-v2-entry.lock').open('a') as entry:
        fcntl.flock(entry, fcntl.LOCK_EX)
        with Path('/dev/shm/pytorch-simd-v2-benchmark.lock').open('a') as timing:
            fcntl.flock(timing, fcntl.LOCK_EX)
            with proof_path.with_suffix('.log').open('w') as log:
                process = subprocess.Popen(command, cwd=root, env=probe_env, stdout=log,
                                           stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    returncode = process.wait(timeout=600)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
                    raise RuntimeError('Reserved FSDP state initialization validation timed out') from None
                if returncode:
                    raise RuntimeError(f'Reserved FSDP state initialization validation failed: {returncode}')
    proof = json.loads(proof_path.read_text())
    if (proof.get('status') != 'passed' or proof.get('world_size') != 2
        or {record.get('rank') for record in proof.get('ranks', [])} != {0, 1}
        or len(proof.get('variants', [])) != 4
        or {(record['backend'], record['autotune']) for record in proof.get('variants', [])}
        != {(backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]}):
        raise RuntimeError('Incomplete FSDP state initialization validation')
    for variant in proof['variants']:
        if (variant.get('backend_selection') != (variant['backend'] == 'flydsl') or not variant.get('first_fsdp_forward_compiled') or variant.get('prior_eager_fsdp_forward_backward') is not False
            or not variant.get('full_optimizer_update_checked') or not variant.get('full_gradient_parameter_tensors')
            or variant.get('max_autotune_pointwise') != bool(variant['autotune'])
            or variant.get('triton_autotune_pointwise') != bool(variant['autotune'])):
            raise RuntimeError('FSDP state initialization validation did not exercise the complete training protocol')
    for name, expected in proof['source_hashes'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
            raise RuntimeError(f'FSDP state initialization validation source changed: {name}')
    source_root = Path(overlay) if overlay else root / 'pytorch'
    expected_paths = [root / 'fsdp_state_init_v3.py', root / 'probe_fsdp_state_init_mixed_v6.py',
                      source_root / 'torch/_inductor/scheduler.py',
                      source_root / 'torch/_inductor/codegen/simd.py',
                      source_root / 'torch/_inductor/codegen/flydsl/flydsl_simd.py',
                      source_root / 'torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py']
    if not {str(path.resolve()) for path in expected_paths} <= proof['source_hashes'].keys():
        raise RuntimeError('FSDP validation did not cover the expected helper and backend sources')
