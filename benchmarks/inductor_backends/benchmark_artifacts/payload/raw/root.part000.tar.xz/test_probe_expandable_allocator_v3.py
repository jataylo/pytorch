import ast
from pathlib import Path
from types import SimpleNamespace

import torch
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


PROBE = Path(__file__).with_name('probe_expandable_allocator_v3.py')


@instantiate_parametrized_tests
class TestExpandableProbePreparation(TestCase):
    def test_allocator_and_rank_cache_environment_precedes_torch(self):
        tree = ast.parse(PROBE.read_text())
        prefix = []
        for node in tree.body:
            if isinstance(node, ast.Import) and any(alias.name == 'torch' for alias in node.names):
                break
            if not isinstance(node, (ast.Import, ast.ImportFrom)):
                prefix.append(node)
        code = compile(ast.Module(body=prefix, type_ignores=[]), str(PROBE), 'exec')
        environment = {'TORCHINDUCTOR_CACHE_DIR': '/fresh/inductor', 'RANK': '1',
                       'PYTORCH_CUDA_ALLOC_CONF': 'expandable_segments:False',
                       'PYTORCH_HIP_ALLOC_CONF': 'expandable_segments:False'}
        exec(code, {'os': SimpleNamespace(environ=environment), 'sys': SimpleNamespace(modules={}), 'Path': Path})
        self.assertEqual(environment['PYTORCH_ALLOC_CONF'], 'expandable_segments:True')
        self.assertNotIn('PYTORCH_CUDA_ALLOC_CONF', environment)
        self.assertNotIn('PYTORCH_HIP_ALLOC_CONF', environment)
        self.assertEqual(environment['TORCHINDUCTOR_CACHE_DIR'], '/fresh/inductor/rank1')
        self.assertEqual(environment['TRITON_CACHE_DIR'], '/fresh/triton/rank1')
        self.assertEqual(environment['FLYDSL_RUNTIME_CACHE_DIR'], '/fresh/flydsl/rank1')
        with self.assertRaisesRegex(RuntimeError, 'before importing Torch'):
            exec(code, {'sys': SimpleNamespace(modules={'torch': object()})})

    @parametrize('backend', ['triton', 'flydsl'])
    @parametrize('tune', [0, 1])
    def test_actual_probe_config_keys_and_policy(self, backend, tune):
        from torch._inductor import config

        tree = ast.parse(PROBE.read_text())
        assignments = [node.value for node in ast.walk(tree) if isinstance(node, ast.Assign) and
                       any(isinstance(target, ast.Name) and target.id == 'settings' for target in node.targets)]
        self.assertEqual(len(assignments), 1)
        settings = eval(compile(ast.Expression(assignments[0]), str(PROBE), 'eval'), {'backend': backend, 'tune': tune})
        with config.patch(settings):
            self.assertEqual(config.flydsl.simd, backend == 'flydsl')
            self.assertEqual(config.max_autotune_pointwise, bool(tune))
            self.assertEqual(config.triton.autotune_pointwise, bool(tune))
            self.assertFalse(config.max_autotune_gemm)
            self.assertEqual(config.max_autotune_gemm_backends, 'ATEN')
            self.assertEqual(config.max_autotune_conv_backends, 'ATEN')
            self.assertFalse(config.conv_1x1_as_mm)

    @parametrize('dtype', [torch.float32, torch.bfloat16])
    def test_reference_full_gradient_and_nontrivial_exact_update(self, dtype):
        initial = ((torch.arange(16) % 4) - 2).to(dtype)
        x = ((torch.arange(16) % 4) + 1).to(dtype)
        parameter = torch.nn.Parameter(initial.clone())
        optimizer = torch.optim.SGD([parameter], lr=0.125, foreach=True)
        output = (parameter * x + x).float()
        output.sum().backward()
        self.assertEqual(parameter.grad, x, atol=0, rtol=0)
        optimizer.step()
        self.assertEqual(parameter, initial - x * 0.125, atol=0, rtol=0)
        self.assertTrue(bool((parameter != initial).all()))


if __name__ == '__main__':
    run_tests()
