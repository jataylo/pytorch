import hashlib
import json
from pathlib import Path
import tempfile

from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase

from check_dino_preflight_v4 import verify_dino_preflight


@instantiate_parametrized_tests
class TestDinoPreflightEvidence(TestCase):
    @parametrize('case', ['valid', 'missing_mode', 'numeric_warning', 'wrong_fp', 'wrong_scheduler',
                         'timing_recompile', 'protocol_mismatch', 'policy_mismatch', 'fly_no_mixed',
                         'fly_backend_fallback', 'fly_tune_disabled', 'native_no_mixed', 'workaround'])
    def test_actual_record_contract(self, case):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            scheduler = root / 'source/torch/_inductor/scheduler.py'
            scheduler.parent.mkdir(parents=True)
            scheduler.write_text('synthetic scheduler source\n')
            scheduler_hash = hashlib.sha256(scheduler.read_bytes()).hexdigest()
            fingerprint = {'source_root': str(root / 'source'), 'sha256': 'synthetic-fingerprint',
                           'sources': {'torch/_inductor/scheduler.py': scheduler_hash}}
            model = {'suite': 'synthetic', 'model': 'synthetic_dino', 'physical_gpu': 'synthetic_gpu', 'world_size': 1}
            folder = root / 'results/raw/case'
            folder.mkdir(parents=True)
            kernel = 'def kernel(x, RSPLIT_SIZE):\n    return x\n'
            if case == 'native_no_mixed':
                kernel = 'def kernel(x):\n    return x\n'
            wrapper = root / 'wrapper.py'
            wrapper.write_text(f'async_compile.triton("kernel", {kernel!r})\n')
            audit = root / 'audit.json'
            audit.write_text(json.dumps({'graphs': [{'wrapper': str(wrapper)}]}))
            paths = []
            for backend in ['triton', 'flydsl']:
                for tune in [0, 1]:
                    record = {**model, 'backend': backend, 'autotune': tune, 'status': 'ok',
                              'batch_size': 4, 'model_config_sha256': 'synthetic-config', 'inputs': {'x': [4, 16]},
                              'dtype': 'amp_bf16', 'parameters': 16, 'optimizer': 'synthetic-SGD',
                              'checkpoint': False, 'launch_environment_overrides': {}, 'timing_warmup': 30,
                              'eager_reference_status': 'available', 'validation_warnings': [],
                              'source_fingerprint': {'sha256': fingerprint['sha256']},
                              'loaded_scheduler_source': {str(scheduler): scheduler_hash}, 'timing_recompiles': 0,
                              'training_parameters_with_gradients': 16, 'final_training_loss': 0.25,
                              'backend_selection': False,
                              'inductor_config': {'flydsl.simd_autotune_backend': False, 'max_autotune': False,
                                  'max_autotune_gemm': False, 'max_autotune_gemm_backends': 'ATEN',
                                  'max_autotune_conv_backends': 'ATEN', 'conv_1x1_as_mm': False,
                                  'max_autotune_pointwise': bool(tune), 'triton.autotune_pointwise': bool(tune)},
                              'codegen_audit': {'graphs': 1, 'file': str(audit)},
                              'dynamo_stats': {'stats': {'unique_graphs': 1}},
                              'flydsl_counters': {'flydsl_kernels': 3, 'mix_order': 1, 'triton_kernels': 0,
                                                 'autotuned_kernels': tune}}
                    if case == 'workaround':
                        record['launch_environment_overrides']['TORCHINDUCTOR_MIX_ORDER_REDUCTION'] = '0'
                    path = folder / f'{backend}_{tune}.json'
                    path.write_text(json.dumps(record))
                    paths.append(path)
            if case == 'missing_mode':
                paths[-1].unlink()
            elif case not in {'valid', 'native_no_mixed', 'workaround'}:
                path = paths[-1]
                record = json.loads(path.read_text())
                if case == 'numeric_warning':
                    record['status'] = 'numerical_warning'
                elif case == 'wrong_fp':
                    record['source_fingerprint']['sha256'] = 'different'
                elif case == 'wrong_scheduler':
                    record['loaded_scheduler_source'][str(scheduler)] = 'different'
                elif case == 'timing_recompile':
                    record['timing_recompiles'] = 1
                elif case == 'protocol_mismatch':
                    record['inputs'] = {'x': [4, 32]}
                elif case == 'policy_mismatch':
                    record['inductor_config']['max_autotune_gemm_backends'] = 'TRITON'
                elif case == 'fly_no_mixed':
                    record['flydsl_counters']['mix_order'] = 0
                elif case == 'fly_backend_fallback':
                    record['flydsl_counters']['triton_kernels'] = 1
                elif case == 'fly_tune_disabled':
                    record['flydsl_counters']['autotuned_kernels'] = 0
                path.write_text(json.dumps(record))
            if case == 'valid':
                proof = verify_dino_preflight(root / 'results', model, fingerprint)
                self.assertEqual(proof['status'], 'passed')
                self.assertEqual(len(proof['records']), 4)
            else:
                with self.assertRaises(RuntimeError):
                    verify_dino_preflight(root / 'results', model, fingerprint)


if __name__ == '__main__':
    run_tests()
