import hashlib
import json
from pathlib import Path
import subprocess


root = Path(__file__).resolve().parent
clone = root / 'pytorch'
files = ['torch/_inductor/config.py',
         'torch/_inductor/codegen/flydsl/flydsl_simd.py',
         'torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py',
         'torch/_inductor/codegen/flydsl/flydsl_diagnostics.py',
         'test/inductor/test_flydsl_autotune.py']
helpers = ['train_worker_v2.py', 'run_suite_v2.py', 'run_fsdp_v2.py', 'collect_codegen_v2.py',
           'benchmark_all_v2.py', 'analyze_v2.py',
           'benchmark_matrix_v2.json', 'model_manifest_v2.json', 'build.sh', 'run_env.sh']
fingerprint = {'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone, text=True).strip(),
               'source_modified': True,
               'sources': {file: hashlib.sha256((clone / file).read_bytes()).hexdigest() for file in files},
               'harness': {file: hashlib.sha256((root / file).read_bytes()).hexdigest() for file in helpers}}
fingerprint['sha256'] = hashlib.sha256(json.dumps(fingerprint, sort_keys=True).encode()).hexdigest()
(root / 'source_fingerprint_v2.json').write_text(json.dumps(fingerprint, indent=2) + '\n')
patch = subprocess.check_output(['git', 'diff', '--', *files], cwd=clone)
for file in files:
    tracked = subprocess.run(['git', 'ls-files', '--error-unmatch', file], cwd=clone, capture_output=True)
    if tracked.returncode:
        addition = subprocess.run(['git', 'diff', '--no-index', '/dev/null', file], cwd=clone, capture_output=True)
        patch += addition.stdout
(root / 'flydsl_autotune_v2.patch').write_bytes(patch)
print(json.dumps(fingerprint, indent=2))
