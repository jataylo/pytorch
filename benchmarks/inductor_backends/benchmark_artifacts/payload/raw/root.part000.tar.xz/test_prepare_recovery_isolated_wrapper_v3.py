from pathlib import Path
import tempfile
from unittest.mock import patch

import test_prepare_fsdp_state_recovery_v3 as fixtures
from torch.testing._internal.common_utils import run_tests


TestPrepareFSDPStateRecovery = fixtures.TestPrepareFSDPStateRecovery

if __name__ == '__main__':
    source = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix='recovery-fixture-sources-', dir='/tmp') as temporary:
        root = Path(temporary)
        for path in source.iterdir():
            if not path.name.startswith('training_results'):
                (root / path.name).symlink_to(path)
        with patch.object(fixtures, 'ROOT', root):
            run_tests()
