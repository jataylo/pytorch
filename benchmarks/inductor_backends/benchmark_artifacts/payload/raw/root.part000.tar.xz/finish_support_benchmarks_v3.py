import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


root = Path(__file__).resolve().parent
state_path = root / 'support_pipeline_v3.json'


def state(stage, **details):
    value = {'stage': stage, 'time': time.time(), **details}
    state_path.write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps(value), flush=True)


def run(name, *arguments, no_site=False):
    state('running', script=name, arguments=arguments)
    subprocess.run([sys.executable, *(['-S'] if no_site else []), str(root / name), *arguments],
                   cwd=root, check=True)


def check_audit(directory):
    audit = json.loads((root / directory / 'final_audit.json').read_text())
    for key in ['source_drift', 'external_source_drift', 'optional_dependency_drift',
                'input_metadata_mismatches', 'unexpected_triton_matrix_templates',
                'codegen_collection_errors', 'checkpoint_files']:
        if audit[key]:
            raise RuntimeError(f'{directory}: {key} requires review')
    unexpected = set(audit['run_fingerprints']) - {audit['expected_fingerprint']}
    if unexpected:
        raise RuntimeError(f'{directory}: unexpected run fingerprints: {unexpected}')


def reusable_validation(destination, freeze_path, plan_path):
    if not (destination / 'VERIFIED.json').exists() or not (destination / 'status.json').exists():
        return False
    try:
        previous = json.loads((destination / 'status.json').read_text())
        freeze = json.loads(freeze_path.read_text())
        plan = json.loads(plan_path.read_text())
        commands = [{key: item.get(key) for key in ['label', 'argv']} for item in previous.get('commands', [])]
    except (OSError, ValueError, TypeError):
        return False
    return bool(previous.get('finished') and previous.get('state') in {'passed', 'test_failure'}
                and not previous.get('source_drift')
                and previous.get('freeze_manifest') == freeze and commands == plan['commands'])


state('waiting_for_original_recovery_and_inventory')
required = ['training_results_v2_steady/COMPLETE.json', 'training_results_v2/final_timing_sources.csv',
            'training_results_v2/fallback_fix_worklist.json', 'training_results_v2/stable_summary.json',
            'training_results_v2/kernel_inventory/summary.json', 'baseline_fallback_review_v3.json']
while not all((root / name).exists() for name in required):
    time.sleep(5)
try:
    check_audit('training_results_v2')
    check_audit('training_results_v2_steady')
    review = json.loads((root / 'baseline_fallback_review_v3.json').read_text())
    reviewed_files = {
        'inventory_sha256': 'training_results_v2/kernel_inventory/summary.json',
        'worklist_sha256': 'training_results_v2/fallback_fix_worklist.json',
        'failures_sha256': 'training_results_v2/all_compile_execution_failures.csv',
        'freeze_sha256': 'fallback_fixes/agent_space/gpu_validation_freeze.json',
    }
    if review.get('ready_for_gpu_validation') is not True:
        raise RuntimeError('Complete the full fallback/geometry review before GPU validation')
    for key, name in reviewed_files.items():
        if review.get(key) != hashlib.sha256((root / name).read_bytes()).hexdigest():
            raise RuntimeError(f'Fallback review no longer matches {name}')
    coverage = json.loads((root / 'training_results_v2/kernel_inventory/summary.json').read_text())
    for key in ['triton_static_context_sites_without_matching_diagnostic', 'uncertain_triton_context_sites',
                'unresolved_launch_sites', 'wrapper_errors', 'record_errors', 'diagnostic_errors',
                'missing_caches', 'missing_snapshot_sources']:
        if coverage[key]:
            raise RuntimeError(f'Static coverage requires review: {key}')
    known = {'transposed access needs a 2D tile', 'online_softmax_reduce of a tuple',
             'mix-order reduction over a looped row'}
    known.update(review.get('resolved_fallback_reasons', []))
    worklist = json.loads((root / 'training_results_v2/fallback_fix_worklist.json').read_text())
    new_reasons = [item['reason'] for item in worklist if item['reason'] not in known]
    unknown_failures = []
    with (root / 'training_results_v2/all_compile_execution_failures.csv').open() as source:
        for failure in csv.DictReader(source):
            if failure.get('failure_kind') not in {'compiler_or_execution', 'external_termination'}:
                continue
            message = failure.get('error', '')
            failure_hash = hashlib.sha256(json.dumps(
                {key: failure.get(key) for key in ['model', 'phase', 'error']}, sort_keys=True).encode()).hexdigest()
            known_compiler_failure = failure.get('failure_kind') == 'compiler_or_execution' and any(
                text in message for text in ['FusedMixOrderReductions', 'Trying to backward through the graph a second time']
            )
            if failure_hash not in review.get('reviewed_failure_hashes', []) and not known_compiler_failure:
                unknown_failures.append({key: failure.get(key) for key in ['model', 'phase', 'error']})
    if new_reasons or unknown_failures:
        state('needs_new_fallback_or_failure_review', new_reasons=new_reasons, failures=unknown_failures)
        raise RuntimeError('Additional baseline failures must be reviewed before freezing the final full sweep')
    validation = 'fallback_validation_v3_tail'
    if not reusable_validation(root / validation, root / 'fallback_fixes/agent_space/gpu_validation_freeze.json',
                               root / 'fallback_gpu_plan_v3_tail.json'):
        if (root / validation).exists():
            validation += '_' + str(time.time_ns())
        run('validate_fallbacks_reserved_v2.py', str(root / 'fallback_gpu_plan_v3_tail.json'),
            '--results', validation, '--budget', '1200', '--keep-going')
    run('verify_fallback_validation_v3.py', '--results', validation)
    run('prepare_support_suite_v3.py')
    run('run_support_v3.py')
    results = 'training_results_support_v3'
    run('final_audit_v2.py', '--results', results, '--fingerprint', 'source_fingerprint_support_v3.json')
    check_audit(results)
    summary = json.loads((root / results / 'summary.json').read_text())
    if summary['observed_runs'] != 524 or summary['expected_runs'] != 524 or any(
        summary[key] for key in ['timing_overlaps', 'aten_policy_errors', 'malformed_diagnostics']
    ):
        raise RuntimeError('The final full model matrix is incomplete or failed an audit')
    run('merge_steady_v2.py', '--results', results, '--steady', 'training_results_support_v3_rechecks',
        '--manifest', 'model_manifest_support_v3.json', '--support-sweep')
    run('summarize_kernel_gaps_v2.py', '--results', results)
    run('collect_fallback_worklist_v2.py', '--results', results)
    run('collect_kernel_inventory_v3.py', '--results', str(root / results),
        '--output', str(root / results / 'kernel_inventory'), no_site=True)
    state('measurements_complete_manual_review_required', results=results,
          validation_results=validation,
          worklist=str(root / results / 'fallback_fix_worklist.json'),
          final_report=str(root / results / 'stable_report.html'))
except Exception as error:
    previous = json.loads(state_path.read_text())
    state('needs_review', failed_stage=previous, error=f'{type(error).__name__}: {error}')
    raise
