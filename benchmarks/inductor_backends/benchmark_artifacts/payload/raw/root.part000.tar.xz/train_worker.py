import argparse
import gc
import json
import os
from pathlib import Path
import statistics
import sys
import time
import traceback


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--suite', required=True)
    parser.add_argument('--model', required=True)
    parser.add_argument('--batch-size', type=int, required=True)
    parser.add_argument('--backend', choices=['triton', 'flydsl'], required=True)
    parser.add_argument('--autotune', type=int, choices=[0, 1], required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--skip-eager-reference', action='store_true')
    parser.add_argument('--warmup', type=int, default=5)
    parser.add_argument('--iterations', type=int, default=20)
    parser.add_argument('--repeats', type=int, default=5)
    args = parser.parse_args()
    result = vars(args).copy()
    result.update(status='started', mode='training', dtype='amp_bf16', checkpoint=False)
    result['physical_gpu'] = os.environ.get('CUDA_VISIBLE_DEVICES')
    started = time.monotonic()

    def save():
        result['wall_seconds'] = time.monotonic() - started
        target = Path(args.output)
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_suffix('.tmp')
        temp.write_text(json.dumps(result, indent=2, default=str) + '\n')
        temp.replace(target)

    save()
    try:
        os.environ['TORCHINDUCTOR_COMPILE_THREADS'] = '32'
        binary_cache = Path('/dev/shm/pytorch-simd-compiled-artifacts')
        binary_cache /= f"gpu{result['physical_gpu']}/{args.backend}_autotune{args.autotune}"
        binary_cache.mkdir(parents=True, exist_ok=True)
        triton_cache = Path('/dev/shm/pytorch-simd-compiled-artifacts') / f'shared_autotune{args.autotune}' / 'triton'
        os.environ['TRITON_CACHE_DIR'] = str(triton_cache)
        os.environ['FLYDSL_RUNTIME_CACHE_DIR'] = str(binary_cache / 'flydsl')
        result['compiled_artifact_cache'] = str(binary_cache)
        result['triton_binary_cache'] = str(triton_cache)
        import torch
        from torch._dynamo.utils import counters
        from torch._inductor import config

        sys.path.insert(0, '/dockerx/Triton_Conv_Development/scripts')
        from common import (
            is_diffusion_model, load_model, load_model_meta,
            make_model_input, register_grouped_mm_autocast, resolve_dtype_spec,
        )

        torch.set_num_threads(8)
        torch.manual_seed(2026)
        torch.cuda.manual_seed_all(2026)
        torch._dynamo.config.suppress_errors = False
        config.flydsl.simd = args.backend == 'flydsl'
        config.max_autotune = bool(args.autotune)
        config.max_autotune_pointwise = bool(args.autotune)
        config.triton.autotune_pointwise = bool(args.autotune)
        config.fx_graph_cache = False
        config.triton.cudagraphs = False
        result['inductor_config'] = {
            'flydsl.simd': config.flydsl.simd,
            'max_autotune': config.max_autotune,
            'max_autotune_pointwise': config.max_autotune_pointwise,
            'triton.autotune_pointwise': config.triton.autotune_pointwise,
            'max_autotune_gemm_backends': config.max_autotune_gemm_backends,
            'max_autotune_conv_backends': config.max_autotune_conv_backends,
            'triton.cudagraphs': config.triton.cudagraphs,
        }
        register_grouped_mm_autocast()
        props = torch.cuda.get_device_properties(0)
        result.update(torch_version=torch.__version__, torch_git=torch.version.git_version,
                      gpu=props.name, arch=props.gcnArchName, total_vram_bytes=props.total_memory,
                      gpu_uuid=str(props.uuid), pci_bus_id=props.pci_bus_id)
        if args.backend == 'flydsl':
            from torch._inductor.codegen.flydsl.flydsl_utils import simd_enabled
            if not simd_enabled():
                raise RuntimeError('FlyDSL SIMD was requested but is unavailable')
        spec = resolve_dtype_spec('amp_bf16')
        result['phase'] = 'model_capacity'
        save()
        meta = load_model_meta(args.model, spec)
        parameters = sum(p.numel() for p in meta.parameters())
        parameter_bytes = parameters * torch.empty((), dtype=spec.param_dtype).element_size()
        result.update(parameters=parameters, parameter_bytes=parameter_bytes,
                      component='diffusion_denoiser' if is_diffusion_model(meta) else 'full_model')
        free, _ = torch.cuda.mem_get_info()
        result['free_vram_before_load_bytes'] = free
        del meta
        gc.collect()
        if parameter_bytes * 2 > free:
            result.update(status='capacity_skip', error='FP32 weights plus gradients alone exceed free GPU memory')
            save()
            return

        result['phase'] = 'model_load'
        save()
        model = load_model(args.model, spec, 'cuda', pretrained=False).eval()
        inputs, kwargs = make_model_input(model, args.model, args.batch_size, spec, 'cuda')
        result['inputs'] = {
            k: {'shape': list(v.shape), 'dtype': str(v.dtype)} if isinstance(v, torch.Tensor) else str(v)
            for k, v in (inputs.items() if kwargs else [('input', inputs)])
        }
        optimizer = torch.optim.SGD(model.parameters(), lr=0.0001, momentum=0.0, foreach=True)
        result['optimizer'] = 'SGD(lr=0.0001, momentum=0, foreach=True)'
        result['loss'] = 'mean squared first differentiable model output; synthetic training objective'

        def objective(output):
            if isinstance(output, torch.Tensor):
                if not output.requires_grad:
                    raise RuntimeError('Model output has no gradients')
                return output.float().square().mean()
            if isinstance(output, dict):
                for key in ('logits', 'last_hidden_state', 'prediction_logits', 'sample', 'loss'):
                    if key in output and isinstance(output[key], torch.Tensor) and output[key].requires_grad:
                        return objective(output[key])
                values = output.values()
            elif isinstance(output, (tuple, list)):
                values = output
            else:
                raise RuntimeError(f'Unsupported output type: {type(output)}')
            for value in values:
                if isinstance(value, torch.Tensor) and value.requires_grad:
                    return objective(value)
            raise RuntimeError('No differentiable output found')

        def forward_loss():
            with spec.autocast('cuda'):
                output = model(**inputs) if kwargs else model(inputs)
                return objective(output)

        norms = [m for m in model.modules() if isinstance(m, torch.nn.modules.batchnorm._BatchNorm)]
        for norm in norms:
            norm.training = True
        result['validation_mode'] = 'eval with BatchNorm batch statistics' if norms else 'eval'

        result['phase'] = 'eager_validation'
        save()
        torch.manual_seed(2026)
        eager_loss = None
        eager_grads = {}
        validation_warnings = []
        if args.skip_eager_reference:
            result['eager_reference_status'] = 'skipped_for_direct_training_recheck'
            result['validation_mode'] = 'not run; direct training recheck'
            validation_warnings.append('Original validation failure archived; actual compiled training measured without a new numerical comparison')
        else:
            try:
                eager_loss = forward_loss()
                eager_loss.backward()
                torch.cuda.synchronize()
                result['eager_loss'] = eager_loss.detach().item()
                if not torch.isfinite(eager_loss).item():
                    raise RuntimeError('Eager training loss is not finite')
                named = [(name, p) for name, p in model.named_parameters() if p.grad is not None]
                result['parameters_with_gradients'] = sum(p.numel() for _, p in named)
                chosen = sorted(set([0, len(named) // 2, len(named) - 1])) if named else []
                eager_grads = {named[i][0]: named[i][1].grad.detach().flatten()[:1024].clone() for i in chosen}
                result['eager_reference_status'] = 'available'
            except torch.OutOfMemoryError as exc:
                result['eager_reference_status'] = 'out_of_memory'
                result['eager_reference_error'] = str(exc)
                eager_grads = {}
                validation_warnings.append('Eager reference exceeded memory; compiled training attempted without a numerical reference')
        eager_loss = None
        optimizer.zero_grad(set_to_none=True)
        if result['eager_reference_status'] == 'out_of_memory':
            gc.collect()
            torch.cuda.empty_cache()
        counters.clear()
        if result['eager_reference_status'] == 'available':
            compiled = torch.compile(forward_loss, backend='inductor')
            result['phase'] = 'compile_validation'
            save()
            torch.manual_seed(2026)
            compile_start = time.monotonic()
            compiled_loss = compiled()
            compiled_loss.backward()
            torch.cuda.synchronize()
            result['validation_compile_seconds'] = time.monotonic() - compile_start
            result['compiled_loss'] = compiled_loss.detach().item()
            if not torch.isfinite(compiled_loss).item():
                raise RuntimeError('Compiled training loss is not finite')
            if result['eager_reference_status'] == 'available':
                try:
                    torch.testing.assert_close(compiled_loss.detach(), torch.tensor(result['eager_loss'], device='cuda'), rtol=0.03, atol=0.003)
                except AssertionError as exc:
                    validation_warnings.append(f'loss: {exc}')
            param_map = dict(model.named_parameters())
            for name, expected in eager_grads.items():
                actual = param_map[name].grad
                if actual is None:
                    raise RuntimeError(f'Missing compiled gradient: {name}')
                sample = actual.detach().flatten()[:1024]
                if not torch.isfinite(sample).all().item():
                    raise RuntimeError(f'Compiled gradient is not finite: {name}')
                rms_error = (sample - expected).square().mean().sqrt().item()
                rms_reference = expected.square().mean().sqrt().item()
                result.setdefault('gradient_validation', {})[name] = {
                    'rms_error': rms_error,
                    'relative_rms_error': rms_error / max(rms_reference, 1e-12),
                    'reference_rms': rms_reference,
                    'max_abs_error': (sample - expected).abs().max().item(),
                }
                try:
                    torch.testing.assert_close(sample, expected, rtol=0.05, atol=0.005)
                except AssertionError as exc:
                    validation_warnings.append(f'gradient {name}: {exc}')
            result['validation'] = 'deterministic eager loss and up to 1024 elements of first/middle/last parameter gradients; normalization mode recorded separately; timing uses train mode'
            result['validation_warnings'] = validation_warnings
            del compiled_loss, eager_grads, param_map
        else:
            result['validation'] = 'Numerical comparison unavailable for this run; actual compiled training attempted directly'
            result['validation_warnings'] = validation_warnings
        optimizer.zero_grad(set_to_none=True)
        model.train()
        torch._dynamo.reset()
        counters.clear()
        compiled = torch.compile(forward_loss, backend='inductor')

        def step():
            optimizer.zero_grad(set_to_none=True)
            loss = compiled()
            loss.backward()
            optimizer.step()
            return loss

        result['phase'] = 'warmup'
        save()
        compile_start = time.monotonic()
        initial_loss = step()
        torch.cuda.synchronize()
        result['first_compiled_step_seconds'] = time.monotonic() - compile_start
        if not torch.isfinite(initial_loss).item():
            raise RuntimeError('First compiled training loss is not finite')
        gradients = [p.grad for p in model.parameters() if p.grad is not None]
        if not gradients:
            raise RuntimeError('Compiled training produced no parameter gradients')
        result['training_parameters_with_gradients'] = sum(g.numel() for g in gradients)
        for index in sorted(set([0, len(gradients) // 2, len(gradients) - 1])):
            if not torch.isfinite(gradients[index].flatten()[:1024]).all().item():
                raise RuntimeError('Compiled training produced nonfinite sampled gradients')
        del initial_loss, gradients
        for _ in range(args.warmup):
            step()
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        result['phase'] = 'timing'
        save()
        samples = []
        for _ in range(args.repeats):
            torch.cuda.synchronize()
            begin = time.perf_counter()
            for _ in range(args.iterations):
                last_loss = step()
            torch.cuda.synchronize()
            samples.append((time.perf_counter() - begin) * 1000 / args.iterations)
        if not torch.isfinite(last_loss).item():
            raise RuntimeError('Training loss is not finite after timing')
        result['final_training_loss'] = last_loss.detach().item()
        status = 'numerical_warning' if validation_warnings else 'ok'
        if result['eager_reference_status'] == 'out_of_memory':
            status = 'reference_unavailable'
        elif result['eager_reference_status'] != 'available':
            status = 'validation_unavailable'
        result.update(status=status, phase='complete', milliseconds=statistics.median(samples),
                      repeat_ms=samples, peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                      peak_reserved_bytes=torch.cuda.max_memory_reserved(),
                      flydsl_counters=dict(counters['flydsl_simd']),
                      dynamo_stats={k: dict(v) for k, v in counters.items()})
        if validation_warnings:
            result['error'] = '\n'.join(validation_warnings)
        if args.backend == 'flydsl' and not counters['flydsl_simd']['flydsl_kernels']:
            result['coverage_note'] = 'No FlyDSL kernels generated; this is a fallback-only run'
    except Exception as exc:
        result.update(status='error', error=f'{type(exc).__name__}: {exc}', traceback=traceback.format_exc())
        traceback.print_exc()
    finally:
        save()
    print(json.dumps({k: result.get(k) for k in ['model', 'backend', 'autotune', 'status', 'milliseconds', 'error']}), flush=True)


if __name__ == '__main__':
    main()
