import re


_ALLOCATION_STATUS = re.compile(
    r'\b(?:hipblas_status_alloc_failed|cublas_status_alloc_failed|'
    r'hipblaslt_status_alloc_failed|cublaslt_status_alloc_failed|'
    r'rocblas_status_memory_error|cudnn_status_alloc_failed|miopenstatusallocfailed|'
    r'hiperroroutofmemory|cudaerrormemoryallocation|cuda_error_out_of_memory)\b', re.IGNORECASE)
_GPU_OOM = re.compile(r'\b(?:cuda|hip)(?: error:)? out of memory\b', re.IGNORECASE)


def is_gpu_allocation_failure(message):
    return isinstance(message, str) and bool(_ALLOCATION_STATUS.search(message) or _GPU_OOM.search(message))


def is_terminal_gpu_memory_failure(record):
    status = record.get('status')
    if status == 'capacity_skip':
        return True
    if status not in {'error', 'timeout', 'process_failed'}:
        return False
    return any(is_gpu_allocation_failure(record.get(field)) for field in ['error', 'traceback'])
