import ast
from collections import defaultdict
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path


root = Path(__file__).resolve().parent
if not (root / 'training_results_support_v3/COMPLETE.json').exists() or not (root / 'training_results_support_v3/kernel_inventory/summary.json').exists():
    raise RuntimeError('Finish the previous fixed-source sweep and its inventory first')
prior_records = defaultdict(list)
for path in (root / 'training_results_support_v3/raw').glob('*/*.json'):
    record = json.loads(path.read_text())
    prior_records[record['suite'], record['model']].append((path, record))


def variable(record):
    times = record.get('repeat_ms', [])
    return bool(record.get('timing_recompiles') or (times and
                (max(times) / min(times) > 1.2 or statistics.median(times[:2]) / statistics.median(times[-2:]) > 1.1)))


if not (root / 'training_results_v2_steady/COMPLETE.json').exists():
    raise RuntimeError('Finish the original sweep, memory retries and steady rechecks first')
provenance = root / 'training_results_v2/final_timing_sources.csv'
if not provenance.exists():
    raise RuntimeError('Merge and review the original results before preparing the support comparison')
references = defaultdict(list)
with provenance.open() as source:
    for row in csv.DictReader(source):
        record = json.loads(Path(row['source_json']).read_text())
        references[record['suite'], record['model']].append(record)
manifest = json.loads((root / 'model_manifest_v2.json').read_text())
for model in manifest['models']:
    records = references[model['suite'], model['model']]
    if len(records) != 4:
        raise RuntimeError(f'Missing reference configurations for {model["model"]}')
    placements = {(str(record['physical_gpu']), record['world_size']) for record in records}
    if len(placements) != 1:
        raise RuntimeError(f'Inconsistent reference placement for {model["model"]}')
    gpu, world = placements.pop()
    times = [time for record in records for time in record.get('repeat_ms', []) if time > 0]
    warmup = min(2000, max(30, math.ceil(1500 / min(times)))) if times else 100
    previous = prior_records[model['suite'], model['model']]
    if len(previous) != 4 or {(item['backend'], item['autotune']) for _, item in previous} != {
        (backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]
    } or any(item['status'] == 'started' for _, item in previous):
        raise RuntimeError(f'Incomplete previous fixed-source model group: {model["model"]}')
    variable_previous = any(item.get('status') in {'ok', 'numerical_warning', 'validation_unavailable', 'reference_unavailable'} and variable(item) for _, item in previous)
    if variable_previous:
        previous_times = [value for _, item in previous for value in item.get('repeat_ms', []) if value > 0]
        if not previous_times:
            raise RuntimeError(f'No timing samples for variable model: {model["model"]}')
        warmup = max(warmup, math.ceil(15000 / min(previous_times)))
    model['warmup_reference'] = 'support_v3_variable_repeats' if variable_previous else 'original_final_repeats'
    model['warmup_target_ms'] = 15000 if variable_previous else 1500
    model['warmup_reference_hashes'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path, _ in previous} if variable_previous else {}
    overrides = dict(records[0].get('launch_environment_overrides', {}))
    if model['model'] == 'levit_128':
        overrides['BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE'] = '1'
    if model['model'] == 'vit_base_patch14_dinov2.lvd142m':
        overrides.pop('TORCHINDUCTOR_MIX_ORDER_REDUCTION', None)
    if any('mm_token_type_ids' in record.get('error', '') and 'missing' in record.get('error', '') for record in records):
        overrides['BENCHMARK_ADD_MM_TOKEN_TYPES'] = '1'
    if model['model'] == 'moonshotai/Kimi-K3':
        overrides.update(BENCHMARK_EXTRA_MODEL_DEPS='1', HF_HUB_OFFLINE='1',
                         BENCHMARK_OFFICIAL_MODEL_REVISION='f831ab66814297da540d832a5235f8e904f29d06')
    if model['model'] == 'Qwen/Qwen-Image':
        overrides['BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS'] = '1'
        if all(record['status'] == 'error' and record.get('phase') == 'fsdp_eager_initialization'
               and record.get('world_size') == 8 and 'out of memory' in (record.get('error') or '').lower()
               for _, record in previous):
            overrides['BENCHMARK_FSDP_STATE_INIT_ONLY'] = '1'
            model['fsdp_state_initialization_evidence'] = {
                str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path, _ in previous
            }
    if model['model'] in {'deepseek-ai/DeepSeek-V4-Flash-0731', 'deepseek-ai/DeepSeek-V4-Flash', 'Qwen/Qwen3.8-Flash-Next'}:
        overrides['BENCHMARK_VERIFY_FSDP_MEMORY_BOUND'] = '1'
    model.update(physical_gpu=gpu, world_size=world, steady_warmup_steps=warmup,
                 launch_environment_overrides=overrides)
manifest['protocol'] = 'Full training matrix with the recursive mixed-order fusion guard and FlyDSL support fixes; common warmup per model with a 15-second estimate for previously variable results; original final GPU placements and validated state-only FSDP initialization for eager-OOM diffusion models'
manifest['support_source_root'] = str(root / 'fallback_fixes_v4')
(root / 'model_manifest_support_v4.json').write_text(json.dumps(manifest, indent=2) + '\n')

tree = ast.parse((root / 'prepare_steady_v2.py').read_text())
replacements = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign) and
                    any(isinstance(target, ast.Name) and target.id == 'replacements' for target in node.targets))
worker = (root / 'train_worker_v2.py').read_text()
for before, after in replacements.items():
    if worker.count(before) != 1:
        raise RuntimeError(f'Unexpected worker while replacing {before!r}')
    worker = worker.replace(before, after.replace('source_fingerprint_v2_steady.json', 'source_fingerprint_support_v4.json')
                            .replace('autotune_v2_aten_steady_recheck', 'support_v4_aten_training'))
anchor = "        register_grouped_mm_autocast()"
addition = """        result['source_overlay'] = os.environ.get('TORCHINDUCTOR_FLYDSL_BASELINE_DIR')
        from torch._inductor import scheduler
        expected_scheduler = Path(__file__).resolve().parent / 'fallback_fixes_v4/torch/_inductor/scheduler.py'
        if Path(scheduler.__file__).resolve() != expected_scheduler.resolve():
            raise RuntimeError(f'Wrong scheduler source overlay: {scheduler.__file__}')
        result['loaded_scheduler_source'] = {str(expected_scheduler): hashlib.sha256(expected_scheduler.read_bytes()).hexdigest()}
        from torch._inductor.codegen import simd
        expected_simd = Path(__file__).resolve().parent / 'fallback_fixes_v4/torch/_inductor/codegen/simd.py'
        if Path(simd.__file__).resolve() != expected_simd.resolve():
            raise RuntimeError(f'Wrong shared SIMD source overlay: {simd.__file__}')
        result['loaded_simd_source'] = {str(expected_simd): hashlib.sha256(expected_simd.read_bytes()).hexdigest()}
        if args.backend == 'flydsl':
            from torch._inductor.codegen.flydsl import flydsl_simd, flydsl_simd_runtime
            expected_overlay = Path(__file__).resolve().parent / 'fallback_fixes_v4/torch/_inductor/codegen/flydsl'
            loaded = [Path(module.__file__).resolve() for module in [flydsl_simd, flydsl_simd_runtime]]
            if any(path.parent != expected_overlay.resolve() for path in loaded):
                raise RuntimeError(f'Wrong FlyDSL source overlay: {loaded}')
            result['loaded_flydsl_sources'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in loaded}
"""
if worker.count(anchor) != 1:
    raise RuntimeError('Missing overlay verification insertion point')
worker = worker.replace(anchor, addition + anchor)
compile(worker, 'train_worker_support_v4.py', 'exec')
(root / 'train_worker_support_v4.py').write_text(worker)

runner = (root / 'run_suite_v2.py').read_text()
runner = runner.replace("'train_worker_v2.py'", "'train_worker_support_v4.py'")
runner = runner.replace("default='training_results_v2'", "default='training_results_support_v4'")
runner = runner.replace("default='model_manifest_v2.json'", "default='model_manifest_support_v4.json'")
runner = runner.replace("PYTHONPATH=str(ROOT / 'model_deps'),",
                        "PYTHONPATH=os.pathsep.join([str(ROOT / 'support_startup_v4'), str(ROOT / 'model_deps')]),\n"
                        "                BENCHMARK_SUPPORT_SOURCE_ROOT=str(ROOT / 'fallback_fixes_v4'),")
runner = runner.replace("'TORCHINDUCTOR_FLYDSL_SIMD_STAGES']", "'TORCHINDUCTOR_FLYDSL_SIMD_STAGES', 'TORCHINDUCTOR_MIX_ORDER_REDUCTION', 'BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE', 'BENCHMARK_ADD_MM_TOKEN_TYPES', 'BENCHMARK_PLACEMENT_OVERRIDE', 'BENCHMARK_EXTRA_MODEL_DEPS', 'BENCHMARK_OFFICIAL_MODEL_REVISION', 'BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS', 'BENCHMARK_VERIFY_FSDP_MEMORY_BOUND', 'BENCHMARK_FSDP_STATE_INIT_ONLY', 'HF_HUB_OFFLINE']")
runner = runner.replace("    parser.add_argument('--fsdp', action='store_true')",
                        "    parser.add_argument('--fsdp', action='store_true')\n    parser.add_argument('--override-placement', action='store_true')")
runner = runner.replace("    models = manifest['models']",
                        "    models = [model for model in manifest['models'] if args.override_placement or model['physical_gpu'] == args.gpus]")
runner = runner.replace('            env.update(\n',
                        "            env.update(model.get('launch_environment_overrides', {}))\n            env.update(\n"
                        "                TORCHINDUCTOR_FLYDSL_BASELINE_DIR=str(ROOT / 'fallback_fixes_v4/torch/_inductor/codegen/flydsl'),\n"
                        "                BENCHMARK_LAUNCH_OVERRIDES=json.dumps(model.get('launch_environment_overrides', {})),\n"
                        "                BENCHMARK_PLACEMENT_OVERRIDE=str(int(args.override_placement)),\n"
                        "                BENCHMARK_STEADY_WARMUP_STEPS=str(model['steady_warmup_steps']),\n")
runner = runner.replace("\n            cmd = [sys.executable,", "\n            if model.get('launch_environment_overrides', {}).get('BENCHMARK_EXTRA_MODEL_DEPS') == '1':\n                env['PYTHONPATH'] = os.pathsep.join([str(ROOT / 'support_startup_v4'), str(ROOT / 'optional_model_deps_v3'), str(ROOT / 'model_deps')])\n            cmd = [sys.executable,")
compile(runner, 'run_suite_support_v4.py', 'exec')
(root / 'run_suite_support_v4.py').write_text(runner)
controller = (root / 'run_steady_v2.py').read_text().replace('training_results_v2_steady', 'training_results_support_v4')
controller = controller.replace('model_manifest_v2_steady.json', 'model_manifest_support_v4.json')
controller = controller.replace('run_suite_v2_steady.py', 'run_suite_support_v4.py')
controller = controller.replace('support_startup_v3', 'support_startup_v4')
controller = controller.replace('probe_fsdp_state_init_v3.py', 'probe_fsdp_state_init_v4.py')
controller = controller.replace("source_root / 'torch/_inductor/scheduler.py',",
                                "source_root / 'torch/_inductor/scheduler.py',\n                      source_root / 'torch/_inductor/codegen/simd.py',")
controller = controller.replace('Steady-state', 'Support comparison').replace('Steady-state rechecks complete.', 'Support comparison complete.')
memory_predicate = "record['status'] == 'capacity_skip' or 'out of memory' in record.get('error', '').lower()"
if controller.count(memory_predicate) != 2:
    raise RuntimeError('Unexpected memory retry predicates in the controller template')
controller = 'from allocation_failures_v3 import is_terminal_gpu_memory_failure\n' + controller
controller = controller.replace(memory_predicate, 'is_terminal_gpu_memory_failure(record)')
controller = 'from check_dino_preflight_v4 import verify_dino_preflight\n' + controller
preflight = """dino_preflight = next((model for model in manifest['models'] if model['model'] == 'vit_base_patch14_dinov2.lvd142m'), None)
if dino_preflight is not None:
    command = [sys.executable, str(root / 'run_suite_support_v4.py'), '--gpus', str(dino_preflight['physical_gpu']),
               '--timeout', '5400', '--models', dino_preflight['model']]
    if dino_preflight['world_size'] > 1:
        command.append('--fsdp')
    subprocess.run(command, cwd=root, check=True)
    fingerprint = json.loads((root / 'source_fingerprint_support_v4.json').read_text())
    proof = verify_dino_preflight(root / 'training_results_support_v4', dino_preflight, fingerprint)
    (root / 'training_results_support_v4/DINO_PREFLIGHT.json').write_text(json.dumps(proof, indent=2) + '\\n')

"""
if controller.count('groups = defaultdict(list)\n') != 1:
    raise RuntimeError('Missing DINO preflight scheduling insertion point')
controller = controller.replace('groups = defaultdict(list)\n', preflight + 'groups = defaultdict(list)\n')
compile(controller, 'run_support_v4.py', 'exec')
(root / 'run_support_v4.py').write_text(controller)

fingerprint = json.loads((root / 'source_fingerprint_v2.json').read_text())
fingerprint['parent_sha256'] = fingerprint.pop('sha256')
fingerprint['protocol'] = manifest['protocol']
fingerprint['source_root'] = str(root / 'fallback_fixes_v4')
overlaid = {'torch/_inductor/codegen/flydsl/flydsl_simd.py',
            'torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py',
            'torch/_inductor/scheduler.py', 'torch/_inductor/codegen/simd.py'}
for name in fingerprint['sources']:
    if name.startswith('torch/') and name not in overlaid:
        if (root / 'pytorch' / name).read_bytes() != (root / 'fallback_fixes_v4' / name).read_bytes():
            raise RuntimeError(f'Additional source overlay required before benchmarking {name}')
extra_tests = ['test/inductor/test_flydsl_simd.py', 'test/inductor/test_flydsl_layouts.py', 'test/inductor/test_flydsl_mix_layout.py',
               'test/inductor/test_flydsl_tuple_softmax.py', 'test/inductor/test_flydsl_scheduler_fusion.py',
               'test/inductor/test_flydsl_rng.py', 'test/inductor/test_flydsl_ocml.py',
               'test/inductor/test_flydsl_ocml_cpu.py', 'test/inductor/test_flydsl_subword_tail.py',
               'test/inductor/test_scheduler_recursive_mix.py', 'test/inductor/test_flydsl_global_tail.py', 'test/inductor/test_flydsl_symbolic_split.py']
for name in [*fingerprint['sources'], 'torch/_inductor/scheduler.py', 'torch/_inductor/codegen/simd.py', *extra_tests]:
    fingerprint['sources'][name] = hashlib.sha256((root / 'fallback_fixes_v4' / name).read_bytes()).hexdigest()
for name in ['train_worker_support_v4.py', 'run_suite_support_v4.py', 'run_support_v4.py',
             'model_manifest_support_v4.json', 'prepare_support_suite_v4.py', 'fallback_fixes_v4/agent_space/run_overlay.py',
             'model_deps/sitecustomize.py', 'support_startup_v4/sitecustomize.py',
             'multimodal_inputs_v2.py', 'optional_model_deps_v3_manifest.json',
             'diffusion_meta_constants_v3.py', 'test_diffusion_meta_constants_v3.py',
             'fsdp_memory_bound_v3.py', 'test_fsdp_memory_bound_v3.py',
             'fsdp_large_embedding_bound_v3.py', 'test_fsdp_large_embedding_bound_v3.py',
             'fsdp_state_init_v3.py', 'test_fsdp_state_init_v3.py', 'probe_fsdp_state_init_v4.py',
             'test_prepare_fsdp_state_recovery_v3.py',
             'test_prepare_support_qwen_image_v3.py',
             'merge_steady_v2.py', 'test_merge_raw_failures_v3.py', 'summarize_kernel_gaps_v2.py', 'collect_fallback_worklist_v2.py',
             'allocation_failures_v3.py', 'test_allocation_failures_v3.py', 'test_tuning_coverage_report_v3.py',
             'verify_fallback_validation_v4.py', 'test_verify_fallback_causes_v3.py', 'validate_fallbacks_reserved_v4.py',
             'fallback_gpu_plan_v4_dino.json', 'fallback_fixes_v4/agent_space/gpu_validation_freeze.json',
             'collect_kernel_inventory_v3.py', 'test_collect_kernel_inventory_v3.py',
             'finish_support_benchmarks_v4.py', 'test_support_failure_review_gate_v4.py',
             'test_reuse_fallback_validation_v3.py', 'baseline_fallback_review_v4.json',
             'guard_fatal_gpu_dumps_v3.py', 'check_dino_preflight_v4.py', 'test_check_dino_preflight_v4.py',
             'test_verify_scheduler_validation_v4.py',
             'test_prepare_support_followup_v4.py', 'fallback_fixes_v4/agent_space/check_gpu_guards.py']:
    fingerprint['harness'][name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
fingerprint['sha256'] = hashlib.sha256(json.dumps(fingerprint, sort_keys=True).encode()).hexdigest()
(root / 'source_fingerprint_support_v4.json').write_text(json.dumps(fingerprint, indent=2) + '\n')
print(json.dumps({'models': len(manifest['models']), 'configurations': len(manifest['models']) * 4,
                  'fingerprint': fingerprint['sha256']}, indent=2))
