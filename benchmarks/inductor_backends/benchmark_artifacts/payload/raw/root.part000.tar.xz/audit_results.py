from collections import Counter
import json
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
models = json.loads((ROOT / 'model_manifest.json').read_text())['models']
records = [json.loads(p.read_text()) for p in (ROOT / 'training_results/raw').glob('*/*.json')]
expected = {(m['suite'], m['model'], backend, tune) for m in models for backend in ['triton', 'flydsl'] for tune in [0, 1]}
actual = [(r['suite'], r['model'], r['backend'], r['autotune']) for r in records]
problems = []
if set(actual) != expected or len(actual) != len(expected):
    problems.append('Missing, extra or duplicate primary configurations')
for r in records:
    identity = f"{r['model']}/{r['backend']}/{r['autotune']}"
    if r['status'] == 'started':
        problems.append(f'{identity}: unfinished')
    if r.get('checkpoint') is not False:
        problems.append(f'{identity}: missing no-checkpoint metadata')
    if r.get('torch_git') and r['torch_git'] != '937d7fd7cdb37e3136c90e86ca71b57d8e5193be':
        problems.append(f'{identity}: unexpected torch commit')
    if 'milliseconds' in r:
        value = r['milliseconds']
        if not math.isfinite(value) or value <= 0 or len(r.get('repeat_ms', [])) != 5:
            problems.append(f'{identity}: invalid timing or repeats')
        elif not math.isclose(value, statistics.median(r['repeat_ms']), rel_tol=1e-10):
            problems.append(f'{identity}: timing differs from recorded median')
        if r.get('iterations') != 10 or r.get('warmup') != 5:
            problems.append(f'{identity}: inconsistent iteration or warmup counts')
for m in models:
    measured = [r for r in records if r['suite'] == m['suite'] and r['model'] == m['model'] and 'milliseconds' in r]
    if len({r['physical_gpu'] for r in measured}) > 1 or len({r.get('gpu_uuid') for r in measured}) > 1:
        problems.append(f"{m['model']}: measurements span different GPUs")
checkpoint_files = [str(p) for p in (ROOT / 'hf_config_cache').rglob('*') if p.is_file() and p.suffix in ['.safetensors', '.bin', '.pt', '.pth', '.ckpt']]
if checkpoint_files:
    problems.append('Checkpoint files present in model cache')
report = {'expected_configurations': len(expected), 'actual_configurations': len(actual),
          'models': len(models), 'statuses': dict(Counter(r['status'] for r in records)),
          'measured_configurations': sum('milliseconds' in r for r in records),
          'checkpoint_files': checkpoint_files, 'problems': problems}
(ROOT / 'training_results/audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
if problems:
    raise RuntimeError('Result audit failed')
