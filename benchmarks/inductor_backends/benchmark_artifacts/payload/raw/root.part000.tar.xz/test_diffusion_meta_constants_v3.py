from pathlib import Path
import sys

import torch
from diffusers.models.transformers.transformer_qwenimage import QwenEmbedLayer3DRope, QwenEmbedRope
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests,
    parametrize,
    run_tests,
    TestCase,
)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from diffusion_meta_constants_v3 import restore_diffusion_meta_constants


@instantiate_parametrized_tests
class TestDiffusionMetaConstants(TestCase):
    @parametrize("rope_type", [QwenEmbedRope, QwenEmbedLayer3DRope])
    @parametrize("scale_rope", [False, True])
    @parametrize("meta", [False, True])
    def test_qwen_tables_match_real_constructor(self, rope_type, scale_rope, meta):
        kwargs = {"theta": 10000, "axes_dim": [16, 56, 56], "scale_rope": scale_rope}
        reference = rope_type(**kwargs)
        with torch.device("meta" if meta else "cpu"):
            rope = rope_type(**kwargs)
        model = torch.nn.Module()
        model.add_module("pos_embed", rope)
        self.assertEqual(rope.pos_freqs.is_meta, meta)
        self.assertEqual(dict(model.named_buffers()), {})
        if meta:
            with self.assertRaisesRegex(NotImplementedError, "Cannot copy out of meta tensor"):
                rope._get_device_freqs(torch.device("cpu"))
        with torch.device("meta"):
            changes = restore_diffusion_meta_constants(model)
        self.assertEqual(len(changes), 2)
        self.assertTrue(all(change["was_meta"] == meta for change in changes))
        self.assertEqual(dict(model.named_buffers()), {})
        self.assertIs(model.pos_embed, rope)
        actual = rope._get_device_freqs(torch.device("cpu"))
        self.assertEqual(actual, (reference.pos_freqs, reference.neg_freqs))
        self.assertEqual(actual[0].dtype, torch.complex64)
        self.assertGreater(actual[0].imag.abs().sum().item(), 0)
        self.assertEqual(rope.theta, 10000)
        self.assertEqual(rope.axes_dim, [16, 56, 56])
        self.assertEqual(rope.scale_rope, scale_rope)

    @parametrize("container", ["direct", "nested", "cycle"])
    def test_unknown_meta_constants_raise_with_path(self, container):
        model = torch.nn.Module()
        value = torch.empty((3, 5), device="meta", dtype=torch.complex64)
        if container == "direct":
            model.frequencies = value
        elif container == "nested":
            model.frequencies = {"values": [value]}
        else:
            model.frequencies = {"values": [value]}
            model.frequencies["self"] = model.frequencies
        with self.assertRaisesRegex(RuntimeError, "Unregistered meta tensor state.*frequencies"):
            restore_diffusion_meta_constants(model)
        self.assertTrue(value.is_meta)

    def test_registered_meta_state_is_left_to_fsdp(self):
        model = torch.nn.Linear(3, 5, device="meta")
        model.register_buffer("frequencies", torch.empty((5,), device="meta"))
        self.assertEqual(restore_diffusion_meta_constants(model), [])
        self.assertTrue(model.weight.is_meta)
        self.assertTrue(model.frequencies.is_meta)


if __name__ == "__main__":
    run_tests()
