import csv
import json
from pathlib import Path
import subprocess
import sys
import tempfile

from torch.testing._internal.common_utils import run_tests, TestCase


class TestTuningCoverageReport(TestCase):
    def run_merge(self, events):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        root = Path(directory.name)
        (root / 'manifest.json').write_text(json.dumps({'models': []}))
        (root / 'kernel_decisions.jsonl').write_text(''.join(json.dumps(event) + '\n' for event in events))
        subprocess.run([sys.executable, str(Path(__file__).with_name('merge_steady_v2.py')),
                        '--results', str(root), '--steady', str(root / 'missing'),
                        '--manifest', str(root / 'manifest.json')], check=True, stdout=subprocess.DEVNULL)
        return root

    def test_capacity_guards_are_not_unsupported_lowerings(self):
        common = dict(suite='suite', model='model', requested_backend='flydsl', autotune=1,
                      attempt_id='attempt', rank=0, phase='warmup')
        events = [
            dict(common, category='autotune_selection', kernel_name='guarded', selected_candidate=0,
                 reason='insufficient scratch memory', candidate_times_ms=None),
            dict(common, category='autotune_selection', kernel_name='timed', selected_candidate=1,
                 candidate_times_ms=[1.0, 0.8]),
            dict(common, category='lowered', kernel_name='fallback', backend='triton', reason='unsupported schedule'),
        ]
        root = self.run_merge(events)
        summary = json.loads((root / 'stable_summary.json').read_text())
        self.assertEqual(summary['autotune_selection_events'], 2)
        self.assertEqual(summary['autotune_selection_reasons'],
                         {'insufficient scratch memory': 1, 'candidate timings recorded': 1})
        with (root / 'all_autotune_selections.csv').open() as stream:
            tuning = list(csv.DictReader(stream))
        self.assertEqual({record['kernel_name'] for record in tuning}, {'guarded', 'timed'})
        self.assertEqual({record['selected_for_final_timing'] for record in tuning}, {'False'})
        with (root / 'all_unsupported_flydsl_kernels.csv').open() as stream:
            unsupported = list(csv.DictReader(stream))
        self.assertEqual([record['kernel_name'] for record in unsupported], ['fallback'])

    def test_no_tuning_events(self):
        root = self.run_merge([])
        summary = json.loads((root / 'stable_summary.json').read_text())
        self.assertEqual(summary['autotune_selection_events'], 0)
        self.assertEqual(summary['autotune_selection_reasons'], {})


if __name__ == '__main__':
    run_tests()
