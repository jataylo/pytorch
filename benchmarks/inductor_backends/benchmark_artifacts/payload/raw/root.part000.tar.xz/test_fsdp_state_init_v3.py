import ast
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import torch
from torch.testing._internal.common_utils import run_tests, TestCase

from fsdp_state_init_v3 import initialize_fsdp_state_for_compile


class FakeFSDP:
    def __init__(self, events, root=True):
        self.events = events
        self.root = root

    def check_is_root(self):
        self.events.append('root')
        return self.root

    def __call__(self):
        raise AssertionError('Model execution is forbidden during state initialization')


class TestFSDPStateInitialization(TestCase):
    def contexts(self, events, initialized=True):
        self.enterContext(patch('torch.distributed.fsdp.FullyShardedDataParallel', FakeFSDP))
        self.enterContext(patch('torch.distributed.is_initialized', return_value=initialized))
        self.enterContext(patch('torch.cuda.synchronize', side_effect=lambda: events.append('synchronize')))
        self.enterContext(patch('torch.distributed.barrier', side_effect=lambda: events.append('barrier')))
        self.enterContext(patch('torch.distributed.get_rank', return_value=1))
        self.enterContext(patch('torch.distributed.get_world_size', return_value=2))

    def test_order_and_no_model_execution(self):
        events = []
        self.contexts(events)
        result = initialize_fsdp_state_for_compile(FakeFSDP(events))
        self.assertEqual(events, ['root', 'synchronize', 'barrier'])
        self.assertEqual(result, {'method': 'public_fsdp_check_is_root', 'rank': 1, 'world_size': 2,
                                  'model_forward_calls': 0, 'model_backward_calls': 0})

    def test_reject_non_fsdp(self):
        events = []
        self.contexts(events)
        with self.assertRaisesRegex(TypeError, 'root FullyShardedDataParallel'):
            initialize_fsdp_state_for_compile(torch.nn.Linear(2, 2))
        self.assertEqual(events, [])

    def test_reject_no_process_group(self):
        events = []
        self.contexts(events, initialized=False)
        with self.assertRaisesRegex(RuntimeError, 'initialized process group'):
            initialize_fsdp_state_for_compile(FakeFSDP(events))
        self.assertEqual(events, [])

    def test_reject_non_root(self):
        events = []
        self.contexts(events)
        with self.assertRaisesRegex(RuntimeError, 'root FSDP instance'):
            initialize_fsdp_state_for_compile(FakeFSDP(events, root=False))
        self.assertEqual(events, ['root'])

    def test_initialization_failure_propagates(self):
        events = []
        self.contexts(events)
        model = FakeFSDP(events)
        with patch.object(model, 'check_is_root', side_effect=RuntimeError('actual initialization failure')):
            with self.assertRaisesRegex(RuntimeError, 'actual initialization failure'):
                initialize_fsdp_state_for_compile(model)
        self.assertEqual(events, [])

    def test_synchronization_failure_stops_before_barrier(self):
        events = []
        self.contexts(events)
        with patch('torch.cuda.synchronize', side_effect=RuntimeError('device synchronization failed')):
            with self.assertRaisesRegex(RuntimeError, 'device synchronization failed'):
                initialize_fsdp_state_for_compile(FakeFSDP(events))
        self.assertEqual(events, ['root'])

    def test_barrier_failure_propagates(self):
        events = []
        self.contexts(events)
        with patch('torch.distributed.barrier', side_effect=RuntimeError('collective failed')):
            with self.assertRaisesRegex(RuntimeError, 'collective failed'):
                initialize_fsdp_state_for_compile(FakeFSDP(events))
        self.assertEqual(events, ['root', 'synchronize'])

    def test_probe_configures_distinct_caches_before_torch(self):
        tree = ast.parse(Path(__file__).with_name('probe_fsdp_state_init_v3.py').read_text())
        prefix = []
        for node in tree.body:
            if isinstance(node, ast.Import) and any(alias.name == 'torch' for alias in node.names):
                break
            if not isinstance(node, (ast.Import, ast.ImportFrom)):
                prefix.append(node)
        code = compile(ast.Module(body=prefix, type_ignores=[]), '<probe cache setup>', 'exec')
        for rank in ['0', '1']:
            environment = {'TORCHINDUCTOR_CACHE_DIR': '/fresh/inductor', 'RANK': rank}
            scope = {'os': SimpleNamespace(environ=environment), 'sys': SimpleNamespace(modules={}), 'Path': Path}
            exec(code, scope)
            self.assertEqual(environment['TORCHINDUCTOR_CACHE_DIR'], f'/fresh/inductor/rank{rank}')
            self.assertEqual(environment['TRITON_CACHE_DIR'], f'/fresh/triton/rank{rank}')
            self.assertEqual(environment['FLYDSL_RUNTIME_CACHE_DIR'], f'/fresh/flydsl/rank{rank}')
        with self.assertRaisesRegex(RuntimeError, 'directly'):
            exec(code, {'sys': SimpleNamespace(modules={'torch': object()})})

    def test_probe_config_keys_exist(self):
        from torch._inductor import config

        tree = ast.parse(Path(__file__).with_name('probe_fsdp_state_init_v3.py').read_text())
        patches = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and
                   isinstance(node.func, ast.Attribute) and node.func.attr == 'patch' and node.args]
        self.assertEqual(len(patches), 1)
        with config.patch(ast.literal_eval(patches[0].args[0])):
            self.assertEqual(config.max_autotune_gemm_backends, 'ATEN')


if __name__ == '__main__':
    run_tests()
