from xml.etree import ElementTree

from torch.testing._internal.common_utils import TestCase, run_tests
from build_live_three_backend_v8 import build_rows, choose_pure, choose_references, runtime_svg, summary_rows


def record(ms=10, gpu='0', world=1):
    return dict(suite='test', model='toy', backend='flydsl', autotune=1, status='ok', milliseconds=ms,
                repeat_ms=[ms] * 5, physical_gpu=gpu, world_size=world, batch_size=1, parameters=10,
                dtype='amp_bf16', model_config_sha256='same', diagnostics_file='/nonexistent',
                source_fingerprint={'sources': {'torch/core.py': 'same'}})


class TestLiveThreeBackend(TestCase):
    def test_historical_other_gpu_labeled(self):
        pure, source = choose_pure(('test', 'toy'), 1, record(), {}, {('test', 'toy', 'flydsl', 1): record(8, '4')})
        self.assertEqual(pure['physical_gpu'], '4')
        self.assertEqual(source, 'historical_pure_flydsl_v4')

    def test_wrong_world_not_substituted(self):
        pure, source = choose_pure(('test', 'toy'), 1, record(), {}, {('test', 'toy', 'flydsl', 1): record(8, '0,1', 2)})
        self.assertIsNone(pure)
        self.assertEqual(source, 'pending_fresh_pure_flydsl')

    def test_wrong_compiler_not_substituted(self):
        old = record()
        old['source_fingerprint'] = {'sources': {'torch/core.py': 'different'}}
        self.assertIsNone(choose_pure(('test', 'toy'), 1, record(), {}, {('test', 'toy', 'flydsl', 1): old})[0])

    def test_fresh_preferred(self):
        fresh, old = record(9), record(8)
        pure, source = choose_pure(('test', 'toy'), 1, record(), {('test', 'toy', 'flydsl', 1): fresh}, {('test', 'toy', 'flydsl', 1): old})
        self.assertEqual(pure['milliseconds'], 9)
        self.assertEqual(source, 'fresh_pure_flydsl')

    def test_partial_multi_does_not_replace_single_pair(self):
        single = {('test', 'toy', 'triton', 1): record(10), ('test', 'toy', 'flydsl', 1): record(8)}
        multi = {('test', 'toy', 'triton', 1): record(9, '0,1', 2)}
        native, mixed, protocol = choose_references(('test', 'toy'), 1, single, multi)
        self.assertEqual(protocol, 'current_single_gpu')
        self.assertEqual(native['world_size'], 1)

    def test_pure_pending_preserves_current_mix_ratio(self):
        manifest = {'models': [dict(suite='test', model='toy', batch_size=1)]}
        single = {( 'test', 'toy', backend, tune): record(10 if backend == 'triton' else 8)
                  for backend in ['triton', 'flydsl'] for tune in [0, 1]}
        rows, _ = build_rows(manifest, single, {}, {}, {})
        self.assertEqual(len(rows), 2)
        self.assertIsNone(rows[0]['flydsl_ms'])
        self.assertEqual(rows[0]['mix_speedup_percent'], 20)
        self.assertFalse(rows[0]['headline_eligible'])
        self.assertTrue(rows[0]['current_pair_validated_stable'])

    def test_historical_not_final_headline(self):
        manifest = {'models': [dict(suite='test', model='toy', batch_size=1)]}
        single = {('test', 'toy', backend, tune): record(10 if backend == 'triton' else 8)
                  for backend in ['triton', 'flydsl'] for tune in [0, 1]}
        historical = {('test', 'toy', 'flydsl', tune): record(9, '3') for tune in [0, 1]}
        rows, _ = build_rows(manifest, single, {}, {}, historical)
        self.assertFalse(rows[0]['headline_eligible'])
        self.assertTrue(rows[0]['preview_three_way_validated_stable'])
        self.assertIn('historical_preview/', rows[0]['evidence_tier'])
        summaries = summary_rows(rows)
        self.assertTrue(any(value['cohort'].startswith('HISTORICAL_PREVIEW') for value in summaries))

    def test_svg_has_three_numeric_bars(self):
        row = dict(model='test<a&b', tuning='expanded', preview_three_way_validated_stable=True,
                   triton_ms=10, flydsl_ms=9, mix_ms=8, gpu_count=1, flydsl_origin='historical', reference_protocol='current')
        source = runtime_svg([row], 'expanded')
        ElementTree.fromstring(source)
        self.assertEqual(source.count('<title>test&lt;a&amp;b:'), 3)
        self.assertIn('10.00', source)
        self.assertIn('runtime (ms)', source)


if __name__ == '__main__':
    run_tests()
