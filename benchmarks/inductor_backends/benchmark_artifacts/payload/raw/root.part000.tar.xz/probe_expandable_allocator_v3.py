import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

if 'torch' in sys.modules:
    raise RuntimeError('Launch the allocator probe directly before importing Torch')
os.environ['PYTORCH_ALLOC_CONF'] = 'expandable_segments:True'
os.environ.pop('PYTORCH_CUDA_ALLOC_CONF', None)
os.environ.pop('PYTORCH_HIP_ALLOC_CONF', None)
cache_root = os.environ.get('TORCHINDUCTOR_CACHE_DIR')
if not cache_root:
    raise RuntimeError('Set a fresh TORCHINDUCTOR_CACHE_DIR base for this probe')
for variable, subdir in [('TORCHINDUCTOR_CACHE_DIR', 'inductor'), ('TRITON_CACHE_DIR', 'triton'),
                         ('FLYDSL_RUNTIME_CACHE_DIR', 'flydsl')]:
    base = os.environ.get(variable, str(Path(cache_root).parent / subdir))
    os.environ[variable] = str(Path(base) / ('rank' + os.environ['RANK']))

import torch
import torch.distributed as dist
from torch._dynamo.utils import counters
from torch._inductor import config
from torch._inductor.utils import run_and_get_code

from allocator_fragmentation_v3 import require_expandable_allocation


N = 1 << 21


def allocation_proof(tensor):
    if not tensor.is_contiguous():
        raise RuntimeError('Expandable-allocation proof requires a complete contiguous test tensor')
    torch.cuda.synchronize()
    return require_expandable_allocation(torch.cuda.memory._snapshot(), tensor.data_ptr(),
                                         tensor.numel() * tensor.element_size(), tensor.device.index)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    rank = int(os.environ['RANK'])
    local_rank = int(os.environ['LOCAL_RANK'])
    if rank == 0 and args.output.exists():
        raise RuntimeError('Choose a fresh output path to preserve earlier allocator probe evidence')
    torch.cuda.set_device(local_rank)
    dist.init_process_group('nccl')
    if dist.get_world_size() != 2 or not torch.version.hip:
        raise RuntimeError('This correctness probe requires exactly two ROCm GPUs')
    if torch.cuda.memory.get_allocator_backend() != 'native':
        raise RuntimeError('Expandable-segment validation requires the native allocator')
    from torch._inductor.fx_passes.joint_graph import lazy_init
    lazy_init(torch.device('cuda', local_rank))
    torch.cuda.synchronize()
    dist.barrier()
    from torch._inductor import scheduler
    from torch._inductor.codegen.flydsl import flydsl_simd, flydsl_simd_runtime
    source_paths = [Path(__file__).resolve(), Path(__file__).with_name('allocator_fragmentation_v3.py').resolve(),
                    Path(scheduler.__file__).resolve(), Path(flydsl_simd.__file__).resolve(),
                    Path(flydsl_simd_runtime.__file__).resolve(),
                    Path(torch.__file__).parent / 'cuda/memory.py',
                    Path(torch.__file__).parent / 'csrc/cuda/Module.cpp',
                    Path(torch.__file__).parent.parent / 'c10/cuda/CUDAAllocatorConfig.h']
    source_hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in source_paths}
    collectives = []
    for dtype in [torch.float32, torch.bfloat16]:
        value = torch.full((N,), rank + 1, dtype=dtype, device='cuda')
        gathered = torch.empty((2 * N,), dtype=dtype, device='cuda')
        input_proof = allocation_proof(value)
        output_proof = allocation_proof(gathered)
        dist.all_gather_into_tensor(gathered, value)
        torch.cuda.synchronize()
        if not torch.equal(gathered[:N], torch.ones_like(value)) or not torch.equal(gathered[N:], torch.full_like(value, 2)):
            raise RuntimeError('RCCL all_gather produced incorrect values')
        reduction_input = torch.full((2 * N,), rank + 1, dtype=dtype, device='cuda')
        scattered = torch.empty((N,), dtype=dtype, device='cuda')
        reduction_input_proof = allocation_proof(reduction_input)
        scattered_proof = allocation_proof(scattered)
        dist.reduce_scatter_tensor(scattered, reduction_input)
        dist.all_reduce(value)
        torch.cuda.synchronize()
        if not torch.equal(scattered, torch.full_like(scattered, 3)) or not torch.equal(value, torch.full_like(value, 3)):
            raise RuntimeError('RCCL reduce_scatter/all_reduce produced incorrect values')
        collectives.append({'dtype': str(dtype), 'all_gather': 'passed', 'reduce_scatter': 'passed',
                            'all_reduce': 'passed', 'numel': N,
                            'allocation_proofs': [input_proof, output_proof, reduction_input_proof, scattered_proof]})
        del value, gathered, reduction_input, scattered

    variants = []
    for backend in ['triton', 'flydsl']:
        for tune in [0, 1]:
            for dtype in [torch.float32, torch.bfloat16]:
                settings = {'flydsl.simd': backend == 'flydsl', 'flydsl.simd_strict': True,
                            'flydsl.simd_autotune_backend': False, 'flydsl.simd_autotune_min_numel': 0,
                            'max_autotune': False, 'max_autotune_gemm': False,
                            'max_autotune_pointwise': bool(tune), 'triton.autotune_pointwise': bool(tune),
                            'max_autotune_gemm_backends': 'ATEN', 'max_autotune_conv_backends': 'ATEN',
                            'conv_1x1_as_mm': False, 'triton.cudagraphs': False, 'fx_graph_cache': False}
                os.environ['TORCHINDUCTOR_FLYDSL_SIMD_TUNE'] = f'autotune={tune}'
                flydsl_simd._tune_table.cache_clear()
                if flydsl_simd._tune_table().get('autotune') != tune:
                    raise RuntimeError('Wrong effective FlyDSL autotuning mode')
                initial = ((torch.arange(N, device='cuda') % 4) - 2).to(dtype)
                parameter = torch.nn.Parameter(initial.clone())
                reference = torch.nn.Parameter(initial.clone())
                x = ((torch.arange(N, device='cuda') % 4) + 1).to(dtype)
                optimizer = torch.optim.SGD([parameter], lr=0.125, foreach=True)
                reference_optimizer = torch.optim.SGD([reference], lr=0.125, foreach=True)

                def function(weight, inputs):
                    return (weight * inputs + inputs).float()

                torch._dynamo.reset()
                counters.clear()
                with config.patch(settings):
                    expected = function(reference, x)
                    expected.sum().backward()
                    compiled = torch.compile(function, backend='inductor', dynamic=False)
                    actual, generated = run_and_get_code(compiled, parameter, x)
                    actual.sum().backward()
                    torch.cuda.synchronize()
                    if not torch.equal(actual, expected) or not torch.equal(parameter.grad, reference.grad):
                        raise RuntimeError('Compiled pointwise forward or complete gradient differs from eager')
                    proofs = {'parameter': allocation_proof(parameter), 'input': allocation_proof(x),
                              'output': allocation_proof(actual), 'gradient': allocation_proof(parameter.grad)}
                    dist.all_reduce(parameter.grad)
                    parameter.grad.div_(2)
                    if not torch.equal(parameter.grad, reference.grad):
                        raise RuntimeError('RCCL reduction of compiled VMM gradient differs from eager')
                    optimizer.step()
                    reference_optimizer.step()
                    torch.cuda.synchronize()
                    if not torch.equal(parameter, reference) or not torch.equal(parameter, initial - x * 0.125):
                        raise RuntimeError('Complete SGD update differs from exact expected values')
                    if torch.equal(parameter, initial):
                        raise RuntimeError('SGD did not update the parameter')
                    fly_counts = dict(counters['flydsl_simd'])
                    source = '\n'.join(generated)
                    if backend == 'flydsl':
                        if fly_counts.get('flydsl_kernels', 0) <= 0 or fly_counts.get('triton_kernels', 0):
                            raise RuntimeError(f'FlyDSL execution was not established: {fly_counts}')
                        if tune and fly_counts.get('autotuned_kernels', 0) <= 0:
                            raise RuntimeError('FlyDSL autotuning was not exercised')
                    elif 'async_compile.triton(' not in source:
                        raise RuntimeError('Native Triton code generation was not established')
                    variants.append({'backend': backend, 'autotune': tune, 'dtype': str(dtype),
                                     'forward': 'exact', 'full_gradient': 'exact', 'sgd_update': 'exact',
                                     'gradient_all_reduce': 'exact', 'allocation_proofs': proofs,
                                     'flydsl_counters': fly_counts, 'config': settings,
                                     'config_sha256': hashlib.sha256(json.dumps(settings, sort_keys=True).encode()).hexdigest(),
                                     'generated_source_sha256': hashlib.sha256(source.encode()).hexdigest()})
                del compiled, actual, expected, parameter, reference, initial, x, optimizer, reference_optimizer
                dist.barrier()
    for name, digest in source_hashes.items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f'Source changed during allocator probe: {name}')
    probe_config = {'numel': N, 'optimizer': 'SGD', 'learning_rate': 0.125, 'foreach': True,
                    'allocator_environment': os.environ['PYTORCH_ALLOC_CONF'],
                    'allocator_backend': torch.cuda.memory.get_allocator_backend()}
    payload = {'status': 'passed', 'rank': rank, 'world_size': 2,
               'allocator_environment': os.environ['PYTORCH_ALLOC_CONF'],
               'allocator_backend': torch.cuda.memory.get_allocator_backend(),
               'hip_version': torch.version.hip,
               'device_arch': torch.cuda.get_device_properties(local_rank).gcnArchName,
               'config': probe_config,
               'config_sha256': hashlib.sha256(json.dumps(probe_config, sort_keys=True).encode()).hexdigest(),
               'collectives': collectives, 'variants': variants, 'source_hashes': source_hashes,
               'protocol': 'Correctness and actual expandable-segment placement only; no performance measurement'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.with_name(args.output.stem + f'.rank{rank}.json').write_text(json.dumps(payload, indent=2) + '\n')
    ranks = [None, None]
    dist.all_gather_object(ranks, payload)
    if rank == 0:
        expected_variants = {(backend, tune, str(dtype)) for backend in ['triton', 'flydsl']
                             for tune in [0, 1] for dtype in [torch.float32, torch.bfloat16]}
        for item in ranks:
            if item['status'] != 'passed' or item['world_size'] != 2 or len(item['variants']) != 8:
                raise RuntimeError('Incomplete allocator correctness probe')
            if {(entry['backend'], entry['autotune'], entry['dtype']) for entry in item['variants']} != expected_variants:
                raise RuntimeError('Missing backend/tuning/dtype coverage')
            if item['source_hashes'] != source_hashes:
                raise RuntimeError('Rank source versions differ')
            if item['config_sha256'] != payload['config_sha256'] or len(item['collectives']) != 2:
                raise RuntimeError('Inconsistent rank configuration or incomplete RCCL dtype coverage')
        args.output.write_text(json.dumps({**payload, 'ranks': ranks}, indent=2) + '\n')
        print(json.dumps({'status': 'passed', 'world_size': 2, 'variants_per_rank': 8}), flush=True)
    dist.destroy_process_group()


if __name__ == '__main__':
    main()
