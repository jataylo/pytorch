from pathlib import Path
root=Path(__file__).resolve().parent
p=root/'codegen_bench_v13/run_overlay.py';s=p.read_text();needle="NAMES={'torch._inductor.config'";pos=s.index(needle);s=s[:pos]+"os.environ['AMD_CODEGEN_SOURCE_ROOT']=str(ROOT)\nstartup=str(ROOT.parent/'codegen_startup_v13')\nos.environ['PYTHONPATH']=os.pathsep.join([startup,*[p for p in os.environ.get('PYTHONPATH','').split(os.pathsep) if p and p!=startup]])\n"+s[pos:];p.write_text(s)
p=root/'pytorch_codegen_v13/torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py';s=p.read_text();s=s.replace('            best = next(m for m in mains if m.__name__ == f.read().strip())','            winner = f.read().strip()\n        best = next(m for m in mains if m.__name__ == winner)');p.write_text(s)
