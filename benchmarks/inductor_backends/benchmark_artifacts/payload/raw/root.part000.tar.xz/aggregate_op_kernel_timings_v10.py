import csv
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics

from build_three_backend_report_v7 import write_csv, write_workbook

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'kernel_routes_v9/op_kernel_timings.csv'
DESTINATION = ROOT / 'kernel_routes_v9/aggregation'
SUCCESS = {'ok', 'validation_unavailable', 'reference_unavailable'}


def percentile(values, fraction):
    values = sorted(values)
    index = (len(values)-1)*fraction
    lo = int(index)
    hi = min(lo+1,len(values)-1)
    return values[lo] + (values[hi]-values[lo])*(index-lo)


def group_labels(row, dimension):
    if dimension == 'aten_op':
        return row['aten_origins'].split(';') if row['aten_origins'] else ['unknown_origin']
    if dimension == 'overall':
        return ['all logged kernels']
    return [row.get(dimension) or 'unknown']


def aggregate(rows, dimension):
    buckets = defaultdict(list)
    for row in rows:
        if row['model_status'] not in SUCCESS:
            continue
        for cohort in [row['validation_tier'], 'all_successful_training']:
            for label in group_labels(row,dimension):
                buckets[row['tuning'],cohort,label].append(row)
    result=[]
    for (tuning,cohort,label),members in buckets.items():
        selected=[row for row in members if row['decision_source']=='performance_selection']
        measured=[row for row in selected if row['triton_speed_us'] and row['flydsl_speed_us']]
        output=dict(tuning=tuning,cohort=cohort,group=label,models_with_logged_contexts=len({row['model'] for row in members}),
            logged_kernel_contexts=len(members),performance_selection_contexts=len(selected),measured_contexts=len(measured),
            models_with_measurements=len({row['model'] for row in measured}),
            timing_coverage_percent=100*len(measured)/len(selected) if selected else None,
            cached_or_untimed_contexts=len(selected)-len(measured),
            selection_skipped_contexts=sum(row['decision_source']=='selection_skipped_uses_flydsl' for row in members),
            selected_flydsl_contexts=sum(row['selected_backend']=='flydsl' for row in selected),
            selected_triton_contexts=sum(row['selected_backend']=='triton' for row in selected))
        metrics=['measured_clear_flydsl_wins','measured_clear_triton_wins','measured_within3percent',
                 'geomean_triton_over_flydsl','geomean_flydsl_time_saved_percent','median_flydsl_time_saved_percent',
                 'p10_flydsl_time_saved_percent','p90_flydsl_time_saved_percent','geomean_triton_us','geomean_flydsl_us',
                 'median_flydsl_time_saved_us','best_flydsl_time_saved_percent','best_model','best_kernel',
                 'worst_flydsl_time_saved_percent','worst_model','worst_kernel']
        output.update({key:None for key in metrics})
        if measured:
            tri=[float(row['triton_speed_us']) for row in measured]
            fly=[float(row['flydsl_speed_us']) for row in measured]
            ratios=[a/b for a,b in zip(tri,fly)]
            percentages=[100*(a-b)/a for a,b in zip(tri,fly)]
            ratio=statistics.geometric_mean(ratios)
            best_index=max(range(len(measured)),key=percentages.__getitem__)
            worst_index=min(range(len(measured)),key=percentages.__getitem__)
            wins=sum(value>1.03 for value in ratios)
            losses=sum(value<1/1.03 for value in ratios)
            ties=sum(1/1.03<=value<=1.03 for value in ratios)
            if wins+losses+ties != len(measured):
                raise RuntimeError('Win/tie accounting mismatch')
            output.update(measured_clear_flydsl_wins=wins,measured_clear_triton_wins=losses,measured_within3percent=ties,
                geomean_triton_over_flydsl=ratio,geomean_flydsl_time_saved_percent=100*(1-1/ratio),
                median_flydsl_time_saved_percent=statistics.median(percentages),
                p10_flydsl_time_saved_percent=percentile(percentages,.1),p90_flydsl_time_saved_percent=percentile(percentages,.9),
                geomean_triton_us=statistics.geometric_mean(tri),geomean_flydsl_us=statistics.geometric_mean(fly),
                median_flydsl_time_saved_us=statistics.median(a-b for a,b in zip(tri,fly)),
                best_flydsl_time_saved_percent=percentages[best_index],best_model=measured[best_index]['model'],best_kernel=measured[best_index]['kernel_name'],
                worst_flydsl_time_saved_percent=percentages[worst_index],worst_model=measured[worst_index]['model'],worst_kernel=measured[worst_index]['kernel_name'])
        result.append(output)
    return sorted(result,key=lambda row:(row['tuning'],row['cohort'],-row['measured_contexts'],row['group']))


def main():
    with SOURCE.open() as source:
        rows=list(csv.DictReader(source))
    tables={label:aggregate(rows,dimension) for label,dimension in [
        ('overall','overall'),('by_fused_op','op'),('by_kernel_stage','stage'),('by_model','model'),('by_aten_origin','aten_op')]}
    eager=[row for row in tables['by_fused_op'] if row['cohort']=='eager_validated' and row['models_with_measurements']>=2 and row['measured_contexts']>=5]
    tables['flydsl_favorable_fusions']=sorted([row for row in eager if row['geomean_triton_over_flydsl'] and row['geomean_triton_over_flydsl']>1.03],key=lambda row:(row['tuning'],-row['geomean_triton_over_flydsl']))
    tables['triton_favorable_fusions']=sorted([row for row in eager if row['geomean_triton_over_flydsl'] and row['geomean_triton_over_flydsl']<1/1.03],key=lambda row:(row['tuning'],row['geomean_triton_over_flydsl']))
    tables['flydsl_consistent_measured_fusions']=[row for row in tables['flydsl_favorable_fusions'] if row['p10_flydsl_time_saved_percent']>0]
    notes=[dict(item='coverage warning',definition='The measured subset is biased: cached choices omit candidate timings, while non-first cached choices can be remeasured by the existing backend cache-read bug. These aggregates describe logged measurements, not overall backend win rates or operator performance guarantees.'),
        dict(item='row unit',definition='One unique kernel-name training context per model/tuning/current placement, rank0 only; not runtime invocation counts and not weighted by dynamic frequency.'),
        dict(item='op meaning',definition='Fused original ATen origin labels, not necessarily standalone operators. GEMM/conv ancestry remains native ATen. by_aten_origin overlaps across fused contexts, so its counts must not be summed.'),
        dict(item='cohorts',definition='eager_validated is primary for inspection; training_only is separate. all_successful_training combines both explicitly. Numerical-warning and failed-model contexts are excluded from aggregates.'),
        dict(item='speedup',definition='100*(Triton_us-FlyDSL_us)/Triton_us, positive saves time. Geomean uses Triton/FlyDSL timing ratios first; it is not an average of percentages. Lower microsecond timings are better.'),
        dict(item='clear win',definition='3% ratio band: Triton/FlyDSL>1.03 is FlyDSL win, <1/1.03 is Triton win, otherwise near tie. This is a reporting threshold, not statistical significance.'),
        dict(item='favorable tables',definition='At least five measured contexts across at least two models, eager-validated only, grouped separately per tuning mode. Consistent measured fusions additionally require the 10th percentile of logged FlyDSL time savings above zero. Bias warning still applies.'),
        dict(item='whole model',definition='Kernel autotuner times are not full-step contributions. No per-model speedup is inferred by summing these kernel contexts.')]
    DESTINATION.mkdir(exist_ok=True)
    sheets=[]
    fields=list(tables['overall'][0])
    names={'overall':'Overall','by_fused_op':'Fused ops','by_kernel_stage':'Kernel stages','by_model':'Models','by_aten_origin':'ATen origins',
           'flydsl_favorable_fusions':'FlyDSL favorable','triton_favorable_fusions':'Triton favorable','flydsl_consistent_measured_fusions':'FlyDSL consistent'}
    for label,table in tables.items():
        write_csv(DESTINATION/(label+'.csv'),table,fields)
        sheets.append((names[label],table,fields))
    write_csv(DESTINATION/'definitions.csv',notes,['item','definition'])
    sheets.append(('Definitions',notes,['item','definition']))
    write_workbook(DESTINATION/'kernel_timing_aggregations.xlsx',sheets)
    provenance=dict(generated_utc=datetime.now(timezone.utc).isoformat(),source=str(SOURCE),
                    source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    source_rows=len(rows),table_rows={key:len(value) for key,value in tables.items()})
    (DESTINATION/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    (DESTINATION/'README.txt').write_text('\n\n'.join(value['item']+': '+value['definition'] for value in notes)+'\n')
    print(json.dumps(provenance,indent=2))
    print('EXPANDED EAGER-VALIDATED STAGES')
    print(json.dumps([row for row in tables['by_kernel_stage'] if row['tuning']=='expanded' and row['cohort']=='eager_validated'],indent=2))
    print('EXPANDED FLYDSL FAVORABLE FUSIONS')
    print(json.dumps([row for row in tables['flydsl_favorable_fusions'] if row['tuning']=='expanded'][:10],indent=2))


if __name__=='__main__':
    main()
