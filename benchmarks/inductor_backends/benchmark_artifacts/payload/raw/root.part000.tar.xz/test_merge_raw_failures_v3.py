import ast
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile

from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


source = Path(__file__).with_name('merge_steady_v2.py')
tree = ast.parse(source.read_text())
functions = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef) and
                            node.name in {'failure_identity', 'collect_raw_failures'}], type_ignores=[])
namespace = {'json': json, 're': re}
exec(compile(functions, str(source), 'exec'), namespace)
collect = namespace['collect_raw_failures']


class TestRawFailureInventory(TestCase):
    def setUp(self):
        super().setUp()
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name) / 'results'

    def record(self, name, **changes):
        record = dict(suite='priority', model='actual_model', backend='flydsl', autotune=0,
                      attempt_id='attempt', world_size=4, rank=0, status='process_failed',
                      phase='warmup', returncode=-6)
        record.update(changes)
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(record))
        return path, record

    def test_crash_without_diagnostic(self):
        path, _ = self.record('raw/model/flydsl_autotune0.json', error=None)
        failures = []
        collect(self.root, 'primary', failures)
        self.assertEqual(len(failures), 1)
        event = failures[0]
        self.assertTrue(event['external_termination'])
        self.assertIn('process_failed', event['error'])
        self.assertEqual(event['raw_failure_records'][0]['returncode'], -6)
        self.assertEqual(event['raw_failure_records'][0]['source_json'], str(path))
        self.assertEqual(event['raw_failure_records'][0]['phase'], 'warmup')

    def test_diagnostic_and_raw_deduplicate(self):
        _, record = self.record('raw/model/flydsl_autotune0.json', status='error', error='compiler detail')
        diagnostic = {**record, 'measurement_protocol': 'primary', 'category': 'compile_or_execution_failure'}
        failures = [diagnostic]
        collect(self.root, 'primary', failures)
        self.assertEqual(len(failures), 1)
        self.assertEqual(failures[0]['error'], 'compiler detail')
        self.assertEqual(len(failures[0]['raw_failure_records']), 1)

    def test_archived_attempts_and_duplicate_provenance(self):
        self.record('raw/model/flydsl_autotune0.json', attempt_id='new')
        self.record('archive/retry/model/flydsl_autotune0.json', attempt_id='old')
        self.record('archive/copy/model/flydsl_autotune0.json', attempt_id='old')
        failures = []
        collect(self.root, 'primary', failures)
        self.assertEqual(len(failures), 2)
        self.assertEqual(sorted(len(x['raw_failure_records']) for x in failures), [1, 2])

    def test_multi_rank_aggregate_uses_failed_rank(self):
        self.record('raw/model/flydsl_autotune0.json', status='error', failed_rank=2, error='rank failure')
        self.record('raw/model/ranks/flydsl_autotune0.world4.rank2.json', status='error', rank=2, error='rank failure')
        self.record('raw/model/ranks/flydsl_autotune0.world4.rank3.json', status='error', rank=3, error='different rank')
        failures = []
        collect(self.root, 'primary', failures)
        self.assertEqual({x['rank'] for x in failures}, {2, 3})
        self.assertEqual(len(failures), 2)
        rank_two = next(x for x in failures if x['rank'] == 2)
        self.assertEqual(len(rank_two['raw_failure_records']), 2)
        self.assertEqual({x['log_path'] for x in rank_two['raw_failure_records']},
                         {str(self.root / 'raw/model/flydsl_autotune0.log')})

    def test_timeout_and_normal_records(self):
        self.record('raw/model/flydsl_autotune0.json', status='timeout', returncode=-9)
        for index, status in enumerate(['ok', 'capacity_skip', 'started', 'numerical_warning']):
            self.record(f'raw/normal{index}/flydsl_autotune0.json', status=status)
        failures = []
        collect(self.root, 'primary', failures)
        self.assertEqual(len(failures), 1)
        self.assertEqual(failures[0]['status'], 'timeout')
        self.assertTrue(failures[0]['external_termination'])

    def test_archived_rank_and_single_snapshot(self):
        self.record('archive/old/model/ranks/flydsl_autotune0.world4.rank1.json', rank=1)
        snapshot = self.root.with_name(self.root.name + '_single') / 'raw/model/flydsl_autotune0.json'
        snapshot.parent.mkdir(parents=True)
        snapshot.write_text(json.dumps(dict(suite='priority', model='actual_model', backend='flydsl',
                                           autotune=0, attempt_id='single', world_size=1, status='timeout')))
        failures = []
        collect(self.root, 'primary', failures)
        self.assertEqual(len(failures), 2)
        self.assertEqual({x['attempt_id'] for x in failures}, {'attempt', 'single'})

    def test_protocol_mode_and_missing_attempt_not_conflated(self):
        self.record('raw/a/flydsl_autotune0.json', attempt_id=None)
        self.record('archive/old/a/flydsl_autotune0.json', attempt_id=None)
        self.record('raw/b/flydsl_autotune1.json', autotune=1)
        failures = []
        collect(self.root, 'primary', failures)
        self.assertEqual(len(failures), 3)
        collect(self.root, 'steady_recheck', failures)
        self.assertEqual(len(failures), 6)

    def test_real_merge_classifies_external_outcomes(self):
        import csv

        self.record('raw/a/flydsl_autotune0.json', error=None)
        self.record('raw/b/flydsl_autotune0.json', attempt_id='timeout', status='timeout')
        self.record('raw/c/flydsl_autotune0.json', attempt_id='normal', status='ok', milliseconds=1)
        (self.root / 'kernel_decisions.jsonl').write_text('')
        manifest = self.root / 'manifest.json'
        manifest.write_text(json.dumps({'models': []}))
        subprocess.run([sys.executable, str(source), '--results', str(self.root), '--steady',
                        str(self.root / 'absent_steady'), '--manifest', str(manifest)],
                       check=True, stdout=subprocess.DEVNULL)
        with (self.root / 'all_compile_execution_failures.csv').open() as stream:
            failures = list(csv.DictReader(stream))
        self.assertEqual(len(failures), 2)
        self.assertEqual({item['failure_kind'] for item in failures}, {'external_termination'})
        self.assertEqual({item['status'] for item in failures}, {'process_failed', 'timeout'})

    @parametrize('message, expected', [
        ('HIPBLAS_STATUS_ALLOC_FAILED when calling hipblasCreate(handle)', 'memory'),
        ('CUBLAS_STATUS_ALLOC_FAILED when calling cublasCreate(handle)', 'memory'),
        ('HIPLaunchOutOfResources: too many resources requested for launch', 'compiler_or_execution'),
    ])
    @parametrize('field', ['error', 'traceback'])
    def test_real_merge_precise_gpu_allocation_classification(self, message, expected, field):
        import csv

        changes = {'status': 'error', 'error': None, field: message}
        _, record = self.record('raw/model/flydsl_autotune0.json', **changes)
        event = {**record, 'requested_backend': 'flydsl', 'category': 'compile_or_execution_failure'}
        (self.root / 'kernel_decisions.jsonl').write_text(json.dumps(event) + '\n')
        manifest = self.root / 'manifest.json'
        manifest.write_text(json.dumps({'models': []}))
        subprocess.run([sys.executable, str(source), '--results', str(self.root), '--steady',
                        str(self.root / 'absent_steady'), '--manifest', str(manifest)],
                       check=True, stdout=subprocess.DEVNULL)
        with (self.root / 'all_compile_execution_failures.csv').open() as stream:
            failures = list(csv.DictReader(stream))
        self.assertEqual(len(failures), 1)
        self.assertEqual(failures[0]['failure_kind'], expected)
        self.assertEqual(failures[0][field], message)
        self.assertEqual(len(json.loads(failures[0]['raw_failure_records'])), 1)

    @parametrize('scenario', ['terminal_error', 'measured', 'missing_mode', 'inconsistent_group'])
    def test_state_only_recovery_atomic_adoption(self, scenario):
        import csv

        steady = self.root.with_name('steady')
        original_events = []
        recovery_events = []
        for backend in ['triton', 'flydsl']:
            for tune in [0, 1]:
                variant = f'{backend}_autotune{tune}'
                _, original = self.record(f'raw/model/{variant}.json', backend=backend, autotune=tune,
                    attempt_id=f'old_{variant}', status='error', error='Out of memory during eager initialization',
                    phase='fsdp_eager_initialization', batch_size=32, parameters=12345, model_config_sha256='full_model',
                    physical_gpu='0,1,2,3,4,5,6,7', world_size=8, source_fingerprint={'sha256': 'original'})
                original_events.append({**original, 'requested_backend': backend, 'category': 'compile_or_execution_failure'})
                if scenario == 'missing_mode' and backend == 'flydsl' and tune == 1:
                    continue
                recovery = {**original, 'attempt_id': f'new_{variant}', 'phase': 'warmup',
                    'launch_environment_overrides': {'BENCHMARK_FSDP_STATE_INIT_ONLY': '1'},
                    'source_fingerprint': {'sha256': 'shared_recovery'}, 'returncode': 0}
                if scenario == 'terminal_error':
                    recovery.update(status='error', error='Out of memory in compiled training')
                else:
                    recovery.update(status='validation_unavailable', error='No eager reference', milliseconds=2 + tune,
                                    repeat_ms=[2 + tune] * 5, timing_recompiles=0)
                if scenario == 'inconsistent_group' and backend == 'flydsl' and tune == 1:
                    recovery.update(physical_gpu='4,5,6,7', world_size=4)
                path = steady / 'raw/model' / f'{variant}.json'
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(recovery))
                recovery_events.append({**recovery, 'requested_backend': backend,
                    'category': 'compile_or_execution_failure' if scenario == 'terminal_error' else 'lowered',
                    'kernel_name': 'actual_kernel' if scenario != 'terminal_error' else None})
        (self.root / 'kernel_decisions.jsonl').write_text(''.join(json.dumps(x) + '\n' for x in original_events))
        (steady / 'kernel_decisions.jsonl').write_text(''.join(json.dumps(x) + '\n' for x in recovery_events))
        manifest = self.root / 'manifest.json'
        manifest.write_text(json.dumps({'models': [{'suite': 'priority', 'model': 'actual_model', 'batch_size': 32}]}))
        subprocess.run([sys.executable, str(source), '--results', str(self.root), '--steady', str(steady),
                        '--manifest', str(manifest)], check=True, stdout=subprocess.DEVNULL)
        with (self.root / 'final_timing_sources.csv').open() as stream:
            provenance = list(csv.DictReader(stream))
        adopted = scenario in {'terminal_error', 'measured'}
        self.assertEqual(len(provenance), 4)
        self.assertEqual({item['timing_source'] for item in provenance}, {'steady_recheck' if adopted else 'primary'})
        expected_base = steady if adopted else self.root
        self.assertTrue(all(Path(item['source_json']).is_relative_to(expected_base) for item in provenance))
        summary = json.loads((self.root / 'stable_summary.json').read_text())
        self.assertEqual(summary['accepted_steady_rechecks'], ['actual_model'] if adopted else [])
        self.assertEqual(summary['terminal_recoveries_without_four_timings'], ['actual_model'] if scenario == 'terminal_error' else [])
        with (self.root / 'comparison_stable.csv').open() as stream:
            comparisons = list(csv.DictReader(stream))
        self.assertEqual(len(comparisons), 2)
        if scenario == 'measured':
            self.assertEqual({item['triton_over_flydsl'] for item in comparisons}, {'1.0'})
            self.assertTrue(all(item['numerically_validated'] == 'False' for item in comparisons))
        else:
            self.assertTrue(all(not item.get('triton_over_flydsl') for item in comparisons))
            self.assertTrue(all(not item.get('milliseconds') for item in provenance))
        events = [json.loads(line) for line in (self.root / 'all_kernel_decisions.jsonl').read_text().splitlines()]
        self.assertEqual(len(events), len(original_events) + len(recovery_events))
        self.assertEqual(sum(event['selected_for_final_timing'] for event in events), 4 if scenario == 'measured' else 0)
        if scenario == 'terminal_error':
            with (self.root / 'all_compile_execution_failures.csv').open() as stream:
                failures = list(csv.DictReader(stream))
            self.assertEqual(len(failures), 8)
            self.assertEqual({item['attempt_id'] for item in failures},
                             {item['attempt_id'] for item in original_events + recovery_events})


instantiate_parametrized_tests(TestRawFailureInventory)


if __name__ == '__main__':
    run_tests()
