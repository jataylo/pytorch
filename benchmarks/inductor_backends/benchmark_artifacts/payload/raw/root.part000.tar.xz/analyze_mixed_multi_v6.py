import argparse
from collections import Counter
import csv
import hashlib
import html
import json
import math
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parent
MEASURED = {'ok', 'numerical_warning', 'validation_unavailable', 'reference_unavailable'}


def write_csv(path, rows, fields=None):
    fields = fields or sorted({key for row in rows for key in row})
    with path.open('w') as output:
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value) if isinstance(value, (dict, list)) else value
                             for key, value in row.items()})


def compatible(first, second):
    return all(first.get(key) == second.get(key) for key in
               ['physical_gpu', 'world_size', 'batch_size', 'model_config_sha256', 'source_fingerprint'])


def summarize(rows):
    if not rows:
        return {'pairs': 0}
    values = [row['triton_over_flydsl'] for row in rows]
    return {'pairs': len(values), 'geomean': math.exp(statistics.mean(map(math.log, values))),
            'median': statistics.median(values), 'wins': dict(Counter(row['winner'] for row in rows))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', default='training_results_v2')
    parser.add_argument('--manifest', default='model_manifest_v2.json')
    args = parser.parse_args()
    destination = ROOT / args.results
    models = json.loads((ROOT / args.manifest).read_text())['models']
    records = [json.loads(path.read_text()) for path in sorted((destination / 'raw').glob('*/*.json'))]
    indexed = {(r['suite'], r['model'], r['backend'], r['autotune']): r for r in records}
    pairs = []
    for model in models:
        for tune in [0, 1]:
            row = dict(model, autotune=tune)
            runs = [indexed.get((model['suite'], model['model'], backend, tune)) for backend in ['triton', 'flydsl']]
            for backend, run in zip(['triton', 'flydsl'], runs):
                row[f'{backend}_status'] = run['status'] if run else 'pending'
                row[f'{backend}_ms'] = run.get('milliseconds') if run else None
                row[f'{backend}_error'] = run.get('error') if run else None
            if all(runs):
                first, second = runs
                row.update(world_size=first.get('world_size'), physical_gpu=first.get('physical_gpu'))
                row['paired_configuration'] = compatible(first, second)
                row['eager_validated'] = all(r['status'] == 'ok' for r in runs)
                if row['paired_configuration'] and all(r['status'] in MEASURED and r.get('milliseconds', 0) > 0 for r in runs):
                    ratio = first['milliseconds'] / second['milliseconds']
                    row.update(triton_over_flydsl=ratio,
                               winner='flydsl' if ratio > 1.03 else 'triton' if ratio < 1 / 1.03 else 'within_3_percent')
                    row['flydsl_kernels'] = second.get('flydsl_counters', {}).get('flydsl_kernels', 0)
                    row['triton_fallback_kernels'] = second.get('flydsl_counters', {}).get('triton_kernels', 0)
            pairs.append(row)
    effects = []
    for model in models:
        for backend in ['triton', 'flydsl']:
            runs = [indexed.get((model['suite'], model['model'], backend, tune)) for tune in [0, 1]]
            if all(runs) and compatible(*runs) and all(r['status'] in MEASURED and r.get('milliseconds', 0) > 0 for r in runs):
                effects.append(dict(model, backend=backend, eager_validated=all(r['status'] == 'ok' for r in runs),
                                    no_autotune_ms=runs[0]['milliseconds'], autotune_ms=runs[1]['milliseconds'],
                                    autotune_speedup=runs[0]['milliseconds'] / runs[1]['milliseconds']))
    write_csv(destination / 'runs.csv', records)
    write_csv(destination / 'comparison.csv', pairs)
    write_csv(destination / 'autotune_effect.csv', effects)

    events = []
    malformed = []
    for path in sorted((destination / 'raw').glob('*/kernels/*.jsonl')):
        for line_number, line in enumerate(path.open(), 1):
            try:
                event = json.loads(line)
            except ValueError:
                malformed.append(f'{path}:{line_number}')
                continue
            active = indexed.get((event.get('suite'), event.get('model'), event.get('requested_backend', event.get('backend')), event.get('autotune')))
            event['active_configuration'] = bool(active and active.get('world_size') == event.get('world_size') and
                                                 active.get('physical_gpu') == event.get('gpu_group') and
                                                 active.get('attempt_id') == event.get('attempt_id'))
            event['diagnostic_file'] = str(path)
            event['line'] = line_number
            events.append(event)
    with (destination / 'kernel_decisions.jsonl').open('w') as output:
        for event in events:
            output.write(json.dumps(event) + '\n')
    unsupported = [e for e in events if e.get('category') == 'lowered' and e.get('backend') == 'triton'
                   and e.get('reason')]
    for event in unsupported:
        identity = {key: event.get(key) for key in ['suite', 'model', 'autotune', 'world_size', 'rank',
                                                   'phase', 'graph_id', 'is_backward', 'kernel_name']}
        event['scheduled_kernel_id'] = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()[:20]
    write_csv(destination / 'unsupported_flydsl_kernels.csv', unsupported)
    reasons = Counter(e['reason'] for e in unsupported if e['active_configuration'])
    write_csv(destination / 'unsupported_reasons.csv', [dict(reason=reason, scheduled_kernel_events=count)
              for reason, count in reasons.most_common()])
    native_calls = []
    for path in sorted((destination / 'raw').glob('*/codegen/*.json')):
        audit = json.loads(path.read_text())
        for graph in audit['graphs']:
            for call in graph['native_calls']:
                native_calls.append(dict(audit_file=str(path), wrapper=graph['wrapper'], **call))
    write_csv(destination / 'intentional_native_calls.csv', native_calls)

    intervals = sorted((r['timing_begin_ns'], r['timing_end_ns'], r['model'], r['backend'], r['autotune'])
                       for r in records if 'timing_end_ns' in r)
    overlapping = [(previous, current) for previous, current in zip(intervals, intervals[1:]) if previous[1] > current[0]]
    policy_errors = []
    for record in records:
        config = record.get('inductor_config', {})
        if config and (config.get('max_autotune') or config.get('max_autotune_gemm') or
                       config.get('max_autotune_gemm_backends') != 'ATEN' or config.get('max_autotune_conv_backends') != 'ATEN'):
            policy_errors.append([record['model'], record['backend'], record['autotune']])
    summary = {'expected_runs': len(models) * 4, 'observed_runs': len(records),
               'statuses': dict(Counter(r['status'] for r in records)),
               'kernel_event_categories': dict(Counter(e.get('category') for e in events)),
               'unsupported_scheduled_events': len(unsupported),
               'unsupported_unique_scheduled_ids': len({e['scheduled_kernel_id'] for e in unsupported}),
               'malformed_diagnostics': malformed, 'timing_overlaps': overlapping, 'aten_policy_errors': policy_errors,
               'comparisons': {}}
    for suite in ['all', *sorted({m['suite'] for m in models})]:
        for tune in [0, 1]:
            candidates = [r for r in pairs if 'triton_over_flydsl' in r and r['autotune'] == tune
                          and (suite == 'all' or suite == r['suite'])]
            summary['comparisons'][f'{suite}/autotune{tune}/all_measured'] = summarize(candidates)
            summary['comparisons'][f'{suite}/autotune{tune}/eager_validated'] = summarize([r for r in candidates if r['eager_validated']])
    (destination / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    method = ('Real forward, backward, zero_grad and SGD updates; AMP BF16 with FP32 master weights. '
              'Random initialization, no checkpoints. Full model architectures at listed batch sizes; diffusion entries are denoisers. '
              'GEMM and convolution forced to ATen in every mode. Global max_autotune disabled; SIMD tuning toggled independently. '
              'FlyDSL-versus-Triton performance selection enabled in mixed rows (backend=flydsl); baseline rows are Triton-only. Native unsupported SIMD fallback remains enabled. '
              'Compile/warmup excluded; synchronized wall time, 5 repeats of 10 training steps. '
              'Compile/setup and timing serialize through a global lock, including other suite workers. '
              'OOM follow-up uses FSDP with identical GPU groups for all four variants, includes communication, and reports maximum rank latency. Single-GPU data remains separate. '
              'Full-step timing includes graph breaks/eager regions and optimizer. Eager-validated means sampled loss/gradients passed; '
              'training-only and numerical-warning results remain separate. Ratio = Triton ms / FlyDSL ms; greater than one favors FlyDSL. '
              'Wins use a 3% band, not a statistical significance test. Kernel census counts generated scheduled kernels, not runtime launches; '
              'native ATen calls are a separate inventory. Inspect active_configuration to separate previous single-GPU/FSDP attempts. '
              'Source fingerprints in each raw record identify modified sources on top of branch SHA 937d7fd.')
    (destination / 'RESULTS.txt').write_text(method + '\n\n' + json.dumps(summary, indent=2) + '\n')
    rows = ''.join('<tr>' + ''.join('<td>' + html.escape(str(row.get(key, ''))) + '</td>' for key in
                   ['suite', 'model', 'autotune', 'world_size', 'triton_status', 'flydsl_status', 'triton_ms', 'flydsl_ms',
                    'triton_over_flydsl', 'eager_validated']) + '</tr>' for row in pairs)
    page = '<!doctype html><meta charset="utf-8"><title>Triton-only / mixed backend training</title><style>body{font:15px system-ui;margin:28px}td,th{padding:7px;text-align:left;border-bottom:1px solid #ddd}input{padding:10px;width:400px}pre{white-space:pre-wrap}</style>'
    page += '<h1>Triton-only / mixed backend full-model training</h1><p>' + html.escape(method) + '</p>'
    page += '<p><a href="comparison.csv">Comparisons CSV</a> | <a href="runs.csv">All outcomes</a> | <a href="unsupported_flydsl_kernels.csv">Unsupported kernels</a> | <a href="unsupported_reasons.csv">Fallback reasons</a> | <a href="intentional_native_calls.csv">ATen calls</a> | <a href="kernel_decisions.jsonl">Full kernel decisions</a></p>'
    page += '<pre>' + html.escape(json.dumps(summary, indent=2)) + '</pre><input id="filter" placeholder="Filter model or status"><table><thead><tr>'
    page += ''.join('<th>' + key + '</th>' for key in ['Suite', 'Model', 'Tune', 'GPUs', 'Triton status', 'FlyDSL status', 'Triton ms', 'FlyDSL ms', 'Speedup', 'Validated'])
    page += '</tr></thead><tbody>' + rows + '</tbody></table><script>document.getElementById("filter").oninput=function(){for(const row of document.querySelectorAll("tbody tr"))row.hidden=!row.textContent.toLowerCase().includes(this.value.toLowerCase())}</script>'
    (destination / 'report.html').write_text(page)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
