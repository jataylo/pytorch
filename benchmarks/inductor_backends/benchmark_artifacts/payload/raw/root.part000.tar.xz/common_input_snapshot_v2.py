"""Shared helpers for the conv / gemm / sdpa benchmark and metadata scripts.

Centralises three things that used to be copy-pasted across the per-op
scripts:

  * result/output directory layout  -> results/<arch>/<list>/<op>/
  * model loading (timm + HuggingFace) and dummy input construction
  * dtype handling, including AMP (autocast) modes
"""

from __future__ import annotations

import glob
import os
import re
import shutil
from dataclasses import dataclass

import torch


# ---------------------------------------------------------------------------
# GPU architecture detection
# ---------------------------------------------------------------------------

_ARCH_ENV_VAR = "RESULTS_ARCH"


def _normalise_arch(raw: str) -> str:
    """'AMD Instinct MI308X' -> 'mi308x',  'NVIDIA H100 80GB HBM3' -> 'h100'."""
    name = raw.strip().lower()
    name = re.sub(r"\b(amd|nvidia|instinct|radeon|geforce|tesla)\b", " ", name)

    m = re.search(r"\bmi\s*(\d{2,3}[a-z]*)\b", name)
    if m:
        return "mi" + m.group(1).replace(" ", "")

    m = re.search(r"\b([ahblv])(\d{2,3})\b", name)
    if m:
        return m.group(1) + m.group(2)

    m = re.search(r"\bgfx[0-9a-f]+\b", name)
    if m:
        return m.group(0)

    return re.sub(r"[^a-z0-9]+", "_", name).strip("_") or "unknown"


def detect_arch(override: str | None = None) -> str:
    """Short lowercase name for the current accelerator, e.g. 'mi308x'.

    Resolution order: explicit override -> $RESULTS_ARCH -> device query -> 'cpu'.
    """
    if override:
        return _normalise_arch(override)
    env = os.environ.get(_ARCH_ENV_VAR)
    if env:
        return _normalise_arch(env)
    if not torch.cuda.is_available():
        return "cpu"
    props = torch.cuda.get_device_properties(0)
    arch = _normalise_arch(props.name)
    if arch in ("unknown", ""):
        arch = _normalise_arch(getattr(props, "gcnArchName", "") or "unknown")
    return arch


# Every model list lives in scripts/models/ and is named <name>_models.txt, so
# the name is both the selector (--list NAME) and the output path component
# (metadata/<name>/, results/<arch>/<name>/).
LIST_SUFFIX = "_models.txt"
DEFAULT_LIST = "default"
ALL_LIST = "all"


def results_dir(op: str, arch: str | None = None, name: str = DEFAULT_LIST,
                create: bool = True) -> str:
    """Path for benchmark outputs: results/<arch>/<list>/<op>/.

    ``name`` is the model-list name the run came from, so two lists that share a
    model do not overwrite each other's timings.  Arch stays outermost because
    results are only comparable within one accelerator.
    """
    path = os.path.join("results", detect_arch(arch), name, op)
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def metadata_dir(op: str, name: str = DEFAULT_LIST, create: bool = True) -> str:
    """Path for captured op metadata: metadata/<list>/<op>/.

    Metadata is shape information extracted from the model graph, so unlike
    benchmark results it is not architecture specific — but it is specific to
    the list, because the batch size a model was captured at comes from there.
    """
    path = os.path.join("metadata", name, op)
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def status_csv(name: str = DEFAULT_LIST, create: bool = True) -> str:
    """Path for the per-list collection ledger."""
    path = os.path.join("metadata", name)
    if create:
        os.makedirs(path, exist_ok=True)
    return os.path.join(path, "collection_status.csv")


# ---------------------------------------------------------------------------
# Autotune logs
# ---------------------------------------------------------------------------

# Inductor appends every autotune result to one JSON file per op family, named
# by these environment variables.
AUTOTUNE_LOG_ENV = {
    "gemm": "TORCHINDUCTOR_MM_LOGGING_FILE",
    "conv": "TORCHINDUCTOR_CONV_LOGGING_FILE",
    "sdpa": "TORCHINDUCTOR_FLEX_ATTENTION_LOGGING_FILE",
}

# The @functools.cache'd getter behind each variable, which has to be
# invalidated for a mid-run change of log file to take effect.
_AUTOTUNE_LOG_GETTER = {
    "gemm": "get_mm_log_filename",
    "conv": "get_conv_log_filename",
    "sdpa": "get_flex_attention_log_filename",
}


def tuning_space_name(search_space: str | None = None,
                      max_configs: int | None = None) -> str:
    """Short label for the config space a run searched.

    Goes into the autotune log filename, because the configs in a log are only
    meaningful next to the space they were drawn from: a shape searched over a
    5000-config space and the same shape searched over Inductor's default 30 are
    not comparable, and merging them silently would hide that.

    A ``max_configs`` cap is part of that identity too — 'wide' sampled down to
    1000 configs is a different space from all 7555 of it — and naming it also
    keeps the per-space Inductor cache from serving the smaller sample's kernels
    to a run that asked for more.
    """
    if search_space:
        stem = os.path.splitext(os.path.basename(search_space))[0]
        cleaned = re.sub(r"[^A-Za-z0-9.-]+", "-", stem).strip("-")
        base = cleaned or "custom"
    else:
        base = "inductor-default"
    return f"{base}-max{max_configs}" if max_configs else base


def autotune_log_path(op: str, space: str, model_name: str, batch_size: int,
                      dtype_tag: str, arch: str | None = None,
                      name: str = DEFAULT_LIST, create: bool = True,
                      variant: str | None = None) -> str:
    """Path for one run's autotune log, beside that run's benchmark results.

    results/<arch>/<list>/<op>/<op>_benchmark_cache_<space>_<model>_bs<N>_<dtype>.json

    One file per (model, batch size, dtype) rather than one per sweep: a log
    that lands next to the CSV it was produced with can be traced back to the
    run that wrote it, and a sweep that dies partway leaves the models it did
    finish intact.  postprocess_autotune.py merges them back together, and its
    AUTOTUNE_LOG_GLOBS must keep matching the name built here.

    ``variant`` distinguishes logs that would otherwise collide within one
    (model, batch size, dtype): the shards of a split sweep, and shapes whose
    inputs differ only in memory format, which Inductor's log records
    identically because it prints shapes without strides.
    """
    directory = results_dir(op, arch, name, create=create)
    return os.path.join(
        directory,
        f"{op}_benchmark_cache_{space}_{safe_model_name(model_name)}"
        f"_bs{batch_size}_{dtype_tag}{_variant_suffix(variant)}.json",
    )


def _variant_suffix(variant: str | None) -> str:
    """'.<variant>' for a filename, or '' — sanitised like a space label.

    Dot-separated rather than underscore-separated so the variant cannot be
    mistaken for part of the dtype tag when a filename is read back apart.
    Dots survive sanitising, so several variants can be composed: a sharded
    sweep over channels-last inputs is '.shard2of3.channels-last'.
    """
    if not variant:
        return ""
    cleaned = re.sub(r"[^A-Za-z0-9.-]+", "-", variant).strip("-.")
    return f".{cleaned}" if cleaned else ""


def join_variants(*parts: str | None) -> str | None:
    """Compose variant tokens into one dot-separated label, or None."""
    kept = [p for p in parts if p]
    return ".".join(kept) if kept else None


def census_path(output_dir: str, variant: str | None = None) -> str:
    """Where a run writes its shape census.

    Sharded runs each get their own file rather than sharing one, because the
    census is written whole at the end of a sweep: two shards pointed at one
    filename would race, and the loser's shapes would vanish even though they
    were measured.  top_configs.py globs them and merges, which it already does
    for the census of every list it combines.
    """
    return os.path.join(
        output_dir, f"shape_census{_variant_suffix(variant)}.csv")


def set_autotune_log(op: str, path: str) -> str:
    """Point Inductor's autotune log for ``op`` at ``path``, effective now.

    Inductor reads the filename from the environment once and caches it for the
    life of the process, so a sweep that writes one log per model has to
    invalidate that cache at every model boundary as well as set the variable.
    """
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    os.environ[AUTOTUNE_LOG_ENV[op]] = path

    from torch._inductor import select_algorithm

    getter = getattr(select_algorithm, _AUTOTUNE_LOG_GETTER[op], None)
    if getter is not None and hasattr(getter, "cache_clear"):
        getter.cache_clear()
    return path


def clear_autotune_locks(directory: str) -> int:
    """Delete the .lock files Inductor leaves beside each autotune log."""
    removed = 0
    for path in glob.glob(os.path.join(directory, "*_benchmark_cache_*.lock")):
        try:
            os.remove(path)
            removed += 1
        except OSError:
            pass
    return removed


# ---------------------------------------------------------------------------
# Per-run outputs, and resuming from them
# ---------------------------------------------------------------------------


def run_artifact(op: str, output_dir: str, kind: str, space: str,
                 model_name: str, batch_size: int, dtype_tag: str,
                 ext: str, variant: str | None = None) -> str:
    """Path for one (model, batch size, dtype) run's output file.

    Named like the autotune log beside it, config space included, because what
    a benchmark measures is the kernel autotuning settled on: the compiled
    timings for a model swept over 'wide' and the same model swept over
    Inductor's default space are different numbers, and sharing a filename
    would let whichever ran last silently stand for both.

    ``variant`` carries the same meaning as in autotune_log_path, so a shard's
    results and the log they came from stay named alike.
    """
    return os.path.join(
        output_dir,
        f"{op}_benchmark_{kind}_{space}_{safe_model_name(model_name)}"
        f"_bs{batch_size}_{dtype_tag}{_variant_suffix(variant)}.{ext}",
    )


def _unspaced_run_artifact(op: str, output_dir: str, kind: str,
                           model_name: str, batch_size: int, dtype_tag: str,
                           ext: str) -> str:
    """The name run_artifact produced before the space was part of it."""
    return os.path.join(
        output_dir,
        f"{op}_benchmark_{kind}_{safe_model_name(model_name)}"
        f"_bs{batch_size}_{dtype_tag}.{ext}",
    )


def completed_run(op: str, output_dir: str, space: str, model_name: str,
                  batch_size: int, dtype_tag: str,
                  log_path: str | None = None,
                  variant: str | None = None) -> str | None:
    """Results CSV of an earlier sweep that already finished this run, or None.

    This is the checkpoint a benchmark resumes from, so it has to mean
    *finished* and not merely *started*.  A results CSV is written once the
    model's last shape has been measured, while its autotune log grows shape by
    shape as the search proceeds, so a log newer than its CSV is the signature
    of a sweep that died mid-model — those remaining shapes were never searched
    and the model has to be run again.

    A CSV from before the config space was part of the filename is accepted
    too, but only when this space's log sits beside it.  On its own such a file
    could have come from any space, and taking it at face value would let a
    default-space sweep pass for the wide one being asked for.  That fallback
    is skipped for a ``variant`` run: no legacy file covers one shard of a
    sweep, so an unqualified CSV would claim shapes the shard never measured.
    """
    def finished_after_log(csv_path: str) -> bool:
        if log_path is None or not os.path.exists(log_path):
            return True
        return os.path.getmtime(csv_path) >= os.path.getmtime(log_path)

    path = run_artifact(op, output_dir, "results", space, model_name,
                        batch_size, dtype_tag, "csv", variant=variant)
    if os.path.exists(path):
        return path if finished_after_log(path) else None
    if variant:
        return None

    unspaced = _unspaced_run_artifact(op, output_dir, "results", model_name,
                                      batch_size, dtype_tag, "csv")
    if (log_path and os.path.exists(log_path) and os.path.exists(unspaced)
            and finished_after_log(unspaced)):
        return unspaced
    return None


def previous_rows(csv_path: str) -> dict[int, dict]:
    """An earlier run's result rows, keyed by the input index they were measured at.

    pandas is imported here rather than at module scope because the metadata
    and kernel-collection scripts import this module without needing it.
    """
    import pandas as pd

    # round_trip, because the default parser is a shortest-path float reader
    # that loses the last digit or two: replayed rows would then be written
    # back slightly different from the measurement that produced them.
    frame = pd.read_csv(csv_path, float_precision="round_trip")
    return {int(row["input_index"]): row for row in frame.to_dict("records")}


# Inductor's own kernel categories, mapped to the directory each one is filed
# under.  The names come from the @triton_heuristics.<category> decorator that
# every generated kernel carries; 'for' is short for foreach, matching the
# triton_for_ prefix Inductor puts in the kernel name itself.
KERNEL_CATEGORY_DIRS: dict[str, str] = {
    "pointwise":            "pointwise",
    "reduction":            "reduction",
    "persistent_reduction": "persistent_reduction",
    "foreach":              "for",
    "template":             "templated",
    "split_scan":           "others",
    "unknown":              "others",
}
# Template kernels are split one level further, into templated/{gemm,conv,flex,
# others}, because a GEMM tile config has nothing in common with a conv or
# attention one.  See collect_kernels.template_family.


def kernel_run_tag(model_name: str, batch_size: int, dtype_tag: str) -> str:
    """Directory name for one captured model run."""
    return f"{safe_model_name(model_name)}_bs{batch_size}_{dtype_tag}"


def kernel_dir(run_tag: str, name: str = DEFAULT_LIST, category: str = "",
               create: bool = True) -> str:
    """Path for captured Triton kernels: kernels/<list>/<run>/<category>/.

    One directory per model run rather than per model: which kernels Inductor
    generates depends on the batch size and dtype the graph was compiled at, so
    the run carries the same <model>_bs<N>_<dtype> tag that metadata filenames
    do.  ``category`` may be a nested path such as 'templated/gemm'.
    """
    path = os.path.join("kernels", name, run_tag, category)
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def kernel_status_csv(name: str = DEFAULT_LIST, create: bool = True) -> str:
    """Path for the per-list kernel capture ledger."""
    path = os.path.join("kernels", name)
    if create:
        os.makedirs(path, exist_ok=True)
    return os.path.join(path, "capture_status.csv")


# ---------------------------------------------------------------------------
# dtype / AMP handling
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DtypeSpec:
    """How to run a model: parameter dtype plus optional autocast dtype.

    ``tag`` is what ends up in metadata/result filenames.  For AMP modes the
    parameters stay in fp32 and only the autocast-eligible ops (conv, linear,
    matmul, sdpa) run in reduced precision, which is what the real training and
    inference harnesses do.
    """

    tag: str
    param_dtype: torch.dtype
    autocast_dtype: torch.dtype | None = None

    @property
    def is_amp(self) -> bool:
        return self.autocast_dtype is not None

    def autocast(self, device_type: str = "cuda"):
        """Context manager for the forward pass (no-op when not an AMP spec)."""
        if self.autocast_dtype is None:
            return torch.autocast(device_type, enabled=False)
        return torch.autocast(device_type, dtype=self.autocast_dtype, enabled=True)


DTYPE_SPECS: dict[str, DtypeSpec] = {
    "float32":  DtypeSpec("float32",  torch.float32),
    "float16":  DtypeSpec("float16",  torch.float16),
    "bfloat16": DtypeSpec("bfloat16", torch.bfloat16),
    # AMP: fp32 master weights, reduced-precision compute
    "amp_bf16": DtypeSpec("amp_bf16", torch.float32, torch.bfloat16),
    "amp_fp16": DtypeSpec("amp_fp16", torch.float32, torch.float16),
}

DEFAULT_DTYPES = ["amp_bf16"]


def resolve_dtype_spec(name: str) -> DtypeSpec:
    if name not in DTYPE_SPECS:
        raise ValueError(
            f"Unknown dtype '{name}'. Choose from: {', '.join(DTYPE_SPECS)}"
        )
    return DTYPE_SPECS[name]


def torch_dtype_name(dtype: torch.dtype) -> str:
    return str(dtype).replace("torch.", "")


# Reduced-precision accumulation makes fp32 tolerances meaningless: bf16 keeps
# roughly 3 significant decimal digits, fp16 about 3-4.
_TOLERANCES = {
    torch.float32:  (1e-4, 1e-4),
    torch.float64:  (1e-6, 1e-6),
    torch.float16:  (1e-2, 1e-2),
    torch.bfloat16: (5e-2, 5e-2),
}


def allclose_for_dtype(a: torch.Tensor, b: torch.Tensor) -> bool:
    """torch.allclose with a tolerance appropriate to the tensor dtype."""
    atol, rtol = _TOLERANCES.get(a.dtype, (1e-4, 1e-4))
    return torch.allclose(a.float(), b.float(), atol=atol, rtol=rtol)


# ---------------------------------------------------------------------------
# Model suite detection & loading
# ---------------------------------------------------------------------------

# Benchmark shorthand aliases -> real HuggingFace hub IDs or class names.
HF_ALIAS_MAP: dict[str, str] = {
    "AllenaiLongformerBase":   "allenai/longformer-base-4096",
    "DistillGPT2":             "distilgpt2",
    "GoogleFnet":              "google/fnet-base",
    "T5Small":                 "t5-small",
    "TrOCRForCausalLM":        "microsoft/trocr-base-handwritten",
    "YituTechConvBert":        "YituTech/conv-bert-base",
    "MegatronBertForCausalLM": "MegatronBertForMaskedLM",
}


def is_hf_model(model_name: str) -> bool:
    """HuggingFace if it looks like a hub ID or a transformers class name.

    timm model names are always lowercase, so a leading capital is a reliable
    discriminator and avoids importing transformers just to classify.
    """
    if "/" in model_name:
        return True
    return bool(model_name) and model_name[0].isupper()


_GROUPED_MM_AUTOCAST_LIB = None


def register_grouped_mm_autocast() -> bool:
    """Give MoE expert GEMMs an autocast rule, which upstream does not.

    ``aten::_grouped_mm`` has no AutocastCUDA kernel, so under an AMP spec —
    fp32 parameters with autocast converting at each op — it is handed fp32
    matrices and rejects them outright ("Expected mat_a to be BFloat16 or
    supported Float16 matrix").  That takes out every MoE model, which is most of
    the priority list, at the default dtype.

    The rule casts both matrices to whatever dtype autocast is currently
    promoting to, matching what the built-in mm/bmm rules do, rather than a fixed
    dtype: the sweep runs amp_bf16 and amp_fp16 and both have to work.  ``offs``
    is integral and left alone.
    """
    global _GROUPED_MM_AUTOCAST_LIB
    if _GROUPED_MM_AUTOCAST_LIB is not None:
        return True
    if torch._C._dispatch_has_kernel_for_dispatch_key("aten::_grouped_mm",
                                                      "AutocastCUDA"):
        return False  # upstream grew one; leave it alone

    def _grouped_mm_autocast(self, mat2, offs=None, bias=None, out_dtype=None):
        dtype = torch.get_autocast_dtype("cuda")
        with torch.amp.autocast("cuda", enabled=False):
            return torch.ops.aten._grouped_mm(
                self.to(dtype) if self.is_floating_point() else self,
                mat2.to(dtype) if mat2.is_floating_point() else mat2,
                offs, bias, out_dtype)

    # Held at module scope: the registration lives only as long as the Library.
    lib = torch.library.Library("aten", "IMPL")
    lib.impl("_grouped_mm", _grouped_mm_autocast, "AutocastCUDA")
    _GROUPED_MM_AUTOCAST_LIB = lib
    return True


def _shim_remote_code_imports() -> None:
    """Re-export symbols that remote modelling code imports from old locations.

    Models shipping custom code pin themselves to whichever transformers version
    they were written against.  Kimi-K3 imports ``OutputRecorder`` from
    ``transformers.utils.generic``, which is where it lived in 4.x; in 5.x it
    moved to ``transformers.modeling_utils``.  Aliasing it back is enough to let
    that code import, and it costs nothing when the name is already present.
    """
    import transformers.utils.generic as generic

    moved = {"OutputRecorder": "transformers.modeling_utils",
             "check_model_inputs": "transformers.modeling_utils"}
    for symbol, home in moved.items():
        if hasattr(generic, symbol):
            continue
        try:
            module = __import__(home, fromlist=[symbol])
        except Exception:
            continue
        if hasattr(module, symbol):
            setattr(generic, symbol, getattr(module, symbol))

    # Symbols 5.x removed outright rather than moved.  torch.fx tracing support
    # is gone, and the remote code that asks about it only does so to decide
    # whether to enable a tracing path we do not want anyway, so reporting False
    # is both honest and what we want.  Nothing in stock transformers imports
    # these any more, so the stubs are visible only to remote code.
    import transformers.utils.import_utils as import_utils

    for module, stubs in ((import_utils, {"is_torch_fx_available": lambda: False}),):
        for symbol, stub in stubs.items():
            if not hasattr(module, symbol):
                setattr(module, symbol, stub)

    _shim_mask_helpers()
    _shim_legacy_tie_weights()


def _shim_mask_helpers() -> None:
    """Let the mask builders tolerate the argument names 4.x used.

    ``create_causal_mask`` took ``input_embeds`` and ``cache_position`` in 4.x;
    in 5.x the first is spelled ``inputs_embeds`` and the second is gone.  Remote
    modelling code still calls the old spelling.  The wrapper renames what it can
    and drops what no longer exists, then delegates — callers using the current
    names pass straight through, so stock models are unaffected.
    """
    import functools
    import inspect

    import transformers.masking_utils as masking

    renames = {"input_embeds": "inputs_embeds"}

    for fname in ("create_causal_mask", "create_sliding_window_causal_mask",
                  "create_chunked_causal_mask"):
        original = getattr(masking, fname, None)
        if original is None or getattr(original, "_legacy_shim", False):
            continue
        accepted = set(inspect.signature(original).parameters)

        @functools.wraps(original)
        def wrapper(*args, _original=original, _accepted=accepted, **kwargs):
            for old, new in renames.items():
                if old in kwargs and new not in kwargs:
                    kwargs[new] = kwargs.pop(old)
            return _original(*args, **{k: v for k, v in kwargs.items()
                                       if k in _accepted})

        wrapper._legacy_shim = True
        setattr(masking, fname, wrapper)

    _shim_fa2_padding_mask()


def _shim_fa2_padding_mask() -> None:
    """Let the flash-attention mask builder answer "no padding" when it cannot look.

    ``flash_attention_mask`` returns None — meaning no mask is needed and the
    causal flag will do — once it has established there are no padding tokens,
    and it establishes that by evaluating ``attention_mask.all()``.  That reads
    tensor *values*, so under fake tensors it raises rather than answering, and a
    model that insists on flash attention cannot be captured at all: Kimi-K3
    overwrites ``_attn_implementation`` with flash_attention_2 in its own
    ``__init__`` whatever it was handed, so there is no way to negotiate.

    The answer is knowable here even though the tensor is not.  make_hf_input
    builds the attention mask as all ones, so there is no padding to find, and
    the wrapper says so — but only when asking properly was impossible.  A real
    run evaluates the mask exactly as before, and so does a fake run of any model
    that lets us pick SDPA, since neither reaches this path.
    """
    import functools

    import transformers.masking_utils as masking
    from torch._subclasses.fake_tensor import DataDependentOutputException

    original = getattr(masking, "flash_attention_mask", None)
    if original is None or getattr(original, "_legacy_shim", False):
        return

    @functools.wraps(original)
    def wrapper(*args, **kwargs):
        try:
            return original(*args, **kwargs)
        except DataDependentOutputException:
            return None

    wrapper._legacy_shim = True
    masking.flash_attention_mask = wrapper
    # Dispatch is by registry, not by module attribute, and the flash variants
    # share the one builder.
    mapping = masking.ALL_MASK_ATTENTION_FUNCTIONS._global_mapping
    for key, func in list(mapping.items()):
        if func is original:
            mapping[key] = wrapper


def _shim_legacy_tie_weights() -> None:
    """Let a model whose ``tie_weights`` predates 5.x still be instantiated.

    ``init_weights`` calls ``self.tie_weights(recompute_mapping=False)``, and an
    override written against 4.x takes no arguments at all — Kimi-K3's is one
    line delegating to its language model.  The failure is a TypeError raised
    inside ``from_config``, so there is no instance to repair afterwards; the
    signature has to be made tolerant before construction reaches it.

    Only a class that cannot accept the argument is touched, and only by dropping
    what it does not understand.  Tying matters less here than anywhere: no
    checkpoint is ever loaded, so it decides which uninitialised tensor shares
    storage with which, and neither shape nor kernel depends on the answer.
    """
    import functools
    import inspect

    from transformers.modeling_utils import PreTrainedModel

    original = PreTrainedModel.init_weights
    if getattr(original, "_legacy_shim", False):
        return

    @functools.wraps(original)
    def init_weights(self):
        cls = type(self)
        tie = cls.tie_weights
        params = inspect.signature(tie).parameters
        stale = ("recompute_mapping" not in params
                 and not any(p.kind is inspect.Parameter.VAR_KEYWORD
                             for p in params.values()))
        if stale and not getattr(tie, "_legacy_shim", False):
            @functools.wraps(tie)
            def tolerant(self, *args, _tie=tie, **kwargs):
                return _tie(self)

            tolerant._legacy_shim = True
            cls.tie_weights = tolerant
        return original(self)

    init_weights._legacy_shim = True
    PreTrainedModel.init_weights = init_weights


def _remote_code_classes(config):
    """Auto classes named in a remote-code config's ``auto_map``, best first.

    A config loaded with ``trust_remote_code`` is a dynamically created class, so
    it is in no auto class's ``_model_mapping`` and the usual registry lookup
    finds nothing.  ``auto_map`` is the model's own declaration of which heads it
    supports, so that is what we follow instead.
    """
    import transformers

    auto_map = getattr(config, "auto_map", None) or {}
    preferred = ["AutoModelForCausalLM", "AutoModelForConditionalGeneration",
                 "AutoModelForImageTextToText", "AutoModel"]
    names = [n for n in preferred if n in auto_map]
    names += [n for n in auto_map if n not in names and n != "AutoConfig"]
    return [getattr(transformers, n) for n in names if hasattr(transformers, n)]


def _auto_class_candidates():
    """Auto classes to try, most specific first.

    Order matters: Whisper is registered under both AutoModelForSpeechSeq2Seq
    and AutoModelForCausalLM, and picking the causal-LM head silently discards
    the audio encoder (and every convolution in it).  Multimodal models have
    the same problem with their vision towers.
    """
    import transformers

    names = [
        "AutoModelForSpeechSeq2Seq",
        "AutoModelForImageTextToText",
        "AutoModelForVision2Seq",
        "AutoModelForSeq2SeqLM",
        "AutoModelForCausalLM",
        "AutoModelForMaskedLM",
        "AutoModel",
    ]
    return [getattr(transformers, n) for n in names if hasattr(transformers, n)]


def _from_pretrained(auto_cls, hub_id: str, dtype: torch.dtype):
    """from_pretrained across the torch_dtype -> dtype rename in transformers v5."""
    last_exc: Exception | None = None
    for kwargs in ({"dtype": dtype}, {"torch_dtype": dtype}, {}):
        try:
            return auto_cls.from_pretrained(hub_id, **kwargs)
        except TypeError as exc:
            last_exc = exc
            continue
    raise last_exc if last_exc else RuntimeError("from_pretrained failed")


def _load_from_hub(hub_id: str, dtype: torch.dtype):
    import transformers

    # Match the config against each auto class's registry rather than trying
    # them blindly, so we get the architecture the checkpoint was built for.
    try:
        config = transformers.AutoConfig.from_pretrained(hub_id)
    except Exception as exc:
        raise RuntimeError(f"Could not load config for '{hub_id}': {exc}") from exc

    last_exc: Exception | None = None
    for auto_cls in _auto_class_candidates():
        mapping = getattr(auto_cls, "_model_mapping", None)
        if mapping is not None and type(config) not in mapping:
            continue
        try:
            return _from_pretrained(auto_cls, hub_id, dtype)
        except Exception as exc:
            last_exc = exc

    try:
        return _from_pretrained(transformers.AutoModel, hub_id, dtype)
    except Exception as exc:
        last_exc = exc
    raise RuntimeError(f"Could not load HuggingFace hub model '{hub_id}': {last_exc}")


def load_hf_model(model_name: str, dtype: torch.dtype):
    """Alias map -> hub ID -> transformers class (random weights) -> hub fallback."""
    import transformers

    resolved = HF_ALIAS_MAP.get(model_name, model_name)

    if "/" in resolved:
        return _load_from_hub(resolved, dtype)

    model_class = getattr(transformers, resolved, None)
    if model_class is not None:
        config = model_class.config_class()

        # GPT-style configs have no pad token, which breaks batched forwards.
        if getattr(config, "pad_token_id", None) is None:
            eos = getattr(config, "eos_token_id", None)
            if eos is not None:
                config.pad_token_id = eos[0] if isinstance(eos, list) else eos

        # A *ForCausalLM head built from an encoder-decoder config still thinks
        # it is one half of a seq2seq model and sets up a cross-attention cache
        # with no layers, which blows up on the first decoder block.
        if resolved.endswith("ForCausalLM") and getattr(
            config, "is_encoder_decoder", False
        ):
            config.is_encoder_decoder = False
            config.is_decoder = True

        # Prefer SDPA so attention shows up in the SDPA metadata; models whose
        # attention is eager-only reject this and keep their default.
        # The attempt is made on a copy because _from_config stamps the
        # implementation onto the config before validating it, which would make
        # the fallback fail the same way.
        import copy

        try:
            return model_class._from_config(
                copy.deepcopy(config), attn_implementation="sdpa"
            )
        except Exception:
            return model_class(config)

    return _load_from_hub(resolved, dtype)


def build_model_from_config(model_name: str, dtype: torch.dtype,
                            trust_remote_code: bool = True):
    """Instantiate a model from its architecture definition alone.

    Nothing but ``config.json`` is fetched — for a hub ID this means
    ``from_config`` instead of ``from_pretrained``, and for timm
    ``pretrained=False``.  The weights are whatever the model's own initialiser
    produces.

    This is the default because shape capture never needs *trained* values: the
    conv, GEMM and attention shapes a model executes are fixed by its
    architecture. Skipping the checkpoint is what makes a 1.6T model no more
    expensive to inspect than an 8B one, and it removes the download as a
    failure mode entirely.

    ``trust_remote_code`` lets models that ship their own modelling code (Kimi,
    MiMo) resolve.  It executes code from the Hub repo, which is why it is a
    knob at all; it defaults on because every list in scripts/models/ is curated.
    """
    if not is_hf_model(model_name):
        import timm

        return timm.create_model(model_name, pretrained=False).eval()

    import transformers

    resolved = HF_ALIAS_MAP.get(model_name, model_name)
    if getattr(transformers, resolved, None) is not None:
        # A transformers class name: already built from a default config.
        return load_hf_model(model_name, dtype).eval()

    if trust_remote_code:
        _shim_remote_code_imports()
    # Stock models need the mask shims too, and the stock path is reached with
    # remote code turned off.
    _shim_mask_helpers()
    try:
        config = transformers.AutoConfig.from_pretrained(
            resolved, trust_remote_code=trust_remote_code)
    except Exception as exc:
        # Diffusion repos are pipelines, not models: no model_type, so no
        # AutoConfig entry, and sometimes a top-level config.json that is not a
        # transformers config at all.  Rather than pattern-match the failure,
        # just try diffusers and report the transformers error if that fails too.
        try:
            return build_diffusion_denoiser(resolved, dtype)
        except Exception:
            raise exc from None

    # Quantized checkpoints carry a quantization_config that sends
    # instantiation through a quantizer expecting real weights to pack.  There
    # are no weights here, and the GEMM shapes are the same either way, so the
    # dense architecture is what we want.
    if getattr(config, "quantization_config", None) is not None:
        config.quantization_config = None

    import copy

    # Remote-code configs are dynamic classes and appear in no _model_mapping,
    # so they are resolved through the config's own auto_map instead.
    candidates = [(c, {"trust_remote_code": True})
                  for c in _remote_code_classes(config)]
    candidates += [(c, {}) for c in _auto_class_candidates()
                   if (m := getattr(c, "_model_mapping", None)) is not None
                   and type(config) in m]

    for auto_cls, extra in candidates:
        # Prefer SDPA so attention lands in the SDPA metadata rather than being
        # decomposed into bmms; models without an SDPA path reject it.  Each
        # attempt gets its own copy because from_config stamps the
        # implementation onto the config before validating it, which would make
        # the plain retry fail exactly the same way.
        for kwargs in ({"attn_implementation": "sdpa"}, {}):
            try:
                return auto_cls.from_config(copy.deepcopy(config),
                                            **extra, **kwargs).eval()
            except Exception:
                continue

    # A repo can ship modelling code for an architecture transformers has since
    # absorbed, and the vendored copy is then the older of the two.  MiniMax-M3's
    # leaves its vision config untyped, so the defaults that config class
    # declares — temporal_patch_size among them — never exist and its own
    # __init__ raises reading one.  Where the installed transformers knows the
    # architecture natively, that implementation is the better answer: same
    # model, maintained against this version.
    if trust_remote_code and getattr(config, "auto_map", None):
        try:
            return build_model_from_config(model_name, dtype,
                                           trust_remote_code=False)
        except Exception:
            pass
    return transformers.AutoModel.from_config(
        copy.deepcopy(config), trust_remote_code=trust_remote_code).eval()


# ---------------------------------------------------------------------------
# diffusion pipelines
# ---------------------------------------------------------------------------
#
# A diffusion repo is a pipeline, not a model: text encoder, denoiser, VAE and
# scheduler side by side, with no model_type and so no AutoConfig entry.  Only
# the denoiser ("transformer") is captured, because that is where essentially all
# of the GEMM and attention work is — the VAE runs once per generation and the
# text encoder is a stock transformer already covered by the other lists.

DIFFUSION_COMPONENT = "transformer"


def is_diffusion_model(model) -> bool:
    """True for a denoiser built by build_diffusion_denoiser()."""
    return getattr(model, "_shape_capture_diffusion", False)


def build_diffusion_denoiser(hub_id: str, dtype: torch.dtype):
    """Build a pipeline's denoiser from its component config alone.

    Only ``model_index.json`` and the denoiser's ``config.json`` are fetched, so
    this stays as cheap as the transformers path even for a 16B video model.
    """
    import json

    import diffusers
    from huggingface_hub import hf_hub_download

    try:
        index = json.load(open(hf_hub_download(hub_id, "model_index.json")))
    except Exception as exc:
        raise RuntimeError(
            f"'{hub_id}' is neither a transformers model nor a diffusers "
            f"pipeline (no model_index.json): {exc}") from exc

    entry = index.get(DIFFUSION_COMPONENT)
    if not entry:
        raise RuntimeError(
            f"diffusers pipeline '{hub_id}' has no '{DIFFUSION_COMPONENT}' "
            f"component; found {sorted(k for k in index if not k.startswith('_'))}")

    cls_name = entry[-1]
    cls = getattr(diffusers, cls_name, None)
    if cls is None:
        raise RuntimeError(
            f"'{hub_id}' needs {cls_name}, which diffusers "
            f"{diffusers.__version__} does not provide")

    config = cls.load_config(hub_id, subfolder=DIFFUSION_COMPONENT)
    model = cls.from_config(config).eval()
    # make_model_input dispatches on this: a denoiser takes video latents and
    # text embeddings, nothing like a transformers model's token IDs.
    model._shape_capture_diffusion = True
    return model


# The clip every denoiser is exercised on: 33 frames of 480x832.  Latent grids
# are derived from it per family, because VAE compression differs by an order of
# magnitude — Wan and HunyuanVideo compress 8x spatially, LTX 32x — and attention
# cost is quadratic in the token count, so a shared grid would be wrong for one
# of them by a factor of 16.
DIFFUSION_FRAMES = 33
DIFFUSION_HEIGHT = 480
DIFFUSION_WIDTH = 832
DIFFUSION_TEXT_LEN = 512

# family prefix -> (spatial compression, temporal compression)
_VAE_COMPRESSION = {
    "Wan": (8, 4),
    "HunyuanVideo": (8, 4),
    "LTXVideo": (32, 8),
    "QwenImage": (8, 1),
}

# Image models get a single frame at 1328x1328, the resolution Qwen-Image is
# tuned for, rather than the video clip.
DIFFUSION_IMAGE_SIZE = 1328


def _latent_grid(class_name: str) -> tuple[int, int, int]:
    spatial, temporal = next(
        (v for k, v in _VAE_COMPRESSION.items() if class_name.startswith(k)),
        (8, 4))
    if temporal == 1:
        return 1, DIFFUSION_IMAGE_SIZE // spatial, DIFFUSION_IMAGE_SIZE // spatial
    return ((DIFFUSION_FRAMES - 1) // temporal + 1,
            DIFFUSION_HEIGHT // spatial,
            DIFFUSION_WIDTH // spatial)


def make_diffusion_input(model, batch_size: int, spec: DtypeSpec,
                         device: str = "cuda") -> dict:
    """Inputs for one denoising step, sized from the denoiser's own config."""
    cfg = model.config
    dt = spec.param_dtype
    name = type(model).__name__
    f, h, w = _latent_grid(name)
    c_in = cfg.in_channels

    def rand(*shape):
        return torch.randn(*shape, device=device, dtype=dt)

    inputs: dict[str, object] = {
        "timestep": torch.full((batch_size,), 500, device=device,
                               dtype=torch.long),
    }

    if name.startswith("QwenImage"):
        # Packed 2x2 patches of the latent image, plus the grid so RoPE can be
        # rebuilt.  Text comes from a Qwen2.5-VL encoder, hence the long context.
        p = getattr(cfg, "patch_size", 2)
        seq = (h // p) * (w // p)
        inputs["hidden_states"] = rand(batch_size, seq, c_in)
        inputs["encoder_hidden_states"] = rand(batch_size, DIFFUSION_TEXT_LEN,
                                              cfg.joint_attention_dim)
        inputs["encoder_hidden_states_mask"] = torch.ones(
            batch_size, DIFFUSION_TEXT_LEN, device=device, dtype=torch.long)
        inputs["img_shapes"] = [(1, h // p, w // p)] * batch_size
        if getattr(cfg, "guidance_embeds", False):
            inputs["guidance"] = torch.full((batch_size,), 1000.0,
                                            device=device, dtype=dt)
        return inputs

    if name.startswith("LTXVideo"):
        # LTX patchifies before the transformer, so it takes a packed sequence
        # and is told the grid separately to rebuild positions.
        pt = getattr(cfg, "patch_size", 1)
        ptt = getattr(cfg, "patch_size_t", 1)
        seq = (f // ptt) * (h // pt) * (w // pt)
        inputs["hidden_states"] = rand(batch_size, seq, c_in)
        inputs["encoder_hidden_states"] = rand(batch_size, DIFFUSION_TEXT_LEN,
                                               cfg.caption_channels)
        inputs["encoder_attention_mask"] = torch.ones(
            batch_size, DIFFUSION_TEXT_LEN, device=device, dtype=torch.long)
        inputs["num_frames"] = f // ptt
        inputs["height"] = h // pt
        inputs["width"] = w // pt
        return inputs

    # Wan and HunyuanVideo both patchify inside the denoiser, so they take the
    # latent video as a 5-D tensor.
    inputs["hidden_states"] = rand(batch_size, c_in, f, h, w)

    if name.startswith("HunyuanVideo"):
        inputs["encoder_hidden_states"] = rand(batch_size, DIFFUSION_TEXT_LEN,
                                               cfg.text_embed_dim)
        inputs["encoder_attention_mask"] = torch.ones(
            batch_size, DIFFUSION_TEXT_LEN, device=device, dtype=torch.long)
        inputs["pooled_projections"] = rand(batch_size,
                                            cfg.pooled_projection_dim)
        if getattr(cfg, "guidance_embeds", False):
            inputs["guidance"] = torch.full((batch_size,), 1000.0,
                                            device=device, dtype=dt)
        return inputs

    # Wan
    inputs["encoder_hidden_states"] = rand(batch_size, DIFFUSION_TEXT_LEN,
                                           cfg.text_dim)
    if getattr(cfg, "image_dim", None):
        # I2V variants also cross-attend to CLIP features of the seed frame.
        inputs["encoder_hidden_states_image"] = rand(batch_size, 257,
                                                     cfg.image_dim)
    return inputs


def load_model(model_name: str, spec: DtypeSpec, device: str = "cuda",
               pretrained: bool = False, trust_remote_code: bool = True):
    """Load a timm or HuggingFace model onto ``device`` in ``spec.param_dtype``.

    ``pretrained`` controls whether the checkpoint is downloaded.  It defaults
    to False: trained values do not change which kernels run, so paying for a
    multi-hundred-GB download to discover that is a bad trade.  Pass True only
    when the captured values themselves matter.
    """
    if pretrained:
        if is_hf_model(model_name):
            model = load_hf_model(model_name, spec.param_dtype)
        else:
            import timm

            model = timm.create_model(model_name, pretrained=True)
    else:
        model = build_model_from_config(model_name, spec.param_dtype,
                                        trust_remote_code)

    diffusion = is_diffusion_model(model)
    model = model.to(device).to(spec.param_dtype).eval()
    model._shape_capture_diffusion = diffusion
    return model


def load_model_meta(model_name: str, spec: DtypeSpec,
                    trust_remote_code: bool = True):
    """Build the model on the meta device: correct shapes, zero allocation.

    Construction happens *outside* any FakeTensorMode on purpose. Config-time
    code often computes on real CPU tensors — timm's stochastic-depth schedule
    does ``[x.item() for x in torch.linspace(...)]`` — and ``.item()`` raises
    under fake tensors even though it has nothing to do with the model's shapes.
    Meta params keep that code working while still allocating nothing.
    """
    import torch

    with torch.device("meta"):
        return build_model_from_config(model_name, spec.param_dtype,
                                       trust_remote_code)


def fakeify_module(model, dtype: torch.dtype, device: str = "cuda"):
    """Swap every parameter and buffer for a fake tensor of the same shape.

    Must be called inside a ``FakeTensorMode`` so ``torch.empty`` yields fake
    tensors. Assigns into ``_parameters``/``_buffers`` directly instead of using
    ``.to()``: ``nn.Module._apply`` forces the ``swap_tensors`` path whenever a
    parameter is a ``FakeTensor``, and that swap always fails.

    Buffer *values* become meaningless, which costs nothing here because fake
    tensors have no values at all — only shapes and dtypes are being collected.
    Integer buffers keep their dtype so index and mask arithmetic still types.
    """
    for module in model.modules():
        for name, param in list(module._parameters.items()):
            if param is None:
                continue
            want = dtype if param.is_floating_point() else param.dtype
            module._parameters[name] = torch.nn.Parameter(
                torch.empty(param.shape, dtype=want, device=device),
                requires_grad=param.requires_grad,
            )
        for name, buf in list(module._buffers.items()):
            if buf is None:
                continue
            want = dtype if buf.is_floating_point() else buf.dtype
            module._buffers[name] = torch.empty(
                buf.shape, dtype=want, device=device
            )
    _shim_vision_value_reads(model)
    return model


def _shim_vision_value_reads(model) -> None:
    """Answer the two questions a vision tower asks of values we supplied.

    Both are about the *input*, not the weights, so both have answers even though
    a fake tensor cannot give them.  Applied only on the fake path, and only to
    the model in hand.

    ``get_vision_position_ids`` turns the (t, h, w) grid into per-patch position
    indices, which is index arithmetic over numbers this harness chose — but it
    goes through ``grid_thw.tolist()``, and it tensorises the merge size first,
    so the list comes back from a tensor born inside fake mode with no storage to
    read.  Running it with fake mode lifted computes the same indices for real.

    ``get_placeholder_mask`` masks the embeddings to count image placeholders and
    check they match the features, which needs nonzero on a fake tensor.  The
    count is right by construction — _grid_vision_inputs emits one placeholder
    per merged patch — and the model skips the check when handed no features, so
    the retry drops them.  The masks it returns are plain comparisons either way.
    """
    import functools
    import sys

    from torch._subclasses.fake_tensor import (DynamicOutputShapeException,
                                               unset_fake_temporarily)

    try:
        import transformers.vision_utils as vision_utils
    except ImportError:            # no grid-based tower in this transformers
        vision_utils = None

    for fname in () if vision_utils is None else ("get_vision_position_ids",
                                                 "get_vision_window_index"):
        original = getattr(vision_utils, fname, None)
        if original is None or getattr(original, "_fake_shim", False):
            continue

        @functools.wraps(original)
        def outside_fake(*args, _original=original, **kwargs):
            with unset_fake_temporarily():
                return _original(*args, **kwargs)

        outside_fake._fake_shim = True
        setattr(vision_utils, fname, outside_fake)
        # Modelling code imports these by name, so the module it landed in holds
        # its own reference to the original.
        for module in list(sys.modules.values()):
            if module is not vision_utils and \
                    getattr(module, fname, None) is original:
                setattr(module, fname, outside_fake)

    for module in model.modules():
        cls = type(module)
        original = getattr(cls, "get_placeholder_mask", None)
        if original is None or getattr(original, "_fake_shim", False):
            continue

        @functools.wraps(original)
        def without_feature_check(self, *args, _original=original, **kwargs):
            try:
                return _original(self, *args, **kwargs)
            except DynamicOutputShapeException:
                kwargs.pop("image_features", None)
                kwargs.pop("video_features", None)
                return _original(self, *args[:2], **kwargs)

        without_feature_check._fake_shim = True
        cls.get_placeholder_mask = without_feature_check


# ---------------------------------------------------------------------------
# Dummy inputs
# ---------------------------------------------------------------------------

HF_SEQ_LEN = 128

# Side of the square image handed to a grid-based vision tower.  672 is a
# multiple of patch x merge (28) for the whole family, so it divides into a
# 48x48 patch grid and 576 tokens after merging — and 672^2 is exactly the
# 451584-pixel ceiling MiniMax-M3's own image processor declares, which makes it
# the resolution that model expects to serve rather than a number we chose.
# Native-resolution towers have no fixed input size to read instead: their
# config's image_size is the largest image allowed (2016 here, 5184 tokens), not
# a typical one.
VL_IMAGE_SIZE = 672


def _sub_config(config, *names):
    """Fetch a nested sub-config (e.g. vision_config) if the model has one."""
    for name in names:
        sub = getattr(config, name, None)
        if sub is not None and hasattr(sub, "to_dict"):
            return sub
    return None


def _cfg(config, *names, default=None):
    for name in names:
        value = getattr(config, name, None)
        if value is not None:
            return value
    return default


def _grid_vision_inputs(config, vision_cfg, input_ids, device: str) -> dict:
    """Pixels already cut into patches, their grid, and the tokens standing in.

    A native-resolution tower (the Qwen2-VL family, MiniMax-M3-VL here) does not
    take an image as ``(B, C, H, W)``.  Its processor does the patching, so
    ``pixel_values`` arrives already flattened to
    ``(patches, channels x temporal x patch x patch)`` with a separate ``(t, h,
    w)`` grid saying how to fold it back up, and ``input_ids`` has to carry one
    placeholder token per *merged* patch so the features have somewhere to land.
    Handing such a model a plain image tensor leaves the grid at None, which is
    the first thing its position-id helper reads.

    Returned alongside the pixels is the replacement ``input_ids``: the text
    tokens the caller built, with an image's worth of placeholders appended.
    """
    batch_size = input_ids.shape[0]
    patch = int(_cfg(vision_cfg, "patch_size", default=14))
    temporal = int(_cfg(vision_cfg, "temporal_patch_size", default=2))
    merge = int(_cfg(vision_cfg, "spatial_merge_size", "merge_size", default=2))
    channels = int(_cfg(vision_cfg, "num_channels", default=3))

    # A whole number of merged patches, and never larger than the tower allows.
    step = patch * merge
    largest = int(_cfg(vision_cfg, "image_size", default=VL_IMAGE_SIZE)
                  or VL_IMAGE_SIZE)
    side = max(step, min(VL_IMAGE_SIZE, largest))
    side -= side % step

    # One still image per sequence: a frame is repeated to fill the temporal
    # patch, so the grid stays one deep however large temporal_patch_size is.
    grid_t, grid = 1, side // patch
    per_image = grid_t * grid * grid

    inputs = {
        "pixel_values": torch.randn(batch_size * per_image,
                                    channels * temporal * patch * patch,
                                    device=device),
        "image_grid_thw": torch.tensor([[grid_t, grid, grid]] * batch_size,
                                       dtype=torch.long, device=device),
    }

    image_token = _cfg(config, "image_token_index", "image_token_id")
    if image_token is None:
        return inputs

    text = input_ids.clone()
    # A placeholder drawn by chance in the text half would be counted as an
    # image token and outnumber the features.
    for token in (image_token, _cfg(config, "video_token_index",
                                    "video_token_id")):
        if token is not None:
            text[text == int(token)] = 0
    placeholders = torch.full((batch_size, per_image // (merge * merge)),
                              int(image_token), dtype=text.dtype, device=device)
    inputs["input_ids"] = torch.cat([text, placeholders], dim=1)
    inputs["attention_mask"] = torch.ones_like(inputs["input_ids"])
    return inputs


def _decoder_inputs(config, batch_size: int, device: str) -> dict:
    dec_start = _cfg(config, "decoder_start_token_id", "bos_token_id", default=0) or 0
    return {
        "decoder_input_ids": torch.full(
            (batch_size, 1), int(dec_start), dtype=torch.long, device=device
        )
    }


def make_hf_input(model, batch_size: int, device: str) -> dict:
    """Dummy inputs matching the model's actual modality.

    Feeding token IDs to a speech or vision encoder means the encoder never
    runs, so its convolutions are never observed.  We pick the input kind from
    the forward signature and the config instead of assuming text.
    """
    import inspect

    config = model.config
    try:
        params = set(inspect.signature(model.forward).parameters)
    except (TypeError, ValueError):
        params = set()

    # ---- speech encoders (Whisper, Wav2Vec2, SpeechT5, …) -----------------
    # Only when the model cannot take text at all, mirroring the vision branch.
    # Omni-modal models (Gemma 4) accept input_features *and* input_ids, and
    # feeding them audio alone leaves the language model without the tokens it
    # requires and the forward fails outright.
    if "input_features" in params and "input_ids" not in params:
        num_mel = int(_cfg(config, "num_mel_bins", "input_feat_per_channel",
                           "feature_size", default=80))
        frames = int(_cfg(config, "max_source_positions", default=1500)) * 2
        inputs = {
            "input_features": torch.randn(batch_size, num_mel, frames, device=device)
        }
        inputs.update(_decoder_inputs(config, batch_size, device))
        return inputs

    if "input_values" in params:
        samples = int(_cfg(config, "sampling_rate", default=16000))
        return {"input_values": torch.randn(batch_size, samples, device=device)}

    # ---- vision-only encoders (ViT, BEiT, … as HF models) -----------------
    # VisionEncoderDecoder models (TrOCR) keep the image geometry under
    # 'encoder' rather than 'vision_config', and guessing 224 there fails
    # against a 384x384 encoder.
    vision_cfg = _sub_config(config, "vision_config", "encoder") or config
    image_size = _cfg(vision_cfg, "image_size")
    num_channels = int(_cfg(vision_cfg, "num_channels", default=3))

    if "pixel_values" in params and "input_ids" not in params:
        size = int(image_size or 224)
        inputs = {
            "pixel_values": torch.randn(
                batch_size, num_channels, size, size, device=device
            )
        }
        if getattr(config, "is_encoder_decoder", False) or "decoder_input_ids" in params:
            inputs.update(_decoder_inputs(
                _sub_config(config, "decoder", "decoder_config") or config,
                batch_size, device,
            ))
        return inputs

    # ---- text, optionally multimodal --------------------------------------
    text_cfg = _sub_config(config, "text_config") or config
    vocab_size = int(_cfg(text_cfg, "vocab_size", default=30522) or 30522)
    inputs = {
        "input_ids": torch.randint(
            0, vocab_size, (batch_size, HF_SEQ_LEN), device=device
        ),
        "attention_mask": torch.ones(
            batch_size, HF_SEQ_LEN, dtype=torch.long, device=device
        ),
    }

    # Multimodal models keep their conv-bearing vision tower dormant unless we
    # also hand them pixels.
    if "image_grid_thw" in params and _sub_config(config, "vision_config"):
        inputs.update(_grid_vision_inputs(config, vision_cfg,
                                          inputs["input_ids"], device))
    elif "pixel_values" in params and image_size and _sub_config(config, "vision_config"):
        size = int(image_size)
        inputs["pixel_values"] = torch.randn(
            batch_size, num_channels, size, size, device=device
        )

    if getattr(config, "is_encoder_decoder", False):
        inputs.update(_decoder_inputs(config, batch_size, device))
    return inputs


def _disable_cache(inputs: dict, model) -> dict:
    """Turn off the KV cache for the capture pass.

    We only ever run a single forward, so the cache buys nothing, and some
    decoder-only heads derived from seq2seq configs build a cross-attention
    cache with no layers and crash on the first block.
    """
    import inspect

    try:
        params = inspect.signature(model.forward).parameters
    except (TypeError, ValueError):
        return inputs
    if "use_cache" in params:
        inputs["use_cache"] = False
    return inputs


def make_timm_input(model, batch_size: int, spec: DtypeSpec, device: str):
    """Image tensor matching the resolution the timm model was trained at."""
    import timm.data

    c, h, w = timm.data.resolve_model_data_config(model)["input_size"]
    return torch.randn(batch_size, c, h, w, device=device, dtype=spec.param_dtype)


def make_model_input(model, model_name: str, batch_size: int,
                     spec: DtypeSpec, device: str = "cuda"):
    """Return (inputs, is_kwargs) suitable for a single forward pass.

    Float inputs are cast to the parameter dtype; integer inputs (token IDs,
    masks) are left alone.  Under AMP the parameters stay fp32 and autocast
    handles the conversion at each op.
    """
    if is_diffusion_model(model):
        return make_diffusion_input(model, batch_size, spec, device), True

    if not is_hf_model(model_name):
        return make_timm_input(model, batch_size, spec, device), False

    inputs = make_hf_input(model, batch_size, device)
    inputs = {
        k: v.to(spec.param_dtype) if torch.is_floating_point(v) else v
        for k, v in inputs.items()
    }
    return _disable_cache(inputs, model), True


# ---------------------------------------------------------------------------
# model list parsing and resolution
# ---------------------------------------------------------------------------

DEFAULT_BATCH_SIZE = 32


def models_dir() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")


def available_lists() -> list[str]:
    """Names of every list in scripts/models/, sorted."""
    if not os.path.isdir(models_dir()):
        return []
    return sorted(f[: -len(LIST_SUFFIX)] for f in os.listdir(models_dir())
                  if f.endswith(LIST_SUFFIX))


def list_name_for(path: str) -> str:
    """The list name a path denotes, so --models-file also names its outputs."""
    base = os.path.basename(path)
    return base[: -len(LIST_SUFFIX)] if base.endswith(LIST_SUFFIX) else \
        os.path.splitext(base)[0]


def list_path(name: str) -> str:
    return os.path.join(models_dir(), f"{name}{LIST_SUFFIX}")


def parse_models_file(path: str, default_batch_size: int = DEFAULT_BATCH_SIZE
                      ) -> list[tuple[str, int]]:
    """Parse 'model_name [batch_size]' lines, skipping blanks and comments."""
    entries: list[tuple[str, int]] = []
    with open(path) as fh:
        for line in fh:
            parts = line.strip().split()
            if not parts or parts[0].startswith("#"):
                continue
            batch_size = int(parts[1]) if len(parts) > 1 else default_batch_size
            entries.append((parts[0], batch_size))
    return entries


def parse_all_lists(default_batch_size: int = DEFAULT_BATCH_SIZE
                    ) -> list[tuple[str, int]]:
    """Every unique model across every list in scripts/models/.

    First occurrence wins, so a model that appears in two lists is captured once
    at the batch size of whichever list sorts first.  Lists are visited in name
    order to keep that deterministic.
    """
    seen: dict[str, int] = {}
    for name in available_lists():
        for model, batch_size in parse_models_file(list_path(name),
                                                   default_batch_size):
            seen.setdefault(model, batch_size)
    return list(seen.items())


def resolve_models(models_file: str | None, list_name: str | None,
                   use_all: bool) -> tuple[list[tuple[str, int]], str, str]:
    """Turn the list-selection flags into (entries, name, description).

    Precedence is --models-file, then --list, then --all, then the default list.
    The returned name is what output paths are keyed on.
    """
    if models_file:
        if not os.path.isfile(models_file):
            raise SystemExit(f"ERROR: models file not found: {models_file}")
        return (parse_models_file(models_file), list_name_for(models_file),
                models_file)
    if list_name:
        path = list_path(list_name)
        if not os.path.isfile(path):
            raise SystemExit(
                f"ERROR: no list named '{list_name}'. Available: "
                f"{', '.join(available_lists()) or '(none)'}")
        return parse_models_file(path), list_name, path
    if use_all:
        names = available_lists()
        if not names:
            raise SystemExit(f"ERROR: no {LIST_SUFFIX} files in {models_dir()}")
        return (parse_all_lists(), ALL_LIST,
                f"all lists ({', '.join(names)})")
    path = list_path(DEFAULT_LIST)
    if not os.path.isfile(path):
        raise SystemExit(f"ERROR: default list not found: {path}")
    return parse_models_file(path), DEFAULT_LIST, path


def add_multi_gpu_argument(parser) -> None:
    """The multi-device autotuning flag, shared by every driver."""
    parser.add_argument(
        "--multi-gpu", action="store_true",
        help="Time one shape's candidate configs across every visible GPU, "
             "one benchmarking subprocess per device.  Restrict the set with "
             "HIP_VISIBLE_DEVICES or CUDA_VISIBLE_DEVICES.  Compilation stays "
             "serial in this process, so this speeds up the benchmarking half "
             "only, and a shape's candidates end up timed on different dies")


def _isolate_visible_devices_for_pool() -> None:
    """Move a HIP_VISIBLE_DEVICES isolation onto CUDA_VISIBLE_DEVICES.

    Inductor hands each benchmarking subprocess one GPU by setting
    CUDA_VISIBLE_DEVICES, but HIP supersedes that with HIP_VISIBLE_DEVICES
    whenever both are set, so a parent isolated the ROCm way would give every
    child the same physical device and time one shape's candidates on a single
    contended GPU — with no error, just wrong numbers.  Translating here is
    safe because this process' HIP runtime read the variable when it
    initialised, and the children inherit whatever we leave behind.
    """
    hip = os.environ.get("HIP_VISIBLE_DEVICES")
    if not hip:
        return
    os.environ["CUDA_VISIBLE_DEVICES"] = hip
    del os.environ["HIP_VISIBLE_DEVICES"]
    print(f"[multi-gpu] HIP_VISIBLE_DEVICES={hip} moved to CUDA_VISIBLE_DEVICES, "
          f"which is the variable the benchmarking subprocesses are given")


def enable_multi_device() -> list:
    """Spread one autotune call's benchmarking across the visible GPUs.

    Sets the config attributes rather than the environment: Inductor reads both
    of these from os.environ when torch._inductor.config is imported, which has
    already happened by the time a driver parses its arguments, so exporting
    them at this point would be silently ignored.
    """
    from torch._inductor import config as _inductor_config
    from torch._inductor.autotune_process import TuningProcessPool

    _isolate_visible_devices_for_pool()
    # autotune_multi_device is only consulted when the benchmarking itself runs
    # in subprocesses, so the pair has to be set together.
    _inductor_config.autotune_in_subproc = True
    _inductor_config.autotune_multi_device = True
    return list(TuningProcessPool.get_device_list())


def add_shard_argument(parser) -> None:
    """The shape-sharding flag, shared by every driver."""
    parser.add_argument(
        "--shard", metavar="I/N",
        help="Measure only shard I of N, so one list can be swept by N "
             "processes on N GPUs.  Shapes are dealt round-robin rather than "
             "cut into blocks, because cost rises with shape index in most "
             "metadata and contiguous blocks would leave one shard with all "
             "the expensive shapes.  Each shard names its own outputs, and "
             "top_configs.py merges them because it globs the whole directory")


def parse_shard(spec: str | None) -> tuple[int, int] | None:
    """'I/N' -> (I, N), one-based on the command line and zero-based here.

    Rejecting a bad spec matters more than usual: a typo that silently ran the
    whole list in every shard would produce N copies of the same sweep and look
    like success.
    """
    if not spec:
        return None
    try:
        index, count = (int(part) for part in spec.split("/", 1))
    except ValueError:
        raise SystemExit(f"ERROR: --shard wants I/N, got '{spec}'")
    if count < 1 or not 1 <= index <= count:
        raise SystemExit(f"ERROR: --shard {spec} is out of range; "
                         f"I must be between 1 and N")
    return index - 1, count


def in_shard(position: int, shard: tuple[int, int] | None) -> bool:
    """Whether the shape at ``position`` belongs to this shard.

    Callers filter inside their loop rather than slicing the metadata, so the
    input index a row is recorded under keeps meaning the same thing in every
    shard and the merged results still line up with the metadata CSV.
    """
    if shard is None:
        return True
    index, count = shard
    return position % count == index


def shard_label(shard: tuple[int, int] | None) -> str | None:
    """'shard2of3' for filenames, or None when the sweep is not sharded."""
    if shard is None:
        return None
    index, count = shard
    return f"shard{index + 1}of{count}"


def namespace_inductor_cache(space: str, pinned: bool = False) -> str | None:
    """Give each config space its own Inductor cache directory.

    Inductor's caches are keyed on the graph and its own config, neither of
    which sees the search space we install over its heuristics.  Re-running a
    shape against a wider space therefore hits the FxGraph cache, returns the
    kernel the *previous* space picked, and never autotunes — so the log gains
    no entry for it and the widening silently does nothing.  Separating the
    cache directories per space makes that a miss, while a re-run of the same
    space still resumes from a warm cache, which is what makes an interrupted
    sweep cheap to finish.

    ``pinned`` says the caller found TORCHINDUCTOR_CACHE_DIR already set in the
    environment, in which case the choice is the operator's and is left alone.
    Returns the directory now in force, or None if it was not touched.
    """
    if pinned:
        return None
    root = os.environ.get("TORCHINDUCTOR_CACHE_DIR")
    if root is None:
        from torch._inductor.runtime.cache_dir_utils import default_cache_dir
        root = default_cache_dir()
    path = os.path.join(root, re.sub(r"[^A-Za-z0-9.-]+", "-", space))
    os.makedirs(path, exist_ok=True)
    os.environ["TORCHINDUCTOR_CACHE_DIR"] = path
    return path


def refresh_inductor_cache(inductor_root: str) -> str | None:
    """Start the sweep from an empty Inductor cache, keeping the old one aside.

    Without this a re-run of the same space hits the FxGraph cache, returns the
    kernel that run already picked and never autotunes, so the log gains no
    entry and --fresh-autotune does nothing.

    The old cache is moved rather than deleted so an interrupted sweep can still
    be resumed against it, and ``discard_inductor_backup`` drops it once the
    sweep has finished.  Only ever one backup exists: what is in there is
    compiled artifacts (.hsaco, .ttir and friends) that a re-run regenerates,
    and a wide space fills it with hundreds of gigabytes of them, so a backup
    per run fills the disk within a few sweeps.  Nothing irreplaceable is at
    stake either way -- the autotune logs are written per model under results/
    and were never in here.

    Returns where the old cache went, or None if there was none, to be handed
    to ``discard_inductor_backup`` at the end of the sweep.
    """
    for stale in sorted(glob.glob(f"{inductor_root}_bak*")):
        shutil.rmtree(stale, ignore_errors=True)
        print(f"[fresh-autotune] Removed earlier backup {stale}")

    moved = None
    if os.path.isdir(inductor_root):
        moved = f"{inductor_root}_bak"
        shutil.move(inductor_root, moved)
        print(f"[fresh-autotune] Moved {inductor_root} → {moved}")

    os.makedirs(inductor_root, exist_ok=True)
    os.environ["TORCHINDUCTOR_CACHE_DIR"] = inductor_root
    print(f"[fresh-autotune] TORCHINDUCTOR_CACHE_DIR={inductor_root} (fresh)")
    return moved


def discard_inductor_backup(backup: str | None) -> None:
    """Drop the cache ``refresh_inductor_cache`` moved aside.

    Called only once a sweep has run to the end, so a run that dies partway
    leaves the cache it was resumable against in place.  That one is reaped by
    the next --fresh-autotune rather than kept.
    """
    if not backup or not os.path.isdir(backup):
        return
    shutil.rmtree(backup, ignore_errors=True)
    print(f"[fresh-autotune] Discarded {backup}; the sweep it insured against "
          f"finished")


def add_model_list_arguments(parser) -> None:
    """The list-selection flags, shared by every driver."""
    parser.add_argument("--model", help="Run a single model only")
    parser.add_argument(
        "--list", dest="list_name", metavar="NAME",
        help="Model list to use, resolved to scripts/models/NAME_models.txt. "
             f"Available: {', '.join(available_lists()) or '(none)'}")
    parser.add_argument(
        "--all", action="store_true",
        help="Every unique model across all lists in scripts/models/, keyed on "
             f"'{ALL_LIST}' for output paths")
    parser.add_argument(
        "--models-file", metavar="PATH",
        help="Explicit path to a '<model_name> [batch_size]' list, overriding "
             "--list and --all.  Name it <name>_models.txt so its outputs are "
             "keyed on <name>.  Use the same list for collection and tuning so "
             "the batch sizes match the captured metadata")


def safe_model_name(model_name: str) -> str:
    return model_name.replace("/", "_")


# ---------------------------------------------------------------------------
# Provenance
# ---------------------------------------------------------------------------

# Fields that must match for a tuned config to be worth trusting on the current
# machine.  A different gfx target or Triton version can change which tile
# shape wins, so a mismatch is reported rather than silently ignored.
PROVENANCE_CRITICAL = ("arch", "gcn_arch", "torch", "triton", "hip")


def collect_provenance(extra: dict | None = None) -> dict:
    """Describe the software and hardware a tuning result was produced on.

    Kernel configs are not portable: the winning tile shape depends on the GPU
    target and on the Triton and compiler versions that generated the code.
    Without this recorded alongside the results there is no way to tell a
    current config from one tuned on a machine that no longer exists.
    """
    import platform
    import sys
    from datetime import datetime, timezone

    def _ver(mod_name: str) -> str:
        try:
            import importlib
            return getattr(importlib.import_module(mod_name), "__version__", "?")
        except Exception:
            return "not installed"

    prov = {
        "timestamp":  datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "arch":       detect_arch(),
        "gpu_name":   "",
        "gcn_arch":   "",
        "n_gpus":     0,
        "torch":      torch.__version__,
        "triton":     _ver("triton"),
        "hip":        getattr(getattr(torch, "version", None), "hip", None) or "",
        "cuda":       getattr(getattr(torch, "version", None), "cuda", None) or "",
        "transformers": _ver("transformers"),
        "timm":       _ver("timm"),
        "python":     sys.version.split()[0],
        "hostname":   platform.node(),
    }

    if torch.cuda.is_available():
        try:
            props = torch.cuda.get_device_properties(0)
            prov["gpu_name"] = props.name
            # gfx target — the value that actually decides code generation
            prov["gcn_arch"] = getattr(props, "gcnArchName", "")
            prov["n_gpus"] = torch.cuda.device_count()
        except Exception:
            pass

    # Search-space env vars change which configs were even candidates, so a
    # portfolio built under DEFAULT is not comparable with one built under
    # EXHAUSTIVE.
    for var in ("TORCHINDUCTOR_MAX_AUTOTUNE_GEMM_SEARCH_SPACE",
                "TORCHINDUCTOR_MAX_AUTOTUNE",
                "TORCHINDUCTOR_MAX_AUTOTUNE_GEMM_BACKENDS"):
        if os.environ.get(var):
            prov[var.lower()] = os.environ[var]

    if extra:
        prov.update(extra)
    return prov


def write_provenance(directory: str, extra: dict | None = None) -> str:
    """Write provenance.json into ``directory``.  Returns the path."""
    import json

    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, "provenance.json")
    with open(path, "w") as fh:
        json.dump(collect_provenance(extra), fh, indent=2, sort_keys=True)
        fh.write("\n")
    return path


def read_provenance(directory: str) -> dict | None:
    """Read provenance.json from ``directory``, or None if absent/unreadable."""
    import json

    path = os.path.join(directory, "provenance.json")
    try:
        with open(path) as fh:
            return json.load(fh)
    except Exception:
        return None


def provenance_mismatches(recorded: dict) -> list[str]:
    """Critical fields where the current environment differs from ``recorded``.

    Each entry reads 'field: recorded -> current'.  An empty list means the
    configs were tuned somewhere comparable to here.
    """
    current = collect_provenance()
    out = []
    for field in PROVENANCE_CRITICAL:
        was, now = recorded.get(field), current.get(field)
        if was and now and str(was) != str(now):
            out.append(f"{field}: {was} -> {now}")
    return out


# ---------------------------------------------------------------------------
# Timing helpers
# ---------------------------------------------------------------------------

def _time_calls(step, warmup: int, iters: int, reps: int) -> tuple[float, float]:
    """Per-call device time for ``step``, as (avg_ms, best_ms) over ``reps``.

    Timed with CUDA events around a batch of back-to-back calls, deliberately
    not with a synchronise around each one.  Syncing per call bills the whole
    host-side dispatch to the kernel, and the backends being compared do not pay
    the same amount of it: a torch.compile'd callable re-checks its guards on
    entry, which costs several times what an ATen C++ dispatch does.  On the
    sub-millisecond kernels in these sweeps that gap was large enough to reverse
    the verdict — flex_attention decode measured 0.93x against eager per-call,
    and 1.27x once only device time was counted.

    Enqueueing a batch instead keeps the queue full, so host overhead overlaps
    with execution the way it does in a real model step.
    """
    from statistics import mean

    for _ in range(warmup):
        step()
    torch.cuda.synchronize()

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    per_call = []
    for _ in range(reps):
        start.record()
        for _ in range(iters):
            step()
        end.record()
        torch.cuda.synchronize()
        per_call.append(start.elapsed_time(end) / iters)
    return mean(per_call), min(per_call)


def benchmark_fn(fn, warmup: int = 5, iters: int = 20, reps: int = 5
                 ) -> tuple[float, float]:
    """Time a zero-argument callable.  Returns (avg_ms, best_ms) per call."""
    return _time_calls(fn, warmup, iters, reps)


def benchmark_backward(forward_fn, inputs, warmup: int = 5, iters: int = 20,
                       reps: int = 5) -> tuple[float, float]:
    """Time the backward pass on its own.  Returns (avg_ms, best_ms).

    Backward needs the forward's saved activations, so the usual shortcut is to
    time forward+backward together and report the total.  That total is not
    comparable between an eager and a compiled implementation when only one of
    them changes the backward: the forward cost dilutes the difference.  Here
    the graph is built once and only ``torch.autograd.grad`` is timed, which
    isolates the backward and makes eager-vs-compiled meaningful.

    Returns (nan, nan) when nothing is differentiable or autograd raises, so a
    failure shows up as a blank column rather than aborting the sweep.
    """
    leaves = [t for t in inputs
              if isinstance(t, torch.Tensor) and t.requires_grad]
    if not leaves:
        return float("nan"), float("nan")

    try:
        out = forward_fn()
        if isinstance(out, (tuple, list)):
            out = out[0]
        if not isinstance(out, torch.Tensor) or not out.requires_grad:
            return float("nan"), float("nan")
        grad_out = torch.ones_like(out)

        def _step():
            torch.autograd.grad(out, leaves, grad_outputs=grad_out,
                                retain_graph=True)

        return _time_calls(_step, warmup, iters, reps)
    except Exception as exc:
        print(f"  backward timing failed: {exc}")
        return float("nan"), float("nan")


# ---------------------------------------------------------------------------
# Cross-model shape registry (dedup + invocation census)
# ---------------------------------------------------------------------------

class ShapeCensus:
    """Tracks every distinct shape tuned during one benchmark run.

    The same shape occurs in many models — a 768-wide BERT projection shows up
    in every BERT-family entry — and because --fresh-autotune deliberately
    disables both the FxGraph and autotune caches, each occurrence would
    otherwise re-run the full exhaustive search for an answer we already have.

    Two responsibilities:

    1. Dedup.  ``lookup`` returns the previously measured result for a shape so
       the caller can skip the compile and reuse it, keeping the per-model
       output complete without paying for the search twice.
    2. Census.  Invocation counts are summed across every model containing the
       shape and written to a CSV that ``top_configs.py`` joins against, so
       config selection can favour shapes that actually run often.

    Keys are supplied by the caller rather than derived here, because only the
    caller knows how its metadata maps onto the shape columns that Inductor
    logs (M/K/N for GEMM, NCHW for conv, and so on).
    """

    def __init__(self, shape_cols: list[str]):
        self.shape_cols = list(shape_cols)
        self._entries: dict[tuple, dict] = {}

    def lookup(self, key: tuple):
        """Previously measured result for this shape, or None if unseen."""
        entry = self._entries.get(key)
        return entry["result"] if entry else None

    def add(self, key: tuple, result: dict | None = None,
            count_forward: int = 0, count_backward: int = 0,
            model: str | None = None, eager_ms: float | None = None) -> bool:
        """Register one occurrence.  Returns True if this shape is new.

        ``eager_ms`` is the measured aten/library time for the shape.  Inductor
        logs its extern candidate for conv but not for mm, so for GEMM this is
        the only record of what Triton has to beat.
        """
        entry = self._entries.get(key)
        is_new = entry is None
        if is_new:
            entry = {"result": result, "count_forward": 0, "count_backward": 0,
                     "models": set(), "eager_ms": None, "eager_bwd_ms": None}
            self._entries[key] = entry
        elif result is not None and entry["result"] is None:
            entry["result"] = result

        entry["count_forward"]  += int(count_forward or 0)
        entry["count_backward"] += int(count_backward or 0)
        if model:
            entry["models"].add(model)
        if eager_ms is not None and eager_ms == eager_ms and eager_ms > 0:
            prev = entry["eager_ms"]
            entry["eager_ms"] = eager_ms if prev is None else min(prev, eager_ms)
        return is_new

    def set_eager(self, key: tuple, eager_ms: float | None,
                  field: str = "eager_ms") -> None:
        """Record a measured aten/library time for an already-added shape.

        ``field`` selects the forward or backward baseline; keeping them apart
        matters because comparing a backward kernel against a forward eager
        time is meaningless.
        """
        entry = self._entries.get(key)
        if entry is None or eager_ms is None:
            return
        if eager_ms != eager_ms or eager_ms <= 0:      # NaN or non-positive
            return
        prev = entry.get(field)
        entry[field] = eager_ms if prev is None else min(prev, eager_ms)

    def __len__(self) -> int:
        return len(self._entries)

    @property
    def total_occurrences(self) -> int:
        return sum(len(e["models"]) for e in self._entries.values())

    def write(self, path: str) -> None:
        import csv as _csv
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        cols = self.shape_cols + ["count_forward", "count_backward",
                                  "eager_ms", "eager_bwd_ms",
                                  "num_models", "models"]
        with open(path, "w", newline="") as fh:
            w = _csv.DictWriter(fh, fieldnames=cols)
            w.writeheader()
            for key, entry in self._entries.items():
                row = dict(zip(self.shape_cols, key))
                row["count_forward"]  = entry["count_forward"]
                row["count_backward"] = entry["count_backward"]
                row["eager_ms"]       = ("" if entry["eager_ms"] is None
                                         else entry["eager_ms"])
                row["eager_bwd_ms"]   = ("" if entry.get("eager_bwd_ms") is None
                                         else entry["eager_bwd_ms"])
                row["num_models"]     = len(entry["models"])
                row["models"]         = ";".join(sorted(entry["models"]))
                w.writerow(row)
        print(f"[census] {len(self._entries)} unique shapes "
              f"({self.total_occurrences} occurrences) → {path}")
