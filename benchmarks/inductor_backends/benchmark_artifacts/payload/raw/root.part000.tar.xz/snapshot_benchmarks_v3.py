import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil


root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--results', default='training_results_v2')
args = parser.parse_args()
records = []
read_errors = []
for path in (root / args.results / 'raw').glob('*/*.json'):
    try:
        records.append(json.loads(path.read_text()))
    except (OSError, ValueError) as error:
        read_errors.append({'path': str(path), 'error': str(error)})
print(json.dumps({
    'captured_utc': datetime.now(timezone.utc).isoformat(),
    'results': args.results,
    'records': len(records),
    'read_errors': read_errors,
    'statuses': dict(Counter(record['status'] for record in records)),
    'active': [{key: record.get(key) for key in ['model', 'backend', 'autotune', 'world_size', 'phase']}
               for record in records if record['status'] == 'started'],
    'gpu_core_dumps': [{'name': path.name, 'bytes': path.stat().st_size} for path in root.glob('gpucore.*.gpu')],
    'disk_free_bytes': shutil.disk_usage(root).free,
}))
