import argparse
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import time
from xml.etree import ElementTree

from build_live_three_backend_v8 import ROOT, runtime_svg, write_dashboard


def final_charts(directory):
    with (directory / 'per_model_all_modes.csv').open() as source:
        rows = list(csv.DictReader(source))
    for row in rows:
        for field in ['triton_ms','flydsl_ms','mix_ms','mix_speedup_percent','flydsl_speedup_percent']:
            row[field] = float(row[field]) if row.get(field) else None
        for field in ['gpu_count','flydsl_kernels','triton_kernels']:
            row[field] = int(row[field]) if row.get(field) else None
        row['autotune'] = int(row['autotune'])
        row['preview_three_way_validated_stable'] = row['evidence_tier'] == 'validated_stable'
        row['current_pair_training_only_stable'] = row['evidence_tier'] == 'training_only'
        row['current_pair_validated_stable'] = row['preview_three_way_validated_stable']
        row['flydsl_origin'] = 'fresh_pure_flydsl'
        row['reference_protocol'] = 'final_current_triton_and_mixed'
        row['flydsl_gpu_group'] = row['gpu_group']
    for mode in ['standard','expanded']:
        path = directory / ('runtime_' + mode + '.svg')
        path.write_text(runtime_svg(rows,mode,historical=False))
        ElementTree.parse(path)
        for suite in sorted({row['suite'] for row in rows}):
            path = directory / ('runtime_' + mode + '_' + suite.replace('-dashboard','') + '.svg')
            path.write_text(runtime_svg([row for row in rows if row['suite'] == suite], mode, suite + ' full training runtime', historical=False))
            ElementTree.parse(path)
    info = dict(final=True,generated_utc=datetime.now(timezone.utc).isoformat(),models=len(rows)//2)
    write_dashboard(directory,rows,info)
    (directory / 'chart_generation.json').write_text(json.dumps(info,indent=2)+'\n')
    return info


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--wait',action='store_true')
    parser.add_argument('--results',type=Path,default=ROOT/'three_backend_report_v7')
    args = parser.parse_args()
    if args.wait:
        while True:
            try:
                state=json.loads((ROOT/'training_results_purefly_v7/pipeline.json').read_text())
            except (OSError,ValueError):
                time.sleep(10)
                continue
            if state['phase']=='three_backend_reports_complete_manual_review_required':
                break
            time.sleep(10)
    print(json.dumps(final_charts(args.results),indent=2))
