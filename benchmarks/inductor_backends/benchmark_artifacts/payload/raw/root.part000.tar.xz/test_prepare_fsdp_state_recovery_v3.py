import ast
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests,
    parametrize,
    run_tests,
    TestCase,
)


ROOT = Path(__file__).resolve().parent
FLAG = 'BENCHMARK_FSDP_STATE_INIT_ONLY'
MODELS = [
    'hunyuanvideo-community/HunyuanVideo',
    'Wan-AI/Wan2.1-I2V-14B-720P-Diffusers',
    'Wan-AI/Wan2.2-I2V-A14B-Diffusers',
]


@instantiate_parametrized_tests
class TestPrepareFSDPStateRecovery(TestCase):
    def prepare(self, model=MODELS[0], mutation=None):
        temporary = tempfile.TemporaryDirectory(prefix="fsdp-state-prepare-", dir=ROOT)
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        for script in ['prepare_steady_v2.py', 'prepare_support_suite_v3.py']:
            tree = ast.parse((ROOT / script).read_text())
            names = {node.value for node in ast.walk(tree) if isinstance(node, ast.Constant)
                     and isinstance(node.value, str) and '\n' not in node.value
                     and len(node.value) < 240 and node.value.endswith(('.py', '.json'))}
            for name in names | {script, 'train_worker_v2.py', 'run_suite_v2.py'}:
                source = ROOT / name
                if not source.is_file():
                    source = ROOT / 'fallback_fixes' / name
                    target = root / 'fallback_fixes' / name
                else:
                    target = root / name
                if source.is_file():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, target)
        # The final review artifact is only hashed by the support preparer.
        review = root / 'baseline_fallback_review_v3.json'
        if not review.exists():
            review.write_text('{}')
        manifest = {'models': [dict(suite='priority', model=model, batch_size=8)]}
        (root / 'model_manifest_v2.json').write_text(json.dumps(manifest))
        (root / 'source_fingerprint_v2.json').write_text(json.dumps(
            dict(sha256='synthetic-parent', sources={}, harness={})))
        case = root / 'training_results_v2/raw/case'
        case.mkdir(parents=True)
        (case.parents[1] / 'COMPLETE.json').write_text('{}')
        records = [dict(suite='priority', model=model, batch_size=8, backend=backend, autotune=tune,
                        status='error', phase='fsdp_eager_initialization', world_size=8,
                        physical_gpu='0,1,2,3,4,5,6,7', error='torch.OutOfMemoryError: HIP out of memory')
                   for backend in ['triton', 'flydsl'] for tune in [0, 1]]
        if mutation:
            mutation(records)
        for record in records:
            (case / f"{record['backend']}_autotune{record['autotune']}.json").write_text(json.dumps(record))
        result = subprocess.run([sys.executable, str(root / 'prepare_steady_v2.py')], cwd=root,
                                env={**os.environ, 'CUDA_VISIBLE_DEVICES': ''}, capture_output=True,
                                text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        return root

    @parametrize('model', MODELS)
    def test_shared_initialization_oom_selects_all_variants(self, model):
        root = self.prepare(model)
        selected = json.loads((root / 'model_manifest_v2_steady.json').read_text())['models']
        self.assertEqual(len(selected), 1)
        self.assertEqual(selected[0]['launch_environment_overrides'], {FLAG: '1'})
        self.assertEqual(selected[0]['world_size'], 8)
        self.assertEqual(selected[0]['steady_warmup_steps'], 30)

    @parametrize('case', ['incomplete', 'mixed_phase', 'mixed_status', 'wrong_error',
                         'world4', 'mixed_world', 'mixed_placement', 'unsupported'])
    def test_recovery_is_not_selected_for_unmatched_failure(self, case):
        def mutate(records):
            if case == 'incomplete':
                records.pop()
            elif case == 'mixed_phase':
                records[-1]['phase'] = 'warmup'
            elif case == 'mixed_status':
                records[-1]['status'] = 'timeout'
            elif case == 'wrong_error':
                records[-1]['error'] = 'unrelated compilation error'
            elif case == 'world4':
                for record in records:
                    record['world_size'] = 4
            elif case == 'mixed_world':
                records[-1]['world_size'] = 4
            elif case == 'mixed_placement':
                records[-1]['physical_gpu'] = '8,9,10,11,12,13,14,15'
        root = self.prepare('unrelated/model' if case == 'unsupported' else MODELS[0], mutate)
        self.assertEqual(json.loads((root / 'model_manifest_v2_steady.json').read_text())['models'], [])

    def assert_worker_preserves_training(self, source):
        original = ast.parse((ROOT / 'train_worker_v2.py').read_text())
        generated = ast.parse(source)
        compile(generated, '<generated-worker>', 'exec')
        for name in ['step', 'forward_loss']:
            before = next(node for node in ast.walk(original) if isinstance(node, ast.FunctionDef) and node.name == name)
            after = next(node for node in ast.walk(generated) if isinstance(node, ast.FunctionDef) and node.name == name)
            self.assertEqual(ast.dump(after), ast.dump(before))
        finite_checks = lambda tree: Counter(ast.dump(node) for node in ast.walk(tree)
            if isinstance(node, ast.Call) and ast.unparse(node.func) == 'torch.isfinite')
        self.assertEqual(finite_checks(generated), finite_checks(original))
        before_errors = Counter(node.value for node in ast.walk(original)
            if isinstance(node, ast.Constant) and isinstance(node.value, str)
            and ('not finite' in node.value or 'nonfinite' in node.value or 'no parameter gradients' in node.value))
        after_errors = Counter(node.value for node in ast.walk(generated)
            if isinstance(node, ast.Constant) and isinstance(node.value, str)
            and ('not finite' in node.value or 'nonfinite' in node.value or 'no parameter gradients' in node.value))
        self.assertEqual(after_errors, before_errors)
        self.assertIn("from torch._inductor.fx_passes.joint_graph import lazy_init", source)
        self.assertIn("lazy_init(torch.device('cuda', local_rank))", source)
        self.assertLess(source.index("lazy_init(torch.device('cuda', local_rank))"),
                        source.index("initialize_fsdp_state_for_compile(model)"))
        self.assertIn("checkpoint=False", source)
        self.assertEqual(source.count('checkpoint'), (ROOT / 'train_worker_v2.py').read_text().count('checkpoint'))
        self.assertIn("result['fsdp_initialization_mode'] = 'state_only'", source)
        self.assertIn("result['fsdp_initialization_mode'] = 'eager_training'", source)

    def assert_runner_environment(self, source, root, support=False):
        tree = ast.parse(source)
        compile(tree, '<generated-runner>', 'exec')
        function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'run_gpu')
        loop = next(node for node in ast.walk(function) if isinstance(node, ast.For)
                    and ast.unparse(node.target) == '(backend, tune)')
        start = next(i for i, node in enumerate(loop.body) if isinstance(node, ast.Assign)
                     and any(isinstance(target, ast.Name) and target.id == 'env' for target in node.targets))
        stop = next(i for i, node in enumerate(loop.body[start:], start) if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == 'cmd' for target in node.targets))
        code = compile(ast.Module(body=loop.body[start:stop], type_ignores=[]), '<environment-only>', 'exec')
        for overrides in [{}, {FLAG: '1'}]:
            namespace = dict(os=os, json=json, ROOT=root, time=SimpleNamespace(time_ns=lambda: 1),
                             model=dict(launch_environment_overrides=overrides, steady_warmup_steps=30),
                             args=SimpleNamespace(override_placement=False), gpu='0,1,2,3,4,5,6,7',
                             backend='flydsl', tune=0, cache=root / 'cache')
            with patch.dict(os.environ, {FLAG: 'inherited-must-be-cleared'}):
                exec(code, namespace)
            self.assertEqual(namespace['env'].get(FLAG), overrides.get(FLAG))
            self.assertEqual(json.loads(namespace['env']['BENCHMARK_LAUNCH_OVERRIDES']), overrides)
            if support:
                self.assertEqual(namespace['env']['BENCHMARK_SUPPORT_SOURCE_ROOT'], str(root / 'fallback_fixes'))

    def test_generated_worker_runner_and_fingerprint(self):
        root = self.prepare()
        self.assert_worker_preserves_training((root / 'train_worker_v2_steady.py').read_text())
        self.assert_runner_environment((root / 'run_suite_v2_steady.py').read_text(), root)
        fingerprint = json.loads((root / 'source_fingerprint_v2_steady.json').read_text())
        self.assertEqual(fingerprint['parent_sha256'], 'synthetic-parent')
        for name in ['fsdp_state_init_v3.py', 'test_fsdp_state_init_v3.py', 'probe_fsdp_state_init_v3.py']:
            self.assertEqual(fingerprint['harness'][name], hashlib.sha256((root / name).read_bytes()).hexdigest())

    def test_support_generation_retains_recovery_and_probe(self):
        root = self.prepare()
        (root / 'training_results_v2_steady/COMPLETE.json').parent.mkdir()
        (root / 'training_results_v2_steady/COMPLETE.json').write_text('{}')
        rows = ['source_json']
        for path in sorted((root / 'training_results_v2/raw/case').glob('*.json')):
            record = json.loads(path.read_text())
            record['launch_environment_overrides'] = {FLAG: '1'}
            path.write_text(json.dumps(record))
            rows.append(str(path))
        (root / 'training_results_v2/final_timing_sources.csv').write_text('\n'.join(rows) + '\n')
        result = subprocess.run([sys.executable, str(root / 'prepare_support_suite_v3.py')], cwd=root,
                                env={**os.environ, 'CUDA_VISIBLE_DEVICES': ''}, capture_output=True,
                                text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads((root / 'model_manifest_support_v3.json').read_text())
        self.assertEqual(manifest['models'][0]['launch_environment_overrides'], {FLAG: '1'})
        self.assertEqual(manifest['support_source_root'], str(root / 'fallback_fixes'))
        self.assert_worker_preserves_training((root / 'train_worker_support_v3.py').read_text())
        self.assert_runner_environment((root / 'run_suite_support_v3.py').read_text(), root, support=True)
        controller = (root / 'run_support_v3.py').read_text()
        compile(controller, '<support-controller>', 'exec')
        self.assertIn("'probe_fsdp_state_init_v3.py'", controller)
        self.assertIn("'--nproc_per_node=2'", controller)
        self.assertIn("overlay = manifest.get('support_source_root')", controller)
        self.assertIn("probe_env['BENCHMARK_SUPPORT_SOURCE_ROOT'] = overlay", controller)
        self.assertIn("FSDP validation did not cover the expected helper and backend sources", controller)
        self.assertLess(controller.index("'probe_fsdp_state_init_v3.py'"), controller.index('def run_group('))


if __name__ == '__main__':
    run_tests()
