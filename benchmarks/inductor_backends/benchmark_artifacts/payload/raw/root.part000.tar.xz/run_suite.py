import argparse
from concurrent.futures import ThreadPoolExecutor
import fcntl
import hashlib
import json
import os
from pathlib import Path
import queue
import random
import signal
import shutil
import subprocess
import sys
import threading
import time


ROOT = Path(__file__).resolve().parent
LOCK = threading.Lock()


def run_gpu(gpu, jobs, args):
    while True:
        try:
            index, model = jobs.get_nowait()
        except queue.Empty:
            return
        identity = f"{model['suite']}--{model['model']}--bs{model['batch_size']}"
        tag = identity.replace('/', '_')
        claims = ROOT / args.results / 'claims'
        claims.mkdir(parents=True, exist_ok=True)
        claim = (claims / f'{tag}.lock').open('w')
        try:
            fcntl.flock(claim, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            claim.close()
            jobs.task_done()
            continue
        variants = [(backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]]
        if args.autotune_modes is not None:
            variants = [(backend, tune) for backend, tune in variants if tune in args.autotune_modes]
        random.Random(index).shuffle(variants)
        for backend, tune in variants:
            variant = f'{backend}_autotune{tune}'
            output = ROOT / args.results / 'raw' / tag / f'{variant}.json'
            if output.exists():
                old = json.loads(output.read_text())
                if args.force:
                    archive = ROOT / args.results / 'archive' / args.archive_label / tag
                    archive.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(output, archive / output.name)
                    log_path = output.with_suffix('.log')
                    if log_path.exists():
                        shutil.copy2(log_path, archive / log_path.name)
                elif old.get('status') not in ['started', 'timeout', 'process_failed']:
                    continue
            output.parent.mkdir(parents=True, exist_ok=True)
            cache_key = hashlib.sha256(f'{args.results}/{identity}/{variant}'.encode()).hexdigest()[:20]
            cache = Path('/dev/shm/pytorch-simd-training-cache') / cache_key
            cache.mkdir(parents=True, exist_ok=True)
            env = os.environ.copy()
            for key in ['LD_LIBRARY_PATH', 'ROCM_HOME', 'HIP_VISIBLE_DEVICES', 'CMAKE_PREFIX_PATH', 'TORCH_LOGS']:
                env.pop(key, None)
            env.update(
                CUDA_VISIBLE_DEVICES=str(gpu),
                TORCHINDUCTOR_FLYDSL_SIMD=str(int(backend == 'flydsl')),
                TORCHINDUCTOR_FLYDSL_SIMD_TUNE=f'autotune={tune}',
                TORCHINDUCTOR_COMPILE_THREADS='8',
                OMP_NUM_THREADS='8', MKL_NUM_THREADS='8',
                TORCHINDUCTOR_CACHE_DIR=str(cache / 'inductor'),
                TRITON_CACHE_DIR=str(cache / 'triton'),
                FLYDSL_RUNTIME_CACHE_DIR=str(cache / 'flydsl'),
                ROCM_PATH='/dockerx/venvs/flex-build/lib/python3.12/site-packages/_rocm_sdk_devel',
                PYTHONPATH=str(ROOT / 'model_deps'),
                HF_HOME=str(ROOT / 'hf_config_cache'),
                HF_HUB_DISABLE_TELEMETRY='1',
                TOKENIZERS_PARALLELISM='false',
                TMPDIR='/dev/shm/pytorch-simd-937d7fd-tmp',
            )
            cmd = [sys.executable, str(ROOT / 'train_worker.py'), '--suite', model['suite'],
                   '--model', model['model'], '--batch-size', str(model['batch_size']),
                   '--backend', backend, '--autotune', str(tune), '--output', str(output),
                   '--iterations', str(args.iterations), '--repeats', str(args.repeats)]
            if model['model'] in args.skip_eager_reference_models:
                cmd.append('--skip-eager-reference')
            begin = time.monotonic()
            with output.with_suffix('.log').open('w') as log:
                process = subprocess.Popen(cmd, env=env, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    code = process.wait(timeout=args.timeout)
                    failure = 'process_failed' if code else None
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
                    failure = 'timeout'
                if failure:
                    result = json.loads(output.read_text()) if output.exists() else dict(model)
                    result.update(status=failure, backend=backend, autotune=tune, physical_gpu=gpu,
                                  subprocess_seconds=time.monotonic() - begin, returncode=process.returncode)
                    output.write_text(json.dumps(result, indent=2) + '\n')
            result = json.loads(output.read_text())
            with LOCK:
                print(json.dumps({'gpu': gpu, 'model': model['model'], 'variant': variant,
                                  'status': result['status'], 'ms': result.get('milliseconds'),
                                  'error': result.get('error', '')[:180],
                                  'elapsed': round(time.monotonic() - begin, 1)}), flush=True)
        jobs.task_done()
        claim.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpus', default='0,1,3,6,7')
    parser.add_argument('--results', default='training_results')
    parser.add_argument('--timeout', type=int, default=1800)
    parser.add_argument('--iterations', type=int, default=10)
    parser.add_argument('--repeats', type=int, default=5)
    parser.add_argument('--models', nargs='*')
    parser.add_argument('--suites', nargs='*')
    parser.add_argument('--wait-pid', type=int)
    parser.add_argument('--force', action='store_true')
    parser.add_argument('--skip-eager-reference-models', nargs='*', default=[])
    parser.add_argument('--archive-label')
    parser.add_argument('--autotune-modes', type=int, choices=[0, 1], nargs='+')
    args = parser.parse_args()
    if args.archive_label is None:
        args.archive_label = f'recheck_{time.time_ns()}'
    if args.wait_pid:
        while True:
            try:
                os.kill(args.wait_pid, 0)
            except ProcessLookupError:
                break
            time.sleep(5)
    manifest = json.loads((ROOT / 'model_manifest.json').read_text())
    models = manifest['models']
    if args.models:
        models = [m for m in models if m['model'] in args.models]
    if args.suites:
        models = [m for m in models if m['suite'] in args.suites]
    jobs = queue.Queue()
    for index, model in enumerate(models):
        jobs.put((index, model))
    gpus = args.gpus.split(',')
    with ThreadPoolExecutor(max_workers=len(gpus)) as pool:
        futures = [pool.submit(run_gpu, gpu, jobs, args) for gpu in gpus]
        for future in futures:
            future.result()


if __name__ == '__main__':
    main()
