#!/bin/bash
set -euo pipefail
TASK_ROOT=/dockerx/pytorch-flex/agent_space/simd_bench
export VIRTUAL_ENV="$TASK_ROOT/.venv"
export PATH="$VIRTUAL_ENV/bin:/dockerx/venvs/flex-build/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
unset LD_LIBRARY_PATH ROCM_HOME CMAKE_PREFIX_PATH
export ROCM_PATH=$(/dockerx/venvs/flex-build/bin/rocm-sdk path --root)
export ROCM_HOME="$ROCM_PATH" HIP_PATH="$ROCM_PATH"
export CMAKE_PREFIX_PATH="$(/dockerx/venvs/flex-build/bin/rocm-sdk path --cmake):$VIRTUAL_ENV"
export PATH="$ROCM_PATH/bin:$PATH"
export USE_ROCM=1 USE_CUDA=0 PYTORCH_ROCM_ARCH=gfx950 BUILD_TEST=0 MAX_JOBS=200
export USE_FLASH_ATTENTION=0 USE_MEM_EFF_ATTENTION=0 USE_ROCM_CK_GEMM=0 USE_ROCM_CK_SDPA=0 USE_FBGEMM_GENAI=0
export USE_NCCL=1 USE_RCCL=1 USE_SYSTEM_NCCL=1 USE_MPI=0 USE_KINETO=0 USE_MKLDNN=0 BUILD_CAFFE2=0
export USE_NNPACK=0
export CMAKE_PROJECT_INCLUDE="$TASK_ROOT/hipify.cmake"
export SKBUILD_BUILD_DIR=/dev/shm/pytorch-simd-937d7fd-build
export TMPDIR=/dev/shm/pytorch-simd-937d7fd-tmp
cd "$TASK_ROOT/pytorch"
python -m pip install -e . -v --no-build-isolation
