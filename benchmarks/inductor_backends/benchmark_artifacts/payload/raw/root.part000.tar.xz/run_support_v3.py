from allocation_failures_v3 import is_terminal_gpu_memory_failure
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time


root = Path(__file__).resolve().parent
(root / 'training_results_support_v3/raw').mkdir(parents=True, exist_ok=True)
manifest = json.loads((root / 'model_manifest_support_v3.json').read_text())
if any(model.get('launch_environment_overrides', {}).get('BENCHMARK_FSDP_STATE_INIT_ONLY') == '1'
       for model in manifest['models']):
    proof_path = root / 'training_results_support_v3/fsdp_state_init_validation.json'
    old_probe_files = [path for path in proof_path.parent.glob(proof_path.stem + '*') if path.is_file()]
    if old_probe_files:
        archive = proof_path.parent / 'fsdp_state_init_validation_attempts' / str(time.time_ns())
        archive.mkdir(parents=True)
        for path in old_probe_files:
            shutil.copy2(path, archive / path.name)
    proof_path.unlink(missing_ok=True)
    probe_env = os.environ.copy()
    for name in ['LD_LIBRARY_PATH', 'ROCM_HOME', 'HIP_VISIBLE_DEVICES', 'CMAKE_PREFIX_PATH', 'TORCH_LOGS',
                 'TORCHINDUCTOR_FLYDSL_BASELINE_DIR', 'TORCHINDUCTOR_FLYDSL_SIMD_STAGES',
                 'TORCHINDUCTOR_MIX_ORDER_REDUCTION', 'BENCHMARK_SUPPORT_SOURCE_ROOT']:
        probe_env.pop(name, None)
    cache_tag = proof_path.parent.name + '-' + str(time.time_ns())
    probe_env.update(CUDA_VISIBLE_DEVICES='0,1',
                     PYTHONPATH=str(root / 'model_deps'), OMP_NUM_THREADS='8', MKL_NUM_THREADS='8',
                     TORCHINDUCTOR_COMPILE_THREADS='8',
                     TORCHINDUCTOR_CACHE_DIR=str(Path('/dev/shm') / ('pytorch-simd-state-init-' + cache_tag)),
                     TRITON_CACHE_DIR=str(Path('/dev/shm') / ('pytorch-simd-state-init-triton-' + cache_tag)),
                     FLYDSL_RUNTIME_CACHE_DIR=str(Path('/dev/shm') / ('pytorch-simd-state-init-flydsl-' + cache_tag)),
                     ROCM_PATH='/dockerx/venvs/flex-build/lib/python3.12/site-packages/_rocm_sdk_devel')
    overlay = manifest.get('support_source_root')
    if overlay:
        probe_env['PYTHONPATH'] = os.pathsep.join([str(root / 'support_startup_v3'), str(root / 'model_deps')])
        probe_env['BENCHMARK_SUPPORT_SOURCE_ROOT'] = overlay
    command = [sys.executable, '-m', 'torch.distributed.run', '--standalone', '--nproc_per_node=2',
               str(root / 'probe_fsdp_state_init_v3.py'), '--output', str(proof_path)]
    with Path('/dev/shm/pytorch-simd-v2-entry.lock').open('a') as entry:
        fcntl.flock(entry, fcntl.LOCK_EX)
        with Path('/dev/shm/pytorch-simd-v2-benchmark.lock').open('a') as timing:
            fcntl.flock(timing, fcntl.LOCK_EX)
            with proof_path.with_suffix('.log').open('w') as log:
                process = subprocess.Popen(command, cwd=root, env=probe_env, stdout=log,
                                           stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    returncode = process.wait(timeout=600)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
                    raise RuntimeError('Reserved FSDP state initialization validation timed out') from None
                if returncode:
                    raise RuntimeError(f'Reserved FSDP state initialization validation failed: {returncode}')
    proof = json.loads(proof_path.read_text())
    if (proof.get('status') != 'passed' or proof.get('world_size') != 2
        or {record.get('rank') for record in proof.get('ranks', [])} != {0, 1}
        or len(proof.get('variants', [])) != 4
        or {(record['backend'], record['autotune']) for record in proof.get('variants', [])}
        != {(backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]}):
        raise RuntimeError('Incomplete FSDP state initialization validation')
    for variant in proof['variants']:
        if (not variant.get('first_fsdp_forward_compiled') or variant.get('prior_eager_fsdp_forward_backward') is not False
            or not variant.get('full_optimizer_update_checked') or not variant.get('full_gradient_parameter_tensors')
            or variant.get('max_autotune_pointwise') != bool(variant['autotune'])
            or variant.get('triton_autotune_pointwise') != bool(variant['autotune'])):
            raise RuntimeError('FSDP state initialization validation did not exercise the complete training protocol')
    for name, expected in proof['source_hashes'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
            raise RuntimeError(f'FSDP state initialization validation source changed: {name}')
    source_root = Path(overlay) if overlay else root / 'pytorch'
    expected_paths = [root / 'fsdp_state_init_v3.py', root / 'probe_fsdp_state_init_v3.py',
                      source_root / 'torch/_inductor/scheduler.py',
                      source_root / 'torch/_inductor/codegen/flydsl/flydsl_simd.py',
                      source_root / 'torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py']
    if not {str(path.resolve()) for path in expected_paths} <= proof['source_hashes'].keys():
        raise RuntimeError('FSDP validation did not cover the expected helper and backend sources')
groups = defaultdict(list)
for model in manifest['models']:
    groups[model['physical_gpu'], model['world_size']].append(model)


def run_group(group):
    (gpu, world_size), models = group
    command = [sys.executable, str(root / 'run_suite_support_v3.py'), '--gpus', gpu, '--timeout', '5400',
               '--models', *[model['model'] for model in models]]
    if world_size > 1:
        command.append('--fsdp')
    subprocess.run(command, cwd=root, check=True)


singles = [group for group in groups.items() if group[0][1] == 1]
with ThreadPoolExecutor(max_workers=max(1, len(singles))) as pool:
    for result in pool.map(run_group, singles):
        pass
for group in groups.items():
    if group[0][1] > 1:
        run_group(group)

case_records = defaultdict(list)
for path in (root / 'training_results_support_v3/raw').glob('*/*.json'):
    record = json.loads(path.read_text())
    case_records[record['suite'], record['model']].append((path, record))
memory_cases = {identity: records for identity, records in case_records.items()
                if any(is_terminal_gpu_memory_failure(record)
                       for _, record in records)}
if memory_cases:
    import torch

    gpu_ids = [str(device) for device in range(torch.cuda.device_count())]
    free = {gpu: torch.cuda.mem_get_info(int(gpu))[0] for gpu in gpu_ids}
    sizes = [count for count in [2, 4, 8] if count <= len(gpu_ids)]
    for (suite, model), records in memory_cases.items():
        required = max(record.get('parameter_bytes', 0) * 2 for _, record in records)
        previous_world = max(record.get('world_size', 1) for _, record in records)
        if required > sum(free.values()):
            for path, record in records:
                record['multi_gpu_capacity_check'] = dict(gpus=gpu_ids, aggregate_free_bytes=sum(free.values()),
                                                          minimum_weight_gradient_bytes=required, fits=False)
                path.write_text(json.dumps(record, indent=2) + '\n')
            continue
        available = [count for count in sizes if count > previous_world]
        if not required or not available:
            continue
        first = next((count for count in available if required < sum(free[gpu] for gpu in gpu_ids[:count]) * 0.8), available[-1])
        for count in [count for count in available if count >= first]:
            print(json.dumps(dict(model=model, world_size=count, status='memory_retry')), flush=True)
            command = [sys.executable, str(root / 'run_suite_support_v3.py'), '--models', model, '--suites', suite,
                       '--gpus', ','.join(gpu_ids[:count]), '--fsdp', '--override-placement', '--force',
                       '--archive-label', f'fsdp{count}_{time.time_ns()}', '--timeout', '5400']
            subprocess.run(command, cwd=root, check=True)
            latest = [json.loads(path.read_text()) for path, _ in records]
            if not any(is_terminal_gpu_memory_failure(record)
                       for record in latest):
                break
subprocess.run([sys.executable, str(root / 'analyze_v2.py'), '--results', 'training_results_support_v3',
                '--manifest', 'model_manifest_support_v3.json'], cwd=root, check=True)
summary = json.loads((root / 'training_results_support_v3/summary.json').read_text())
if summary['observed_runs'] != summary['expected_runs'] or summary['timing_overlaps'] or summary['aten_policy_errors']:
    raise RuntimeError('Support comparison matrix audit failed')
(root / 'training_results_support_v3/COMPLETE.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Support comparison rechecks complete.', flush=True)
