from collections import Counter, defaultdict
from datetime import datetime, timezone
import csv
import hashlib
import json
from pathlib import Path
import re


root = Path(__file__).resolve().parent
destination = root / 'fallback_review_v2'
destination.mkdir(exist_ok=True)
records = [json.loads(path.read_text()) for path in (root / 'training_results_v2/raw').glob('*/*.json')]
indexed = {(record['suite'], record['model'], record['backend'], record['autotune']): record for record in records}
events = []
malformed = []
for path in sorted((root / 'training_results_v2/raw').glob('*/kernels/*.jsonl')):
    for number, line in enumerate(path.open(), 1):
        try:
            event = json.loads(line)
        except ValueError:
            malformed.append(f'{path}:{number}')
            continue
        if event.get('category') != 'lowered' or event.get('backend') != 'triton' or not event.get('reason'):
            continue
        record = indexed.get((event['suite'], event['model'], event.get('requested_backend'), event['autotune']), {})
        event.update(diagnostic_file=str(path), line=number,
                     active_configuration=record.get('attempt_id') == event.get('attempt_id') and
                         record.get('world_size') == event.get('world_size') and
                         record.get('physical_gpu') == event.get('gpu_group'),
                     current_result_status=record.get('status'))
        events.append(event)
with (destination / 'events.jsonl').open('w') as output:
    for event in events:
        output.write(json.dumps(event) + '\n')

groups = defaultdict(list)
model_groups = defaultdict(list)
for event in events:
    if event['active_configuration']:
        groups[event['reason']].append(event)
        model_groups[event['reason'], event['suite'], event['model']].append(event)
summary = []
examples = {}
for reason, items in sorted(groups.items(), key=lambda pair: -len(pair[1])):
    operations = Counter()
    for event in items:
        operations.update(set(re.findall(r'aten\.[A-Za-z0-9_]+', event.get('origins', ''))))
    contexts = {(event['suite'], event['model'], event['autotune'], event['rank'], event['attempt_id'],
                 event['graph_id'], event['kernel_name']) for event in items}
    models = Counter(event['model'] for event in items)
    dtypes = Counter(dtype for event in items for dtype in {buffer.get('dtype', 'unknown')
                                                          for buffer in event.get('buffers', {}).values()})
    summary.append(dict(reason=reason, schedule_events=len(items), kernel_contexts=len(contexts),
                        models=len(models), backward_events=sum(bool(event.get('is_backward')) for event in items),
                        autotune_modes=dict(Counter(event['autotune'] for event in items)),
                        statuses=dict(Counter(event['current_result_status'] for event in items)),
                        source_operations=dict(operations.most_common()), dtypes=dict(dtypes),
                        model_event_counts=dict(models.most_common())))
    seen = set()
    examples[reason] = []
    for event in items:
        key = event['model'], event.get('is_backward'), event.get('origins')
        if key not in seen:
            seen.add(key)
            examples[reason].append(event)
        if len(examples[reason]) == 8:
            break
model_rows = []
for (reason, suite, model), items in sorted(model_groups.items()):
    model_rows.append(dict(reason=reason, suite=suite, model=model, schedule_events=len(items),
                           backward_events=sum(bool(event.get('is_backward')) for event in items),
                           kernel_names=sorted({event['kernel_name'] for event in items})))
for name, rows in [('reasons.csv', summary), ('models.csv', model_rows)]:
    with (destination / name).open('w') as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]) if rows else ['reason'])
        writer.writeheader()
        writer.writerows({key: json.dumps(value) if isinstance(value, (dict, list)) else value
                         for key, value in row.items()} for row in rows)
(destination / 'examples.json').write_text(json.dumps(examples, indent=2) + '\n')
report = dict(captured_utc=datetime.now(timezone.utc).isoformat(),
              scope='Provisional active-attempt lowering decisions; schedule counts are not GPU launch counts or runtime cost',
              source_fingerprint=json.loads((root / 'source_fingerprint_v2.json').read_text())['sha256'],
              collector_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              all_fallback_events=len(events), active_fallback_events=sum(event['active_configuration'] for event in events),
              malformed_lines=malformed, reasons=summary)
(destination / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
