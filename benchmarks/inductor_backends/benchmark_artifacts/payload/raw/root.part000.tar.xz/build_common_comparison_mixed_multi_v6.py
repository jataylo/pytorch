import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import html
import json
import math
from pathlib import Path
import statistics

MODES = [('triton', 0), ('flydsl', 0), ('triton', 1), ('flydsl', 1)]
MEASURED = {'ok', 'numerical_warning', 'validation_unavailable', 'reference_unavailable'}
META_FIELDS = ['physical_gpu', 'world_size', 'batch_size', 'local_batch_size',
               'effective_global_batch_size', 'batch_distribution', 'parameters', 'model_config_sha256', 'dtype']


def positive(value):
    if value is None or value == '':
        return None
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise ValueError(f'Expected positive finite timing/ratio: {value}')
    return number


def family_row(suite, model, runs, pairs):
    metadata = {tuple(json.dumps(record.get(key), sort_keys=True) for key in META_FIELDS)
                for record in runs.values()}
    common_metadata = len(metadata) == 1
    measured = all(record['status'] in MEASURED for record in runs.values())
    warning = any(record['status'] == 'numerical_warning' for record in runs.values())
    variable = any(pair.get('timing_quality') != 'stable' for pair in pairs.values())
    ratios = {tune: positive(pairs[tune].get('triton_over_flydsl')) for tune in [0, 1]}
    timings = {mode: positive(record.get('milliseconds')) if record['status'] in MEASURED else None
               for mode, record in runs.items()}
    if any(record['status'] in MEASURED and timings[mode] is None for mode, record in runs.items()):
        raise ValueError('Measured result missing a positive timing')
    for tune in [0, 1]:
        if ratios[tune] is not None:
            if not timings['triton', tune] or not timings['flydsl', tune]:
                raise ValueError('Comparison ratio lacks measured records')
            if not math.isclose(ratios[tune], timings['triton', tune] / timings['flydsl', tune], rel_tol=1e-10):
                raise ValueError('Comparison ratio does not match selected raw timings')
    comparable = common_metadata and all(ratios.values())
    validated = all(record['status'] == 'ok' for record in runs.values()) and all(
        str(pair.get('eager_validated')).lower() == 'true' for pair in pairs.values())
    training_only = all(record['status'] in {'validation_unavailable', 'reference_unavailable'}
                        for record in runs.values())
    headline = bool(measured and comparable and validated and not variable)
    if headline:
        tier = 'validated_stable_four_modes'
    elif not measured:
        tier = 'unavailable_or_failed'
    elif not comparable:
        tier = 'incomparable_metadata'
    elif warning:
        tier = 'numerical_warning'
    elif variable:
        tier = 'variable_timing'
    elif training_only:
        tier = 'training_only_stable_four_modes'
    else:
        tier = 'mixed_validation_tiers'
    first = runs[MODES[0]]
    row = {'suite': suite, 'model': model, 'tier': tier, 'headline': headline,
           'common_four_mode_metadata': common_metadata, 'any_numerical_warning': warning,
           'any_variable_timing': variable, 'world_size': first.get('world_size'),
           'physical_gpu': first.get('physical_gpu'), 'batch_size': first.get('batch_size'),
           'component': first.get('component'),
           'parameters': next((record.get('parameters') for record in runs.values() if record.get('parameters')), None)}
    for backend, tune in MODES:
        record = runs[backend, tune]
        row[f'{backend}_{tune}_status'] = record['status']
        row[f'{backend}_{tune}_ms'] = timings[backend, tune]
        row[f'{backend}_{tune}_source'] = record.get('source_json')
    for tune in [0, 1]:
        row[f'triton_over_flydsl_{tune}'] = ratios[tune]
    return row


def aggregate(rows):
    output = {'models': len(rows)}
    for tune in [0, 1]:
        values = [row[f'triton_over_flydsl_{tune}'] for row in rows]
        output[f'autotune{tune}'] = {
            'models': len(values), 'geomean_triton_over_flydsl': statistics.geometric_mean(values) if values else None,
            'median_triton_over_flydsl': statistics.median(values) if values else None,
            'wins': dict(Counter('flydsl' if ratio > 1.03 else 'triton' if ratio < 1 / 1.03
                                 else 'within_3_percent' for ratio in values)),
        }
    for backend in ['triton', 'flydsl']:
        values = [row[f'{backend}_0_ms'] / row[f'{backend}_1_ms'] for row in rows]
        output[f'{backend}_expanded_tuning_speedup'] = statistics.geometric_mean(values) if values else None
    return output


def build(results, manifest_path, fingerprint_path):
    required = ['COMPLETE.json', 'final_audit.json', 'final_timing_sources.csv', 'comparison_stable.csv']
    if any(not (results / name).exists() for name in required):
        raise RuntimeError('Complete the entire matrix and automatic postprocessing before generating the final comparison')
    fingerprint = json.loads(fingerprint_path.read_text())['sha256']
    audit = json.loads((results / 'final_audit.json').read_text())
    if audit['expected_fingerprint'] != fingerprint or set(audit['run_fingerprints']) != {fingerprint}:
        raise RuntimeError('Final audit does not establish a uniform source fingerprint')
    for key in ['source_drift', 'external_source_drift', 'optional_dependency_drift', 'input_metadata_mismatches',
                'unexpected_triton_matrix_templates', 'codegen_collection_errors', 'checkpoint_files']:
        if audit[key]:
            raise RuntimeError(f'Final audit requires review: {key}')
    manifest = json.loads(manifest_path.read_text())
    families = {(item['suite'], item['model']) for item in manifest['models']}
    inputs = {results / name for name in required} | {manifest_path, fingerprint_path, Path(__file__)}
    selected = {}
    for source in csv.DictReader((results / 'final_timing_sources.csv').open()):
        path = Path(source['source_json'])
        record = json.loads(path.read_text())
        actual = record.get('source_fingerprint')
        actual = actual.get('sha256') if isinstance(actual, dict) else actual
        if actual != fingerprint or record['status'] == 'started':
            raise RuntimeError(f'Incomplete or mixed source result: {path}')
        key = (record['suite'], record['model'], record['backend'], int(record['autotune']))
        if key in selected:
            raise RuntimeError(f'Duplicate selected result: {key}')
        selected[key] = dict(record, source_json=str(path))
        inputs.add(path)
    expected = {(suite, model, backend, tune) for suite, model in families for backend, tune in MODES}
    if set(selected) != expected:
        raise RuntimeError('Selected result coverage does not equal the complete four-mode manifest')
    pair_rows = {}
    for row in csv.DictReader((results / 'comparison_stable.csv').open()):
        key = row['suite'], row['model'], int(row['autotune'])
        if key in pair_rows:
            raise RuntimeError(f'Duplicate comparison: {key}')
        pair_rows[key] = row
    if set(pair_rows) != {(suite, model, tune) for suite, model in families for tune in [0, 1]}:
        raise RuntimeError('Missing comparison rows')
    rows = [family_row(suite, model,
                      {(backend, tune): selected[suite, model, backend, tune] for backend, tune in MODES},
                      {tune: pair_rows[suite, model, tune] for tune in [0, 1]}) for suite, model in sorted(families)]
    common = [row for row in rows if row['headline']]
    grouped = defaultdict(list)
    for row in common:
        grouped[row['suite']].append(row)
    summary = {
        'source_fingerprint': fingerprint, 'models': len(families), 'configurations': len(selected),
        'ratio_definition': 'Triton milliseconds / Mixed backend milliseconds; above1 means Mixed backend faster',
        'headline_rule': 'One identical model set for both tuning modes: all four records ok, stable repeats, positive comparable ratios, common placement/batch/config/dtype/parameters',
        'common_four_mode_validated_stable': aggregate(common),
        'by_suite_same_common_set': {suite: aggregate(items) for suite, items in sorted(grouped.items())},
        'tiers': dict(Counter(row['tier'] for row in rows)),
        'training_only_separate': aggregate([row for row in rows if row['tier'] == 'training_only_stable_four_modes']),
        'numerical_warning_models': [row['model'] for row in rows if row['any_numerical_warning']],
        'variable_timing_models': [row['model'] for row in rows if row['any_variable_timing']],
        'input_hashes': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(inputs)},
        'limits': ['Synthetic MSE training benchmark with randomly initialized official full architecture; no checkpoints.',
                   'Diffusion entries are the configured denoiser components, not complete generation pipelines.',
                   'Training-only and warning records remain visible but are excluded from validated headlines.',
                   'Mode0/1 controls pointwise/SIMD search; GEMM/conv lowering remains ATen and global matrix autotuning disabled.',
                   'Kernel census counts are static coverage, not dynamic GPU launch counts.'],
    }
    return rows, summary


def write_report(results, rows, summary):
    csv_path = results / 'common_four_mode_comparison.csv'
    with csv_path.open('w') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (results / 'common_four_mode_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    def number(value):
        return '' if value is None else f'{value:.3f}'
    body = []
    for row in rows:
        cells = [row['suite'], row['model'], row['component'], row['tier'], row['world_size'], row['parameters']]
        cells += [number(row[f'{backend}_{tune}_ms']) for backend, tune in MODES]
        cells += [number(row[f'triton_over_flydsl_{tune}']) for tune in [0, 1]]
        body.append('<tr>' + ''.join('<td>' + html.escape(str(value if value is not None else '')) + '</td>'
                                    for value in cells) + '</tr>')
    headings = ['suite', 'model', 'component', 'evidence tier', 'GPUs', 'parameters', 'Triton0 ms', 'Mixed backend0 ms',
                'Triton1 ms', 'Mixed backend1 ms', 'Triton/Fly0', 'Triton/Fly1']
    common = summary['common_four_mode_validated_stable']
    page = '<!doctype html><meta charset="utf-8"><title>Four-mode training comparison</title>'
    page += '<style>body{font:14px sans-serif;margin:24px}table{border-collapse:collapse}td,th{padding:6px;border:1px solid #ddd}th{position:sticky;top:0;background:#fff}td:nth-child(n+5){text-align:right}</style>'
    page += '<h1>Four-mode full training comparison</h1><p>' + html.escape(summary['ratio_definition']) + '.</p>'
    page += '<p>One common validated, stable set for both tuning modes: ' + str(common['models']) + ' models. '
    page += 'Geomean Triton/Mixed backend: mode0 ' + number(common['autotune0']['geomean_triton_over_flydsl'])
    page += ', mode1 ' + number(common['autotune1']['geomean_triton_over_flydsl']) + '.</p>'
    page += '<p>All ' + str(summary['models']) + ' model outcomes remain below. Warnings, failures, capacity skips, variable timings and training-only measurements are excluded from the headline set.</p>'
    page += '<p><a href="common_four_mode_comparison.csv">CSV</a> | <a href="common_four_mode_summary.json">Summary and provenance</a> | <a href="stable_report.html">Detailed per-mode report</a></p>'
    page += '<table><thead><tr>' + ''.join('<th>' + html.escape(value) + '</th>' for value in headings) + '</tr></thead><tbody>' + ''.join(body) + '</tbody></table>'
    page += '<ul>' + ''.join('<li>' + html.escape(value) + '</li>' for value in summary['limits']) + '</ul>'
    (results / 'common_four_mode_report.html').write_text(page)


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', type=Path, default=root / 'training_results_mixed_multi_v6')
    parser.add_argument('--manifest', type=Path, default=root / 'model_manifest_mixed_multi_v6.json')
    parser.add_argument('--fingerprint', type=Path, default=root / 'source_fingerprint_mixed_multi_v6.json')
    args = parser.parse_args()
    rows, summary = build(args.results, args.manifest, args.fingerprint)
    write_report(args.results, rows, summary)
    print(json.dumps({key: summary[key] for key in ['models', 'configurations', 'common_four_mode_validated_stable', 'tiers']}, indent=2))
