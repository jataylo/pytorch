import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--wait-pid', type=int, required=True)
    args = parser.parse_args()
    while True:
        try:
            os.kill(args.wait_pid, 0)
        except ProcessLookupError:
            break
        time.sleep(5)
    for repeat in [1, 2]:
        for model, gpu, modes in [('MBartForCausalLM', '0', ['1']), ('ghostnet_100', '3', ['0', '1']), ('resnest101e', '1', ['0'])]:
            command = [sys.executable, str(ROOT / 'run_suite.py'), '--results', f'outlier_recheck_{repeat}',
                       '--models', model, '--gpus', gpu, '--autotune-modes', *modes]
            print(json.dumps({'repeat': repeat, 'model': model, 'gpu': gpu}), flush=True)
            subprocess.run(command, cwd=ROOT, check=True)
    rows = []
    for model in ['MBartForCausalLM', 'ghostnet_100', 'resnest101e']:
        for backend in ['triton', 'flydsl']:
            for tune in ({'MBartForCausalLM': [1], 'ghostnet_100': [0, 1], 'resnest101e': [0]}[model]):
                sources = []
                for directory in ['training_results', 'outlier_recheck_1', 'outlier_recheck_2']:
                    for path in (ROOT / directory / 'raw').glob(f'*/{backend}_autotune{tune}.json'):
                        record = json.loads(path.read_text())
                        if record['model'] == model:
                            sources.append({'source': str(path.relative_to(ROOT)), 'status': record['status'],
                                            'milliseconds': record.get('milliseconds'), 'physical_gpu': record.get('physical_gpu')})
                rows.append({'model': model, 'backend': backend, 'autotune': tune, 'runs': sources})
    (ROOT / 'training_results/outlier_rechecks.json').write_text(json.dumps(rows, indent=2) + '\n')
    subprocess.run([sys.executable, str(ROOT / 'analyze_results.py')], cwd=ROOT, check=True)
    print('Outlier rechecks complete; primary results preserved unchanged.', flush=True)


if __name__ == '__main__':
    main()
