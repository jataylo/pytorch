import functools
import json
import os

import torch
import torch.distributed as dist
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP, MixedPrecision
from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy
from torch._inductor import config

rank = int(os.environ['RANK'])
local_rank = int(os.environ['LOCAL_RANK'])
torch.cuda.set_device(local_rank)
dist.init_process_group('nccl')
torch.manual_seed(2026)
config.max_autotune = False
config.max_autotune_gemm = False
config.max_autotune_gemm_backends = 'ATEN'
config.max_autotune_conv_backends = 'ATEN'
config.triton.cudagraphs = False
config.fx_graph_cache = False
with torch.device('cpu' if rank == 0 else 'meta'):
    model = torch.nn.Sequential(torch.nn.Linear(128, 256), torch.nn.GELU(), torch.nn.Linear(256, 64))
model = FSDP(model, device_id=local_rank, use_orig_params=True, sync_module_states=True,
             param_init_fn=lambda m: m.to_empty(device=torch.device('cuda', local_rank), recurse=False),
             auto_wrap_policy=functools.partial(transformer_auto_wrap_policy, transformer_layer_cls={torch.nn.Linear}),
             mixed_precision=MixedPrecision(param_dtype=torch.bfloat16, reduce_dtype=torch.float32))
optimizer = torch.optim.SGD(model.parameters(), lr=0.0001)
torch.manual_seed(2026 + rank)
x = torch.randn(32, 128, device='cuda')

def loss():
    with torch.autocast('cuda', dtype=torch.bfloat16):
        return model(x).float().square().mean()

for backend in ['triton', 'flydsl']:
    config.flydsl.simd = backend == 'flydsl'
    optimizer.zero_grad(set_to_none=True)
    expected_loss = loss()
    expected_loss.backward()
    expected = {n: p.grad.clone() for n, p in model.named_parameters() if p.grad is not None}
    optimizer.zero_grad(set_to_none=True)
    torch._dynamo.reset()
    compiled = torch.compile(loss)
    actual = compiled()
    actual.backward()
    torch.testing.assert_close(actual, expected_loss, atol=0.003, rtol=0.03)
    for n, p in model.named_parameters():
        if n in expected:
            torch.testing.assert_close(p.grad, expected[n], atol=0.005, rtol=0.05)
    optimizer.step()
    if rank == 0:
        print(json.dumps({'backend': backend, 'status': 'ok', 'world_size': dist.get_world_size(), 'loss': actual.item()}), flush=True)
dist.destroy_process_group()
