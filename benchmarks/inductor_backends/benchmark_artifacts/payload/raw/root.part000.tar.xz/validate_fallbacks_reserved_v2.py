import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time


root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('plan')
parser.add_argument('--budget', type=int, default=1200)
parser.add_argument('--results', default='fallback_validation_v2')
parser.add_argument('--keep-going', action='store_true')
args = parser.parse_args()
plan = json.loads(Path(args.plan).read_text())
destination = root / args.results
destination.mkdir(exist_ok=True)
status = {'state': 'waiting_for_benchmark_locks', 'started': time.time(), 'commands': []}


def save():
    (destination / 'status.json').write_text(json.dumps(status, indent=2) + '\n')


save()
print('Waiting for a clean validation window using the existing benchmark locks.', flush=True)
process = None
with Path('/dev/shm/pytorch-simd-v2-entry.lock').open('a') as entry:
    fcntl.flock(entry, fcntl.LOCK_EX)
    with Path('/dev/shm/pytorch-simd-v2-benchmark.lock').open('a') as timing:
        fcntl.flock(timing, fcntl.LOCK_EX)
        try:
            # Distributed startup bypasses the single-GPU entry gate.
            processes = subprocess.check_output(['ps', '-eo', 'args='], text=True).splitlines()
            if any(str(root) in command and ('run_fsdp_v2.py' in command or '--fsdp' in command.split())
                   for command in processes):
                raise RuntimeError('Reserve GPU validation during the single-GPU phase or after all benchmark jobs finish')
            import torch

            capacities = {str(device): torch.cuda.mem_get_info(device)[0]
                          for device in range(torch.cuda.device_count())}
            device = max(capacities, key=capacities.get)
            if capacities[device] < plan.get('minimum_free_bytes', 8 * 1024**3):
                raise RuntimeError('Insufficient free memory for isolated regression tests')
            worktree = root / 'fallback_fixes'
            freeze = json.loads((worktree / 'agent_space/gpu_validation_freeze.json').read_text())
            expected = {worktree / name: digest for name, digest in freeze['files'].items()}
            expected[worktree / 'agent_space/run_overlay.py'] = freeze['overlay_sha256']
            expected.update({root / name: digest for name, digest in freeze.get('harness_files', {}).items()})
            sources = list(expected)
            hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
            if any(hashes[str(path)] != digest for path, digest in expected.items()):
                raise RuntimeError('Isolated sources differ from the supplied validation freeze manifest')
            status.update(state='validating', acquired=time.time(), physical_gpu=device,
                          free_bytes=capacities, source_hashes=hashes, freeze_manifest=freeze)
            save()
            print(json.dumps(status), flush=True)
            deadline = time.monotonic() + args.budget
            env = os.environ.copy()
            env.update(CUDA_VISIBLE_DEVICES=device, TORCHINDUCTOR_COMPILE_THREADS='8',
                       OMP_NUM_THREADS='8', MKL_NUM_THREADS='8')
            for index, command in enumerate(plan['commands']):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    status['state'] = 'budget_exhausted'
                    break
                log_path = destination / f'{index:02d}_{command["label"]}.log'
                started = time.time()
                with log_path.open('w') as log:
                    process = subprocess.Popen(command['argv'], cwd=root.parent.parent,
                                               env=env, stdout=log, stderr=subprocess.STDOUT,
                                               start_new_session=True)
                    try:
                        code = process.wait(timeout=remaining)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                        code = process.returncode
                        status['state'] = 'budget_exhausted'
                result = dict(command, returncode=code, log=str(log_path), elapsed=time.time() - started)
                status['commands'].append(result)
                print(json.dumps(result), flush=True)
                save()
                if code:
                    if status['state'] != 'budget_exhausted':
                        status['state'] = 'test_failure'
                    if not args.keep_going or status['state'] == 'budget_exhausted':
                        break
            else:
                status['state'] = 'test_failure' if any(result['returncode'] for result in status['commands']) else 'passed'
            status['source_drift'] = [str(path) for path in sources
                                      if hashlib.sha256(path.read_bytes()).hexdigest() != hashes[str(path)]]
            if status['source_drift']:
                status['state'] = 'source_drift'
        except Exception as error:
            status.update(state='manager_error', error=str(error))
            raise
        finally:
            if process is not None and process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            status['finished'] = time.time()
            save()
            print('Validation window closed; original benchmark workers can continue.', flush=True)
print(json.dumps(status), flush=True)
