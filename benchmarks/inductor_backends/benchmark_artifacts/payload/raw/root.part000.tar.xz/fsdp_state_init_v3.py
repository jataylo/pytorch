def initialize_fsdp_state_for_compile(model):
    import torch
    import torch.distributed as dist
    from torch.distributed.fsdp import FullyShardedDataParallel

    if not isinstance(model, FullyShardedDataParallel):
        raise TypeError('Initialization-only recovery requires a root FullyShardedDataParallel model')
    if not dist.is_initialized():
        raise RuntimeError('Initialization-only recovery requires an initialized process group')
    if not model.check_is_root():
        raise RuntimeError('Initialization-only recovery requires the root FSDP instance')
    torch.cuda.synchronize()
    dist.barrier()
    return {'method': 'public_fsdp_check_is_root', 'rank': dist.get_rank(),
            'world_size': dist.get_world_size(), 'model_forward_calls': 0,
            'model_backward_calls': 0}
