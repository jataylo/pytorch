import resource
from types import SimpleNamespace
from unittest import mock

resource.setrlimit(resource.RLIMIT_AS, (32 << 30, 32 << 30))

import torch
from transformers.models.deepseek_v4.configuration_deepseek_v4 import DeepseekV4Config
from transformers.models.deepseek_v4.modeling_deepseek_v4 import DeepseekV4ForCausalLM, DeepseekV4PreTrainedModel
from torch.distributed.fsdp._init_utils import _get_modules_to_materialize
from torch.distributed.fsdp._common_utils import TrainingState
from torch.distributed.fsdp._runtime_utils import _accumulate_sharded_grad, _get_reduce_scatter_tensors
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


def tiny_config(tied=False):
    return DeepseekV4Config(
        vocab_size=32, hidden_size=32, moe_intermediate_size=16, num_hidden_layers=2,
        num_attention_heads=2, head_dim=16, q_lora_rank=8, n_routed_experts=4,
        num_experts_per_tok=2, hc_mult=2, o_groups=2, o_lora_rank=8,
        index_n_heads=2, index_head_dim=8, index_topk=4,
        layer_types=['compressed_sparse_attention', 'heavily_compressed_attention'],
        mlp_layer_types=['hash_moe', 'moe'], max_position_embeddings=128,
        partial_rotary_factor=0.5, tie_word_embeddings=tied,
    )


def meta_model(tied=False):
    with torch.device('meta'):
        return DeepseekV4ForCausalLM(tiny_config(tied))


def materialize_on_cpu(model):
    parameters, buffers = {}, {}
    for module in model.modules():
        for name, value in module._parameters.items():
            if value is not None and value.is_meta:
                if id(value) not in parameters:
                    parameters[id(value)] = torch.nn.Parameter(torch.empty_like(value, device='cpu'), requires_grad=value.requires_grad)
                module._parameters[name] = parameters[id(value)]
        for name, value in module._buffers.items():
            if value is not None and value.is_meta:
                if id(value) not in buffers:
                    buffers[id(value)] = torch.empty_like(value, device='cpu')
                module._buffers[name] = buffers[id(value)]


def clear_initialization_flags(model):
    for module in model.modules():
        if hasattr(module, '_is_hf_initialized'):
            del module._is_hf_initialized
    for value in list(model.parameters()) + list(model.buffers()):
        if hasattr(value, '_is_hf_initialized'):
            del value._is_hf_initialized


@instantiate_parametrized_tests
class TestDeepseekMetaInitializationFeasibility(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(mock.patch.object(torch.cuda, '_lazy_init', side_effect=RuntimeError('CPU-only feasibility probe')))

    def test_native_meta_constructor_allows_official_initialization(self):
        model = meta_model()
        self.assertTrue(all(p.is_meta for p in model.parameters()))
        self.assertFalse(getattr(model, '_is_hf_initialized', False))
        materialize_on_cpu(model)
        with torch.no_grad():
            for value in model.parameters():
                value.fill_(float('nan'))
        model.initialize_weights()
        self.assertTrue(all(p.isfinite().all().item() for p in model.parameters()))

    @parametrize('tied', [False, True])
    def test_official_initializer_buffers_aliases_and_repeatability(self, tied):
        states = []
        for _ in range(2):
            model = meta_model(tied)
            materialize_on_cpu(model)
            clear_initialization_flags(model)
            torch.manual_seed(2026)
            model.initialize_weights()
            if tied:
                self.assertIs(model.get_input_embeddings().weight, model.get_output_embeddings().weight)
            else:
                self.assertIsNot(model.get_input_embeddings().weight, model.get_output_embeddings().weight)
            self.assertTrue(all(not p.is_meta and p.isfinite().all().item() for p in model.parameters()))
            self.assertEqual(model.model.norm.weight, torch.ones_like(model.model.norm.weight))
            self.assertEqual(model.model.layers[0].mlp.gate.tid2eid, torch.zeros_like(model.model.layers[0].mlp.gate.tid2eid))
            for name, value in model.named_buffers():
                if 'inv_freq' in name:
                    self.assertTrue(value.isfinite().all().item())
                    self.assertTrue((value > 0).all().item())
            states.append({k: v.clone() for k, v in model.state_dict().items()})
        self.assertEqual(states[0], states[1])
        self.assertFalse(torch.cuda.is_initialized())

    def test_official_packed_expert_backward_has_full_bf16_gradient_and_cast_overlap(self):
        model = DeepseekV4ForCausalLM(tiny_config())
        expert = model.model.layers[0].mlp.experts.to(torch.bfloat16)
        hidden = torch.randn(4, 32, dtype=torch.bfloat16, requires_grad=True)
        indices = torch.zeros((4, 1), dtype=torch.long)
        weights = torch.ones((4, 1), dtype=torch.bfloat16)
        output = expert.forward.__wrapped__(expert, hidden, indices, weights)
        output.float().square().sum().backward()
        parameter = expert.gate_up_proj
        self.assertEqual(parameter.grad.shape, parameter.shape)
        self.assertEqual(parameter.grad.dtype, torch.bfloat16)
        self.assertEqual(parameter.grad[1:], torch.zeros_like(parameter.grad[1:]))
        full_numel = parameter.numel()
        parameter.data = torch.empty((full_numel + 7) // 8, dtype=torch.float32)
        autograd_computed_grad = parameter.grad.data
        parameter.grad.data = parameter.grad.to(torch.float32)
        self.assertEqual(autograd_computed_grad.numel(), full_numel)
        self.assertEqual(autograd_computed_grad.dtype, torch.bfloat16)
        self.assertEqual(parameter.grad.dtype, torch.float32)
        self.assertNotEqual(autograd_computed_grad.untyped_storage().data_ptr(), parameter.grad.untyped_storage().data_ptr())
        self.assertFalse(torch.cuda.is_initialized())

    def test_fsdp_materialization_order_differs_from_official_initialization(self):
        model = meta_model()
        names = {id(module): name for name, module in model.named_modules()}
        breadth_first = [names[id(module)] for module in _get_modules_to_materialize(model, set())]
        order = []
        original = DeepseekV4PreTrainedModel._init_weights

        def observe(owner, module):
            order.append(names[id(module)])
            return original(owner, module)

        clear_initialization_flags(model)
        with mock.patch.object(DeepseekV4PreTrainedModel, '_init_weights', new=observe):
            model.initialize_weights()
        self.assertEqual(set(order), set(breadth_first))
        self.assertNotEqual(order, breadth_first)
        self.assertEqual(order[-1], '')
        self.assertEqual(breadth_first[0], '')


@instantiate_parametrized_tests
class TestFSDPGradientStorageCPU(TestCase):
    @parametrize('numel', [4096, 4099])
    def test_reduce_input_and_output_are_distinct_live_storages(self, numel):
        gradient = torch.ones(numel, dtype=torch.float32)
        state = SimpleNamespace(world_size=8)
        padded, shard = _get_reduce_scatter_tensors(state, gradient)
        self.assertEqual(shard.numel(), (numel + 7) // 8)
        self.assertEqual(shard.dtype, torch.float32)
        self.assertNotEqual(padded.untyped_storage().data_ptr(), shard.untyped_storage().data_ptr())
        if numel % 8 == 0:
            self.assertIs(padded, gradient)
        else:
            self.assertNotEqual(padded.untyped_storage().data_ptr(), gradient.untyped_storage().data_ptr())
            self.assertEqual(padded[:numel], gradient)
        self.assertEqual(gradient, torch.ones_like(gradient))

    def test_low_precision_backward_cast_keeps_original_full_gradient_alive(self):
        parameter = torch.nn.Parameter(torch.ones(4096, dtype=torch.float32))
        parameter.data = parameter.detach().to(torch.bfloat16)
        parameter[512:1024].square().sum().backward()
        self.assertEqual(parameter.grad.shape, (4096,))
        self.assertEqual(parameter.grad.dtype, torch.bfloat16)
        parameter.data = torch.empty(512, dtype=torch.float32)
        autograd_computed_grad = parameter.grad.data
        parameter.grad.data = parameter.grad.to(torch.float32)
        self.assertEqual(autograd_computed_grad.dtype, torch.bfloat16)
        self.assertEqual(parameter.grad.dtype, torch.float32)
        self.assertNotEqual(autograd_computed_grad.untyped_storage().data_ptr(), parameter.grad.untyped_storage().data_ptr())
        self.assertEqual(autograd_computed_grad.numel(), 4096)
        self.assertEqual(parameter.grad.numel(), 4096)
        self.assertEqual(autograd_computed_grad[512:1024], torch.full((512,), 2.0, dtype=torch.bfloat16))

    def test_completed_reductions_keep_separate_fp32_shards(self):
        state = SimpleNamespace(training_state=TrainingState.FORWARD_BACKWARD, _comm_hook=None)
        parameters = [torch.nn.Parameter(torch.empty(512, dtype=torch.float32)) for _ in range(2)]
        gradients = [torch.ones(512, dtype=torch.float32), torch.full((512,), 2.0, dtype=torch.float32)]
        for parameter, gradient in zip(parameters, gradients):
            stored = _accumulate_sharded_grad(state, SimpleNamespace(flat_param=parameter), gradient)
            self.assertIs(stored, gradient)
            self.assertIs(parameter._saved_grad_shard, gradient)
            self.assertNotEqual(parameter.untyped_storage().data_ptr(), gradient.untyped_storage().data_ptr())
        self.assertIsNot(parameters[0]._saved_grad_shard, parameters[1]._saved_grad_shard)
        self.assertEqual(parameters[0]._saved_grad_shard, torch.ones(512))


if __name__ == '__main__':
    run_tests()
