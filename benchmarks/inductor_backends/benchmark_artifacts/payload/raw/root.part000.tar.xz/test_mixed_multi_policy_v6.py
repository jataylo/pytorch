from torch.testing._internal.common_utils import TestCase, run_tests, parametrize, instantiate_parametrized_tests
from mixed_multi_policy_v6 import memory_retry_group, retry_worlds


def records(status='ok', error=''):
    return [dict(backend=backend, autotune=tune, status=status, error=error, parameter_bytes=10)
            for backend in ['triton', 'flydsl'] for tune in [0, 1]]


@instantiate_parametrized_tests
class TestMixedMultiPolicy(TestCase):
    @parametrize('failure', [dict(status='error', error='CUDA out of memory'),
                            dict(status='capacity_skip'),
                            dict(status='error', error='HIPBLAS_STATUS_ALLOC_FAILED')])
    def test_one_memory_failure_retries_entire_group(self, failure):
        group = records()
        group[2].update(failure)
        self.assertTrue(memory_retry_group(group))
        self.assertEqual(len(group), 4)

    @parametrize('status,error', [('ok', ''), ('error', 'repository access denied'),
                                ('error', 'unsupported operation'), ('error', 'CPU allocator failed')])
    def test_no_nonmemory_retries(self, status, error):
        self.assertFalse(memory_retry_group(records(status, error)))

    def test_incomplete_group_rejected(self):
        with self.assertRaises(ValueError):
            memory_retry_group(records()[:3])
        group = records()
        group[0]['status'] = 'started'
        with self.assertRaises(ValueError):
            memory_retry_group(group)

    def test_activation_oom_tries_larger_worlds(self):
        self.assertEqual(retry_worlds(records(), [100] * 8), [2, 4, 8])

    def test_weight_bound_starts_at_viable_world(self):
        group = records()
        for record in group:
            record['parameter_bytes'] = 150
        self.assertEqual(retry_worlds(group, [100] * 8), [4, 8])
        for record in group:
            record['parameter_bytes'] = 1000
        self.assertEqual(retry_worlds(group, [100] * 8), [8])

    def test_device_count_respected(self):
        self.assertEqual(retry_worlds(records(), [100] * 4), [2, 4])
        with self.assertRaises(ValueError):
            retry_worlds(records(), [100])


if __name__ == '__main__':
    run_tests()
