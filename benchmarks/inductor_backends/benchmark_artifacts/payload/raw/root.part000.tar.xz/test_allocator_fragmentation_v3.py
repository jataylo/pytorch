import copy
from decimal import Decimal

from allocator_fragmentation_v3 import fragmentation_evidence, require_expandable_allocation
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


def oom(request="18.93 GiB", free="9.00 GiB", allocated="259.00 GiB", reserved="19.33 GiB", backend="CUDA"):
    return (f"{backend} out of memory. Tried to allocate {request}. GPU 0 has a total capacity of 287.98 GiB "
            f"of which {free} is free. Of the allocated memory {allocated} is allocated by PyTorch, "
            f"and {reserved} is reserved by PyTorch but unallocated.")


@instantiate_parametrized_tests
class TestFragmentationEvidence(TestCase):
    @parametrize("status", ["error", "timeout", "process_failed"])
    def test_terminal_oom_stats(self, status):
        result = fragmentation_evidence({"status": status, "error": oom()})
        self.assertTrue(result["plausible_fragmentation"])
        self.assertFalse(result["rounding_uncertain"])
        self.assertEqual(result["request_bytes"], int((Decimal("18.93") * 1024**3).to_integral_value()))
        self.assertEqual(result["source_field"], "error")

    @parametrize("status", ["ok", "capacity_skip", "running", None])
    def test_nonterminal_or_skipped(self, status):
        self.assertIsNone(fragmentation_evidence({"status": status, "error": oom()}))

    def test_measured_excluded(self):
        for field in ["milliseconds", "ms"]:
            for milliseconds in [0.01, 1, 15, "1.2"]:
                self.assertIsNone(fragmentation_evidence({"status": "error", field: milliseconds, "error": oom()}))
        self.assertIsNone(fragmentation_evidence({"status": "error", "milliseconds": 0, "ms": 1, "error": oom()}))
        self.assertIsNone(fragmentation_evidence({"status": "error", "milliseconds": 1, "ms": 0, "error": oom()}))

    def test_timing_gate_fails_closed(self):
        for field in ["milliseconds", "ms"]:
            for timing in ["bad", "NaN", "Infinity", float("nan"), float("inf"), -1, "-0.01", {}, [], False]:
                with self.subTest(field=field, timing=timing):
                    self.assertIsNone(fragmentation_evidence({"status": "error", field: timing, "error": oom()}))
            for timing in [None, 0, 0.0, "0"]:
                self.assertIsNotNone(fragmentation_evidence({"status": "error", field: timing, "error": oom()}))

    @parametrize("unit,factor", [("KiB", 1024), ("MiB", 1024**2), ("GiB", 1024**3),
                                 ("KB", 1000), ("MB", 1000**2), ("GB", 1000**3), ("B", 1), ("bytes", 1)])
    def test_units(self, unit, factor):
        result = fragmentation_evidence({"status": "error", "traceback": oom(f"40 {unit}", f"10 {unit}", f"70 {unit}", f"35 {unit}", "HIP")})
        self.assertEqual(result["request_bytes"], 40 * factor)
        self.assertEqual(result["allocated_bytes"], 70 * factor)
        self.assertTrue(result["plausible_fragmentation"])
        self.assertEqual(result["source_field"], "traceback")

    def test_insufficient_headroom(self):
        result = fragmentation_evidence({"status": "error", "error": oom("18.94 GiB", "6.63 GiB", reserved="2.66 GiB")})
        self.assertFalse(result["plausible_fragmentation"])
        self.assertFalse(result["rounding_uncertain"])

    def test_free_already_sufficient(self):
        result = fragmentation_evidence({"status": "error", "error": oom("8.00 GiB", "9.00 GiB")})
        self.assertFalse(result["plausible_fragmentation"])

    def test_rounding_boundary_is_explicit(self):
        result = fragmentation_evidence({"status": "error", "error": oom("10.00 GiB", "9.00 GiB", reserved="1.00 GiB")})
        self.assertTrue(result["plausible_fragmentation"])
        self.assertTrue(result["rounding_uncertain"])
        self.assertEqual(result["rounding_error_bytes"]["request_bytes"], 5368710)

    def test_warning_or_unrelated_error_not_evidence(self):
        warning = "If reserved but unallocated memory is large try setting PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True"
        for message in [warning, "CPU out of memory. " + oom().split(". ", 1)[1], "ValueError: " + warning,
                        "CUDA out of memory. " + warning, oom().replace("19.33 GiB", "unknown")]:
            self.assertIsNone(fragmentation_evidence({"status": "error", "error": message}))

    def test_never_combine_distinct_ooms_or_fields(self):
        first = "CUDA out of memory. Tried to allocate 18.93 GiB."
        rest = "GPU 0 has a total capacity of 288 GiB of which 9 GiB is free. 259 GiB is allocated by PyTorch, and 19 GiB is reserved by PyTorch but unallocated."
        self.assertIsNone(fragmentation_evidence({"status": "error", "error": first, "traceback": rest}))
        self.assertIsNone(fragmentation_evidence({"status": "error", "error": first + " CUDA out of memory. " + rest}))


@instantiate_parametrized_tests
class TestExpandableAllocationProof(TestCase):
    def setUp(self):
        super().setUp()
        self.pointer = 16 * 1024**2
        self.nbytes = 4 * 1024**2
        self.snapshot = {"allocator_settings": {"expandable_segments": True}, "segments": [
            {"device": 0, "is_expandable": True, "address": self.pointer, "total_size": 8 * 1024**2,
             "blocks": [{"address": self.pointer, "size": 6 * 1024**2, "state": "active_allocated"}]}]}

    def test_live_interval(self):
        proof = require_expandable_allocation(self.snapshot, self.pointer, self.nbytes, 0)
        self.assertEqual(proof["pointer"], self.pointer)
        self.assertTrue(proof["is_expandable"])
        self.assertEqual(proof["state"], "active_allocated")
        self.assertEqual(require_expandable_allocation(self.snapshot, self.pointer + 1024, self.nbytes, 0)["nbytes"], self.nbytes)

    @parametrize("setting", [False, None, "True", 1])
    def test_settings_must_be_proven(self, setting):
        self.snapshot["allocator_settings"]["expandable_segments"] = setting
        with self.assertRaisesRegex(ValueError, "expandable_segments"):
            require_expandable_allocation(self.snapshot, self.pointer, self.nbytes, 0)

    @parametrize("change", ["wrong_device", "not_expandable", "inactive", "awaiting_free", "past_block", "past_segment", "missing_address"])
    def test_invalid_snapshot(self, change):
        segment = self.snapshot["segments"][0]
        block = segment["blocks"][0]
        if change == "wrong_device":
            segment["device"] = 1
        elif change == "not_expandable":
            segment["is_expandable"] = False
        elif change in ["inactive", "awaiting_free"]:
            block["state"] = "inactive" if change == "inactive" else "active_awaiting_free"
        elif change == "past_block":
            block["size"] = self.nbytes - 1
        elif change == "past_segment":
            segment["total_size"] = self.nbytes - 1
        else:
            del block["address"]
        with self.assertRaisesRegex(ValueError, "not contained"):
            require_expandable_allocation(self.snapshot, self.pointer, self.nbytes, 0)

    def test_adjacent_blocks_do_not_prove_single_allocation(self):
        segment = self.snapshot["segments"][0]
        segment["blocks"][0]["size"] = self.nbytes // 2
        second = copy.deepcopy(segment["blocks"][0])
        second["address"] += second["size"]
        segment["blocks"].append(second)
        with self.assertRaises(ValueError):
            require_expandable_allocation(self.snapshot, self.pointer, self.nbytes, 0)

    @parametrize("nbytes", [0, 2 * 1024**2, -1, 3.5, True])
    def test_large_allocation_required(self, nbytes):
        with self.assertRaisesRegex(ValueError, "larger than 2 MiB"):
            require_expandable_allocation(self.snapshot, self.pointer, nbytes, 0)


if __name__ == "__main__":
    run_tests()
