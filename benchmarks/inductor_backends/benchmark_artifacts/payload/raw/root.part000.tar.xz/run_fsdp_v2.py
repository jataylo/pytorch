import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', default='training_results_v2')
    parser.add_argument('--manifest', default='model_manifest_v2.json')
    parser.add_argument('--gpus', default='0,1,2,3,4,5,6,7')
    parser.add_argument('--wait-pid', type=int)
    args = parser.parse_args()
    if args.wait_pid:
        while True:
            try:
                os.kill(args.wait_pid, 0)
            except ProcessLookupError:
                break
            time.sleep(5)
    import torch
    gpus = args.gpus.split(',')
    free = {g: torch.cuda.mem_get_info(int(g))[0] for g in gpus}
    destination = ROOT / args.results
    snapshot = ROOT / f'{args.results}_single' / 'raw'
    if not snapshot.exists():
        shutil.copytree(destination / 'raw', snapshot)
    grouped = {}
    for path in (destination / 'raw').glob('*/*.json'):
        record = json.loads(path.read_text())
        grouped.setdefault((record['suite'], record['model']), []).append((path, record))
    for (suite, model), runs in grouped.items():
        need = any(r['status'] == 'capacity_skip' or
                   (r['status'] in ['error', 'process_failed'] and 'out of memory' in r.get('error', '').lower())
                   for _, r in runs)
        if not need:
            continue
        required = max((r.get('parameter_bytes', 0) * 2 for _, r in runs), default=0)
        if not required:
            continue
        total = sum(free.values())
        if required > total:
            for path, record in runs:
                record['multi_gpu_capacity_check'] = {'gpus': gpus, 'aggregate_free_bytes': total,
                                                       'minimum_weight_gradient_bytes': required, 'fits': False}
                record['error'] = 'FP32 weights plus gradients exceed aggregate available GPU memory'
                path.write_text(json.dumps(record, indent=2) + '\n')
            print(json.dumps({'model': model, 'status': 'aggregate_capacity_skip', 'required': required, 'available': total}), flush=True)
            continue
        sizes = [n for n in [2, 4, 8] if n <= len(gpus)]
        first = next((n for n in sizes if required < sum(free[g] for g in gpus[:n]) * 0.8), sizes[-1])
        for count in [n for n in sizes if n >= first]:
            label = f'fsdp{count}_{time.time_ns()}'
            print(json.dumps({'model': model, 'world_size': count, 'status': 'starting'}), flush=True)
            command = [sys.executable, str(ROOT / 'run_suite_v2.py'), '--results', args.results,
                       '--manifest', args.manifest, '--models', model, '--suites', suite,
                       '--gpus', ','.join(gpus[:count]), '--fsdp', '--force', '--archive-label', label,
                       '--timeout', '5400']
            subprocess.run(command, cwd=ROOT, check=True)
            latest = [json.loads(path.read_text()) for path, _ in runs]
            if not any('out of memory' in r.get('error', '').lower() for r in latest):
                break
    print('FSDP memory retries complete.', flush=True)


if __name__ == '__main__':
    main()
