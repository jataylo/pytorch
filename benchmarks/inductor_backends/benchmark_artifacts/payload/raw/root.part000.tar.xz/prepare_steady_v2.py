from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics


root = Path(__file__).resolve().parent
if not (root / 'training_results_v2/COMPLETE.json').exists():
    raise RuntimeError('Finish the primary matrix and FSDP retries before preparing rechecks')
manifest = json.loads((root / 'model_manifest_v2.json').read_text())
models = {(model['suite'], model['model']): model for model in manifest['models']}
grouped = defaultdict(list)
for path in (root / 'training_results_v2/raw').glob('*/*.json'):
    record = json.loads(path.read_text())
    grouped[record['suite'], record['model']].append(record)
selected = []
measured = {'ok', 'numerical_warning', 'reference_unavailable', 'validation_unavailable', 'timing_recompile'}
for identity, records in grouped.items():
    if len(records) != 4:
        continue
    shared_fusion_failure = all(record['status'] == 'error' and
        any(message in record.get('error', '') for message in
            ['expected node1 to not be a FusedMixOrderReductions', 'expected node2 to not be a FusedMixOrderReductions'])
        for record in records)
    shared_cache_failure = identity[1] == 'levit_128' and all(record['status'] == 'error' and
        record.get('phase') == 'compile_validation' and
        'Trying to backward through the graph a second time' in record.get('error', '') for record in records)
    shared_mm_failure = all(record['status'] == 'error' and 'mm_token_type_ids' in record.get('error', '') and
                            'missing' in record.get('error', '') for record in records)
    shared_dependency_failure = identity[1] == 'moonshotai/Kimi-K3' and all(
        record['status'] == 'error' and 'fla-core' in record.get('error', '') for record in records)
    shared_meta_constants_failure = identity[1] == 'Qwen/Qwen-Image' and all(
        record['status'] == 'error' and 'Cannot copy out of meta tensor' in record.get('error', '') for record in records)
    shared_fsdp_memory_failure = identity[1] in {'deepseek-ai/DeepSeek-V4-Flash-0731', 'deepseek-ai/DeepSeek-V4-Flash', 'Qwen/Qwen3.8-Flash-Next'} and all(
        record['status'] in {'error', 'process_failed', 'timeout', 'capacity_skip'} and record.get('world_size', 1) > 1
        and record.get('parameters', 0) > 0 for record in records)
    shared_fsdp_initialization_failure = identity[1] in {
        'hunyuanvideo-community/HunyuanVideo', 'Wan-AI/Wan2.1-I2V-14B-720P-Diffusers',
        'Wan-AI/Wan2.2-I2V-A14B-Diffusers',
    } and all(record['status'] == 'error' and record.get('phase') == 'fsdp_eager_initialization'
              and record.get('world_size') == 8 and 'out of memory' in record.get('error', '').lower()
              for record in records)
    if not (shared_fusion_failure or shared_cache_failure or shared_mm_failure or shared_dependency_failure or shared_meta_constants_failure or shared_fsdp_memory_failure or shared_fsdp_initialization_failure) and not all(record['status'] in measured and record.get('milliseconds', 0) > 0 for record in records):
        continue
    groups = {(str(record['physical_gpu']), record['world_size']) for record in records}
    if len(groups) != 1:
        continue
    reasons = []
    overrides = {}
    if shared_fusion_failure:
        reasons.append('Shared Inductor nested mix-order fusion assertion; disable this fusion equally for all four variants')
        overrides['TORCHINDUCTOR_MIX_ORDER_REDUCTION'] = '0'
        steps = 100
    elif shared_cache_failure:
        reasons.append('LeViT eval-mode attention-bias cache reuses a freed eager autograd graph; clear it before compiled validation in all four variants')
        overrides['BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE'] = '1'
        steps = 100
    elif shared_mm_failure:
        reasons.append('Multimodal processor token-type metadata missing; derive types from existing image/video placeholder IDs equally for all four variants')
        overrides['BENCHMARK_ADD_MM_TOKEN_TYPES'] = '1'
        steps = 100
    elif shared_dependency_failure:
        reasons.append('Official Kimi-K3 metadata constructor requires isolated fla-core; preserve the complete architecture and perform real capacity checks')
        overrides.update(BENCHMARK_EXTRA_MODEL_DEPS='1', HF_HUB_OFFLINE='1',
                         BENCHMARK_OFFICIAL_MODEL_REVISION='f831ab66814297da540d832a5235f8e904f29d06')
        steps = 30
    elif shared_meta_constants_failure:
        reasons.append('Restore deterministic unregistered complex rotary tables from the official constructor before FSDP for all four variants')
        overrides['BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS'] = '1'
        steps = 30
    elif shared_fsdp_memory_failure:
        reasons.append('Check a source-verified FSDP backward storage lower bound on the complete official meta model before repeated real-weight initialization')
        overrides['BENCHMARK_VERIFY_FSDP_MEMORY_BOUND'] = '1'
        steps = 30
    elif shared_fsdp_initialization_failure:
        reasons.append('Eager FSDP training initialization exceeded memory before compilation; use validated public state initialization and attempt actual compiled training in all four variants')
        overrides['BENCHMARK_FSDP_STATE_INIT_ONLY'] = '1'
        steps = 30
    else:
        for record in records:
            times = record['repeat_ms']
            if max(times) / min(times) > 1.2 or statistics.median(times[:2]) / statistics.median(times[-2:]) > 1.1:
                reasons.append(f'{record["backend"]}/autotune{record["autotune"]}: repeat drift')
            if record.get('timing_recompiles'):
                reasons.append(f'{record["backend"]}/autotune{record["autotune"]}: timing recompilation')
        fastest = min(min(record['repeat_ms']) for record in records)
        steps = min(2000, max(30, math.ceil(1500 / fastest)))
    if reasons:
        gpu, world_size = groups.pop()
        selected.append(dict(models[identity], physical_gpu=gpu, world_size=world_size,
                             steady_warmup_steps=steps, recheck_reasons=reasons, launch_environment_overrides=overrides))
manifest['models'] = selected
manifest['protocol'] = 'Targeted rechecks with common longer warmup; shared fusion, validation-cache and multimodal-input recoveries apply equally to all four variants, with explicit FSDP memory retries and validated state-only initialization for eager-OOM diffusion cases'
(root / 'model_manifest_v2_steady.json').write_text(json.dumps(manifest, indent=2) + '\n')

worker = (root / 'train_worker_v2.py').read_text()
replacements = {
    "'source_fingerprint_v2.json'": "'source_fingerprint_v2_steady.json'",
    "benchmark_variant='autotune_v2_aten'": "benchmark_variant='autotune_v2_aten_steady_recheck'",
    "    result['physical_gpu'] = os.environ.get('CUDA_VISIBLE_DEVICES')":
        "    result['physical_gpu'] = os.environ.get('CUDA_VISIBLE_DEVICES')\n    result['launch_environment_overrides'] = json.loads(os.environ.get('BENCHMARK_LAUNCH_OVERRIDES', '{}'))\n    result['placement_override'] = os.environ.get('BENCHMARK_PLACEMENT_OVERRIDE') == '1'",
    '        for _ in range(3): step()':
        "        steady_steps = int(os.environ['BENCHMARK_STEADY_WARMUP_STEPS'])\n        for _ in range(steady_steps): step()",
    "result['timing_warmup'] = 3": "result['timing_warmup'] = steady_steps",
    "        counters.clear()\n        if result['eager_reference_status'] == 'available':":
        "        if os.environ.get('BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE') == '1':\n            reset_modules = 0\n            for module in model.modules():\n                cache = getattr(module, 'attention_bias_cache', None)\n                if isinstance(cache, dict):\n                    cache.clear()\n                    reset_modules += 1\n            result['validation_cache_reset_modules'] = reset_modules\n        counters.clear()\n        if result['eager_reference_status'] == 'available':",
    "        result['inputs'] = {":
        "        if os.environ.get('BENCHMARK_ADD_MM_TOKEN_TYPES') == '1':\n            from multimodal_inputs_v2 import with_mm_token_type_ids\n            inputs = with_mm_token_type_ids(model, inputs)\n        result['inputs'] = {",
    "        del meta\n        gc.collect()":
        "        if args.fsdp and os.environ.get('BENCHMARK_VERIFY_FSDP_MEMORY_BOUND') == '1':\n            from fsdp_memory_bound_v3 import fsdp_backward_memory_bound\n            bound = fsdp_backward_memory_bound(meta.to(spec.param_dtype), world_size,\n                free_bytes_per_rank=[capacity['free'] for capacity in capacities])\n            if bound is None:\n                from fsdp_large_embedding_bound_v3 import fsdp_large_embedding_memory_bound\n                bound = fsdp_large_embedding_memory_bound(meta, world_size,\n                    free_bytes_per_rank=[capacity['free'] for capacity in capacities])\n            result['fsdp_memory_bound'] = bound\n            if bound is not None and bound.get('insufficient_capacity'):\n                result.update(status='capacity_skip', error=bound['reason'])\n                save()\n                return\n        del meta\n        gc.collect()",
    "            split_names = set(getattr(model, '_no_split_modules', None) or [])":
        "            if os.environ.get('BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS') == '1':\n                from diffusion_meta_constants_v3 import restore_diffusion_meta_constants\n                result['restored_diffusion_constants'] = restore_diffusion_meta_constants(model)\n            split_names = set(getattr(model, '_no_split_modules', None) or [])",
    "        register_grouped_mm_autocast()": """        if os.environ.get('BENCHMARK_EXTRA_MODEL_DEPS') == '1':
            dependency_root = Path(__file__).resolve().parent / 'optional_model_deps_v3'
            manifest_path = dependency_root.with_name('optional_model_deps_v3_manifest.json')
            dependency_manifest = json.loads(manifest_path.read_text())
            for name, expected in dependency_manifest['file_hashes'].items():
                if hashlib.sha256((dependency_root / name).read_bytes()).hexdigest() != expected:
                    raise RuntimeError(f'Optional model dependency source changed: {name}')
            import fla
            if not Path(fla.__file__).resolve().is_relative_to(dependency_root.resolve()):
                raise RuntimeError(f'Wrong optional dependency path: {fla.__file__}')
            result['optional_model_dependencies'] = {
                'package': 'fla-core', 'version': fla.__version__, 'path': fla.__file__,
                'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
            }
        register_grouped_mm_autocast()""",
    "            result['phase'] = 'fsdp_eager_initialization'":
        "            result['phase'] = 'fsdp_state_initialization' if os.environ.get('BENCHMARK_FSDP_STATE_INIT_ONLY') == '1' else 'fsdp_eager_initialization'",
    """            initialization_loss = forward_loss()
            initialization_loss.backward()
            torch.cuda.synchronize()
            if not torch.isfinite(initialization_loss).item():
                raise RuntimeError('FSDP eager initialization loss is not finite')
            result['fsdp_initialization_loss'] = initialization_loss.detach().item()
            del initialization_loss
            optimizer.zero_grad(set_to_none=True)
            dist.barrier()""": """            if os.environ.get('BENCHMARK_FSDP_STATE_INIT_ONLY') == '1':
                from fsdp_state_init_v3 import initialize_fsdp_state_for_compile
                result['fsdp_initialization_details'] = initialize_fsdp_state_for_compile(model)
                result['fsdp_initialization_mode'] = 'state_only'
            else:
                initialization_loss = forward_loss()
                initialization_loss.backward()
                torch.cuda.synchronize()
                if not torch.isfinite(initialization_loss).item():
                    raise RuntimeError('FSDP eager initialization loss is not finite')
                result['fsdp_initialization_loss'] = initialization_loss.detach().item()
                del initialization_loss
                optimizer.zero_grad(set_to_none=True)
                dist.barrier()
                result['fsdp_initialization_mode'] = 'eager_training'
            save()""",
    "        parameters = sum(p.numel() for p in meta.parameters())": """        expected_revision = os.environ.get('BENCHMARK_OFFICIAL_MODEL_REVISION')
        if expected_revision and expected_revision not in type(meta).__module__:
            raise RuntimeError(f'Unexpected official model revision: {type(meta).__module__}')
        parameters = sum(p.numel() for p in meta.parameters())""",
}
for before, after in replacements.items():
    if worker.count(before) != 1:
        raise RuntimeError(f'Unexpected worker source while replacing {before!r}')
    worker = worker.replace(before, after)
compile(worker, 'train_worker_v2_steady.py', 'exec')
(root / 'train_worker_v2_steady.py').write_text(worker)
runner = (root / 'run_suite_v2.py').read_text()
runner = runner.replace("'train_worker_v2.py'", "'train_worker_v2_steady.py'")
runner = runner.replace("default='training_results_v2'", "default='training_results_v2_steady'")
runner = runner.replace("default='model_manifest_v2.json'", "default='model_manifest_v2_steady.json'")
runner = runner.replace("'TORCHINDUCTOR_FLYDSL_SIMD_STAGES']", "'TORCHINDUCTOR_FLYDSL_SIMD_STAGES', 'TORCHINDUCTOR_MIX_ORDER_REDUCTION', 'BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE', 'BENCHMARK_ADD_MM_TOKEN_TYPES', 'BENCHMARK_PLACEMENT_OVERRIDE', 'BENCHMARK_EXTRA_MODEL_DEPS', 'BENCHMARK_OFFICIAL_MODEL_REVISION', 'BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS', 'BENCHMARK_VERIFY_FSDP_MEMORY_BOUND', 'BENCHMARK_FSDP_STATE_INIT_ONLY', 'HF_HUB_OFFLINE']")
runner = runner.replace("    parser.add_argument('--fsdp', action='store_true')",
                        "    parser.add_argument('--fsdp', action='store_true')\n    parser.add_argument('--override-placement', action='store_true')")
runner = runner.replace("    models = manifest['models']",
                        "    models = [model for model in manifest['models'] if args.override_placement or model['physical_gpu'] == args.gpus]")
runner = runner.replace('            env.update(\n',
                        "            env.update(model.get('launch_environment_overrides', {}))\n            env.update(\n                BENCHMARK_LAUNCH_OVERRIDES=json.dumps(model.get('launch_environment_overrides', {})),\n                BENCHMARK_STEADY_WARMUP_STEPS=str(model['steady_warmup_steps']),\n")
runner = runner.replace("                BENCHMARK_LAUNCH_OVERRIDES=", "                BENCHMARK_PLACEMENT_OVERRIDE=str(int(args.override_placement)),\n                BENCHMARK_LAUNCH_OVERRIDES=")
runner = runner.replace("\n            cmd = [sys.executable,", "\n            if model.get('launch_environment_overrides', {}).get('BENCHMARK_EXTRA_MODEL_DEPS') == '1':\n                env['PYTHONPATH'] = os.pathsep.join([str(ROOT / 'optional_model_deps_v3'), str(ROOT / 'model_deps')])\n            cmd = [sys.executable,")
compile(runner, 'run_suite_v2_steady.py', 'exec')
(root / 'run_suite_v2_steady.py').write_text(runner)
fingerprint = json.loads((root / 'source_fingerprint_v2.json').read_text())
fingerprint['parent_sha256'] = fingerprint.pop('sha256')
fingerprint['protocol'] = manifest['protocol']
for name in ['train_worker_v2_steady.py', 'run_suite_v2_steady.py', 'model_manifest_v2_steady.json',
             'prepare_steady_v2.py', 'run_steady_v2.py', 'multimodal_inputs_v2.py', 'optional_model_deps_v3_manifest.json',
             'diffusion_meta_constants_v3.py', 'test_diffusion_meta_constants_v3.py',
             'fsdp_memory_bound_v3.py', 'test_fsdp_memory_bound_v3.py',
             'fsdp_large_embedding_bound_v3.py', 'test_fsdp_large_embedding_bound_v3.py',
             'fsdp_state_init_v3.py', 'test_fsdp_state_init_v3.py', 'probe_fsdp_state_init_v3.py',
             'test_prepare_fsdp_state_recovery_v3.py']:
    fingerprint['harness'][name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
fingerprint['sha256'] = hashlib.sha256(json.dumps(fingerprint, sort_keys=True).encode()).hexdigest()
(root / 'source_fingerprint_v2_steady.json').write_text(json.dumps(fingerprint, indent=2) + '\n')
print(json.dumps({'models': len(selected), 'configurations': len(selected) * 4,
                  'fingerprint': fingerprint['sha256'], 'selection': selected}, indent=2))
