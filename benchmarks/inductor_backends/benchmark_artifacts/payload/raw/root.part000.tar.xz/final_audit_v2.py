from collections import Counter, defaultdict
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re

from collect_codegen_v2 import collect_codegen


root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--results', default='training_results_v2')
parser.add_argument('--fingerprint', default='source_fingerprint_v2.json')
args = parser.parse_args()
destination = root / args.results
fingerprint = json.loads((root / args.fingerprint).read_text())
drift = []
for group, base in [('sources', Path(fingerprint.get('source_root', root / 'pytorch'))), ('harness', root)]:
    for name, expected in fingerprint[group].items():
        if hashlib.sha256((base / name).read_bytes()).hexdigest() != expected:
            drift.append(str(base / name))
records = [(path, json.loads(path.read_text())) for path in sorted((destination / 'raw').glob('*/*.json'))]
external = json.loads((root / 'external_sources_v2.json').read_text())
external_drift = [name for name, expected in external['source_input_sha256'].items()
                  if not Path(name).exists() or hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected]
optional_dependency_drift = []
if 'optional_model_deps_v3_manifest.json' in fingerprint['harness']:
    optional = json.loads((root / 'optional_model_deps_v3_manifest.json').read_text())
    optional_dependency_drift = [name for name, expected in optional['file_hashes'].items()
                                 if not (root / 'optional_model_deps_v3' / name).exists() or
                                 hashlib.sha256((root / 'optional_model_deps_v3' / name).read_bytes()).hexdigest() != expected]
input_groups = defaultdict(list)
for _, record in records:
    if 'inputs' in record:
        input_groups[record['suite'], record['model']].append(record)
input_mismatches = [dict(suite=identity[0], model=identity[1]) for identity, group in input_groups.items()
                    if len(group) == 4 and len({json.dumps(record['inputs'], sort_keys=True) for record in group}) > 1]
lookup = {(path.parent.name, path.stem): record for path, record in records}
collection_errors = []
attempt_paths = [path for path, _ in records]
attempt_paths += list((destination / 'raw').glob('*/ranks/*.json'))
attempt_paths += list((destination / 'archive').glob('*/*/*.json'))
snapshot = root / f'{args.results}_single/raw'
attempt_paths += list(snapshot.glob('*/*.json')) + list(snapshot.glob('*/ranks/*.json'))
seen_caches = set()
for path in attempt_paths:
    record = json.loads(path.read_text())
    cache = record.get('inductor_cache')
    if not cache or cache in seen_caches or not Path(cache).exists():
        continue
    seen_caches.add(cache)
    tag = f'{record["suite"]}--{record["model"]}--bs{record["batch_size"]}'.replace('/', '_')
    variant = f'{record["backend"]}_autotune{record["autotune"]}'
    output = destination / 'raw' / tag / 'codegen' / f'{variant}.world{record["world_size"]}.rank{record["rank"]}.json'
    try:
        collect_codegen(cache, output)
    except (RuntimeError, SyntaxError, OSError) as error:
        collection_errors.append({'model': record['model'], 'variant': variant, 'rank': record['rank'], 'error': str(error)})
native = []
matrix_templates = []
for path in sorted((destination / 'raw').glob('*/codegen/*.json')):
    match = re.fullmatch(r'(.+)\.world(\d+)\.rank(\d+)\.json', path.name)
    if not match:
        continue
    variant, world, rank = match.groups()
    record = lookup.get((path.parent.parent.name, variant), {})
    active = int(world) == record.get('world_size')
    audit = json.loads(path.read_text())
    for item in audit['unexpected_triton_matrix_templates']:
        matrix_templates.append(dict(model=record.get('model'), active_configuration=active, **item))
    for graph in audit['graphs']:
        with Path(graph['wrapper']).open() as wrapper_file:
            aot_graph = wrapper_file.readline().strip()
        for call in graph['native_calls']:
            native.append({**{key: record.get(key) for key in ['suite', 'model', 'backend', 'autotune']},
                           'world_size': world, 'rank': rank, 'matches_current_world': active,
                           'current_result_status': record.get('status'),
                           'aot_graph': aot_graph,
                           'wrapper': graph['wrapper'], 'wrapper_sha256': graph['sha256'], **call})
fields = ['suite', 'model', 'backend', 'autotune', 'world_size', 'rank', 'current_result_status', 'matches_current_world', 'aot_graph',
          'operation', 'call', 'wrapper', 'wrapper_sha256']
with (destination / 'intentional_native_calls.csv').open('w') as output:
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    writer.writerows(native)
events = []
for line in (destination / 'kernel_decisions.jsonl').open():
    event = json.loads(line)
    if event.get('active_configuration') and event.get('category') == 'lowered' and event.get('backend') == 'triton' and event.get('reason'):
        events.append(event)
identities = [{key: event.get(key) for key in ['suite', 'model', 'autotune', 'world_size', 'rank', 'attempt_id',
                                              'phase', 'graph_id', 'kernel_name', 'nodes']} for event in events]
summary = {
    'source_drift': drift,
    'external_source_drift': external_drift,
    'optional_dependency_drift': optional_dependency_drift,
    'input_metadata_mismatches': input_mismatches,
    'run_fingerprints': dict(Counter(record.get('source_fingerprint', {}).get('sha256') for _, record in records)),
    'expected_fingerprint': fingerprint['sha256'],
    'native_call_inventory': {'callsites': len(native), 'operations': dict(Counter(row['operation'] for row in native)),
                              'scope': 'Generated ATen/extern callsites, including partially compiled failed runs; not physical GPU kernel launches'},
    'unexpected_triton_matrix_templates': matrix_templates,
    'codegen_collection_errors': collection_errors,
    'active_unsupported_events': len(events),
    'active_unsupported_schedule_instances': len({json.dumps(identity, sort_keys=True) for identity in identities}),
    'active_unsupported_kernel_contexts': len({(event.get('suite'), event.get('model'), event.get('autotune'),
                                             event.get('world_size'), event.get('rank'), event.get('graph_id'),
                                             event.get('kernel_name')) for event in events}),
    'checkpoint_files': [str(path) for path in (root / 'hf_config_cache').rglob('*')
                         if path.suffix in {'.safetensors', '.bin', '.pt', '.ckpt'}],
    'analyzer_sha256': hashlib.sha256((root / 'analyze_v2.py').read_bytes()).hexdigest(),
    'final_auditor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(destination / 'final_audit.json').write_text(json.dumps(summary, indent=2) + '\n')
(destination / 'BENCHMARK_NOTES.txt').write_text((root / 'UNSUPPORTED_NOTES_V2.txt').read_text())
page = destination / 'report.html'
page.write_text(page.read_text() + '<p><a href="final_audit.json">Final source and native-call audit</a> | '
                '<a href="BENCHMARK_NOTES.txt">Kernel census and methodology notes</a></p>')
print(json.dumps(summary, indent=2))
