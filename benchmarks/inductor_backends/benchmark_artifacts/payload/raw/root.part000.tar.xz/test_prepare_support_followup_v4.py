import ast
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace

from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


ROOT = Path(__file__).resolve().parent


@instantiate_parametrized_tests
class TestPrepareSupportFollowup(TestCase):
    @parametrize('case', ['stable', 'spread', 'unavailable_spread', 'downtrend', 'failed_stale', 'started', 'missing',
                         'duplicate', 'placement', 'qwen_image', 'dino', 'missing_reference', 'missing_complete',
                         'qwen_image_stale_refs', 'qwen_image_nonoom', 'qwen_image_mixed_world', 'qwen_image_wrong_phase'])
    def test_synthetic_generation(self, case):
        qwen_image = case.startswith('qwen_image')
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for script in ['prepare_support_suite_v4.py', 'prepare_steady_v2.py']:
                tree = ast.parse((ROOT / script).read_text())
                names = {node.value for node in ast.walk(tree) if isinstance(node, ast.Constant)
                         and isinstance(node.value, str) and '\n' not in node.value
                         and len(node.value) < 240 and node.value.endswith(('.py', '.json'))}
                for name in names | {script, 'train_worker_v2.py', 'run_suite_v2.py'}:
                    source, target = ROOT / name, root / name
                    if not source.is_file():
                        source = ROOT / 'fallback_fixes_v4' / name
                        target = root / 'fallback_fixes_v4' / name
                    if source.is_file():
                        target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(source, target)
            for name in ['baseline_fallback_review_v4.json', 'fallback_fixes_v4/agent_space/gpu_validation_freeze.json',
                         'training_results_v2_steady/COMPLETE.json', 'training_results_support_v3/COMPLETE.json',
                         'training_results_support_v3/kernel_inventory/summary.json']:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text('{}')
            model = 'Qwen/Qwen-Image' if qwen_image else 'vit_base_patch14_dinov2.lvd142m' if case == 'dino' else 'synthetic_model'
            manifest = {'models': [{'suite': 'priority', 'model': model, 'batch_size': 8}]}
            (root / 'model_manifest_v2.json').write_text(json.dumps(manifest))
            sources = ['torch/_inductor/scheduler.py', 'torch/_inductor/codegen/flydsl/flydsl_simd.py',
                       'torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py']
            (root / 'source_fingerprint_v2.json').write_text(json.dumps({'sha256': 'synthetic-parent',
                'sources': {name: hashlib.sha256((root / 'fallback_fixes_v4' / name).read_bytes()).hexdigest() for name in sources}, 'harness': {}}))
            original = root / 'training_results_v2/raw/case'
            previous = root / 'training_results_support_v3/raw/case'
            original.mkdir(parents=True, exist_ok=True)
            previous.mkdir(parents=True, exist_ok=True)
            paths = []
            for index, (backend, tune) in enumerate((backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]):
                record = {'suite': 'priority', 'model': model, 'backend': backend, 'autotune': tune,
                          'status': 'ok', 'world_size': 1, 'physical_gpu': '0', 'repeat_ms': [10] * 5,
                          'launch_environment_overrides': {}}
                if qwen_image:
                    record.update(status='error', world_size=8, physical_gpu='0,1,2,3,4,5,6,7',
                                  phase='fsdp_eager_initialization', error='HIP out of memory', repeat_ms=[])
                    if case != 'qwen_image':
                        record.update(world_size=2, physical_gpu='0,1',
                                      error='NotImplementedError: Cannot copy out of meta tensor; no data!')
                if case == 'dino':
                    record['launch_environment_overrides'] = {'TORCHINDUCTOR_MIX_ORDER_REDUCTION': '0'}
                if case == 'placement' and index == 0:
                    record['physical_gpu'] = '1'
                path = original / f'{backend}_{tune}.json'
                path.write_text(json.dumps(record))
                if case != 'missing_reference' or index != 0:
                    paths.append(path)
                record['physical_gpu'] = '0'
                if qwen_image:
                    record.update(world_size=8, physical_gpu='0,1,2,3,4,5,6,7',
                                  phase='fsdp_eager_initialization', error='HIP out of memory')
                if index == 0:
                    if case in {'spread', 'unavailable_spread'}:
                        record['repeat_ms'] = [10, 10, 10, 5, 5]
                        if case == 'unavailable_spread':
                            record['status'] = 'validation_unavailable'
                    elif case == 'downtrend':
                        record['repeat_ms'] = [10, 10, 9.6, 9, 8.9]
                    elif case == 'failed_stale':
                        record.update(status='error', phase='compile_validation', repeat_ms=[], timing_recompiles=1)
                    elif case == 'started':
                        record['status'] = 'started'
                    elif case == 'duplicate':
                        record['autotune'] = 1
                    elif case == 'qwen_image_nonoom':
                        record['error'] = 'RuntimeError: unexpected initialization failure'
                    elif case == 'qwen_image_mixed_world':
                        record.update(world_size=4, physical_gpu='0,1,2,3')
                    elif case == 'qwen_image_wrong_phase':
                        record['phase'] = 'warmup'
                if case != 'missing' or index != 0:
                    (previous / path.name).write_text(json.dumps(record))
            provenance = root / 'training_results_v2/final_timing_sources.csv'
            with provenance.open('w') as output:
                writer = csv.DictWriter(output, fieldnames=['source_json'])
                writer.writeheader()
                writer.writerows({'source_json': str(path)} for path in paths)
            if case == 'missing_complete':
                (root / 'training_results_support_v3/COMPLETE.json').unlink()
            process = subprocess.run([sys.executable, '-S', str(root / 'prepare_support_suite_v4.py')],
                                     cwd=root, env={**os.environ, 'CUDA_VISIBLE_DEVICES': ''}, capture_output=True, text=True, timeout=30)
            if case in {'started', 'missing', 'duplicate', 'placement', 'missing_reference', 'missing_complete'}:
                self.assertNotEqual(process.returncode, 0)
                self.assertIn('RuntimeError:', process.stderr)
                self.assertFalse((root / 'source_fingerprint_support_v4.json').exists())
                return
            self.assertEqual(process.returncode, 0, process.stderr)
            generated = json.loads((root / 'model_manifest_support_v4.json').read_text())
            selected = generated['models'][0]
            self.assertEqual(generated['support_source_root'], str(root / 'fallback_fixes_v4'))
            self.assertEqual(selected['warmup_target_ms'], 15000 if case in {'spread', 'unavailable_spread', 'downtrend'} else 1500)
            if case in {'spread', 'unavailable_spread', 'downtrend'}:
                fastest = 8.9 if case == 'downtrend' else 5
                self.assertEqual(selected['steady_warmup_steps'], math.ceil(15000 / fastest))
                self.assertEqual(len(selected['warmup_reference_hashes']), 4)
                for name, digest in selected['warmup_reference_hashes'].items():
                    self.assertEqual(hashlib.sha256(Path(name).read_bytes()).hexdigest(), digest)
            if qwen_image:
                eligible = case in {'qwen_image', 'qwen_image_stale_refs'}
                if eligible:
                    self.assertEqual(selected['launch_environment_overrides']['BENCHMARK_FSDP_STATE_INIT_ONLY'], '1')
                    expected_evidence = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                                         for path in previous.glob('*.json')}
                    self.assertEqual(len(expected_evidence), 4)
                    self.assertEqual(selected['fsdp_state_initialization_evidence'], expected_evidence)
                else:
                    self.assertNotIn('BENCHMARK_FSDP_STATE_INIT_ONLY', selected['launch_environment_overrides'])
                    self.assertNotIn('fsdp_state_initialization_evidence', selected)
                self.assertEqual(selected['world_size'], 8 if case == 'qwen_image' else 2)
                self.assertEqual(selected['physical_gpu'], '0,1,2,3,4,5,6,7' if case == 'qwen_image' else '0,1')
            if case == 'dino':
                self.assertNotIn('TORCHINDUCTOR_MIX_ORDER_REDUCTION', selected['launch_environment_overrides'])
            worker = (root / 'train_worker_support_v4.py').read_text()
            runner = (root / 'run_suite_support_v4.py').read_text()
            controller = (root / 'run_support_v4.py').read_text()
            for text in [worker, runner, controller]:
                ast.parse(text)
            if qwen_image:
                variant_loop = next(node for node in ast.walk(ast.parse(runner)) if isinstance(node, ast.For)
                                    and ast.unparse(node.target) == '(backend, tune)' and ast.unparse(node.iter) == 'variants')
                updates = [node for node in variant_loop.body if isinstance(node, ast.Expr)
                           and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute)
                           and isinstance(node.value.func.value, ast.Name) and node.value.func.value.id == 'env'
                           and node.value.func.attr == 'update']
                self.assertEqual(len(updates), 2)
                program = compile(ast.Module(body=updates, type_ignores=[]), '<generated variant environment>', 'exec')
                for backend in ['triton', 'flydsl']:
                    for tune in [0, 1]:
                        namespace = {'env': {}, 'model': selected, 'ROOT': root, 'cache': root / 'unused_cache',
                                     'args': SimpleNamespace(override_placement=False), 'gpu': selected['physical_gpu'],
                                     'backend': backend, 'tune': tune, 'time': time, 'json': json, 'os': os}
                        exec(program, namespace)
                        self.assertEqual(namespace['env'].get('BENCHMARK_FSDP_STATE_INIT_ONLY'), '1' if eligible else None)
                        self.assertEqual(namespace['env']['BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS'], '1')
            self.assertLess(worker.index('expected_scheduler ='), worker.index("if args.backend == 'flydsl':"))
            self.assertIn("fallback_fixes_v4/torch/_inductor/scheduler.py", worker)
            self.assertLess(worker.index('expected_simd ='), worker.index("if args.backend == 'flydsl':"))
            self.assertIn("fallback_fixes_v4/torch/_inductor/codegen/simd.py", worker)
            self.assertIn("result['loaded_simd_source']", worker)
            for action in ['loss.backward()', 'optimizer.step()', 'torch.isfinite', "result['training_parameters_with_gradients']"]:
                self.assertIn(action, worker)
            self.assertIn("BENCHMARK_STEADY_WARMUP_STEPS=str(model['steady_warmup_steps'])", runner)
            self.assertIn("BENCHMARK_SUPPORT_SOURCE_ROOT=str(ROOT / 'fallback_fixes_v4')", runner)
            self.assertIn('is_terminal_gpu_memory_failure(record)', controller)
            self.assertIn('verify_dino_preflight(', controller)
            self.assertIn('support_startup_v4', runner)
            self.assertIn('support_startup_v4', controller)
            self.assertNotIn('support_startup_v3', runner)
            self.assertNotIn('support_startup_v3', controller)
            self.assertIn('probe_fsdp_state_init_v4.py', controller)
            self.assertNotIn('probe_fsdp_state_init_v3.py', controller)
            self.assertLess(controller.index('dino_preflight = next('), controller.index('with ThreadPoolExecutor('))
            fingerprint = json.loads((root / 'source_fingerprint_support_v4.json').read_text())
            self.assertEqual(fingerprint['source_root'], str(root / 'fallback_fixes_v4'))
            self.assertIn('test/inductor/test_scheduler_recursive_mix.py', fingerprint['sources'])
            self.assertIn('torch/_inductor/codegen/simd.py', fingerprint['sources'])
            self.assertIn('test/inductor/test_flydsl_symbolic_split.py', fingerprint['sources'])
            self.assertIn('support_startup_v4/sitecustomize.py', fingerprint['harness'])
            self.assertIn('probe_fsdp_state_init_v4.py', fingerprint['harness'])
            self.assertIn('verify_fallback_validation_v4.py', fingerprint['harness'])


if __name__ == '__main__':
    run_tests()
