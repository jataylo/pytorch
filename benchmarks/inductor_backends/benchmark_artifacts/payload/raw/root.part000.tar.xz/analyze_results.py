import argparse
from collections import Counter
import csv
import json
import math
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', default='training_results')
    args = parser.parse_args()
    destination = ROOT / args.results
    records = [json.loads(p.read_text()) for p in sorted((destination / 'raw').glob('*/*.json'))]
    for record in records:
        stats = record.get('dynamo_stats', {})
        record['graph_breaks'] = sum(stats.get('graph_break', {}).values()) if stats else None
        record['compiled_graphs'] = stats.get('stats', {}).get('unique_graphs')
    fields = ['suite', 'model', 'batch_size', 'physical_gpu', 'backend', 'autotune', 'status',
              'milliseconds', 'parameters', 'peak_allocated_bytes', 'first_compiled_step_seconds',
              'component', 'coverage_note', 'validation_mode', 'graph_breaks', 'compiled_graphs', 'error']
    with (destination / 'runs.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(records)
    models = json.loads((ROOT / 'model_manifest.json').read_text())['models']
    rechecks = {}
    if (destination / 'outlier_rechecks.csv').exists():
        with (destination / 'outlier_rechecks.csv').open() as source:
            rechecks = {(r['model'], int(r['autotune'])): r for r in csv.DictReader(source)}
    pairs = []
    for model in models:
        runs = [r for r in records if r.get('suite') == model['suite'] and r.get('model') == model['model']]
        for tune in [0, 1]:
            row = dict(model, autotune=tune)
            selected = {}
            for backend in ['triton', 'flydsl']:
                matches = [r for r in runs if r.get('backend') == backend and r.get('autotune') == tune]
                if matches:
                    r = matches[-1]
                    selected[backend] = r
                    row[f'{backend}_status'] = r['status']
                    row[f'{backend}_ms'] = r.get('milliseconds')
                    row[f'{backend}_error'] = r.get('error', '')
                    row[f'{backend}_graph_breaks'] = r.get('graph_breaks', 0)
                    if backend == 'flydsl' and 'flydsl_counters' in r:
                        row['flydsl_kernels'] = r['flydsl_counters'].get('flydsl_kernels', 0)
                        row['triton_fallback_kernels'] = r['flydsl_counters'].get('triton_kernels', 0)
                else:
                    row[f'{backend}_status'] = 'pending'
            if len(selected) == 2 and selected['triton']['physical_gpu'] == selected['flydsl']['physical_gpu']:
                row['physical_gpu'] = selected['flydsl']['physical_gpu']
            if len(selected) == 2 and all(r['status'] == 'ok' for r in selected.values()):
                if selected['triton']['physical_gpu'] == selected['flydsl']['physical_gpu']:
                    row['triton_over_flydsl'] = selected['triton']['milliseconds'] / selected['flydsl']['milliseconds']
                    ratio = row['triton_over_flydsl']
                    row['winner'] = 'flydsl' if ratio > 1.03 else 'triton' if ratio < 1 / 1.03 else 'within_3_percent'
                    row['flydsl_kernels'] = selected['flydsl'].get('flydsl_counters', {}).get('flydsl_kernels', 0)
                    row['triton_fallback_kernels'] = selected['flydsl'].get('flydsl_counters', {}).get('triton_kernels', 0)
                    row['physical_gpu'] = selected['flydsl']['physical_gpu']
                else:
                    row['winner'] = 'unpaired_gpu'
            recheck = rechecks.get((model['model'], tune))
            if recheck:
                row['recheck1_triton_over_flydsl'] = float(recheck['recheck1_triton_over_flydsl'])
                row['recheck2_triton_over_flydsl'] = float(recheck['recheck2_triton_over_flydsl'])
                row['recheck_median_triton_over_flydsl'] = float(recheck['median_triton_over_flydsl'])
                row['recheck_winner_consistent'] = recheck['winner_consistent'] == 'True'
                row['stability_note'] = 'Independent original-GPU rechecks are in outlier_rechecks.csv; primary timing preserved.'
                if not row['recheck_winner_consistent']:
                    row['stability_note'] += ' Comparison outcome varies across fresh-compilation processes.'
            pairs.append(row)
    fields = ['suite', 'model', 'batch_size', 'autotune', 'physical_gpu', 'triton_status', 'flydsl_status',
              'triton_ms', 'flydsl_ms', 'triton_over_flydsl', 'winner', 'flydsl_kernels',
              'triton_fallback_kernels', 'triton_graph_breaks', 'flydsl_graph_breaks', 'triton_error', 'flydsl_error',
              'recheck1_triton_over_flydsl', 'recheck2_triton_over_flydsl', 'recheck_median_triton_over_flydsl',
              'recheck_winner_consistent', 'stability_note']
    with (destination / 'comparison.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(pairs)
    effects = []
    for model in models:
        for backend in ['triton', 'flydsl']:
            runs = [r for r in records if r.get('suite') == model['suite'] and r.get('model') == model['model'] and r.get('backend') == backend and r['status'] == 'ok']
            by_tune = {r['autotune']: r for r in runs}
            if 0 in by_tune and 1 in by_tune:
                if by_tune[0]['physical_gpu'] == by_tune[1]['physical_gpu']:
                    effects.append(dict(model, backend=backend,
                                        no_autotune_ms=by_tune[0]['milliseconds'],
                                        autotune_ms=by_tune[1]['milliseconds'],
                                        autotune_speedup=by_tune[0]['milliseconds'] / by_tune[1]['milliseconds']))
    with (destination / 'autotune_effect.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=['suite', 'model', 'batch_size', 'backend', 'no_autotune_ms', 'autotune_ms', 'autotune_speedup'])
        writer.writeheader()
        writer.writerows(effects)
    coverage = Counter(sum('milliseconds' in r for r in records if r.get('suite') == m['suite'] and r.get('model') == m['model']) for m in models)
    lines = [
        'Full-model training: Triton versus FlyDSL SIMD',
        'Branch commit: 937d7fd7cdb37e3136c90e86ca71b57d8e5193be',
        'Random weights; no model checkpoints downloaded or saved.',
        'AMP BF16; original list batch sizes; SGD without momentum.',
        'Source input helpers: text sequence length 128; timm model-config image sizes.',
        'SGD learning rate 0.0001; real parameter updates are executed.',
        'Synthetic mean-squared model-output loss; forward, backward, zero_grad and optimizer timed.',
        'Warmup and compilation excluded; median of synchronized wall-time repeats.',
        'Where available, deterministic eager loss and sampled gradients checked before training-mode timing.',
        'CNN validation uses BatchNorm batch statistics with stochastic layers disabled; earlier normalization checks are recorded in raw metadata.',
        'Finite runnable numerical mismatches are timed and flagged numerical_warning; excluded from validated speedup aggregates.',
        'Training-only rechecks without a numerical comparison are flagged validation_unavailable; excluded from validated speedup aggregates.',
        'No CUDA graphs; library GEMM/conv backends retain Inductor defaults in all variants.',
        'torch.compile uses its normal graph-break behavior; full-step timings include eager regions.',
        'Model forward/backward compiled where supported; eager SGD updates are included in timing.',
        'Approved build disables native FlashAttention, memory-efficient attention, and ROCm CK SDPA/GEMM.',
        'Diffusion entries refer to the denoiser component identified by the source model loader.',
        'FlyDSL/fallback kernel counters cover the SIMD path; GEMM, conv and attention retain existing backends.',
        'Speedup = Triton time / FlyDSL time; greater than 1 favors FlyDSL.',
        'Win counts use a 3% band as a practical comparison threshold, not a significance test.',
        '',
        f'Run statuses: {dict(Counter(r["status"] for r in records))}',
        f'Models by number of measured variants (0 through 4): {dict(sorted(coverage.items()))}',
    ]
    for suite in ['all', 'priority', 'huggingface-dashboard', 'timm-dashboard']:
        for tune in [0, 1]:
            rows = [r for r in pairs if 'triton_over_flydsl' in r and (suite == 'all' or r['suite'] == suite) and r['autotune'] == tune]
            if not rows:
                lines.append(f'{suite}, autotune={tune}: no successful paired measurements')
                continue
            ratios = [r['triton_over_flydsl'] for r in rows]
            geomean = math.exp(statistics.mean(math.log(x) for x in ratios))
            wins = dict(Counter(r['winner'] for r in rows))
            lines.append(f'{suite}, autotune={tune}: pairs={len(rows)}, geomean={geomean:.4f}x, median={statistics.median(ratios):.4f}x, wins={wins}')
    for backend in ['triton', 'flydsl']:
        values = [r['autotune_speedup'] for r in effects if r['backend'] == backend]
        if values:
            geomean = math.exp(statistics.mean(math.log(x) for x in values))
            lines.append(f'{backend} autotune effect: matched models={len(values)}, geomean speedup={geomean:.4f}x')
    lines += ['', 'Per-model measurements:', 'suite | model | batch | autotune | Triton ms | FlyDSL ms | speedup']
    for row in pairs:
        if 'triton_over_flydsl' in row:
            lines.append(f"{row['suite']} | {row['model']} | {row['batch_size']} | {row['autotune']} | {row['triton_ms']:.3f} | {row['flydsl_ms']:.3f} | {row['triton_over_flydsl']:.3f}x")
    (destination / 'RESULTS.txt').write_text('\n'.join(lines) + '\n')
    page = r'''<!doctype html>
<html lang="en"><meta charset="utf-8"><title>Training benchmark: Triton vs FlyDSL</title>
<style>
body{font:15px system-ui,sans-serif;max-width:1500px;margin:32px auto;padding:0 20px;color:#17202a}
h1{font-size:27px}p{max-width:1100px;line-height:1.5}select,input{font:inherit;padding:7px;margin:5px}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;padding:9px;border-bottom:1px solid #e4e8eb}
th{position:sticky;top:0;background:#edf2f5}td.num{text-align:right;font-variant-numeric:tabular-nums}
.plot{position:relative;width:180px;height:18px;background:linear-gradient(90deg,#fff5ea,#f6f8fa,#e5f6ef)}
.plot:before{content:"";position:absolute;left:50%;height:18px;border-left:1px solid #718096}
.dot{position:absolute;top:4px;width:10px;height:10px;border-radius:50%;background:#12785a;transform:translateX(-50%)}
.error{color:#914219}small{color:#566573}a{color:#175ba8}.muted{color:#697580}
</style>
<h1>Full-model training: Triton vs FlyDSL SIMD</h1>
<p>Randomly initialized weights, AMP BF16, original model-list batch sizes. Timings include forward, synthetic output loss,
backward, gradient clearing and SGD updates. Compilation and warmup are excluded. Each model's variants use the same GPU.
Numbers above 1 in the speedup column favor FlyDSL. Diffusion entries measure the source loader's denoiser component.
Kernel counters cover the SIMD path; GEMM, convolution and attention retain existing backends.
Normal graph-break behavior is allowed; full-step timings include eager regions and SGD updates.</p>
<p><small>Commit 937d7fd7cdb · MI355X / gfx950 · PyTorch 2.14 · FlyDSL 0.3.4.1 · Triton 3.9.
Validated runs pass deterministic loss and sampled-gradient comparisons against eager before train-mode timing.
Measured numerical-warning or validation-unavailable runs retain their timings but have no validated speedup ratio.
Failure and capacity rows have no performance ratio. An asterisk marks comparisons that vary across independent rechecks. Results may be incomplete while the sweep is active.</small></p>
<p><a href="comparison.csv">Comparison CSV</a> · <a href="autotune_effect.csv">Autotune effect CSV</a> · <a href="runs.csv">All runs CSV</a> · <a href="RESULTS.txt">Method and summary</a></p>
<label>Suite <select id="suite"><option value="">All</option><option>priority</option><option>huggingface-dashboard</option><option>timm-dashboard</option></select></label>
<label>Autotune <select id="tune"><option value="">Both</option><option value="0">Off</option><option value="1">On</option></select></label>
<label>Model <input id="search" placeholder="Filter by name"></label>
<label><input type="checkbox" id="failures">Include numerical warnings, failures and pending</label>
<label>Sort <select id="sort"><option value="model">Model</option><option value="fast">FlyDSL advantage</option><option value="slow">Triton advantage</option></select></label>
<p id="summary"></p>
<table><thead><tr><th>Suite / model</th><th>Batch</th><th>Autotune</th><th>Triton ms</th><th>FlyDSL ms</th><th>Speedup</th><th>Triton ← 1 → FlyDSL</th><th>FlyDSL / fallback kernels</th><th>Graph breaks Triton / FlyDSL</th></tr></thead><tbody id="rows"></tbody></table>
<script id="benchmark-data" type="application/json">__DATA__</script>
<script>
const data=JSON.parse(document.getElementById('benchmark-data').textContent);
const ids=['suite','tune','search','failures','sort'];
function render(){
 const value=id=>document.getElementById(id).value;
 const showFailures=document.getElementById('failures').checked;
 let rows=data.filter(r=>(!value('suite')||r.suite===value('suite'))&&
   (value('tune')===''||r.autotune===Number(value('tune')))&&
   r.model.toLowerCase().includes(value('search').toLowerCase())&&(showFailures||r.triton_over_flydsl));
 rows.sort((a,b)=>value('sort')==='fast'?(b.triton_over_flydsl||0)-(a.triton_over_flydsl||0):
   value('sort')==='slow'?(a.triton_over_flydsl||Infinity)-(b.triton_over_flydsl||Infinity):a.model.localeCompare(b.model));
 const paired=rows.filter(r=>r.triton_over_flydsl),ratios=paired.map(r=>r.triton_over_flydsl);
 const gm=ratios.length?Math.exp(ratios.reduce((s,r)=>s+Math.log(r),0)/ratios.length):null;
 document.getElementById('summary').textContent=`${rows.length} rows; ${paired.length} paired measurements`+
   (gm?`; geometric mean speedup ${gm.toFixed(3)}x. Greater than 1 favors FlyDSL.`:'.');
 const body=document.getElementById('rows');body.replaceChildren();
 for(const r of rows){
  const tr=document.createElement('tr');
  const values=[r.suite+' / '+r.model,r.batch_size,r.autotune?'On':'Off',
    r.triton_ms?r.triton_ms.toFixed(3):r.triton_status,r.flydsl_ms?r.flydsl_ms.toFixed(3):r.flydsl_status,
    r.triton_over_flydsl?r.triton_over_flydsl.toFixed(3)+'x'+(r.recheck_winner_consistent===false?' *':''):'—'];
  values.forEach((v,i)=>{const td=document.createElement('td');td.textContent=v;
    if(i>=3)td.className='num';tr.append(td);});
  const td=document.createElement('td');
  if(r.triton_over_flydsl){const plot=document.createElement('div');plot.className='plot';
    const dot=document.createElement('div');dot.className='dot';
    dot.style.left=(50+25*Math.max(-2,Math.min(2,Math.log2(r.triton_over_flydsl))))+'%';
    dot.style.background=r.triton_over_flydsl>=1?'#12785a':'#bc691b';plot.append(dot);td.append(plot);
  }else{td.className='error';td.textContent='No validated pair';}
  tr.append(td);const kernels=document.createElement('td');
  kernels.textContent=r.flydsl_kernels===undefined?'—':`${r.flydsl_kernels} / ${r.triton_fallback_kernels}`;
  tr.append(kernels);const breaks=document.createElement('td');
  breaks.textContent=`${r.triton_graph_breaks??'—'} / ${r.flydsl_graph_breaks??'—'}`;tr.append(breaks);
  tr.title=[r.triton_error,r.flydsl_error,r.stability_note].filter(Boolean).join('\n');body.append(tr);
 }
}
ids.forEach(id=>document.getElementById(id).addEventListener('input',render));render();
</script></html>'''
    if len(records) == len(models) * 4 and not any(r['status'] == 'started' for r in records):
        page = page.replace('Results may be incomplete while the sweep is active.', f'Complete matrix: {len(records)} configuration outcomes, {sum("milliseconds" in r for r in records)} measured timings; failures and capacity skips retained.')
    if (destination / 'outlier_rechecks.csv').exists():
        page = page.replace('<label>Suite', '<p><a href="outlier_rechecks.csv">Independent performance rechecks CSV</a> &middot; <a href="outlier_rechecks.txt">Recheck summary</a></p><label>Suite')
    page = page.replace('__DATA__', json.dumps(pairs).replace('</', '<\\/'))
    (destination / 'comparison.html').write_text(page)
    print('\n'.join(lines[:24]))


if __name__ == '__main__':
    main()
