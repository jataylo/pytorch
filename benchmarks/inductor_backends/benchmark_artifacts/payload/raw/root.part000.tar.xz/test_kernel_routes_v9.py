import json
from pathlib import Path
import tempfile

from torch.testing._internal.common_utils import TestCase, run_tests
from analyze_kernel_routes_v9 import inspect_record, operations, valid_times, grouped, write_csv


def inspect(events):
    with tempfile.TemporaryDirectory() as directory:
        path=Path(directory)/'events.jsonl'
        base=dict(attempt_id='one',rank=0,phase='warmup',kernel_name='kernel')
        path.write_text(''.join(json.dumps(dict(base,**event))+'\n' for event in events))
        record=dict(suite='suite',model='toy',autotune=1,world_size=1,physical_gpu='0',status='ok',
                    attempt_id='one',diagnostics_file=str(path),_source='fixture')
        return inspect_record(record)[0]


class TestKernelRoutes(TestCase):
    def test_measured_units_sign_and_source_join(self):
        rows=inspect([dict(category='lowered',backend='flydsl',stage='norm',origins='Original ATen: [aten._softmax, aten.view]'),
                      dict(category='backend_selection',selected_backend='flydsl',candidate_times_ms=[0.1,0.2])])
        row=rows[0]
        self.assertEqual(row['flydsl_us'],100)
        self.assertEqual(row['triton_us'],200)
        self.assertEqual(row['flydsl_speedup_percent'],50)
        self.assertEqual(row['ops'],'aten._softmax;aten.view')
        self.assertEqual(row['measured_winner'],'flydsl')

    def test_cached_choice_never_invents_timing(self):
        row=inspect([dict(category='backend_selection',selected_backend='flydsl',cache_hit=True,candidate_times_ms=None)])[0]
        self.assertIsNone(row['flydsl_us'])
        self.assertIsNone(row['triton_over_flydsl'])
        self.assertEqual(row['selected_backend'],'flydsl')
        self.assertEqual(row['measured_winner'],'unknown')

    def test_near_tie_not_clear_fly_win(self):
        row=inspect([dict(category='backend_selection',selected_backend='flydsl',candidate_times_ms=[1,0.99])])[0]
        self.assertEqual(row['measured_winner'],'within_3_percent')
        self.assertLess(row['flydsl_speedup_percent'],0)

    def test_skipped_not_measured_win(self):
        row=inspect([dict(category='lowered',backend='flydsl'),dict(category='selection_skipped',reason='workspace')])[0]
        self.assertEqual(row['decision_source'],'selection_skipped_uses_flydsl')
        self.assertIsNone(row['flydsl_speedup_percent'])

    def test_conflicting_choices_not_merged(self):
        row=inspect([dict(category='backend_selection',selected_backend='flydsl',candidate_times_ms=[1,2]),
                     dict(category='backend_selection',selected_backend='triton',candidate_times_ms=[2,1])])[0]
        self.assertEqual(row['selected_backend'],'conflicting_choices')
        self.assertIsNone(row['flydsl_us'])

    def test_invalid_times(self):
        self.assertFalse(valid_times({'candidate_times_ms':[1,None]}))
        self.assertFalse(valid_times({'candidate_times_ms':[1,float('nan')]}))
        self.assertFalse(valid_times({'candidate_times_ms':[0,1]}))

    def test_fused_op_counts_overlap_explicitly(self):
        rows=inspect([dict(category='lowered',backend='flydsl',origins='aten.add aten.mul aten.add'),
                      dict(category='backend_selection',selected_backend='flydsl',candidate_times_ms=[1,2])])
        values=grouped(rows,'ops')
        self.assertEqual({value['group'] for value in values},{'aten.add','aten.mul'})
        self.assertEqual(sum(value['kernel_contexts'] for value in values),2)

    def test_variable_csv_fields_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'values.csv'
            write_csv(path,[dict(model='one'),dict(model='two',rounds=5)])
            self.assertIn('rounds',path.read_text())


if __name__=='__main__':
    run_tests()
