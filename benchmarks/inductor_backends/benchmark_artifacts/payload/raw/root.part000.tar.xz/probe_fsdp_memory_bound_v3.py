import os
from pathlib import Path
import resource
import sys

resource.setrlimit(resource.RLIMIT_AS, (64 << 30, 64 << 30))
os.environ.update(CUDA_VISIBLE_DEVICES='', HIP_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1')
import site
site.main()

import hashlib
import json
from unittest import mock
import torch

root = Path(__file__).resolve().parent
os.environ['HF_HOME'] = str(root / 'hf_config_cache')
sys.path.insert(0, '/dockerx/Triton_Conv_Development/scripts')
sys.path.insert(0, str(root))
from common import load_model_meta, resolve_dtype_spec
from fsdp_memory_bound_v3 import fsdp_backward_memory_bound

with mock.patch.object(torch.cuda, '_lazy_init', side_effect=RuntimeError('CPU-only memory proof')):
    spec = resolve_dtype_spec('amp_bf16')
    model = load_model_meta('deepseek-ai/DeepSeek-V4-Flash-0731', spec).to(spec.param_dtype)
    record = json.loads((root / 'training_results_v2/raw/priority--deepseek-ai_DeepSeek-V4-Flash-0731--bs8/flydsl_autotune0.json').read_text())
    capacity = record['total_vram_bytes']
    bounds = {str(world): fsdp_backward_memory_bound(model, world, free_bytes_per_rank=[capacity] * world) for world in [2, 4, 8]}
    if any(value is None or not value['insufficient_capacity'] for value in bounds.values()):
        raise RuntimeError('Expected the verified actual architecture to exceed capacity at all tested placements')
    output = {
        'model_id': 'deepseek-ai/DeepSeek-V4-Flash-0731',
        'official_config_revision': (root / 'hf_config_cache/hub/models--deepseek-ai--DeepSeek-V4-Flash-0731/refs/main').read_text().strip(),
        'actual_gpu_total_bytes': capacity,
        'actual_gpu_total_gib': capacity / (1 << 30),
        'gpu_initialized': torch.cuda.is_initialized(),
        'all_parameters_meta': all(p.is_meta for p in model.parameters()),
        'rlimit_as_bytes': 64 << 30,
        'helper_sha256': hashlib.sha256((root / 'fsdp_memory_bound_v3.py').read_bytes()).hexdigest(),
        'bounds': bounds,
    }
    path = root / 'fsdp_memory_bound_deepseek_flash0731_v3.json'
    path.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({'artifact': str(path), 'gpu_total_bytes': capacity, 'gpu_total_gib': output['actual_gpu_total_gib'],
                      'bounds': {k: {'bytes': v['per_rank_lower_bound_bytes'], 'gib': v['per_rank_lower_bound_bytes'] / (1 << 30)} for k, v in bounds.items()},
                      'all_parameters_meta': output['all_parameters_meta'], 'gpu_initialized': output['gpu_initialized']}, indent=2))
