import ast
import csv
import hashlib
import json
from pathlib import Path
import tempfile

from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


SOURCE = Path(__file__).with_name('finish_support_benchmarks_v4.py')
TREE = ast.parse(SOURCE.read_text())
GATE = next(node for node in ast.walk(TREE) if isinstance(node, ast.With)
            and 'all_compile_execution_failures.csv' in ast.unparse(node.items[0].context_expr))


@instantiate_parametrized_tests
class TestFollowupFailureReviewGate(TestCase):
    @parametrize('case', ['compiler_unreviewed', 'compiler_reviewed', 'external_unreviewed',
                         'external_reviewed', 'changed_cause', 'memory'])
    def test_exact_hash_review(self, case):
        failure = {'model': 'vit_base_patch14_dinov2.lvd142m', 'phase': 'compile_validation',
                   'error': 'expected node1 to not be a FusedMixOrderReductions',
                   'failure_kind': 'compiler_or_execution'}
        if case.startswith('external'):
            failure.update(phase='warmup', failure_kind='external_termination')
        if case == 'memory':
            failure.update(error='HIP out of memory', failure_kind='memory')
        reviewed = []
        if case in {'compiler_reviewed', 'external_reviewed', 'changed_cause'}:
            reviewed.append(hashlib.sha256(json.dumps(
                {key: failure[key] for key in ['model', 'phase', 'error']}, sort_keys=True).encode()).hexdigest())
        if case == 'changed_cause':
            failure['error'] += ' with a new cause'
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'training_results_support_v3/all_compile_execution_failures.csv'
            path.parent.mkdir()
            with path.open('w') as output:
                writer = csv.DictWriter(output, fieldnames=list(failure))
                writer.writeheader()
                writer.writerow(failure)
            namespace = {'root': root, 'csv': csv, 'hashlib': hashlib, 'json': json,
                         'review': {'reviewed_failure_hashes': reviewed}, 'unknown_failures': []}
            exec(compile(ast.Module(body=[GATE], type_ignores=[]), str(SOURCE), 'exec'), namespace)
        self.assertEqual(len(namespace['unknown_failures']), int(case in {'compiler_unreviewed', 'external_unreviewed', 'changed_cause'}))


if __name__ == '__main__':
    run_tests()
