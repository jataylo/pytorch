import json
from pathlib import Path
import tempfile
from xml.etree import ElementTree
from zipfile import ZipFile

from torch.testing._internal.common_utils import TestCase, run_tests
from build_three_backend_report_v7 import make_row, mixed_kernel_counts, speedup, summarize, write_workbook


def record(ms=10):
    return dict(status='ok', milliseconds=ms, repeat_ms=[ms] * 5, physical_gpu='0', world_size=1,
                batch_size=1, dtype='amp_bf16', parameters=10, model_config_sha256='same',
                source_fingerprint={'sources': {'torch/core.py': 'same'}}, attempt_id='a')


def row(triton=10, flydsl=8, mix=7):
    return make_row(dict(model='toy', suite='test', batch_size=1), 1, record(triton), record(flydsl), record(mix))


class TestThreeBackendReport(TestCase):
    def test_speedup_uses_time_saved(self):
        self.assertEqual(speedup(100, 80), 20)
        self.assertEqual(speedup(100, 120), -20)
        value = row()
        self.assertEqual(value['flydsl_speedup_percent'], 20)
        self.assertEqual(value['mix_speedup_percent'], 30)

    def test_metadata_mismatch_blanks_ratios(self):
        first, second, third = record(), record(8), record(7)
        second['world_size'] = 2
        value = make_row(dict(model='toy', suite='test', batch_size=1), 1, first, second, third)
        self.assertEqual(value['evidence_tier'], 'incomparable_metadata_or_source')
        self.assertIsNone(value['flydsl_speedup_percent'])
        self.assertFalse(value['headline_eligible'])

    def test_compiler_mismatch_rejected(self):
        first, second, third = record(), record(8), record(7)
        third['source_fingerprint'] = {'sources': {'torch/core.py': 'different'}}
        value = make_row(dict(model='toy', suite='test', batch_size=1), 1, first, second, third)
        self.assertFalse(value['identical_compiler_sources'])
        self.assertIsNone(value['mix_speedup_percent'])

    def test_warnings_not_headline(self):
        first, second, third = record(), record(8), record(7)
        second['status'] = 'numerical_warning'
        value = make_row(dict(model='toy', suite='test', batch_size=1), 1, first, second, third)
        self.assertEqual(value['evidence_tier'], 'numerical_warning')
        self.assertFalse(value['headline_eligible'])

    def test_failed_timings_blank(self):
        first, second, third = record(), record(8), record(7)
        second.update(status='error', error='out of memory')
        value = make_row(dict(model='toy', suite='test', batch_size=1), 1, first, second, third)
        self.assertIsNone(value['flydsl_ms'])
        self.assertIsNone(value['flydsl_speedup_percent'])

    def test_training_only_separate(self):
        arms = [record(), record(8), record(7)]
        for arm in arms:
            arm['status'] = 'validation_unavailable'
        value = make_row(dict(model='toy', suite='test', batch_size=1), 1, *arms)
        self.assertEqual(value['evidence_tier'], 'training_only')
        self.assertFalse(value['headline_eligible'])

    def test_geomean_ratios_not_average_percent(self):
        values = [row(10, 5, 5), row(10, 20, 20)]
        result = {item['metric']: item['value'] for item in summarize(values, 'test', 1)}
        self.assertEqual(result['geomean_triton_over_mix'], 1)
        self.assertEqual(result['geomean_mix_speedup_percent'], 0)
        self.assertEqual(result['models_mix_faster_than_triton'], 1)
        self.assertEqual(result['models_triton_faster_than_mix'], 1)

    def test_counts_deduplicate_and_preserve_unknown(self):
        with tempfile.TemporaryDirectory() as directory:
            events = []
            def add(category, name, **values):
                events.append(dict(attempt_id='a', rank=0, phase='warmup', category=category, kernel_name=name, **values))
            for name in ['default', 'selected', 'missing']:
                add('lowered', name, backend='flydsl')
            add('backend_candidates', 'selected')
            add('backend_candidates', 'missing')
            add('backend_selection', 'selected', selected_backend='triton')
            add('backend_selection', 'selected', selected_backend='triton')
            path = Path(directory) / 'events.jsonl'
            path.write_text(''.join(json.dumps(event) + '\n' for event in events))
            value = mixed_kernel_counts(dict(record(), diagnostics_file=str(path)))
            self.assertEqual(value['flydsl_kernels'], 1)
            self.assertEqual(value['triton_kernels'], 1)
            self.assertEqual(value['kernel_selection_unknown'], 1)

    def test_workbook_xml_and_numeric_cells(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'result.xlsx'
            write_workbook(path, [('Summary', [dict(model='a<b&c\x1b', ms=12.5)], ['model', 'ms'])])
            with ZipFile(path) as archive:
                for name in archive.namelist():
                    ElementTree.fromstring(archive.read(name))
                source = archive.read('xl/worksheets/sheet1.xml').decode()
                self.assertIn('<v>12.5</v>', source)
                self.assertIn('a&lt;b&amp;c', source)
                self.assertNotIn('\x1b', source)


if __name__ == '__main__':
    run_tests()
