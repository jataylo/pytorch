from collections import defaultdict, Counter
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from allocation_failures_v3 import is_terminal_gpu_memory_failure
from mixed_multi_policy_v6 import memory_retry_group, retry_worlds

ROOT = Path(__file__).resolve().parent
SINGLE = ROOT / 'training_results_mixed_single_v5'
RESULTS = ROOT / 'training_results_mixed_multi_v6'
RESULTS.mkdir(exist_ok=True)
MANIFEST = 'model_manifest_mixed_multi_v6.json'
FINGERPRINT = 'source_fingerprint_mixed_multi_v6.json'


def state(phase, **details):
    payload = dict(phase=phase, timestamp=time.time(), **details)
    (RESULTS / 'pipeline.json').write_text(json.dumps(payload, indent=2) + '\n')
    print(json.dumps(payload), flush=True)


def run(script, *arguments):
    state('running', script=script, arguments=arguments)
    subprocess.run([sys.executable, str(ROOT / script), *arguments], cwd=ROOT, check=True)


def check_sources(fingerprint):
    for group, base in [('sources', Path(fingerprint['source_root'])), ('harness', ROOT)]:
        for name, expected in fingerprint[group].items():
            if hashlib.sha256((base / name).read_bytes()).hexdigest() != expected:
                raise RuntimeError(f'Source drift: {base / name}')


def read_group(model):
    tag = f"{model['suite']}--{model['model']}--bs{model['batch_size']}".replace('/', '_')
    records = [json.loads(path.read_text()) for path in (RESULTS / 'raw' / tag).glob('*.json')]
    if len(records) != 4 or any(record['status'] == 'started' for record in records):
        raise RuntimeError(f'Incomplete multi-GPU group: {model["model"]}')
    expected = {('triton', 0), ('triton', 1), ('flydsl', 0), ('flydsl', 1)}
    if {(record['backend'], record['autotune']) for record in records} != expected:
        raise RuntimeError('Missing benchmark variants')
    if len({(record['physical_gpu'], record['world_size']) for record in records}) != 1:
        raise RuntimeError('Inconsistent GPU placement')
    for record in records:
        config = record.get('inductor_config')
        if config and config['flydsl.simd_autotune_backend'] != (record['backend'] == 'flydsl'):
            raise RuntimeError('Wrong selector setting')
    return records


state('waiting_for_single_gpu_sweep_and_audits')
while True:
    try:
        pipeline = json.loads((SINGLE / 'pipeline.json').read_text())
    except (OSError, ValueError):
        time.sleep(5)
        continue
    if pipeline['phase'] == 'measurements_complete_manual_review_required':
        break
    if pipeline['phase'] == 'needs_review' and 'build_common_comparison_mixed_single_v5.py' not in pipeline.get('error', ''):
        state('waiting_for_single_gpu_error_review', error=pipeline.get('error'))
    time.sleep(5)

try:
    parent = json.loads((ROOT / 'source_fingerprint_mixed_single_v5.json').read_text())
    check_sources(parent)
    original_manifest = json.loads((ROOT / 'model_manifest_mixed_single_v5.json').read_text())
    groups = defaultdict(list)
    input_hashes = {}
    for path in (SINGLE / 'raw').glob('*/*.json'):
        record = json.loads(path.read_text())
        groups[record['suite'], record['model']].append(record)
        input_hashes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    if len(groups) != len(original_manifest['models']):
        raise RuntimeError('Incomplete single GPU model list')
    selected = {key for key, records in groups.items() if memory_retry_group(records)}
    manifest = json.loads(json.dumps(original_manifest))
    manifest['models'] = [model for model in manifest['models'] if (model['suite'], model['model']) in selected]
    manifest['protocol'] = 'Mixed selector OOM follow-up: identical full architectures and global batch, FSDP on common 2/4/8 GPU groups for all four variants; ATen GEMM/conv, no checkpoints/offload; separate from single GPU results'
    for model in manifest['models']:
        model['physical_gpu'] = '0,1'
        model['world_size'] = 2
        overrides = model['launch_environment_overrides']
        if model['model'] in {'Qwen/Qwen-Image', 'hunyuanvideo-community/HunyuanVideo',
                              'Wan-AI/Wan2.1-I2V-14B-720P-Diffusers', 'Wan-AI/Wan2.2-I2V-A14B-Diffusers'}:
            overrides['BENCHMARK_FSDP_STATE_INIT_ONLY'] = '1'
        if model['model'] in {'deepseek-ai/DeepSeek-V4-Flash', 'deepseek-ai/DeepSeek-V4-Flash-0731', 'Qwen/Qwen3.8-Flash-Next'}:
            overrides['BENCHMARK_VERIFY_FSDP_MEMORY_BOUND'] = '1'
    (ROOT / MANIFEST).write_text(json.dumps(manifest, indent=2) + '\n')
    (RESULTS / 'single_gpu_inputs.json').write_text(json.dumps(input_hashes, indent=2) + '\n')
    fingerprint = json.loads(json.dumps(parent))
    fingerprint['parent_sha256'] = fingerprint.pop('sha256')
    fingerprint['protocol'] = manifest['protocol']
    extras = ['run_mixed_multi_v6.py', 'mixed_multi_policy_v6.py', 'test_mixed_multi_policy_v6.py',
              'train_worker_mixed_multi_v6.py', 'run_suite_mixed_multi_v6.py', MANIFEST,
              'probe_fsdp_state_init_mixed_v6.py', 'validate_mixed_fsdp_v6.py',
              'analyze_mixed_multi_v6.py', 'merge_mixed_multi_v6.py', 'build_common_comparison_mixed_multi_v6.py']
    for name in extras:
        fingerprint['harness'][name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    fingerprint['sha256'] = hashlib.sha256(json.dumps(fingerprint, sort_keys=True).encode()).hexdigest()
    (ROOT / FINGERPRINT).write_text(json.dumps(fingerprint, indent=2) + '\n')
    check_sources(fingerprint)
    if not manifest['models']:
        state('complete_no_memory_failures')
        raise SystemExit(0)
    run('validate_mixed_fsdp_v6.py')
    import torch
    free = [torch.cuda.mem_get_info(device)[0] for device in range(torch.cuda.device_count())]
    plans = []
    for model in manifest['models']:
        worlds = retry_worlds(groups[model['suite'], model['model']], free)
        plans.append(dict(suite=model['suite'], model=model['model'], planned_world_sizes=worlds))
        for index, world in enumerate(worlds):
            gpu_group = ','.join(str(device) for device in range(world))
            command = ['--gpus', gpu_group, '--fsdp', '--override-placement', '--backend-selection',
                       '--models', model['model'], '--suites', model['suite'], '--timeout', '5400']
            if index:
                command += ['--force', '--archive-label', f'world{world}_{time.time_ns()}']
            state('model_retry', model=model['model'], world_size=world)
            run('run_suite_mixed_multi_v6.py', *command)
            records = read_group(model)
            check_sources(fingerprint)
            if not any(is_terminal_gpu_memory_failure(record) for record in records):
                break
    (RESULTS / 'retry_plan.json').write_text(json.dumps(plans, indent=2) + '\n')
    run('analyze_mixed_multi_v6.py', '--results', RESULTS.name, '--manifest', MANIFEST)
    run('final_audit_v2.py', '--results', RESULTS.name, '--fingerprint', FINGERPRINT)
    audit = json.loads((RESULTS / 'final_audit.json').read_text())
    for key in ['source_drift', 'external_source_drift', 'optional_dependency_drift', 'input_metadata_mismatches',
                'unexpected_triton_matrix_templates', 'codegen_collection_errors', 'checkpoint_files']:
        if audit[key]:
            raise RuntimeError(f'Audit failed: {key}')
    run('analyze_mixed_multi_v6.py', '--results', RESULTS.name, '--manifest', MANIFEST)
    summary = json.loads((RESULTS / 'summary.json').read_text())
    if summary['observed_runs'] != summary['expected_runs'] or summary['timing_overlaps'] or summary['aten_policy_errors'] or summary['malformed_diagnostics']:
        raise RuntimeError('Matrix audit failed')
    run('merge_mixed_multi_v6.py', '--results', RESULTS.name, '--steady', 'training_results_mixed_multi_v6_no_rechecks',
        '--manifest', MANIFEST, '--support-sweep')
    (RESULTS / 'COMPLETE.json').write_text(json.dumps(summary, indent=2) + '\n')
    run('build_common_comparison_mixed_multi_v6.py')
    choices = Counter()
    with (RESULTS / 'all_kernel_decisions.jsonl').open() as source, (RESULTS / 'backend_selection_events.jsonl').open('w') as output:
        for line in source:
            event = json.loads(line)
            if event.get('category') in {'backend_selection', 'selection_skipped', 'backend_candidates'}:
                output.write(line)
                choices[event['category'], event.get('selected_backend', event.get('reason', 'eligible'))] += 1
    (RESULTS / 'backend_selection_summary.json').write_text(json.dumps([
        dict(category=key[0], outcome=key[1], count=count) for key, count in choices.items()], indent=2) + '\n')
    run('collect_fallback_worklist_v2.py', '--results', RESULTS.name)
    run('collect_kernel_inventory_v3.py', '--results', str(RESULTS), '--output', str(RESULTS / 'kernel_inventory'))
    check_sources(fingerprint)
    state('measurements_complete_manual_review_required', results=str(RESULTS), models=len(manifest['models']))
except Exception as error:
    state('needs_review', error=f'{type(error).__name__}: {error}')
    raise
