import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--wait-pids', type=int, nargs='+', required=True)
    args = parser.parse_args()
    for pid in args.wait_pids:
        while True:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
            time.sleep(5)
    models = set()
    reference_oom_models = set()
    for path in (ROOT / 'training_results/raw').glob('*/*.json'):
        record = json.loads(path.read_text())
        if record['status'] != 'error':
            continue
        error = record.get('error', '')
        validation_abort = record.get('phase') == 'compile_validation'
        reference_phase = record.get('phase') == 'eager_validation' or (record.get('phase') == 'compile_validation' and record.get('eager_reference_status') == 'out_of_memory')
        reference_oom = reference_phase and 'out of memory' in error.lower()
        if validation_abort or reference_oom:
            models.add(record['model'])
        if reference_oom:
            reference_oom_models.add(record['model'])
    print(json.dumps({'aborted_recheck_models': sorted(models)}), flush=True)
    if not models:
        return
    command = [sys.executable, str(ROOT / 'run_suite.py'), '--gpus', '0,1,3,6,7',
               '--force', '--archive-label', f'aborted_retry_{time.time_ns()}',
               '--models', *sorted(models),
               '--skip-eager-reference-models', *sorted(models)]
    subprocess.run(command, cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
