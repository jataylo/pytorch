from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase

from allocation_failures_v3 import is_gpu_allocation_failure, is_terminal_gpu_memory_failure


@instantiate_parametrized_tests
class TestAllocationFailures(TestCase):
    @parametrize('message', [
        'RuntimeError: CUDA error: HIPBLAS_STATUS_ALLOC_FAILED when calling hipblasCreate(handle)',
        'CUBLAS_STATUS_ALLOC_FAILED when calling cublasCreate(handle)',
        'hipblaslt_status_alloc_failed', 'CUBLASLT_STATUS_ALLOC_FAILED',
        'rocblas_status_memory_error', 'CUDNN_STATUS_ALLOC_FAILED', 'miopenStatusAllocFailed',
        'hipErrorOutOfMemory', 'cudaErrorMemoryAllocation', 'CUDA_ERROR_OUT_OF_MEMORY',
        'OutOfMemoryError: CUDA out of memory. Tried to allocate 2.11 GiB.',
        'HIP out of memory', 'CUDA error: out of memory', 'HIP error: out of memory',
    ])
    def test_precise_gpu_allocation_markers(self, message):
        self.assertTrue(is_gpu_allocation_failure(message))

    @parametrize('message', [
        'HIPLaunchOutOfResources', 'CUDA error: too many resources requested for launch',
        'hipErrorLaunchOutOfResources', 'CUBLAS_STATUS_EXECUTION_FAILED',
        'CUBLAS_STATUS_NOT_SUPPORTED', 'CUDA error: an illegal memory access was encountered',
        'DefaultCPUAllocator: cannot allocate memory', 'MemoryError: out of memory',
        'out of memory', 'NOT_HIPBLAS_STATUS_ALLOC_FAILED_SUFFIX',
        'HIPBLAS_STATUS_ALLOC_FAILEDNESS', 'Missing oclc_daz_opt_off.bc', '', None,
    ])
    def test_non_allocation_failures(self, message):
        self.assertFalse(is_gpu_allocation_failure(message))

    @parametrize('status', ['error', 'timeout', 'process_failed'])
    @parametrize('field', ['error', 'traceback'])
    def test_terminal_records(self, status, field):
        self.assertTrue(is_terminal_gpu_memory_failure({
            'status': status, field: 'HIPBLAS_STATUS_ALLOC_FAILED when calling hipblasCreate(handle)'}))

    @parametrize('status', ['started', 'ok', 'numerical_warning', 'validation_unavailable', None])
    def test_nonterminal_or_measured_records_do_not_trigger_retry(self, status):
        self.assertFalse(is_terminal_gpu_memory_failure({'status': status, 'error': 'CUDA out of memory'}))

    def test_capacity_skip_is_explicit(self):
        self.assertTrue(is_terminal_gpu_memory_failure({'status': 'capacity_skip', 'error': 'Verified capacity lower bound'}))
        self.assertFalse(is_terminal_gpu_memory_failure({'status': 'error', 'error': 'Verified capacity lower bound'}))

    def test_unrelated_terminal_outcome(self):
        self.assertFalse(is_terminal_gpu_memory_failure({'status': 'process_failed', 'error': 'HIPLaunchOutOfResources'}))


if __name__ == '__main__':
    run_tests()
