import os
from pathlib import Path
import subprocess
import sys
import time


root = Path(__file__).resolve().parent
postprocessor = int(sys.argv[1])
while not (root / 'training_results_v2/stable_report.html').exists():
    try:
        os.kill(postprocessor, 0)
    except ProcessLookupError:
        raise RuntimeError('Postprocessing exited before the complete merged inventory was ready') from None
    time.sleep(5)
for script in ['summarize_kernel_gaps_v2.py', 'collect_fallback_worklist_v2.py']:
    subprocess.run([sys.executable, str(root / script)], cwd=root, check=True)
print('Complete all-attempt fallback worklist ready for the next fix pass.', flush=True)
