import ast
import hashlib
import json
import math
from pathlib import Path


def verify_dino_preflight(results, model, fingerprint):
    results = Path(results)
    records = []
    for path in results.glob('raw/*/*.json'):
        record = json.loads(path.read_text())
        if (record['suite'], record['model']) == (model['suite'], model['model']):
            records.append((path, record))
    modes = {(record['backend'], record['autotune']) for _, record in records}
    if len(records) != 4 or modes != {(backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]}:
        raise RuntimeError('DINO preflight requires all four actual model records')
    shared_keys = ['physical_gpu', 'world_size', 'batch_size', 'model_config_sha256', 'inputs', 'dtype',
                   'parameters', 'optimizer', 'checkpoint', 'launch_environment_overrides', 'timing_warmup']
    scheduler = Path(fingerprint['source_root']) / 'torch/_inductor/scheduler.py'
    scheduler_hash = fingerprint['sources']['torch/_inductor/scheduler.py']
    if hashlib.sha256(scheduler.read_bytes()).hexdigest() != scheduler_hash:
        raise RuntimeError('DINO preflight scheduler source changed')
    evidence = []
    for path, record in records:
        if any(record.get(key) != records[0][1].get(key) for key in shared_keys):
            raise RuntimeError('DINO preflight four-mode protocol mismatch')
        if record['status'] != 'ok' or record.get('eager_reference_status') != 'available' or record.get('validation_warnings'):
            raise RuntimeError('DINO preflight did not pass eager numerical validation')
        if record.get('source_fingerprint', {}).get('sha256') != fingerprint['sha256']:
            raise RuntimeError('DINO preflight run source fingerprint mismatch')
        if record.get('loaded_scheduler_source') != {str(scheduler): scheduler_hash}:
            raise RuntimeError('DINO preflight loaded the wrong scheduler')
        if (record.get('timing_recompiles') != 0 or record.get('checkpoint') is not False
            or not record.get('training_parameters_with_gradients') or not math.isfinite(record.get('final_training_loss', float('nan')))):
            raise RuntimeError('DINO preflight training integrity failure')
        if record.get('launch_environment_overrides', {}).get('TORCHINDUCTOR_MIX_ORDER_REDUCTION') == '0':
            raise RuntimeError('DINO preflight must exercise mixed-order fusion')
        config = record.get('inductor_config', {})
        if (record.get('backend_selection') is not False or config.get('flydsl.simd_autotune_backend') is not False
            or config.get('max_autotune') is not False or config.get('max_autotune_gemm') is not False
            or config.get('max_autotune_gemm_backends') != 'ATEN' or config.get('max_autotune_conv_backends') != 'ATEN'
            or config.get('conv_1x1_as_mm') is not False
            or config.get('max_autotune_pointwise') != bool(record['autotune'])
            or config.get('triton.autotune_pointwise') != bool(record['autotune'])):
            raise RuntimeError('DINO preflight benchmark policy mismatch')
        audit = record.get('codegen_audit', {})
        if audit.get('graphs', 0) <= 0 or record.get('dynamo_stats', {}).get('stats', {}).get('unique_graphs', 0) <= 0:
            raise RuntimeError('DINO preflight did not compile the model')
        source_evidence = []
        if record['backend'] == 'flydsl':
            counters = record.get('flydsl_counters', {})
            if counters.get('flydsl_kernels', 0) <= 0 or counters.get('mix_order', 0) <= 0 or counters.get('triton_kernels', 0):
                raise RuntimeError('DINO preflight did not exercise FlyDSL mixed-order kernels')
            if bool(counters.get('autotuned_kernels', 0)) != bool(record['autotune']):
                raise RuntimeError('DINO preflight FlyDSL launch tuning was not exercised as requested')
        else:
            for graph in json.loads(Path(audit['file']).read_text())['graphs']:
                wrapper = Path(graph['wrapper'])
                for node in ast.walk(ast.parse(wrapper.read_text())):
                    if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute) or node.func.attr != 'triton':
                        continue
                    for argument in node.args:
                        if isinstance(argument, ast.Constant) and isinstance(argument.value, str) and 'RSPLIT_SIZE' in argument.value:
                            kernel = ast.parse(argument.value)
                            if any(isinstance(fn, ast.FunctionDef) and any(arg.arg == 'RSPLIT_SIZE' for arg in fn.args.args)
                                   for fn in ast.walk(kernel)):
                                source_evidence.append({'path': str(wrapper), 'sha256': hashlib.sha256(wrapper.read_bytes()).hexdigest()})
            if not source_evidence:
                raise RuntimeError('DINO preflight did not generate native mixed-order kernels')
        evidence.append({'backend': record['backend'], 'autotune': record['autotune'],
                         'record': str(path), 'record_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                         'native_mixed_definition_sources': source_evidence,
                         'flydsl_counters': record.get('flydsl_counters', {})})
    return {'status': 'passed', 'source_fingerprint': fingerprint['sha256'], 'model': model['model'],
            'validation': 'Full-model eager loss and sampled-gradient checks, compiled training integrity, and generated mixed-order kernel evidence; source counts are not dynamic launch counts.',
            'records': evidence}
