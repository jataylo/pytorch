import ast
from collections import defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path


root = Path(__file__).resolve().parent
if not (root / 'training_results_v2_steady/COMPLETE.json').exists():
    raise RuntimeError('Finish the original sweep, memory retries and steady rechecks first')
provenance = root / 'training_results_v2/final_timing_sources.csv'
if not provenance.exists():
    raise RuntimeError('Merge and review the original results before preparing the support comparison')
references = defaultdict(list)
with provenance.open() as source:
    for row in csv.DictReader(source):
        record = json.loads(Path(row['source_json']).read_text())
        references[record['suite'], record['model']].append(record)
manifest = json.loads((root / 'model_manifest_v2.json').read_text())
for model in manifest['models']:
    records = references[model['suite'], model['model']]
    if len(records) != 4:
        raise RuntimeError(f'Missing reference configurations for {model["model"]}')
    placements = {(str(record['physical_gpu']), record['world_size']) for record in records}
    if len(placements) != 1:
        raise RuntimeError(f'Inconsistent reference placement for {model["model"]}')
    gpu, world = placements.pop()
    times = [time for record in records for time in record.get('repeat_ms', []) if time > 0]
    warmup = min(2000, max(30, math.ceil(1500 / min(times)))) if times else 100
    overrides = dict(records[0].get('launch_environment_overrides', {}))
    if model['model'] == 'levit_128':
        overrides['BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE'] = '1'
    if model['model'] == 'vit_base_patch14_dinov2.lvd142m':
        overrides.pop('TORCHINDUCTOR_MIX_ORDER_REDUCTION', None)
    if any('mm_token_type_ids' in record.get('error', '') and 'missing' in record.get('error', '') for record in records):
        overrides['BENCHMARK_ADD_MM_TOKEN_TYPES'] = '1'
    if model['model'] == 'moonshotai/Kimi-K3':
        overrides.update(BENCHMARK_EXTRA_MODEL_DEPS='1', HF_HUB_OFFLINE='1',
                         BENCHMARK_OFFICIAL_MODEL_REVISION='f831ab66814297da540d832a5235f8e904f29d06')
    if model['model'] == 'Qwen/Qwen-Image':
        overrides['BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS'] = '1'
        if {(record['backend'], record['autotune']) for record in records} == {
            (backend, tune) for backend in ['triton', 'flydsl'] for tune in [0, 1]
        } and all(record['status'] == 'error' and record.get('phase') == 'fsdp_eager_initialization'
                  and record.get('world_size') == 8 and 'out of memory' in (record.get('error') or '').lower()
                  for record in records):
            overrides['BENCHMARK_FSDP_STATE_INIT_ONLY'] = '1'
    if model['model'] in {'deepseek-ai/DeepSeek-V4-Flash-0731', 'deepseek-ai/DeepSeek-V4-Flash', 'Qwen/Qwen3.8-Flash-Next'}:
        overrides['BENCHMARK_VERIFY_FSDP_MEMORY_BOUND'] = '1'
    model.update(physical_gpu=gpu, world_size=world, steady_warmup_steps=warmup,
                 launch_environment_overrides=overrides)
manifest['protocol'] = 'Full training matrix with validated scheduler and FlyDSL support fixes; common longer warmup, original final GPU placements and validated state-only FSDP initialization where eager training setup exceeded memory'
manifest['support_source_root'] = str(root / 'fallback_fixes')
(root / 'model_manifest_support_v3.json').write_text(json.dumps(manifest, indent=2) + '\n')

tree = ast.parse((root / 'prepare_steady_v2.py').read_text())
replacements = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign) and
                    any(isinstance(target, ast.Name) and target.id == 'replacements' for target in node.targets))
worker = (root / 'train_worker_v2.py').read_text()
for before, after in replacements.items():
    if worker.count(before) != 1:
        raise RuntimeError(f'Unexpected worker while replacing {before!r}')
    worker = worker.replace(before, after.replace('source_fingerprint_v2_steady.json', 'source_fingerprint_support_v3.json')
                            .replace('autotune_v2_aten_steady_recheck', 'support_v3_aten_training'))
anchor = "        register_grouped_mm_autocast()"
addition = """        result['source_overlay'] = os.environ.get('TORCHINDUCTOR_FLYDSL_BASELINE_DIR')
        from torch._inductor import scheduler
        expected_scheduler = Path(__file__).resolve().parent / 'fallback_fixes/torch/_inductor/scheduler.py'
        if Path(scheduler.__file__).resolve() != expected_scheduler.resolve():
            raise RuntimeError(f'Wrong scheduler source overlay: {scheduler.__file__}')
        result['loaded_scheduler_source'] = {str(expected_scheduler): hashlib.sha256(expected_scheduler.read_bytes()).hexdigest()}
        if args.backend == 'flydsl':
            from torch._inductor.codegen.flydsl import flydsl_simd, flydsl_simd_runtime
            expected_overlay = Path(__file__).resolve().parent / 'fallback_fixes/torch/_inductor/codegen/flydsl'
            loaded = [Path(module.__file__).resolve() for module in [flydsl_simd, flydsl_simd_runtime]]
            if any(path.parent != expected_overlay.resolve() for path in loaded):
                raise RuntimeError(f'Wrong FlyDSL source overlay: {loaded}')
            result['loaded_flydsl_sources'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in loaded}
"""
if worker.count(anchor) != 1:
    raise RuntimeError('Missing overlay verification insertion point')
worker = worker.replace(anchor, addition + anchor)
compile(worker, 'train_worker_support_v3.py', 'exec')
(root / 'train_worker_support_v3.py').write_text(worker)

runner = (root / 'run_suite_v2.py').read_text()
runner = runner.replace("'train_worker_v2.py'", "'train_worker_support_v3.py'")
runner = runner.replace("default='training_results_v2'", "default='training_results_support_v3'")
runner = runner.replace("default='model_manifest_v2.json'", "default='model_manifest_support_v3.json'")
runner = runner.replace("PYTHONPATH=str(ROOT / 'model_deps'),",
                        "PYTHONPATH=os.pathsep.join([str(ROOT / 'support_startup_v3'), str(ROOT / 'model_deps')]),\n"
                        "                BENCHMARK_SUPPORT_SOURCE_ROOT=str(ROOT / 'fallback_fixes'),")
runner = runner.replace("'TORCHINDUCTOR_FLYDSL_SIMD_STAGES']", "'TORCHINDUCTOR_FLYDSL_SIMD_STAGES', 'TORCHINDUCTOR_MIX_ORDER_REDUCTION', 'BENCHMARK_CLEAR_ATTENTION_BIAS_CACHE', 'BENCHMARK_ADD_MM_TOKEN_TYPES', 'BENCHMARK_PLACEMENT_OVERRIDE', 'BENCHMARK_EXTRA_MODEL_DEPS', 'BENCHMARK_OFFICIAL_MODEL_REVISION', 'BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS', 'BENCHMARK_VERIFY_FSDP_MEMORY_BOUND', 'BENCHMARK_FSDP_STATE_INIT_ONLY', 'HF_HUB_OFFLINE']")
runner = runner.replace("    parser.add_argument('--fsdp', action='store_true')",
                        "    parser.add_argument('--fsdp', action='store_true')\n    parser.add_argument('--override-placement', action='store_true')")
runner = runner.replace("    models = manifest['models']",
                        "    models = [model for model in manifest['models'] if args.override_placement or model['physical_gpu'] == args.gpus]")
runner = runner.replace('            env.update(\n',
                        "            env.update(model.get('launch_environment_overrides', {}))\n            env.update(\n"
                        "                TORCHINDUCTOR_FLYDSL_BASELINE_DIR=str(ROOT / 'fallback_fixes/torch/_inductor/codegen/flydsl'),\n"
                        "                BENCHMARK_LAUNCH_OVERRIDES=json.dumps(model.get('launch_environment_overrides', {})),\n"
                        "                BENCHMARK_PLACEMENT_OVERRIDE=str(int(args.override_placement)),\n"
                        "                BENCHMARK_STEADY_WARMUP_STEPS=str(model['steady_warmup_steps']),\n")
runner = runner.replace("\n            cmd = [sys.executable,", "\n            if model.get('launch_environment_overrides', {}).get('BENCHMARK_EXTRA_MODEL_DEPS') == '1':\n                env['PYTHONPATH'] = os.pathsep.join([str(ROOT / 'support_startup_v3'), str(ROOT / 'optional_model_deps_v3'), str(ROOT / 'model_deps')])\n            cmd = [sys.executable,")
compile(runner, 'run_suite_support_v3.py', 'exec')
(root / 'run_suite_support_v3.py').write_text(runner)
controller = (root / 'run_steady_v2.py').read_text().replace('training_results_v2_steady', 'training_results_support_v3')
controller = controller.replace('model_manifest_v2_steady.json', 'model_manifest_support_v3.json')
controller = controller.replace('run_suite_v2_steady.py', 'run_suite_support_v3.py')
controller = controller.replace('Steady-state', 'Support comparison').replace('Steady-state rechecks complete.', 'Support comparison complete.')
memory_predicate = "record['status'] == 'capacity_skip' or 'out of memory' in record.get('error', '').lower()"
if controller.count(memory_predicate) != 2:
    raise RuntimeError('Unexpected memory retry predicates in the controller template')
controller = 'from allocation_failures_v3 import is_terminal_gpu_memory_failure\n' + controller
controller = controller.replace(memory_predicate, 'is_terminal_gpu_memory_failure(record)')
compile(controller, 'run_support_v3.py', 'exec')
(root / 'run_support_v3.py').write_text(controller)

fingerprint = json.loads((root / 'source_fingerprint_v2.json').read_text())
fingerprint['parent_sha256'] = fingerprint.pop('sha256')
fingerprint['protocol'] = manifest['protocol']
fingerprint['source_root'] = str(root / 'fallback_fixes')
overlaid = {'torch/_inductor/codegen/flydsl/flydsl_simd.py',
            'torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py',
            'torch/_inductor/scheduler.py'}
for name in fingerprint['sources']:
    if name.startswith('torch/') and name not in overlaid:
        if (root / 'pytorch' / name).read_bytes() != (root / 'fallback_fixes' / name).read_bytes():
            raise RuntimeError(f'Additional source overlay required before benchmarking {name}')
extra_tests = ['test/inductor/test_flydsl_simd.py', 'test/inductor/test_flydsl_layouts.py', 'test/inductor/test_flydsl_mix_layout.py',
               'test/inductor/test_flydsl_tuple_softmax.py', 'test/inductor/test_flydsl_scheduler_fusion.py',
               'test/inductor/test_flydsl_rng.py', 'test/inductor/test_flydsl_ocml.py',
               'test/inductor/test_flydsl_ocml_cpu.py', 'test/inductor/test_flydsl_subword_tail.py']
for name in [*fingerprint['sources'], 'torch/_inductor/scheduler.py', *extra_tests]:
    fingerprint['sources'][name] = hashlib.sha256((root / 'fallback_fixes' / name).read_bytes()).hexdigest()
for name in ['train_worker_support_v3.py', 'run_suite_support_v3.py', 'run_support_v3.py',
             'model_manifest_support_v3.json', 'prepare_support_suite_v3.py', 'fallback_fixes/agent_space/run_overlay.py',
             'model_deps/sitecustomize.py', 'support_startup_v3/sitecustomize.py',
             'multimodal_inputs_v2.py', 'optional_model_deps_v3_manifest.json',
             'diffusion_meta_constants_v3.py', 'test_diffusion_meta_constants_v3.py',
             'fsdp_memory_bound_v3.py', 'test_fsdp_memory_bound_v3.py',
             'fsdp_large_embedding_bound_v3.py', 'test_fsdp_large_embedding_bound_v3.py',
             'fsdp_state_init_v3.py', 'test_fsdp_state_init_v3.py', 'probe_fsdp_state_init_v3.py',
             'test_prepare_fsdp_state_recovery_v3.py',
             'test_prepare_support_qwen_image_v3.py',
             'merge_steady_v2.py', 'test_merge_raw_failures_v3.py', 'summarize_kernel_gaps_v2.py', 'collect_fallback_worklist_v2.py',
             'allocation_failures_v3.py', 'test_allocation_failures_v3.py', 'test_tuning_coverage_report_v3.py',
             'verify_fallback_validation_v3.py', 'test_verify_fallback_causes_v3.py', 'validate_fallbacks_reserved_v2.py',
             'fallback_gpu_plan_v3_tail.json', 'fallback_fixes/agent_space/gpu_validation_freeze.json',
             'collect_kernel_inventory_v3.py', 'test_collect_kernel_inventory_v3.py',
             'finish_support_benchmarks_v3.py', 'test_support_failure_review_gate_v3.py',
             'test_reuse_fallback_validation_v3.py', 'baseline_fallback_review_v3.json',
             'guard_fatal_gpu_dumps_v3.py']:
    fingerprint['harness'][name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
fingerprint['sha256'] = hashlib.sha256(json.dumps(fingerprint, sort_keys=True).encode()).hexdigest()
(root / 'source_fingerprint_support_v3.json').write_text(json.dumps(fingerprint, indent=2) + '\n')
print(json.dumps({'models': len(manifest['models']), 'configurations': len(manifest['models']) * 4,
                  'fingerprint': fingerprint['sha256']}, indent=2))
