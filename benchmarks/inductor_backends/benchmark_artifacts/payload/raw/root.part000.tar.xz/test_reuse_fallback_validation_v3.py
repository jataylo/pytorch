import ast
import json
from pathlib import Path
import tempfile

from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


source = Path(__file__).with_name('finish_support_benchmarks_v3.py')
tree = ast.parse(source.read_text())
function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'reusable_validation')
namespace = {'json': json}
exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), 'exec'), namespace)


@instantiate_parametrized_tests
class TestValidationReuse(TestCase):
    @parametrize('case', ['matching', 'freeze_changed', 'command_changed', 'unfinished', 'source_drift',
                         'missing_verified', 'missing_status', 'malformed_status', 'invalid_state'])
    def test_reuse_requires_complete_matching_proof(self, case):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            freeze = {'files': {'kernel.py': 'hash'}}
            plan = {'commands': [{'label': 'math', 'argv': ['python', 'tests.py']}]}
            status = {'finished': 1, 'state': 'test_failure', 'source_drift': [],
                      'freeze_manifest': json.loads(json.dumps(freeze)), 'commands': json.loads(json.dumps(plan['commands']))}
            if case == 'freeze_changed':
                freeze['files']['kernel.py'] = 'changed'
            elif case == 'command_changed':
                plan['commands'][0]['argv'] = ['python', 'different_tests.py']
            elif case == 'unfinished':
                status['finished'] = None
            elif case == 'source_drift':
                status['source_drift'] = ['kernel.py']
            elif case == 'invalid_state':
                status['state'] = 'manager_error'
            freeze_path, plan_path = root / 'freeze.json', root / 'plan.json'
            freeze_path.write_text(json.dumps(freeze))
            plan_path.write_text(json.dumps(plan))
            if case != 'missing_verified':
                (root / 'VERIFIED.json').write_text('{}')
            if case != 'missing_status':
                (root / 'status.json').write_text('invalid' if case == 'malformed_status' else json.dumps(status))
            self.assertEqual(namespace['reusable_validation'](root, freeze_path, plan_path), case == 'matching')


if __name__ == '__main__':
    run_tests()
