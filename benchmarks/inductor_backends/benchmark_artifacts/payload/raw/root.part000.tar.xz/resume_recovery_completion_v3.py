import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
journal = root / 'resume_recovery_completion_v3.jsonl'
archive_label = 'interrupted_world8_resume_' + str(time.time_ns())
fingerprint = json.loads((root / 'source_fingerprint_v2_steady.json').read_text())


def record(stage, **details):
    with journal.open('a') as stream:
        stream.write(json.dumps({'time': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                 'stage': stage, **details}) + '\n')


def verify_sources():
    for group, base in [('sources', Path(fingerprint.get('source_root', root / 'pytorch'))), ('harness', root)]:
        for name, expected in fingerprint[group].items():
            if hashlib.sha256((base / name).read_bytes()).hexdigest() != expected:
                raise RuntimeError('Frozen recovery source drift: ' + name)


def run(script, *arguments, no_site=False):
    verify_sources()
    command = [sys.executable, *(['-S'] if no_site else []), str(root / script), *arguments]
    record('command_started', argv=command, script_sha256=hashlib.sha256((root / script).read_bytes()).hexdigest())
    subprocess.run(command, cwd=root, check=True)
    verify_sources()
    record('command_completed', argv=command)


verify_sources()
if (root / 'training_results_v2_steady/COMPLETE.json').exists():
    raise RuntimeError('Recovery already completed; do not replay it')
record('resuming_interrupted_final_group', source_fingerprint=fingerprint['sha256'], archive_label=archive_label,
       explanation='No controller or benchmark worker remains; last Qwen-Image group mixed world8/world4 after controller exit. Preserve all attempts with normal frozen-runner archives and rerun all four modes at world8.')
run('run_suite_v2_steady.py', '--models', 'Qwen/Qwen-Image', '--suites', 'priority', '--gpus', '0,1,2,3,4,5,6,7',
    '--fsdp', '--override-placement', '--force', '--archive-label', archive_label, '--timeout', '5400')
run('analyze_v2.py', '--results', 'training_results_v2_steady', '--manifest', 'model_manifest_v2_steady.json')
manifest = json.loads((root / 'model_manifest_v2_steady.json').read_text())
expected = {(model['suite'], model['model'], backend, tune) for model in manifest['models']
            for backend in ['triton', 'flydsl'] for tune in [0, 1]}
records = [json.loads(path.read_text()) for path in (root / 'training_results_v2_steady/raw').glob('*/*.json')]
actual = {(item['suite'], item['model'], item['backend'], item['autotune']) for item in records}
if actual != expected or len(records) != len(expected) or any(item['status'] == 'started' for item in records):
    raise RuntimeError('Recovery terminal configuration coverage is incomplete')
for model in manifest['models']:
    group = [item for item in records if (item['suite'], item['model']) == (model['suite'], model['model'])]
    if len({(str(item['physical_gpu']), item['world_size']) for item in group}) != 1:
        raise RuntimeError('Recovery variants have inconsistent placements: ' + model['model'])
summary = json.loads((root / 'training_results_v2_steady/summary.json').read_text())
if summary['expected_runs'] != summary['observed_runs'] or any(summary[name] for name in
        ['timing_overlaps', 'aten_policy_errors', 'malformed_diagnostics']):
    raise RuntimeError('Recovery matrix audit failed')
(root / 'training_results_v2_steady/COMPLETE.json').write_text(json.dumps(summary, indent=2) + '\n')
record('recovery_complete', configurations=len(records), summary=summary['statuses'])
run('final_audit_v2.py', '--results', 'training_results_v2_steady', '--fingerprint', 'source_fingerprint_v2_steady.json')
run('merge_steady_v2.py')
run('summarize_kernel_gaps_v2.py')
run('collect_fallback_worklist_v2.py')
run('collect_kernel_inventory_v3.py', '--results', str(root / 'training_results_v2'), '--additional-results',
    str(root / 'training_results_v2_steady'), '--output', str(root / 'training_results_v2/kernel_inventory'), no_site=True)
record('full_baseline_union_ready_for_manual_review')
