from collections import Counter
import json
import os
from pathlib import Path
import sys
import time


root = Path(__file__).resolve().parent
controller = int(sys.argv[1])
results = sys.argv[2] if len(sys.argv) > 2 else 'training_results_v2'
log_name = sys.argv[3] if len(sys.argv) > 3 else 'benchmark_all_v2.log'
position = 0
first = True
while True:
    path = root / log_name
    with path.open() as log:
        log.seek(position)
        lines = log.read().splitlines()
        position = log.tell()
    for line in lines[-5:] if first else lines:
        print(line, flush=True)
    first = False
    records = [json.loads(path.read_text()) for path in (root / results / 'raw').glob('*/*.json')]
    print(json.dumps({'observed': len(records), 'statuses': dict(Counter(record['status'] for record in records)),
                      'active': [(record['model'], record['backend'], record['autotune'], record.get('phase'))
                                 for record in records if record['status'] == 'started']}), flush=True)
    try:
        os.kill(controller, 0)
    except ProcessLookupError:
        print('Controller exited. Check COMPLETE.json and run final_audit_v2.py.', flush=True)
        break
    time.sleep(45)
