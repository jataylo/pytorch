import argparse
import hashlib
import json
from pathlib import Path
import re


root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--results', required=True)
args = parser.parse_args()
destination = root / args.results
(destination / 'VERIFIED.json').unlink(missing_ok=True)
status = json.loads((destination / 'status.json').read_text())
if not status.get('finished') or status.get('source_drift') or status['state'] not in {'passed', 'test_failure'}:
    raise RuntimeError('Validation window did not close cleanly without source drift')
freeze = status['freeze_manifest']
worktree = root / 'fallback_fixes_v4'
expected_sources = {str(worktree / name): digest for name, digest in freeze['files'].items()}
expected_sources[str(worktree / 'agent_space/run_overlay.py')] = freeze['overlay_sha256']
expected_sources.update({str(root / name): digest for name, digest in freeze.get('harness_files', {}).items()})
if status['source_hashes'] != expected_sources:
    raise RuntimeError('The validation source inventory differs from its frozen manifest')
counts = {
    'symbolic_chunk_numeric': 4,
    'global_tail_numeric': 8,
    'scheduler_recursive_numeric': 8,
    'subword_tail_numeric': 5,
    'ocml_math_numeric': 4,
    'rng_geometry_numeric': 8,
    'scheduler_dino_xcit_numeric': 4,
    'tuple_softmax_numeric': 6,
    'multi_axis_layout_numeric': 9,
    'mix_order_numeric': 2,
    'autotune17_regression': 17,
    'simd128_regression': 128,
}
expected_labels = {*counts, 'positive_gpu_guards'}
commands = status['commands']
if len(commands) != len(expected_labels) or {item['label'] for item in commands} != expected_labels:
    raise RuntimeError('Missing or duplicate validation commands')
baseline_path = root / 'test_flydsl_genuine_original.log'
baseline_errors = set(re.findall(r'^(?:ERROR|FAIL): (.+)$', baseline_path.read_text(), re.MULTILINE))
if len(baseline_errors) != 8:
    raise RuntimeError('Original baseline error inventory is incomplete')


def error_excerpts(log):
    result = {}
    for section in re.split(r'(?m)^(?:ERROR|FAIL): ', log)[1:]:
        name, _, body = section.partition('\n')
        causes = [line for line in body.splitlines()
                  if re.match(r'^(?:[\w.]+(?:Error|Exception)|error):', line)]
        result[name] = [line[:512] for line in causes[:5]]
    return result


def check_broad_failures(log, returncode, allowed_causes):
    failures = set(re.findall(r'^(?:ERROR|FAIL): (.+)$', log, re.MULTILINE))
    if returncode != (1 if failures else 0) or re.search(r'^FAIL:', log, re.MULTILINE):
        raise RuntimeError('Broad-suite execution or numerical failure')
    causes = error_excerpts(log)
    if not failures <= allowed_causes.keys() or any(causes[name] != allowed_causes[name] for name in failures):
        raise RuntimeError(f'Unexpected broad-suite errors or changed causes: {sorted(failures)}')


baseline_causes = error_excerpts(baseline_path.read_text())
allowed_causes = {
    name: causes for name, causes in baseline_causes.items()
    if (name.startswith('test_bitcast ') or name.startswith('test_fp8_casts_'))
    and len(causes) == 1
    and re.fullmatch(
        r'torch\._inductor\.exc\.InductorError: FlyDSLUnsupported: FlyDSL SIMD kernel refused '
        r'\(dtype torch\.float8_e(?:4m3|5m2)fnuz on gfx950\)', causes[0])
}
if len(allowed_causes) != 5:
    raise RuntimeError('Expected five explicitly identified gfx950 FNUZ baseline refusals')


reviewed = []
for command in commands:
    label = command['label']
    log = Path(command['log']).read_text()
    failures = set(re.findall(r'^(?:ERROR|FAIL): (.+)$', log, re.MULTILINE))
    if label in counts:
        observed = re.findall(r'^Ran (\d+) tests? in ', log, re.MULTILINE)
        if not observed or int(observed[-1]) != counts[label]:
            raise RuntimeError(f'Unexpected executed test count for {label}: {observed}')
        if re.search(r'^(?:OK|FAILED).*skipped=', log, re.MULTILINE):
            raise RuntimeError(f'GPU validation skipped tests: {label}')
    if label == 'simd128_regression':
        check_broad_failures(log, command['returncode'], allowed_causes)
    elif command['returncode'] or failures:
        raise RuntimeError(f'New focused regression: {label}')
    reviewed.append({'label': label, 'tests': counts.get(label), 'baseline_errors': sorted(failures),
                     'error_excerpts': error_excerpts(log)})
for name, digest in status['source_hashes'].items():
    if hashlib.sha256(Path(name).read_bytes()).hexdigest() != digest:
        raise RuntimeError(f'Validated source changed after the reservation: {name}')
result = {
    'status': 'focused_checks_passed_without_new_broad_suite_errors',
    'physical_gpu': status['physical_gpu'],
    'validation_started': status['acquired'],
    'validation_finished': status['finished'],
    'commands': reviewed,
    'baseline_log': str(baseline_path),
    'baseline_log_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
    'original_baseline_error_excerpts': error_excerpts(baseline_path.read_text()),
    'permitted_remaining_error_causes': allowed_causes,
    'remaining_baseline_errors': next(item['baseline_errors'] for item in reviewed
                                      if item['label'] == 'simd128_regression'),
    'resolved_baseline_errors': sorted(baseline_errors - set(next(item['baseline_errors'] for item in reviewed
                                                               if item['label'] == 'simd128_regression'))),
    'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'freeze_manifest': status['freeze_manifest'],
}
(destination / 'VERIFIED.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
