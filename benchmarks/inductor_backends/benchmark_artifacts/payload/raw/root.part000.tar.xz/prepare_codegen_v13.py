from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parent
branch=root/'pytorch_codegen_v13';frozen=root/'fallback_fixes_v4'
manifest=json.loads((root/'source_fingerprint_support_v4.json').read_text())
for relative,expected in manifest['sources'].items():
    source=frozen/relative
    if hashlib.sha256(source.read_bytes()).hexdigest()!=expected:raise RuntimeError(relative)
    target=branch/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
readme=root/'triton_hillclimb_v12/README.txt';readme.write_text(readme.read_text().replace('--limit65','--limit 65'))
print('Copied',len(manifest['sources']),'validated FlyDSL source/test files into new worktree')
