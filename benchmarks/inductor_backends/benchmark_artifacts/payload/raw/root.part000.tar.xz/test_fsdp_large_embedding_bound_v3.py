import os
from pathlib import Path
import resource
import sys
resource.setrlimit(resource.RLIMIT_AS, (64 << 30, 64 << 30))
os.environ.update(CUDA_VISIBLE_DEVICES='', HIP_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
import site
site.main()

from unittest.mock import patch

import torch
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase

from fsdp_large_embedding_bound_v3 import EMBEDDING_PATH, fsdp_large_embedding_memory_bound


class TestLargeEmbeddingBound(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        root = Path(__file__).resolve().parent
        os.environ['HF_HOME'] = str(root / 'hf_config_cache')
        sys.path.insert(0, '/dockerx/Triton_Conv_Development/scripts')
        from common import load_model_meta, resolve_dtype_spec
        with patch.object(torch.cuda, '_lazy_init', side_effect=RuntimeError('CPU-only memory proof')):
            cls.model = load_model_meta('Qwen/Qwen3.8-Flash-Next', resolve_dtype_spec('amp_bf16')).to(torch.float32)
        cls.embedding = cls.model.get_submodule(EMBEDDING_PATH)

    @parametrize('world', [2, 4, 8])
    def test_actual_full_meta_bound(self, world):
        result = fsdp_large_embedding_memory_bound(self.model, world, free_bytes_per_rank=[309220868096] * world)
        n = 320001536 * 160
        self.assertEqual(result['unique_parameter_numel'], 177392830576)
        self.assertEqual(result['per_rank_lower_bound_bytes'], 6 * n + 4 * (n // world))
        self.assertTrue(result['insufficient_capacity'])
        self.assertEqual(result['embedding_shape'], [320001536, 160])
        self.assertFalse(torch.cuda.is_initialized())
        self.assertTrue(all(value.is_meta for value in self.model.parameters()))

    @parametrize('protocol', [
        {'master_dtype': torch.bfloat16}, {'compute_dtype': torch.float32}, {'reduce_dtype': torch.bfloat16},
        {'cpu_offload': True}, {'keep_low_precision_grads': True}, {'use_orig_params': False},
        {'sharding_strategy': 'SHARD_GRAD_OP'},
    ])
    def test_unknown_protocol(self, protocol):
        self.assertIsNone(fsdp_large_embedding_memory_bound(self.model, 8, **protocol))

    @parametrize('world', [1, 0, -1, True, 2.0])
    def test_invalid_world(self, world):
        self.assertIsNone(fsdp_large_embedding_memory_bound(self.model, world))

    def test_unknown_class(self):
        self.assertIsNone(fsdp_large_embedding_memory_bound(torch.nn.Linear(2, 2), 8))

    def test_source_mismatch(self):
        with patch.dict('fsdp_large_embedding_bound_v3.VERIFIED_SOURCES', {'torch.nn.modules.sparse': 'unknown'}):
            self.assertIsNone(fsdp_large_embedding_memory_bound(self.model, 8))

    def test_alias_rejected(self):
        with patch.dict(self.model._parameters, {'extra_alias': self.embedding.weight}):
            self.assertIsNone(fsdp_large_embedding_memory_bound(self.model, 8))

    def test_changed_total_rejected(self):
        with patch.dict(self.model._parameters, {'extra_unique': torch.nn.Parameter(torch.empty(1, device='meta'))}):
            self.assertIsNone(fsdp_large_embedding_memory_bound(self.model, 8))

    @parametrize('change', ['skip_layer', 'disable_ple'])
    def test_same_parameter_count_config_bypass_rejected(self, change):
        config = self.model.config.text_config
        field, value = ('num_hidden_layers', 1) if change == 'skip_layer' else ('ple_layer_ids', [])
        count = sum(parameter.numel() for parameter in self.model.parameters())
        with patch.object(config, field, value):
            self.assertEqual(sum(parameter.numel() for parameter in self.model.parameters()), count)
            self.assertIsNone(fsdp_large_embedding_memory_bound(self.model, 8))

    def test_divergent_runtime_config_rejected(self):
        import copy

        language_model = self.model.get_submodule('model.language_model')
        detached = copy.deepcopy(language_model.config)
        detached.num_hidden_layers = 1
        with patch.object(language_model, 'config', detached):
            self.assertIsNone(fsdp_large_embedding_memory_bound(self.model, 8))

    @parametrize('change', ['dtype', 'shape', 'stride', 'frozen', 'sparse'])
    def test_embedding_constraints(self, change):
        if change == 'sparse':
            with patch.object(self.embedding, 'sparse', True):
                self.assertIsNone(fsdp_large_embedding_memory_bound(self.model, 8))
            return
        original = self.embedding.weight
        if change == 'dtype':
            changed = original.to(torch.bfloat16)
        elif change == 'shape':
            changed = torch.empty((original.numel(),), device='meta')
        elif change == 'stride':
            changed = torch.empty_strided(original.shape, (1, original.shape[0]), device='meta')
        else:
            changed = original.detach()
        changed = torch.nn.Parameter(changed, requires_grad=change != 'frozen')
        with patch.dict(self.embedding._parameters, {'weight': changed}):
            self.assertIsNone(fsdp_large_embedding_memory_bound(self.model, 8))

    @parametrize('free', [[], [1] * 7, [-1] * 8, [1.0] * 8])
    def test_invalid_capacities(self, free):
        with self.assertRaisesRegex(ValueError, 'one nonnegative integer per rank'):
            fsdp_large_embedding_memory_bound(self.model, 8, free_bytes_per_rank=free)

    def test_dense_bf16_gradient_and_cast_lifetime(self):
        embedding = torch.nn.Embedding(17, 3, dtype=torch.bfloat16)
        embedding(torch.tensor([1, 3])).sum().backward()
        old = embedding.weight.grad
        self.assertEqual(old.dtype, torch.bfloat16)
        self.assertEqual(old.shape, embedding.weight.shape)
        self.assertFalse(old.is_sparse)
        self.assertEqual(old[0], torch.zeros_like(old[0]))
        new = old.to(torch.float32)
        self.assertNotEqual(old.untyped_storage().data_ptr(), new.untyped_storage().data_ptr())
        self.assertEqual(old.untyped_storage().nbytes() + new.untyped_storage().nbytes(), 6 * old.numel())

    def test_own_master_floor_under_handle_refinement(self):
        n = self.embedding.weight.numel()
        for world in [2, 4, 8]:
            own_floor = n // world
            for extra in [0, 1, 123, 1000000]:
                self.assertGreaterEqual((n + extra + world - 1) // world, own_floor)


instantiate_parametrized_tests(TestLargeEmbeddingBound)

if __name__ == '__main__':
    run_tests()
