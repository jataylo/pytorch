from collections import Counter, defaultdict
import argparse
import csv
import json
from pathlib import Path


root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--results', default='training_results_v2')
args = parser.parse_args()
destination = root / args.results
source = destination / 'all_kernel_decisions.jsonl'
if not source.exists():
    raise RuntimeError('Merge the primary and steady-state inventories before collecting the complete worklist')
groups = defaultdict(list)
for line in source.open():
    event = json.loads(line)
    refused = event.get('category') == 'unsupported'
    replaced = event.get('category') == 'lowered' and event.get('backend') == 'triton'
    if (refused or replaced) and event.get('reason'):
        groups[event['reason']].append(event)
known = {
    'transposed access needs a 2D tile': 'multi-axis layout draft',
    'online_softmax_reduce of a tuple': 'tuple softmax draft',
    'mix-order reduction over a looped row': 'mixed-order layout draft',
}
rows = []
for reason, events in sorted(groups.items(), key=lambda pair: -len(pair[1])):
    examples = []
    seen = set()
    for event in events:
        identity = (event.get('suite'), event.get('model'), event.get('kernel_name'), event.get('world_size'))
        if identity not in seen:
            seen.add(identity)
            examples.append({key: event.get(key) for key in
                ['measurement_protocol', 'suite', 'model', 'autotune', 'world_size', 'rank', 'attempt_id',
                 'phase', 'graph_id', 'is_backward', 'kernel_name', 'nodes', 'diagnostic_file', 'line']})
        if len(examples) == 12:
            break
    rows.append(dict(reason=reason, current_fix=known.get(reason, 'new category requiring investigation'),
                     refusal_events=sum(event['category'] == 'unsupported' for event in events),
                     named_fallback_events=sum(event['category'] == 'lowered' for event in events),
                     models=sorted({event.get('model') for event in events if event.get('model')}),
                     world_sizes=dict(Counter(event.get('world_size') for event in events)),
                     protocols=dict(Counter(event.get('measurement_protocol') for event in events)),
                     selected_timing_events=sum(bool(event.get('selected_for_final_timing')) for event in events),
                     examples=examples))
(destination / 'fallback_fix_worklist.json').write_text(json.dumps(rows, indent=2) + '\n')
with (destination / 'fallback_fix_worklist.csv').open('w') as output:
    writer = csv.DictWriter(output, fieldnames=list(rows[0]) if rows else ['reason'])
    writer.writeheader()
    writer.writerows({key: json.dumps(value) if isinstance(value, (dict, list)) else value
                     for key, value in row.items()} for row in rows)
print(json.dumps({'categories': len(rows), 'new_categories': [row['reason'] for row in rows
                   if row['current_fix'] == 'new category requiring investigation']}, indent=2))
