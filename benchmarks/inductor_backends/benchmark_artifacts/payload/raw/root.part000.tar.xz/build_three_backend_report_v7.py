import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
from xml.sax.saxutils import escape
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent
MEASURED = {'ok', 'numerical_warning', 'validation_unavailable', 'reference_unavailable'}
META = ['physical_gpu', 'world_size', 'batch_size', 'local_batch_size', 'effective_global_batch_size',
        'batch_distribution', 'parameters', 'model_config_sha256', 'inputs', 'dtype']


def speedup(baseline, candidate):
    return 100 * (baseline - candidate) / baseline


def stable(record):
    samples = record.get('repeat_ms', [])
    return bool(len(samples) >= 4 and min(samples) > 0 and not record.get('timing_recompiles')
                and max(samples) / min(samples) <= 1.2
                and statistics.median(samples[:2]) / statistics.median(samples[-2:]) <= 1.1)


def load_records(directory):
    found = {}
    for path in (directory / 'raw').glob('*/*.json'):
        record = json.loads(path.read_text())
        record['_source'] = str(path)
        found[record['suite'], record['model'], record['backend'], int(record['autotune'])] = record
    return found


def mixed_kernel_counts(record):
    lowered = {}
    choices = defaultdict(set)
    eligible = set()
    path = Path(record.get('diagnostics_file', '/nonexistent'))
    if not path.exists():
        return dict(flydsl_kernels=None, triton_kernels=None, kernel_selection_unknown=None,
                    kernel_count_scope='missing diagnostic source')
    with path.open() as diagnostic:
        for line in diagnostic:
            event = json.loads(line)
            if event.get('attempt_id') != record.get('attempt_id') or event.get('rank') != 0:
                continue
            if event.get('phase') not in {'warmup', 'timing'}:
                continue
            name = event.get('kernel_name')
            if not name:
                continue
            if event.get('category') == 'lowered':
                lowered[name] = event.get('backend')
            elif event.get('category') == 'backend_candidates':
                eligible.add(name)
            elif event.get('category') == 'backend_selection':
                choices[name].add(event.get('selected_backend'))
    counts = Counter()
    for name, backend in lowered.items():
        if name in choices:
            selected = choices[name]
            backend = next(iter(selected)) if len(selected) == 1 else 'unknown'
        elif name in eligible:
            backend = 'unknown'
        counts[backend] += 1
    return dict(flydsl_kernels=counts['flydsl'], triton_kernels=counts['triton'],
                kernel_selection_unknown=sum(value for key, value in counts.items() if key not in {'flydsl', 'triton'}),
                kernel_count_scope='Mixed mode, rank0, unique emitted training kernel names with resolved choices; static counts, not runtime launches; excludes ATen/eager/RCCL')


def make_row(spec, tune, triton, flydsl, mixed):
    arms = {'triton': triton, 'flydsl': flydsl, 'mix': mixed}
    row = dict(model=spec['model'], suite=spec['suite'], tuning='expanded' if tune else 'standard',
               autotune=tune, gpu_count=mixed.get('world_size', 1), gpu_group=mixed.get('physical_gpu'),
               batch_size=spec['batch_size'], parameters=mixed.get('parameters'), component=mixed.get('component'))
    matched = all(all(record.get(key) == triton.get(key) for key in META) for record in arms.values())
    sources = [{name: digest for name, digest in record.get('source_fingerprint', {}).get('sources', {}).items()
                if name.startswith('torch/')} for record in arms.values()]
    source_match = bool(sources[0]) and all(source == sources[0] for source in sources)
    measured = all(record.get('status') in MEASURED and record.get('milliseconds', 0) > 0 for record in arms.values())
    stable_all = all(stable(record) for record in arms.values())
    statuses = {record.get('status') for record in arms.values()}
    if not measured:
        tier = 'unavailable_or_failed'
    elif not matched or not source_match:
        tier = 'incomparable_metadata_or_source'
    elif 'numerical_warning' in statuses:
        tier = 'numerical_warning'
    elif not stable_all:
        tier = 'variable_timing'
    elif statuses == {'ok'}:
        tier = 'validated_stable'
    else:
        tier = 'training_only'
    row.update(evidence_tier=tier, comparable_metadata=matched, identical_compiler_sources=source_match,
               stable_all=stable_all, headline_eligible=tier == 'validated_stable')
    for arm, record in arms.items():
        value = record.get('milliseconds') if record.get('status') in MEASURED else None
        row[arm + '_ms'] = value
        row[arm + '_status'] = record.get('status')
        row[arm + '_repeat_spread_percent'] = 100 * (max(record['repeat_ms']) / min(record['repeat_ms']) - 1) if record.get('repeat_ms') and min(record['repeat_ms']) > 0 else None
        row[arm + '_source'] = record.get('_source')
        row[arm + '_error'] = record.get('error', '')
        row[arm + '_timing_begin_ns'] = record.get('timing_begin_ns')
        row[arm + '_compile_seconds'] = record.get('first_compiled_step_seconds')
    for arm in ['flydsl', 'mix']:
        good = matched and source_match and row['triton_ms'] and row[arm + '_ms']
        row[arm + '_speedup_percent'] = speedup(row['triton_ms'], row[arm + '_ms']) if good else None
        row['triton_over_' + arm] = row['triton_ms'] / row[arm + '_ms'] if good else None
    row['mix_speedup_vs_flydsl_percent'] = speedup(row['flydsl_ms'], row['mix_ms']) if matched and source_match and row['flydsl_ms'] and row['mix_ms'] else None
    row.update(mixed_kernel_counts(mixed))
    pure_counts = mixed_kernel_counts(flydsl)
    row['pure_flydsl_kernels'] = pure_counts['flydsl_kernels']
    row['pure_fallback_triton_kernels'] = pure_counts['triton_kernels']
    row['pure_kernel_selection_unknown'] = pure_counts['kernel_selection_unknown']
    total = (row['flydsl_kernels'] or 0) + (row['triton_kernels'] or 0)
    row['mix_flydsl_kernel_share_percent'] = 100 * row['flydsl_kernels'] / total if total else None
    return row


def summarize(rows, cohort, tune):
    result = []
    def add(metric, value, model='', units=''):
        result.append(dict(cohort=cohort, tuning='expanded' if tune else 'standard', metric=metric,
                           value=value, model=model, units=units))
    add('models', len(rows), units='count')
    if not rows:
        return result
    for arm in ['triton', 'flydsl', 'mix']:
        add('geomean_' + arm + '_ms', statistics.geometric_mean(row[arm + '_ms'] for row in rows), units='ms per full training step')
    for arm in ['flydsl', 'mix']:
        ratios = [row['triton_ms'] / row[arm + '_ms'] for row in rows]
        ratio = statistics.geometric_mean(ratios)
        add('geomean_triton_over_' + arm, ratio, units='ratio; above1 favors ' + arm)
        add('geomean_' + arm + '_speedup_percent', 100 * (1 - 1 / ratio), units='time saved vs Triton, percent')
        add('models_' + arm + '_faster_than_triton', sum(value > 1 for value in ratios), units='count, exact comparison')
        add('models_triton_faster_than_' + arm, sum(value < 1 for value in ratios), units='count, exact comparison')
        add('models_' + arm + '_wins_over3percent', sum(value > 1.03 for value in ratios), units='count')
        add('models_triton_wins_over3percent_vs_' + arm, sum(value < 1 / 1.03 for value in ratios), units='count')
        add('models_within3percent_' + arm, sum(1 / 1.03 <= value <= 1.03 for value in ratios), units='count')
        for label, fn in [('greatest', max), ('lowest', min)]:
            best = fn(rows, key=lambda row: row[arm + '_speedup_percent'])
            add(label + '_' + arm + '_speedup_percent', best[arm + '_speedup_percent'], best['model'], 'time saved vs Triton, percent; negative means slower')
        lead = max(rows, key=lambda row: speedup(row[arm + '_ms'], row['triton_ms']))
        add('greatest_triton_time_saved_vs_' + arm + '_percent', speedup(lead[arm + '_ms'], lead['triton_ms']), lead['model'], 'time saved relative to ' + arm)
        add('median_' + arm + '_speedup_percent', statistics.median(row[arm + '_speedup_percent'] for row in rows), units='percent')
        add('total_step_time_' + arm + '_ms', sum(row[arm + '_ms'] for row in rows), units='sum of per-model step medians; not a workload-weighted mean')
    ratio = statistics.geometric_mean(row['flydsl_ms'] / row['mix_ms'] for row in rows)
    add('geomean_mix_speedup_vs_flydsl_percent', 100 * (1 - 1 / ratio), units='time saved relative to pure FlyDSL, percent')
    return result


def write_csv(path, rows, fields):
    with path.open('w', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def write_workbook(path, sheets):
    def xml(text):
        clean = ''.join(character for character in str(text) if ord(character) >= 32 or character in '\t\n\r')[:32767]
        return escape(clean, {'"': '&quot;'})
    def letter(number):
        value = ''
        while number:
            number, digit = divmod(number - 1, 26)
            value = chr(65 + digit) + value
        return value
    ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    with ZipFile(path, 'w', ZIP_DEFLATED) as archive:
        overrides = ''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1, len(sheets) + 1))
        archive.writestr('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' + overrides + '</Types>')
        archive.writestr('_rels/.rels', '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        archive.writestr('xl/workbook.xml', f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + ''.join(f'<sheet name="{xml(name)}" sheetId="{i}" r:id="rId{i}"/>' for i, (name, _, _) in enumerate(sheets, 1)) + '</sheets></workbook>')
        archive.writestr('xl/_rels/workbook.xml.rels', '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + ''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1, len(sheets) + 1)) + '</Relationships>')
        for i, (_, rows, fields) in enumerate(sheets, 1):
            values = [fields] + [[row.get(field) for field in fields] for row in rows]
            body = []
            for number, row in enumerate(values, 1):
                cells = []
                for column, value in enumerate(row, 1):
                    if value is None:
                        continue
                    ref = letter(column) + str(number)
                    if isinstance(value, (int, float)) and not isinstance(value, bool):
                        cells.append(f'<c r="{ref}"><v>{value}</v></c>')
                    else:
                        cells.append(f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{xml(value)}</t></is></c>')
                body.append(f'<row r="{number}">' + ''.join(cells) + '</row>')
            last = letter(len(fields)) + str(len(values))
            archive.writestr(f'xl/worksheets/sheet{i}.xml', f'<worksheet xmlns="{ns}"><sheetViews><sheetView workbookViewId="0"><pane xSplit="2" ySplit="1" topLeftCell="C2" activePane="bottomRight" state="frozen"/></sheetView></sheetViews><sheetData>' + ''.join(body) + f'</sheetData><autoFilter ref="A1:{last}"/></worksheet>')


def build(single_dir, multi_dir, pure_dir, output):
    for directory in [single_dir, multi_dir, pure_dir]:
        audit = json.loads((directory / 'final_audit.json').read_text())
        for key in ['source_drift', 'external_source_drift', 'optional_dependency_drift', 'input_metadata_mismatches',
                    'unexpected_triton_matrix_templates', 'codegen_collection_errors', 'checkpoint_files']:
            if audit[key]:
                raise RuntimeError(f'Cannot report unaudited results: {directory}: {key}')
        if set(audit['run_fingerprints']) != {audit['expected_fingerprint']}:
            raise RuntimeError(f'Inconsistent source fingerprint: {directory}')
    manifest = json.loads((ROOT / 'model_manifest_purefly_v7.json').read_text())
    single, multi, pure = map(load_records, [single_dir, multi_dir, pure_dir])
    rows = []
    provenance = {}
    for spec in manifest['models']:
        for tune in [0, 1]:
            key = spec['suite'], spec['model']
            mixed_source = multi if (*key, 'flydsl', tune) in multi else single
            triton = mixed_source[*key, 'triton', tune]
            mixed = mixed_source[*key, 'flydsl', tune]
            flydsl = pure[*key, 'flydsl', tune]
            row = make_row(spec, tune, triton, flydsl, mixed)
            rows.append(row)
            for record in [triton, flydsl, mixed]:
                path = record['_source']
                provenance[path] = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    eligible = defaultdict(list)
    for row in rows:
        if row['headline_eligible']:
            eligible[row['suite'], row['model']].append(row['autotune'])
    common = {key for key, modes in eligible.items() if set(modes) == {0, 1}}
    for row in rows:
        row['common_both_tuning_modes'] = (row['suite'], row['model']) in common
    for tune in [0, 1]:
        selected = [row for row in rows if row['autotune'] == tune and row['common_both_tuning_modes']]
        for arm in ['flydsl', 'mix']:
            for rank, row in enumerate(sorted(selected, key=lambda value: value[arm + '_speedup_percent'], reverse=True), 1):
                row['rank_' + arm + '_speedup_common_validated'] = rank
    summaries = []
    for tune in [0, 1]:
        for cohort, selected in [
            ('common_validated_stable_both_tuning_modes', [row for row in rows if row['autotune'] == tune and row['common_both_tuning_modes']]),
            ('validated_stable_this_tuning_mode', [row for row in rows if row['autotune'] == tune and row['headline_eligible']]),
            ('training_only_separate', [row for row in rows if row['autotune'] == tune and row['evidence_tier'] == 'training_only'])]:
            summaries += summarize(selected, cohort, tune)
        for suite in sorted({row['suite'] for row in rows}):
            summaries += summarize([row for row in rows if row['autotune'] == tune and row['common_both_tuning_modes'] and row['suite'] == suite], 'common_validated_stable/' + suite, tune)
        for gpu_count in sorted({row['gpu_count'] for row in rows}):
            summaries += summarize([row for row in rows if row['autotune'] == tune and row['common_both_tuning_modes'] and row['gpu_count'] == gpu_count], 'common_validated_stable/gpus' + str(gpu_count), tune)
        for tier, count in Counter(row['evidence_tier'] for row in rows if row['autotune'] == tune).items():
            summaries.append(dict(cohort='all_models', tuning='expanded' if tune else 'standard', metric='models_' + tier, value=count, model='', units='count'))
    definitions = [
        dict(item='speedup_percent', definition='100 * (Triton_ms - candidate_ms) / Triton_ms. Positive saves time, negative is slower. Geomean uses timing ratios, never arithmetic means of percentages.'),
        dict(item='kernel_counts', definition='Mixed mode rank0 only: distinct emitted training kernel names, resolving eligible names using recorded selected backends. Unknown/unexecuted/conflicting selections stay in kernel_selection_unknown. These are static kernel counts, not invocation counts or GPU time shares. ATen, eager, GEMM/conv and RCCL excluded.'),
        dict(item='headline', definition='Identical model set with all three backends validated, stable, metadata and compiler sources matching in BOTH tuning modes. Training-only, warnings, unstable, failed or incomparable rows remain visible separately.'),
        dict(item='standard_vs_expanded', definition='Pointwise/SIMD search modes0/1. GEMM and conv stay ATen in every mode. Mixed means per-kernel FlyDSL/Triton selection; pure FlyDSL has selection disabled, with unsupported-kernel fallback retained.'),
        dict(item='protocol', definition='Full randomly initialized architectures, original global batch, actual forward/backward/SGD, no checkpoints/offload. Pure FlyDSL is measured in a separate sequential pass; measurement timestamps and source paths are included. Large-model FSDP results are separated by GPU count and validation tier.'),
        dict(item='timing_stability', definition='At least four repeats; spread<=20%, downward trend<=10%, no timing recompiles. Within3percent is a reporting band, not a confidence interval.'),
        dict(item='failed_models', definition='Missing timings and ratios are blank, never zero. Access, capacity, OOM and compiler errors remain explicit. No extrapolation or fabricated result.'),
    ]
    output.mkdir(exist_ok=True)
    first = ['model', 'suite', 'tuning', 'triton_ms', 'flydsl_ms', 'mix_ms', 'flydsl_kernels', 'triton_kernels',
             'flydsl_speedup_percent', 'mix_speedup_percent', 'mix_speedup_vs_flydsl_percent', 'gpu_count',
             'gpu_group', 'batch_size', 'evidence_tier', 'headline_eligible', 'common_both_tuning_modes', 'kernel_selection_unknown']
    fields = first + sorted(set().union(*(row.keys() for row in rows)) - set(first))
    summary_fields = ['cohort', 'tuning', 'metric', 'value', 'model', 'units']
    for tune, label in [(0, 'standard'), (1, 'expanded')]:
        write_csv(output / ('per_model_' + label + '.csv'), [row for row in rows if row['autotune'] == tune], fields)
    write_csv(output / 'per_model_all_modes.csv', rows, fields)
    write_csv(output / 'summary.csv', summaries, summary_fields)
    write_csv(output / 'definitions.csv', definitions, ['item', 'definition'])
    write_workbook(output / 'three_backend_comparison.xlsx', [
        ('Expanded tuning', [row for row in rows if row['autotune'] == 1], fields),
        ('Standard tuning', [row for row in rows if row['autotune'] == 0], fields),
        ('Summary', summaries, summary_fields), ('Definitions', definitions, ['item', 'definition'])])
    provenance[str(Path(__file__).resolve())] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (output / 'report_provenance.json').write_text(json.dumps(dict(generated_utc=datetime.now(timezone.utc).isoformat(),
        models=len(manifest['models']), common_models=len(common), source_hashes=provenance), indent=2) + '\n')
    return dict(models=len(manifest['models']), rows=len(rows), common_models=len(common), output=str(output))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=ROOT / 'three_backend_report_v7')
    args = parser.parse_args()
    print(json.dumps(build(ROOT / 'training_results_mixed_single_v5', ROOT / 'training_results_mixed_multi_v6',
                           ROOT / 'training_results_purefly_v7', args.output), indent=2))
