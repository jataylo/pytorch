import json
from pathlib import Path
import subprocess
import sys
import time


root = Path(__file__).resolve().parent
results = root / 'training_results_v2'
while not all((results / name).exists() for name in ['stable_report.html', 'fallback_fix_worklist.json']):
    time.sleep(5)
command = [sys.executable, '-S', str(root / 'collect_kernel_inventory_v3.py'),
           '--results', str(results), '--additional-results', str(root / 'training_results_v2_steady'),
           '--output', str(results / 'kernel_inventory')]
print(json.dumps({'started': time.time(), 'command': command}), flush=True)
subprocess.run(command, cwd=root, check=True)
print('Supplemental wrapper/kernel coverage inventory finished; review unknown associations separately.', flush=True)
