import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import html
import json
from pathlib import Path
import statistics

from build_three_backend_report_v7 import (
    META, MEASURED, make_row, speedup, stable, summarize, write_csv, write_workbook,
)

ROOT = Path(__file__).resolve().parent
MODES = {'standard': 0, 'expanded': 1}


def load_snapshot(directory):
    result = {}
    for path in (directory / 'raw').glob('*/*.json'):
        data = path.read_bytes()
        record = json.loads(data)
        record['_source'] = str(path)
        record['_source_sha256'] = hashlib.sha256(data).hexdigest()
        result[record['suite'], record['model'], record['backend'], int(record['autotune'])] = record
    return result


def compatible(first, second, allow_other_physical_gpu=False):
    fields = [key for key in META if not (allow_other_physical_gpu and key == 'physical_gpu')]
    source = lambda record: {key: value for key, value in record.get('source_fingerprint', {}).get('sources', {}).items() if key.startswith('torch/')}
    return bool(source(first)) and source(first) == source(second) and all(first.get(key) == second.get(key) for key in fields)


def terminal(record):
    return bool(record and record.get('status') not in {'started', 'pending'})


def measured(record):
    return bool(record and record.get('status') in MEASURED and record.get('milliseconds', 0) > 0)


def choose_references(key, tune, single, multi):
    native_key, mixed_key = (*key, 'triton', tune), (*key, 'flydsl', tune)
    native, mixed = multi.get(native_key), multi.get(mixed_key)
    if terminal(native) and terminal(mixed) and compatible(native, mixed):
        return native, mixed, 'current_multi_gpu'
    return single.get(native_key), single.get(mixed_key), 'current_single_gpu'


def choose_pure(key, tune, reference, fresh, historical):
    identity = (*key, 'flydsl', tune)
    candidate = fresh.get(identity)
    if terminal(candidate) and compatible(reference, candidate):
        return candidate, 'fresh_pure_flydsl'
    candidate = historical.get(identity)
    if measured(candidate) and compatible(reference, candidate, allow_other_physical_gpu=True):
        return candidate, 'historical_pure_flydsl_v4'
    return None, 'pending_fresh_pure_flydsl'


def placeholder(reference):
    return dict(reference, status='pending', milliseconds=None, repeat_ms=[], diagnostics_file='/nonexistent',
                _source='', _source_sha256='', error='Fresh pure-FlyDSL result pending; no compatible historical result')


def build_rows(manifest, single, multi, fresh, historical):
    rows, used = [], {}
    for spec in manifest['models']:
        key = spec['suite'], spec['model']
        for tune in [0, 1]:
            native, mixed, protocol = choose_references(key, tune, single, multi)
            if not native or not mixed:
                continue
            pure, origin = choose_pure(key, tune, native, fresh, historical)
            pure = pure or placeholder(native)
            row = make_row(spec, tune, native, pure, mixed)
            row.update(snapshot=True, reference_protocol=protocol, flydsl_origin=origin,
                       historical_flydsl=origin == 'historical_pure_flydsl_v4',
                       flydsl_gpu_group=pure.get('physical_gpu'), flydsl_gpu_count=pure.get('world_size'),
                       strict_three_way_metadata=row['comparable_metadata'])
            row['current_pair_validated_stable'] = bool(native['status'] == mixed['status'] == 'ok' and stable(native) and stable(mixed) and compatible(native, mixed))
            row['current_pair_training_only_stable'] = bool(native['status'] == mixed['status'] == 'validation_unavailable' and stable(native) and stable(mixed) and compatible(native, mixed))
            row['preview_three_way_validated_stable'] = bool(row['current_pair_validated_stable'] and pure.get('status') == 'ok' and stable(pure) and compatible(native, pure, allow_other_physical_gpu=True))
            if measured(native) and measured(mixed) and compatible(native, mixed):
                row['mix_speedup_percent'] = speedup(native['milliseconds'], mixed['milliseconds'])
                row['triton_over_mix'] = native['milliseconds'] / mixed['milliseconds']
            if row['historical_flydsl']:
                row['headline_eligible'] = False
                row['evidence_tier'] = 'historical_preview/' + row['evidence_tier']
                row['flydsl_speedup_percent'] = speedup(native['milliseconds'], pure['milliseconds']) if measured(native) else None
                row['triton_over_flydsl'] = native['milliseconds'] / pure['milliseconds'] if measured(native) else None
                row['mix_speedup_vs_flydsl_percent'] = speedup(pure['milliseconds'], mixed['milliseconds']) if measured(mixed) else None
            elif origin == 'pending_fresh_pure_flydsl':
                row['evidence_tier'] = 'pure_flydsl_pending'
            rows.append(row)
            for record in [native, mixed, pure]:
                if record.get('_source'):
                    used[record['_source']] = record.get('_source_sha256')
    return rows, used


def pair_summary(rows, tune, cohort):
    result = []
    def add(metric, value, model='', units=''):
        result.append(dict(cohort=cohort, tuning='expanded' if tune else 'standard', metric=metric, value=value, model=model, units=units))
    add('models', len(rows), units='count')
    if not rows:
        return result
    ratios = [row['triton_ms'] / row['mix_ms'] for row in rows]
    ratio = statistics.geometric_mean(ratios)
    add('geomean_triton_over_mix', ratio, units='ratio; above1 favors mixed')
    add('geomean_mix_speedup_percent', 100 * (1 - 1 / ratio), units='time saved vs Triton, percent')
    add('models_mix_faster_than_triton', sum(value > 1 for value in ratios), units='count, exact comparison')
    add('models_triton_faster_than_mix', sum(value < 1 for value in ratios), units='count, exact comparison')
    add('models_mix_wins_over3percent', sum(value > 1.03 for value in ratios), units='count')
    add('models_triton_wins_over3percent', sum(value < 1 / 1.03 for value in ratios), units='count')
    add('models_within3percent', sum(1 / 1.03 <= value <= 1.03 for value in ratios), units='count')
    for label, fn in [('greatest', max), ('lowest', min)]:
        item = fn(rows, key=lambda value: value['mix_speedup_percent'])
        add(label + '_mix_speedup_percent', item['mix_speedup_percent'], item['model'], 'time saved vs Triton, percent')
    return result


def summary_rows(rows):
    result = []
    common_pair = {row['model'] for row in rows if row['current_pair_validated_stable'] and all(
        any(other['model'] == row['model'] and other['autotune'] == tune and other['current_pair_validated_stable'] for other in rows) for tune in [0, 1])}
    for tune in [0, 1]:
        current = [row for row in rows if row['autotune'] == tune and row['current_pair_validated_stable']]
        result += pair_summary(current, tune, 'CURRENT_triton_vs_mix_validated_stable')
        result += pair_summary([row for row in current if row['model'] in common_pair], tune, 'CURRENT_triton_vs_mix_common_both_tuning_modes')
        result += summarize([row for row in rows if row['autotune'] == tune and row['preview_three_way_validated_stable']], 'HISTORICAL_PREVIEW_three_way_NOT_final_or_concurrent', tune)
        for tier, count in Counter(row['evidence_tier'] for row in rows if row['autotune'] == tune).items():
            result.append(dict(cohort='snapshot_coverage', tuning='expanded' if tune else 'standard', metric=tier, value=count, model='', units='models'))
    return result


def runtime_svg(rows, mode, title='Full training runtime', historical=True):
    selected = [row for row in rows if row['tuning'] == mode and row['preview_three_way_validated_stable']]
    selected.sort(key=lambda row: row['triton_ms'], reverse=True)
    width, left, right, top, step = 1320, 395, 115, 130, 57
    height = top + len(selected) * step + 65
    span = width - left - right
    maximum = max((row[arm + '_ms'] for row in selected for arm in ['triton', 'flydsl', 'mix']), default=1) * 1.08
    caption = 'Preview: current Triton/mixed; pure FlyDSL may be from the previous v4 run. Lower runtime is better.' if historical else 'Final three-way comparison: fresh Triton, pure FlyDSL and mixed measurements. Lower runtime is better.'
    scope = 'Shown: three measured, validated, stable arms with matching architecture, inputs, GPU count and compiler sources; physical GPU may differ.' if historical else 'Shown: three validated, stable arms with matching inputs, compiler sources and GPU placement. Warnings and failures remain in the workbook.'
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
           '<rect width="100%" height="100%" fill="white"/>',
           '<style>text{font-family:Arial,sans-serif;fill:#172033}.grid{stroke:#e2e8f0;stroke-width:1}</style>',
           f'<text x="24" y="30" font-size="22" font-weight="bold">{html.escape(title)} — {mode} tuning</text>',
           f'<text x="24" y="54" font-size="13">{html.escape(caption)}</text>',
           f'<text x="24" y="75" font-size="12">{html.escape(scope)}</text>']
    colors = {'triton': '#64748b', 'flydsl': '#d97706', 'mix': '#059669'}
    for index, (arm, color) in enumerate(colors.items()):
        x = left + index * 190
        out += [f'<rect x="{x}" y="91" width="16" height="10" fill="{color}"/>',
                f'<text x="{x+23}" y="101" font-size="13">{arm.title()}</text>']
    for index in range(6):
        value = maximum * index / 5
        x = left + span * index / 5
        out += [f'<line class="grid" x1="{x}" y1="{top-8}" x2="{x}" y2="{height-45}"/>',
                f'<text x="{x}" y="{height-25}" text-anchor="middle" font-size="12">{value:.1f}</text>']
    for index, row in enumerate(selected):
        y = top + index * step
        name = row['model']
        label = name if len(name) <= 52 else name[:49] + '...'
        out += [f'<text x="{left-12}" y="{y+21}" text-anchor="end" font-size="12"><title>{html.escape(name)}</title>{html.escape(label)}</text>']
        for offset, (arm, color) in enumerate(colors.items()):
            value = row[arm + '_ms']
            bar_width = max(0.5, value / maximum * span)
            by = y + offset * 13
            origin = row.get('flydsl_origin', '') if arm == 'flydsl' else row['reference_protocol']
            tip = f"{name}: {arm} {value:.3f} ms/step; {row['gpu_count']} GPU(s); {origin}"
            out += [f'<rect x="{left}" y="{by}" width="{bar_width:.3f}" height="10" fill="{color}"><title>{html.escape(tip)}</title></rect>',
                    f'<text x="{left+bar_width+5:.3f}" y="{by+9}" font-size="10">{value:.2f}</text>']
    out += [f'<text x="{left+span/2}" y="{height-3}" text-anchor="middle" font-size="13">Full training step runtime (ms)</text>', '</svg>']
    return ''.join(out)


def write_dashboard(output, rows, info):
    slim_fields = ['model', 'suite', 'tuning', 'triton_ms', 'flydsl_ms', 'mix_ms', 'mix_speedup_percent', 'flydsl_speedup_percent',
                   'gpu_count', 'gpu_group', 'flydsl_gpu_group', 'flydsl_origin', 'evidence_tier', 'current_pair_validated_stable',
                   'current_pair_training_only_stable', 'preview_three_way_validated_stable', 'reference_protocol',
                   'triton_status', 'flydsl_status', 'mix_status', 'flydsl_kernels', 'triton_kernels']
    data = json.dumps([{key: row.get(key) for key in slim_fields} for row in rows]).replace('<', chr(92) + 'u003c')
    page = '''<!doctype html><meta charset="utf-8"><title>Three-backend runtime preview</title>
<style>body{font:14px system-ui;margin:24px;color:#172033}h1{margin-bottom:8px}.note{background:#fff7ed;padding:12px;border-left:4px solid #d97706}label{display:inline-block;margin:12px 14px 12px 0}select,input,button{padding:7px}#chart{overflow:auto;border:1px solid #e2e8f0}table{border-collapse:collapse;width:100%;font-size:12px}td,th{border-bottom:1px solid #e2e8f0;padding:6px;text-align:left}th{position:sticky;top:0;background:white}.links a{margin-right:16px}</style>
<h1>Triton / FlyDSL / mixed runtime</h1>
<p class="note">LIVE PREVIEW. Triton and mixed timings are from the current run. Pure FlyDSL uses fresh results when available, otherwise explicitly labeled v4 historical timings on matching architecture, inputs, GPU count and compiler sources. A historical bar may use another physical GPU of the same type. This is not the final three-way comparison.</p>
<p class="links"><a href="three_backend_preview.xlsx">Excel workbook</a><a href="per_model_expanded.csv">Expanded CSV</a><a href="per_model_standard.csv">Standard CSV</a><a href="summary.csv">Summary CSV</a><a href="definitions.csv">Definitions</a></p>
<label>Tuning <select id="mode"><option value="expanded">Expanded</option><option value="standard">Standard</option></select></label>
<label>Suite <select id="suite"><option value="all">All</option></select></label>
<label>GPUs <select id="gpus"><option value="all">All</option><option value="1">Single GPU</option><option value="multi">Multi-GPU</option></select></label>
<label>Evidence <select id="evidence"><option value="validated">Validated, stable, all 3 bars</option><option value="training">Include training-only</option><option value="all">All outcomes / partial bars</option></select></label>
<label>Sort <select id="sort"><option value="runtime">Triton runtime</option><option value="mix">Mixed speedup</option><option value="model">Model name</option></select></label>
<label>Axis <select id="scale"><option value="linear">Linear ms</option><option value="log">Logarithmic ms</option></select></label>
<label>Find <input id="search" placeholder="Model name"></label><button id="download">Download current SVG</button>
<p id="status"></p><div id="chart"></div><h2>Filtered model values</h2><div id="table"></div>
<script>const DATA=__DATA__;const INFO=__INFO__;
const $=id=>document.getElementById(id);const esc=x=>String(x??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
for(const suite of [...new Set(DATA.map(x=>x.suite))].sort()){$('suite').add(new Option(suite,suite));}
let current='';
function render(){let rows=DATA.filter(r=>r.tuning===$('mode').value&&($('suite').value==='all'||r.suite===$('suite').value)&&($('gpus').value==='all'||($('gpus').value==='1'?r.gpu_count===1:r.gpu_count>1))&&r.model.toLowerCase().includes($('search').value.toLowerCase()));
if($('evidence').value==='validated')rows=rows.filter(r=>r.preview_three_way_validated_stable);
if($('evidence').value==='training')rows=rows.filter(r=>r.preview_three_way_validated_stable||(r.current_pair_training_only_stable&&r.flydsl_ms>0));
rows.sort((a,b)=>$('sort').value==='model'?a.model.localeCompare(b.model):$('sort').value==='mix'?(b.mix_speedup_percent??-1e9)-(a.mix_speedup_percent??-1e9):(b.triton_ms??0)-(a.triton_ms??0));
const arms=['triton','flydsl','mix'],colors=['#64748b','#d97706','#059669'];const W=1320,L=390,R=120,T=125,step=58,H=Math.max(250,T+rows.length*step+70),span=W-L-R;
const vals=rows.flatMap(r=>arms.map(a=>r[a+'_ms']).filter(x=>x>0));const hi=Math.max(1,...vals)*1.08,lo=Math.max(.001,Math.min(1,...vals)/2),log=$('scale').value==='log';const pos=x=>log?L+(Math.log10(x)-Math.log10(lo))/(Math.log10(hi)-Math.log10(lo))*span:L+x/hi*span;
let s=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="100%" height="100%" fill="white"/><style>text{font-family:Arial,sans-serif;fill:#172033}</style><text x="24" y="30" font-size="22" font-weight="bold">Full training runtime — ${esc($('mode').value)} tuning</text><text x="24" y="54" font-size="13">Preview: current Triton/mixed; historical pure FlyDSL is labeled in tooltips and table. Lower is better.</text><text x="24" y="75" font-size="12">${esc(rows.length)} models; ${log?'logarithmic':'linear'} runtime axis; snapshot ${esc(INFO.generated_utc)}.</text>`;
arms.forEach((a,i)=>{s+=`<rect x="${L+i*190}" y="90" width="16" height="10" fill="${colors[i]}"/><text x="${L+23+i*190}" y="100" font-size="13">${a}</text>`;});
for(let i=0;i<=5;i++){const v=log?Math.pow(10,Math.log10(lo)+(Math.log10(hi)-Math.log10(lo))*i/5):hi*i/5,x=pos(v);s+=`<line x1="${x}" y1="${T-8}" x2="${x}" y2="${H-45}" stroke="#e2e8f0"/><text x="${x}" y="${H-26}" text-anchor="middle" font-size="12">${v.toPrecision(3)}</text>`;}
rows.forEach((r,i)=>{const y=T+i*step,label=r.model.length>52?r.model.slice(0,49)+'...':r.model;s+=`<text x="${L-12}" y="${y+22}" text-anchor="end" font-size="12"><title>${esc(r.model)}</title>${esc(label)}</text>`;arms.forEach((a,j)=>{const v=r[a+'_ms'],by=y+j*13;if(!(v>0)){s+=`<text x="${L+5}" y="${by+9}" font-size="10" fill="#b91c1c">${a}: ${esc(r[a+'_status']??'pending')}</text>`;return;}const x=pos(v),tip=`${r.model}: ${a} ${v.toFixed(3)} ms; ${r.gpu_count} GPU(s); ${a==='flydsl'?r.flydsl_origin:r.reference_protocol}`;s+=`<rect x="${L}" y="${by}" width="${Math.max(.5,x-L)}" height="10" fill="${colors[j]}"><title>${esc(tip)}</title></rect><text x="${x+5}" y="${by+9}" font-size="10">${v.toFixed(2)}</text>`;});});
s+=`<text x="${L+span/2}" y="${H-5}" text-anchor="middle" font-size="13">Full training step runtime (ms${log?', log scale':''})</text></svg>`;current=s;$('chart').innerHTML=s;
$('status').textContent=`${rows.length} models shown. Mixed comparison uses current measurements; orange historical FlyDSL bars are provisional. Missing timings are not zero.`;
const fields=['model','triton_ms','flydsl_ms','mix_ms','mix_speedup_percent','flydsl_kernels','triton_kernels','gpu_count','gpu_group','flydsl_gpu_group','flydsl_origin','evidence_tier'];$('table').innerHTML='<table><thead><tr>'+fields.map(x=>'<th>'+esc(x)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+fields.map(f=>'<td>'+esc(typeof r[f]==='number'?r[f].toFixed(f.includes('ms')||f.includes('percent')?3:0):r[f])+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
}
for(const id of ['mode','suite','gpus','evidence','sort','scale','search'])$(id).addEventListener('input',render);
$('download').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([current],{type:'image/svg+xml'}));a.download='runtime_'+$('mode').value+'_preview.svg';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};render();</script>'''
    page = page.replace('__DATA__', data).replace('__INFO__', json.dumps(info).replace('<', chr(92) + 'u003c'))
    if info.get('final'):
        page = page.replace('LIVE PREVIEW. Triton and mixed timings are from the current run. Pure FlyDSL uses fresh results when available, otherwise explicitly labeled v4 historical timings on matching architecture, inputs, GPU count and compiler sources. A historical bar may use another physical GPU of the same type. This is not the final three-way comparison.', 'FINAL THREE-WAY RESULTS. All three backends have fresh measurements at matched GPU placements and inputs. Primary summary excludes warnings, unstable results and training-only measurements; all outcomes remain in the workbook.')
        page = page.replace('three_backend_preview.xlsx', 'three_backend_comparison.xlsx')
        page = page.replace('Three-backend runtime preview', 'Final three-backend runtime')
        page = page.replace("+'_preview.svg'", "+'_final.svg'")
        page = page.replace('Preview: current Triton/mixed; historical pure FlyDSL is labeled in tooltips and table.', 'Final: fresh Triton, pure FlyDSL and mixed measurements.')
        page = page.replace('Mixed comparison uses current measurements; orange historical FlyDSL bars are provisional.', 'All three arms are fresh; use evidence filters to inspect excluded rows.')
    (output / 'runtime_dashboard.html').write_text(page)


def main(output):
    manifest = json.loads((ROOT / 'model_manifest_mixed_single_v5.json').read_text())
    single, multi, fresh, historical = [load_snapshot(ROOT / name) for name in [
        'training_results_mixed_single_v5', 'training_results_mixed_multi_v6', 'training_results_purefly_v7', 'training_results_support_v4']]
    rows, provenance = build_rows(manifest, single, multi, fresh, historical)
    summaries = summary_rows(rows)
    definitions = [dict(item='snapshot', definition='Partial live snapshot; never overwrites final v7 report. Historical pure-FlyDSL bars are provisional, not a fresh three-way benchmark.'),
        dict(item='historical_pure_flydsl_v4', definition='Previous full run. Require identical architecture/config, input metadata, global/local batch, GPU count and compiler source hashes. Another physical GPU of the same type is allowed ONLY for explicitly labeled historical preview. Current final headline eligibility remains false.'),
        dict(item='speedup_percent', definition='100*(Triton_ms-candidate_ms)/Triton_ms. Positive is faster; negative slower. Historical percentages are descriptive preview, not a controlled final claim.'),
        dict(item='kernel_counts', definition='Mixed rank0 distinct emitted training kernel names with recorded backend selection, during warmup/timing. Unknown selections explicit. Not dynamic launch counts, GPU time, ATen GEMM/conv, eager or RCCL kernels.'),
        dict(item='summary_cohorts', definition='CURRENT cohorts compare current validated stable Triton/mix only. HISTORICAL_PREVIEW cohort includes older pure FlyDSL and must not be quoted as the final three-way result. All failed/pending/warning rows remain in model CSVs.'),
        dict(item='chart', definition='Models on Y, full-step runtime ms on X, three horizontal bars for Triton, FlyDSL and mixed. Default shows stable validated compatible three-arm preview. Dashboard can show training-only/partial outcomes, choose suite/GPU/tuning/axis and download filtered SVG.'),
        dict(item='pending', definition='Missing timing stays blank; charts label missing bars with status, never draw zero as a measurement.')]
    output.mkdir(parents=True, exist_ok=True)
    first = ['model','suite','tuning','triton_ms','flydsl_ms','mix_ms','flydsl_kernels','triton_kernels','flydsl_speedup_percent','mix_speedup_percent','gpu_count','evidence_tier','flydsl_origin','reference_protocol','current_pair_validated_stable','preview_three_way_validated_stable']
    fields = first + sorted(set().union(*(row.keys() for row in rows)) - set(first))
    summary_fields = ['cohort','tuning','metric','value','model','units']
    for label in MODES:
        selected = [row for row in rows if row['tuning'] == label]
        write_csv(output / ('per_model_' + label + '.csv'), selected, fields)
        (output / ('runtime_' + label + '.svg')).write_text(runtime_svg(rows, label))
        for suite in sorted({row['suite'] for row in rows}):
            suffix = suite.replace('-dashboard', '')
            (output / f'runtime_{label}_{suffix}.svg').write_text(runtime_svg([row for row in rows if row['suite'] == suite], label, suite + ' full training runtime'))
    write_csv(output / 'per_model_all_modes.csv', rows, fields)
    write_csv(output / 'summary.csv', summaries, summary_fields)
    write_csv(output / 'definitions.csv', definitions, ['item','definition'])
    write_workbook(output / 'three_backend_preview.xlsx', [('Expanded preview',[row for row in rows if row['autotune']==1],fields),
        ('Standard preview',[row for row in rows if row['autotune']==0],fields),('Summary',summaries,summary_fields),('Definitions',definitions,['item','definition'])])
    info = dict(generated_utc=datetime.now(timezone.utc).isoformat(), models=len(manifest['models']), rows=len(rows),
        validated_three_bar_preview_by_mode={label:sum(row['preview_three_way_validated_stable'] and row['tuning']==label for row in rows) for label in MODES},
        fresh_pure_rows=sum(row['flydsl_origin']=='fresh_pure_flydsl' for row in rows),
        historical_pure_rows=sum(row['historical_flydsl'] for row in rows),
        note='Preview only; pure FlyDSL historical until fresh results arrive.')
    write_dashboard(output, rows, info)
    provenance[str(Path(__file__).resolve())] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (output / 'snapshot_provenance.json').write_text(json.dumps(dict(info, source_hashes=provenance),indent=2)+'\n')
    (output / 'README.txt').write_text('Open runtime_dashboard.html for filters and SVG export. per_model_expanded.csv and per_model_standard.csv contain all model outcomes. Excel workbook has model, summary and definition tabs. Historical pure-FlyDSL values are explicitly marked. Refresh with: bash agent_space/simd_bench/run_env.sh agent_space/simd_bench/build_live_three_backend_v8.py\n')
    print(json.dumps(info,indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=ROOT/'three_backend_preview_v8')
    args=parser.parse_args()
    main(args.output)
