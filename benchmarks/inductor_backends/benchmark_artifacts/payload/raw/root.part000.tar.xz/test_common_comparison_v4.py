import copy

from build_common_comparison_v4 import aggregate, family_row, MODES, positive
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


def fixture():
    times = {('triton', 0): 10, ('flydsl', 0): 5, ('triton', 1): 8, ('flydsl', 1): 4}
    runs = {mode: {'status': 'ok', 'milliseconds': times[mode], 'physical_gpu': '0',
                   'world_size': 1, 'batch_size': 8, 'parameters': 100, 'model_config_sha256': 'config',
                   'dtype': 'float32'} for mode in MODES}
    pairs = {tune: {'timing_quality': 'stable', 'eager_validated': 'True',
                    'triton_over_flydsl': '2'} for tune in [0, 1]}
    return runs, pairs


@instantiate_parametrized_tests
class TestCommonComparison(TestCase):
    @parametrize('scenario,tier,headline', [
        ('valid', 'validated_stable_four_modes', True),
        ('warning', 'numerical_warning', False),
        ('variable', 'variable_timing', False),
        ('placement', 'incomparable_metadata', False),
        ('training_only', 'training_only_stable_four_modes', False),
    ])
    def test_common_four_mode_selection(self, scenario, tier, headline):
        runs, pairs = fixture()
        if scenario == 'warning':
            runs['flydsl', 1]['status'] = 'numerical_warning'
            pairs[1]['eager_validated'] = 'False'
        elif scenario == 'variable':
            pairs[1]['timing_quality'] = 'variable'
        elif scenario == 'placement':
            for backend in ['triton', 'flydsl']:
                runs[backend, 1]['physical_gpu'] = '1'
        elif scenario == 'training_only':
            for record in runs.values():
                record['status'] = 'validation_unavailable'
            for pair in pairs.values():
                pair['eager_validated'] = 'False'
        row = family_row('suite', 'model', runs, pairs)
        self.assertEqual(row['tier'], tier)
        self.assertEqual(row['headline'], headline)
        self.assertEqual(row['triton_over_flydsl_0'], 2)

    def test_unmeasured_failure_retains_status_without_timing(self):
        runs, pairs = fixture()
        runs['flydsl', 1].update(status='error', milliseconds=None)
        pairs[1]['triton_over_flydsl'] = ''
        row = family_row('suite', 'model', runs, pairs)
        self.assertEqual(row['tier'], 'unavailable_or_failed')
        self.assertIsNone(row['flydsl_1_ms'])
        self.assertEqual(row['flydsl_1_status'], 'error')
        self.assertFalse(row['headline'])

    def test_geomeans_use_identical_model_set(self):
        runs, pairs = fixture()
        first = family_row('suite', 'first', runs, pairs)
        second = copy.deepcopy(first)
        second.update(model='second', triton_over_flydsl_0=0.5, triton_over_flydsl_1=0.5)
        result = aggregate([first, second])
        self.assertEqual(result['autotune0']['models'], 2)
        self.assertEqual(result['autotune1']['models'], 2)
        self.assertEqual(result['autotune0']['geomean_triton_over_flydsl'], 1)
        self.assertEqual(result['autotune1']['geomean_triton_over_flydsl'], 1)
        self.assertEqual(result['flydsl_expanded_tuning_speedup'], 1.25)

    @parametrize('value', [0, float('nan'), float('inf')])
    def test_nonpositive_or_nonfinite_timing_fails_closed(self, value):
        with self.assertRaises(ValueError):
            positive(value)

    def test_stale_comparison_ratio_fails_closed(self):
        runs, pairs = fixture()
        pairs[0]['triton_over_flydsl'] = '3'
        with self.assertRaisesRegex(ValueError, 'selected raw timings'):
            family_row('suite', 'model', runs, pairs)


if __name__ == '__main__':
    run_tests()
