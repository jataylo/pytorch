import json
import os
from pathlib import Path
import subprocess
import sys

from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase
import test_prepare_fsdp_state_recovery_v3 as fixtures


@instantiate_parametrized_tests
class TestSupportQwenImageStateInitialization(TestCase):
    prepare = fixtures.TestPrepareFSDPStateRecovery.prepare
    assert_worker_preserves_training = fixtures.TestPrepareFSDPStateRecovery.assert_worker_preserves_training

    @parametrize('case', ['all_eager_oom', 'compiled_oom', 'world4', 'mixed_phase', 'mixed_status', 'wrong_error'])
    def test_future_support_selection(self, case):
        root = self.prepare(model='Qwen/Qwen-Image')
        paths = sorted((root / 'training_results_v2/raw/case').glob('*.json'))
        for index, path in enumerate(paths):
            record = json.loads(path.read_text())
            record['launch_environment_overrides'] = {'BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS': '1'}
            if case == 'compiled_oom':
                record['phase'] = 'warmup'
            elif case == 'world4':
                record['world_size'] = 4
            elif case == 'mixed_phase' and index == 0:
                record['phase'] = 'model_load'
            elif case == 'mixed_status' and index == 0:
                record['status'] = 'ok'
            elif case == 'wrong_error':
                record['error'] = 'Unrelated backend error'
            path.write_text(json.dumps(record))
        (root / 'training_results_v2_steady').mkdir(exist_ok=True)
        (root / 'training_results_v2_steady/COMPLETE.json').write_text('{}')
        (root / 'training_results_v2/final_timing_sources.csv').write_text('source_json\n' + '\n'.join(map(str, paths)) + '\n')
        completed = subprocess.run([sys.executable, str(root / 'prepare_support_suite_v3.py')], cwd=root,
                                   env={**os.environ, 'CUDA_VISIBLE_DEVICES': ''}, capture_output=True, text=True, timeout=30)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        manifest = json.loads((root / 'model_manifest_support_v3.json').read_text())
        overrides = manifest['models'][0]['launch_environment_overrides']
        self.assertEqual(overrides['BENCHMARK_RESTORE_DIFFUSION_META_CONSTANTS'], '1')
        self.assertEqual(overrides.get('BENCHMARK_FSDP_STATE_INIT_ONLY'), '1' if case == 'all_eager_oom' else None)
        self.assert_worker_preserves_training((root / 'train_worker_support_v3.py').read_text())
        fingerprint = json.loads((root / 'source_fingerprint_support_v3.json').read_text())
        self.assertIn('test_prepare_support_qwen_image_v3.py', fingerprint['harness'])


if __name__ == '__main__':
    run_tests()
