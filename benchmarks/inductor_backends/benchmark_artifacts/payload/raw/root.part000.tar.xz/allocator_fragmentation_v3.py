"""CPU-only evidence checks for an isolated allocator recovery experiment."""

import re
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_HALF_UP


_SIZE = r"([0-9]+(?:\.[0-9]+)?)\s*(KiB|MiB|GiB|KB|MB|GB|bytes|B)\b"
_OOM = re.compile(r"\b(?:CUDA|HIP)(?: error:)? out of memory\b", re.IGNORECASE)
_FIELDS = {
    "request_bytes": re.compile(r"Tried to allocate\s+" + _SIZE, re.IGNORECASE),
    "free_bytes": re.compile(r"of which\s+" + _SIZE + r"\s+is free", re.IGNORECASE),
    "allocated_bytes": re.compile(_SIZE + r"\s+is allocated by PyTorch", re.IGNORECASE),
    "reserved_unallocated_bytes": re.compile(_SIZE + r"\s+is reserved by PyTorch but unallocated", re.IGNORECASE),
}
_UNITS = {"b": 1, "bytes": 1, "kb": 1000, "mb": 1000**2, "gb": 1000**3,
          "kib": 1024, "mib": 1024**2, "gib": 1024**3}


def fragmentation_evidence(record):
    """Parse one complete terminal GPU OOM report, without combining different OOMs.

    Values are display estimates rounded to integer bytes. Binary units use 1024;
    KB/MB/GB use 1000. Each non-byte display can hide half its last printed digit;
    byte integers are exact. The nominal headroom test is only an indication of
    fragmentation, not proof that an allocation or full training step will fit.
    """
    if record.get("status") not in {"error", "timeout", "process_failed"}:
        return None
    for timing_field in ["milliseconds", "ms"]:
        timing = record.get(timing_field)
        if timing is None:
            continue
        if isinstance(timing, bool):
            return None
        try:
            timing = Decimal(str(timing))
        except (InvalidOperation, ValueError):
            return None
        if not timing.is_finite() or timing != 0:
            return None
    for field in ["error", "traceback"]:
        message = record.get(field)
        if not isinstance(message, str):
            continue
        markers = list(_OOM.finditer(message))
        for index, marker in enumerate(markers):
            end = markers[index + 1].start() if index + 1 < len(markers) else len(message)
            stanza = message[marker.end():end]
            matches = {name: pattern.search(stanza) for name, pattern in _FIELDS.items()}
            if any(match is None for match in matches.values()):
                continue
            values, errors = {}, {}
            for name, match in matches.items():
                value = Decimal(match.group(1))
                unit = _UNITS[match.group(2).lower()]
                values[name] = int((value * unit).to_integral_value(rounding=ROUND_HALF_UP))
                exact_bytes = unit == 1 and value.as_tuple().exponent >= 0
                error = Decimal(0) if exact_bytes else Decimal(5).scaleb(value.as_tuple().exponent - 1) * unit
                errors[name] = int(error.to_integral_value(rounding=ROUND_CEILING))
            request, free = values["request_bytes"], values["free_bytes"]
            reserved = values["reserved_unallocated_bytes"]
            uncertain = (abs(request - free) <= errors["request_bytes"] + errors["free_bytes"] or
                         abs(free + reserved - request) <= errors["request_bytes"] + errors["free_bytes"] + errors["reserved_unallocated_bytes"])
            return {**values, "plausible_fragmentation": request > free and free + reserved >= request,
                    "rounding_uncertain": uncertain, "rounding_error_bytes": errors, "source_field": field,
                    "explanation": "Headroom classification uses rounded OOM display values; a positive indication is not proof of allocation or full training fit."}
    return None


def require_expandable_allocation(snapshot, pointer, nbytes, device):
    """Require a live allocation interval in an explicitly expandable segment."""
    if snapshot.get("allocator_settings", {}).get("expandable_segments") is not True:
        raise ValueError("snapshot does not prove expandable_segments=True")
    if (type(pointer) is not int or pointer < 0 or type(nbytes) is not int or nbytes <= 2 * 1024**2 or
            type(device) is not int or device < 0):
        raise ValueError("expected nonnegative integer pointer/device and allocation larger than 2 MiB")
    end = pointer + nbytes
    for segment in snapshot.get("segments", []):
        if segment.get("device") != device or segment.get("is_expandable") is not True:
            continue
        address, size = segment.get("address"), segment.get("total_size")
        if type(address) is not int or type(size) is not int or not address <= pointer < end <= address + size:
            continue
        for block in segment.get("blocks", []):
            if block.get("state") != "active_allocated":
                continue
            block_address, block_size = block.get("address"), block.get("size")
            if (type(block_address) is int and type(block_size) is int and
                    address <= block_address <= pointer < end <= block_address + block_size <= address + size):
                return {"device": device, "pointer": pointer, "nbytes": nbytes,
                        "segment_address": address, "segment_size": size,
                        "block_address": block_address, "block_size": block_size,
                        "expandable_segments": True, "is_expandable": True, "state": "active_allocated"}
    raise ValueError("allocation interval is not contained in one live block of a matching-device expandable segment")
