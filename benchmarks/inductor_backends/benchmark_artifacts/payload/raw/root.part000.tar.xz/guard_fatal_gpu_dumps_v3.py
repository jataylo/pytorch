import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import time


root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--apply', action='store_true')
parser.add_argument('--once', action='store_true')
args = parser.parse_args()
pending = {}
events = root / 'fatal_gpu_dump_guard_v3.jsonl'

while True:
    for core in root.glob('gpucore.*.gpu'):
        try:
            too_small = core.stat().st_size < 1024**3
        except FileNotFoundError:
            continue
        if core.is_symlink() or too_small:
            continue
        match = re.fullmatch(r'gpucore\.(\d+)\.gpu', core.name)
        if match is None:
            continue
        pid = int(match[1])
        proc = Path(f'/proc/{pid}')
        if core.name not in pending:
            try:
                command = (proc / 'cmdline').read_bytes().rstrip(b'\0').split(b'\0')
                command = [item.decode() for item in command]
                if str(root / 'train_worker_v2.py') not in command and not any(
                    item.startswith(str(root / 'train_worker_')) and item.endswith('.py') for item in command
                ):
                    continue
                output = Path(command[command.index('--output') + 1]).resolve()
                relative = output.relative_to(root)
                if not relative.parts[0].startswith('training_results_') or 'raw' not in relative.parts:
                    continue
                log = output.with_suffix('.log')
                with log.open('rb') as stream:
                    start = stream.read(262144)
                    stream.seek(max(0, log.stat().st_size - 262144))
                    text = (start + stream.read()).decode(errors='replace')
                fatal = ('Memory access fault by GPU' in text or
                         ('Callback: Queue' in text and 'HSA_STATUS_ERROR' in text))
                if not fatal or 'Falling back to file-based dump' not in text:
                    continue
                evidence = {'time': time.time(), 'pid': pid, 'core': str(core), 'core_bytes': core.stat().st_size,
                            'log': str(log), 'output': str(output), 'command': command,
                            'action': 'kill_only_fatally_failed_dump_writer' if args.apply else 'dry_run',
                            'reason': 'Fatal GPU fault is already recorded; avoid unrequested multi-GB core filling shared disk. Controllers and healthy workers are untouched.'}
                with events.open('a') as stream:
                    stream.write(json.dumps(evidence) + '\n')
                print(json.dumps(evidence), flush=True)
                if not args.apply:
                    continue
                pending[core.name] = evidence
                os.kill(pid, signal.SIGKILL)
            except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError, IndexError):
                continue
        if core.name in pending:
            try:
                if proc.exists() and 'State:\tZ' not in (proc / 'status').read_text():
                    continue
                size = core.stat().st_size
                with core.open('rb') as stream:
                    first = stream.read(65536)
                    stream.seek(max(0, size - 65536))
                    last = stream.read(65536)
                evidence = {**pending[core.name], 'removed_at': time.time(), 'final_core_bytes': size,
                            'first_64k_sha256': hashlib.sha256(first).hexdigest(),
                            'last_64k_sha256': hashlib.sha256(last).hexdigest()}
                (root / f'{core.name}.recovery.json').write_text(json.dumps(evidence, indent=2) + '\n')
                core.unlink()
                del pending[core.name]
                print(json.dumps({'removed_incomplete_core': core.name, 'bytes': size}), flush=True)
            except (FileNotFoundError, ProcessLookupError):
                continue
    if args.once:
        break
    time.sleep(2)
