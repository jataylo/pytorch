from pathlib import Path
p=Path(__file__).parent/'pytorch/torch/_inductor/codegen/flydsl/flydsl_simd_runtime.py'
s=p.read_text()
a=s.index('def pick_fastest(')
b=s.index('\ndef _pick_path(',a)
s=s[:a]+'''class BackendSelector:
    """Select a supported kernel's backend once, then call its launcher directly."""

    def __init__(self, mains, mutated, warm, kernel_name, stage):
        self.mains = mains
        self.mutated = mutated
        self.warm = warm
        self.metadata = {"category": "backend_selection", "kernel_name": kernel_name,
                         "stage": stage, "backends": ["flydsl", "triton"]}
        self.run = self._select

    def _select(self, *args, stream=None):
        import torch
        if torch.cuda.is_current_stream_capturing():
            self.mains[0](*args, stream=stream)
            return
        best = pick_fastest(self.mains, args, self.mutated, stream, self.warm, self.metadata)
        if best is not None:
            from torch._dynamo.utils import counters
            index = self.mains.index(best)
            counters["flydsl_simd"][f"selected_{self.metadata['backends'][index]}"] += 1
            self.run = best


def pick_fastest(mains, args, mutated, stream=None, warm=None, metadata=None):
    """Measure candidates in modeled cache context; keep the heuristic on close ties."""
    import statistics
    import torch
    from .flydsl_diagnostics import record_kernel_decision

    def report(best, times=None, **extra):
        index = mains.index(best)
        entry = {**(metadata or {}), "category": (metadata or {}).get("category", "autotune_selection"),
                 "kernel_name": (metadata or {}).get("kernel_name", mains[0].__name__),
                 "candidates": [m.__name__ for m in mains], "candidate_times_ms": times,
                 "selected_candidate": index, **extra}
        if metadata and "backends" in metadata:
            entry["selected_backend"] = metadata["backends"][index]
        record_kernel_decision(entry)

    if torch.cuda.is_current_stream_capturing():
        mains[0](*args, stream=stream)
        return None
    path = _pick_path(mains)
    try:
        with open(path) as f:
            best = next(m for m in mains if m.__name__ == f.read().strip())
        best(*args, stream=stream)
        report(best, cache_hit=True)
        return best
    except (OSError, TypeError, StopIteration):
        pass
    device = next(a.device for a in args if isinstance(a, torch.Tensor))
    mutated_storages = {args[i].untyped_storage()._cdata for i in mutated}
    originals = {a.untyped_storage()._cdata: a for a in args
                 if isinstance(a, torch.Tensor) and a.untyped_storage()._cdata in mutated_storages}
    needed = sum(a.untyped_storage().nbytes() for a in originals.values())
    free, _ = torch.cuda.mem_get_info(device)
    if needed + (256 << 20) > free // 2:
        mains[0](*args, stream=stream)
        report(mains[0], reason="insufficient scratch memory", cache_hit=False)
        return mains[0]
    copies = {}
    for key, arg in originals.items():
        original = torch.empty(0, dtype=torch.uint8, device=device).set_(arg.untyped_storage())
        copies[key] = (original, original.clone())
    scratch = []
    for arg in args:
        if isinstance(arg, torch.Tensor) and arg.untyped_storage()._cdata in copies:
            storage = copies[arg.untyped_storage()._cdata][1].untyped_storage()
            arg = torch.empty(0, dtype=arg.dtype, device=device).set_(
                storage, arg.storage_offset(), arg.size(), arg.stride())
        scratch.append(arg)

    def restore():
        for original, copied in copies.values():
            copied.copy_(original)

    for fn in mains:
        restore()
        fn(*scratch, stream=stream)
    flush = torch.empty((256 if warm is not None else 16) << 20, dtype=torch.int8, device=device)
    warm_bufs = [torch.empty(0, dtype=torch.uint8, device=device).set_(scratch[i].untyped_storage())
                 for i in (warm or ()) if isinstance(scratch[i], torch.Tensor)]

    def before():
        flush.zero_()
        restore()
        for t in warm_bufs:
            t.add_(0)

    ev = [torch.cuda.Event(enable_timing=True) for _ in range(2)]
    restore()
    ev[0].record()
    mains[0](*scratch, stream=stream)
    ev[1].record()
    ev[1].synchronize()
    reps = max(1, min(10, int(0.3 / max(ev[0].elapsed_time(ev[1]), 1e-3))))

    def measure(fns):
        samples = [[] for _ in fns]
        sleep_us = len(fns) * reps * 4 * 60
        rounds = 0
        for _ in range(12):
            begin = _time.perf_counter()
            # Conservative cycle budget for supported CDNA devices.
            torch.cuda._sleep(int(sleep_us * 4000))
            events = []
            for j in range(len(fns)):
                index = (rounds + j) % len(fns)
                pairs = []
                for _ in range(reps):
                    before()
                    pair = [torch.cuda.Event(enable_timing=True) for _ in range(2)]
                    pair[0].record()
                    fns[index](*scratch, stream=stream)
                    pair[1].record()
                    pairs.append(pair)
                events.append((index, pairs))
            queued_us = (_time.perf_counter() - begin) * 1e6
            events[-1][1][-1][1].synchronize()
            if queued_us > sleep_us:
                sleep_us *= 2
                continue
            for index, pairs in events:
                samples[index].append(sum(a.elapsed_time(b) for a, b in pairs) / reps)
            rounds += 1
            if rounds == 5:
                return samples
        return None

    samples = measure(mains)
    if samples is None:
        mains[0](*args, stream=stream)
        report(mains[0], reason="host could not queue stable measurements", cache_hit=False)
        return mains[0]
    times = [statistics.median(values) for values in samples]
    close = sorted(range(len(mains)), key=times.__getitem__)[:3]
    if len(close) > 1 and times[close[1]] <= times[close[0]] * 1.03:
        close = list(dict.fromkeys([0, *close]))
        extra = measure([mains[i] for i in close])
        if extra is not None:
            for index, values in zip(close, extra):
                times[index] = statistics.median([*samples[index], *values])
    index = min(range(len(mains)), key=times.__getitem__)
    if times[index] >= times[0] * 0.98:
        index = 0
    best = mains[index]
    if path is not None:
        tmp = f"{path}.{_os.getpid()}"
        try:
            _os.makedirs(_os.path.dirname(path), exist_ok=True)
            with open(tmp, "w") as f:
                f.write(best.__name__)
            _os.replace(tmp, path)
        except OSError:
            pass
    best(*args, stream=stream)
    report(best, times, cache_hit=False, repeats_per_round=reps, rounds=5)
    return best

''' +s[b:]
s=s.replace('[torch.cuda.get_device_properties().gcnArchName, *(m.__name__ for m in mains)]', '[str(torch.cuda.get_device_properties()), torch.version.hip or "", *(m.__name__ for m in mains)]')
p.write_text(s)
