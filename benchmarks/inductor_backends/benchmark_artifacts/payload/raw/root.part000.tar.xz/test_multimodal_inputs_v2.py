import sys
from types import SimpleNamespace
from unittest.mock import patch

import torch
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase
from transformers.models.qwen3_5.configuration_qwen3_5 import Qwen3_5Config, Qwen3_5TextConfig, Qwen3_5VisionConfig
from transformers.models.qwen3_5.modeling_qwen3_5 import Qwen3_5Model
from transformers.models.qwen3_5_moe.configuration_qwen3_5_moe import Qwen3_5MoeConfig, Qwen3_5MoeTextConfig, Qwen3_5MoeVisionConfig
from transformers.models.qwen3_5_moe.modeling_qwen3_5_moe import Qwen3_5MoeModel
from transformers.processing_utils import ProcessorMixin

from multimodal_inputs_v2 import with_mm_token_type_ids


@instantiate_parametrized_tests
class TestMultimodalInputs(TestCase):
    def model(self, kind='dense'):
        config_type, text_type, vision_type, model_type = (
            (Qwen3_5Config, Qwen3_5TextConfig, Qwen3_5VisionConfig, Qwen3_5Model) if kind == 'dense' else
            (Qwen3_5MoeConfig, Qwen3_5MoeTextConfig, Qwen3_5MoeVisionConfig, Qwen3_5MoeModel)
        )
        text = text_type(vocab_size=128, hidden_size=16, intermediate_size=32, num_hidden_layers=1,
                         num_attention_heads=2, num_key_value_heads=2, head_dim=8, layer_types=['full_attention'])
        vision = vision_type(depth=1, hidden_size=16, intermediate_size=32, num_heads=2,
                             patch_size=2, temporal_patch_size=1, spatial_merge_size=2,
                             out_hidden_size=16, num_position_embeddings=16)
        config = config_type(text_config=text, vision_config=vision, image_token_id=61, video_token_id=62)
        model = object.__new__(model_type)
        torch.nn.Module.__init__(model)
        model.config = config
        model.rope_deltas = None
        self.assertEqual(sum(parameter.numel() for parameter in model.parameters()), 0)
        return model

    @parametrize('kind', ['dense', 'moe'])
    def test_official_rope_image_and_video(self, kind):
        model = self.model(kind)
        inputs = {'input_ids': torch.tensor([[5, 61, 61, 61, 61, 6, 62, 62, 7, 62, 62, 8]]),
                  'image_grid_thw': torch.tensor([[1, 4, 4]]), 'video_grid_thw': torch.tensor([[2, 2, 4]]),
                  'pixel_values': torch.randn(16, 12), 'pixel_values_videos': torch.randn(16, 12)}
        with self.assertRaisesRegex(ValueError, 'mm_token_type_ids.*missing'):
            model.compute_3d_position_ids(inputs['input_ids'], None, inputs['image_grid_thw'], inputs['video_grid_thw'])
        updated = with_mm_token_type_ids(model, inputs)
        expected_tags = torch.tensor([[0, 1, 1, 1, 1, 0, 2, 2, 0, 2, 2, 0]])
        self.assertEqual(updated['mm_token_type_ids'], expected_tags)
        processor = SimpleNamespace(image_token_ids=[61], video_token_ids=[62], audio_token_ids=[])
        official_tags = ProcessorMixin.create_mm_token_type_ids(processor, inputs['input_ids'].tolist())
        self.assertEqual(updated['mm_token_type_ids'], torch.tensor(official_tags))
        position, delta = model.get_rope_index(inputs['input_ids'], updated['mm_token_type_ids'],
                                              inputs['image_grid_thw'], inputs['video_grid_thw'])
        expected = torch.tensor([[[0, 1, 1, 1, 1, 3, 4, 4, 6, 7, 7, 9]],
                                 [[0, 1, 1, 2, 2, 3, 4, 4, 6, 7, 7, 9]],
                                 [[0, 1, 2, 1, 2, 3, 4, 5, 6, 7, 8, 9]]])
        self.assertEqual(position, expected)
        self.assertEqual(delta, torch.tensor([[-2]]))
        self.assertEqual(model.compute_3d_position_ids(inputs['input_ids'], None, inputs['image_grid_thw'],
                                                      inputs['video_grid_thw'], mm_token_type_ids=updated['mm_token_type_ids']), expected)
        for key, value in inputs.items():
            self.assertIs(updated[key], value)
        self.assertNotIn('mm_token_type_ids', inputs)

    @parametrize('kind', ['dense', 'moe'])
    def test_existing_suite_image_placeholders(self, kind):
        sys.path.insert(0, '/dockerx/Triton_Conv_Development/scripts')
        import common
        model = self.model(kind)
        text = torch.tensor([[4, 5], [6, 7]])
        with patch.object(common, 'VL_IMAGE_SIZE', 8):
            inputs = common._grid_vision_inputs(model.config, model.config.vision_config, text, 'cpu')
        self.assertEqual(inputs['pixel_values'].shape, (32, 12))
        self.assertEqual(inputs['image_grid_thw'], torch.tensor([[1, 4, 4], [1, 4, 4]]))
        updated = with_mm_token_type_ids(model, inputs)
        self.assertEqual(updated['mm_token_type_ids'], torch.tensor([[0, 0, 1, 1, 1, 1]] * 2))
        position, delta = model.get_rope_index(updated['input_ids'], updated['mm_token_type_ids'],
                                              image_grid_thw=updated['image_grid_thw'],
                                              attention_mask=updated['attention_mask'])
        expected = torch.tensor([[[0, 1, 2, 2, 2, 2]] * 2,
                                 [[0, 1, 2, 2, 3, 3]] * 2,
                                 [[0, 1, 2, 3, 2, 3]] * 2])
        self.assertEqual(position, expected)
        self.assertEqual(delta, torch.tensor([[-2], [-2]]))
        self.assertEqual(updated['input_ids'][:, :2], text)
        for key, value in inputs.items():
            self.assertIs(updated[key], value)

    @parametrize('dtype', [torch.int32, torch.int64])
    def test_alias_metadata_and_unmodified_inputs(self, dtype):
        model = SimpleNamespace(config=SimpleNamespace(image_token_index=11, video_token_index=12))
        inputs = {'input_ids': torch.tensor([[3, 11, 12, 4]], dtype=dtype), 'attention_mask': torch.tensor([[1, 1, 1, 0]]),
                  'pixel_values': torch.randn(1, 3), 'video_grid_thw': torch.tensor([[1, 2, 2]]),
                  'metadata': {'keep': True}}
        before = inputs['input_ids'].clone()
        updated = with_mm_token_type_ids(model, inputs)
        self.assertEqual(updated['mm_token_type_ids'], torch.tensor([[0, 1, 2, 0]]))
        self.assertEqual(inputs['input_ids'], before)
        for key, value in inputs.items():
            self.assertIs(updated[key], value)
        self.assertIsNot(updated, inputs)

    def test_existing_tags_are_preserved_without_metadata(self):
        tags = torch.tensor([[0, 1, 2]])
        inputs = {'mm_token_type_ids': tags, 'pixel_values': torch.randn(1, 3)}
        updated = with_mm_token_type_ids(None, inputs)
        self.assertIs(updated['mm_token_type_ids'], tags)
        self.assertIs(updated['pixel_values'], inputs['pixel_values'])

    @parametrize('kind', ['dense', 'moe'])
    def test_official_rope_ignores_padding(self, kind):
        model = self.model(kind)
        inputs = {'input_ids': torch.tensor([[4, 5, 61, 61, 61, 61, 0, 0], [0, 0, 4, 5, 61, 61, 61, 61]]),
                  'attention_mask': torch.tensor([[1, 1, 1, 1, 1, 1, 0, 0], [0, 0, 1, 1, 1, 1, 1, 1]]),
                  'image_grid_thw': torch.tensor([[1, 4, 4], [1, 4, 4]])}
        updated = with_mm_token_type_ids(model, inputs)
        position, delta = model.get_rope_index(updated['input_ids'], updated['mm_token_type_ids'],
                                              image_grid_thw=updated['image_grid_thw'],
                                              attention_mask=updated['attention_mask'])
        expected = torch.tensor([[[0, 1, 2, 2, 2, 2, 0, 0], [0, 0, 0, 1, 2, 2, 2, 2]],
                                 [[0, 1, 2, 2, 3, 3, 0, 0], [0, 0, 0, 1, 2, 2, 3, 3]],
                                 [[0, 1, 2, 3, 2, 3, 0, 0], [0, 0, 0, 1, 2, 3, 2, 3]]])
        self.assertEqual(position, expected)
        self.assertEqual(delta, torch.tensor([[-2], [-2]]))
        self.assertIs(updated['attention_mask'], inputs['attention_mask'])

    @parametrize('config,inputs,pattern', [
        (None, {'input_ids': torch.tensor([[1]])}, 'model.config'),
        (SimpleNamespace(), {'input_ids': torch.tensor([[1]])}, 'token_id/index'),
        (SimpleNamespace(image_token_id=11), {}, 'input_ids'),
        (SimpleNamespace(image_token_id=11), {'input_ids': torch.tensor([11])}, 'rank-two'),
        (SimpleNamespace(image_token_id=11), {'input_ids': torch.tensor([[11.]])}, 'integer input_ids'),
        (SimpleNamespace(image_token_id='11'), {'input_ids': torch.tensor([[11]])}, 'must be an integer'),
        (SimpleNamespace(image_token_id=11, image_token_index=13), {'input_ids': torch.tensor([[11]])}, 'Conflicting image'),
        (SimpleNamespace(image_token_id=11, video_token_id=11), {'input_ids': torch.tensor([[11]])}, 'must be distinct'),
        (SimpleNamespace(video_token_id=12), {'input_ids': torch.tensor([[12]]), 'pixel_values': torch.randn(1, 3)}, 'lacks image'),
        (SimpleNamespace(image_token_id=11), {'input_ids': torch.tensor([[2]]), 'image_grid_thw': torch.tensor([[1, 2, 2]])}, 'no image placeholder'),
    ])
    def test_invalid_or_ambiguous_metadata(self, config, inputs, pattern):
        with self.assertRaisesRegex(ValueError, pattern):
            with_mm_token_type_ids(SimpleNamespace(config=config), inputs)


if __name__ == '__main__':
    run_tests()
