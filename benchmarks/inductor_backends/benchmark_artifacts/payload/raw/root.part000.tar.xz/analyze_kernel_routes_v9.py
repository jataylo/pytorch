import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).resolve().parent
SUCCESS = {'ok', 'validation_unavailable', 'reference_unavailable'}


def read_records(directory):
    records = {}
    for path in (directory / 'raw').glob('*/flydsl_autotune*.json'):
        data = path.read_bytes()
        record = json.loads(data)
        record['_source'] = str(path)
        record['_source_sha256'] = hashlib.sha256(data).hexdigest()
        records[record['suite'], record['model'], int(record['autotune'])] = record
    return records


def valid_times(event):
    values = event.get('candidate_times_ms')
    return bool(isinstance(values, list) and len(values) == 2 and all(
        isinstance(value, (int, float)) and math.isfinite(value) and value > 0 for value in values))


def operations(event):
    return sorted(set(re.findall(r'\baten\.[A-Za-z_0-9]+', event.get('origins') or '')))


def inspect_record(record):
    path = Path(record.get('diagnostics_file', '/nonexistent'))
    if not path.exists():
        expected = record['status'] == 'capacity_skip' or record.get('phase') in {'model_capacity', 'model_load'}
        return [], dict(record=record['_source'], diagnostic=str(path),
                        **({'expected_no_codegen': True} if expected else {'issue': 'diagnostics_missing'}))
    lowered, choices, skipped, eligible = {}, defaultdict(list), {}, set()
    malformed = []
    with path.open() as source:
        for line_number, line in enumerate(source, 1):
            try:
                event = json.loads(line)
            except ValueError:
                malformed.append(line_number)
                continue
            if event.get('attempt_id') != record.get('attempt_id') or event.get('rank') != 0 or event.get('phase') not in {'warmup', 'timing'}:
                continue
            name = event.get('kernel_name')
            if not name:
                continue
            event['_line'] = line_number
            category = event.get('category')
            if category == 'lowered':
                lowered[name] = {key: event.get(key) for key in ['backend', 'reason', 'stage', 'is_backward', 'graph_id', 'origins', 'buffers', 'nodes', '_line']}
            elif category == 'backend_selection':
                choices[name].append(event)
            elif category == 'selection_skipped':
                skipped[name] = event
            elif category == 'backend_candidates':
                eligible.add(name)
    rows = []
    for name in sorted(set(lowered) | set(choices) | set(skipped)):
        metadata = lowered.get(name, {})
        selected = choices.get(name, [])
        winners = {event.get('selected_backend') for event in selected}
        timed = [event for event in selected if valid_times(event)]
        chosen = timed[-1] if timed else (selected[-1] if selected else {})
        if len(winners) > 1:
            direction, origin = 'conflicting_choices', 'multiple recorded choices for same name'
        elif selected:
            direction, origin = chosen.get('selected_backend'), 'performance_selection'
        elif name in skipped:
            direction, origin = 'flydsl', 'selection_skipped_uses_flydsl'
        elif metadata.get('backend') == 'triton':
            direction, origin = 'triton', 'unsupported_flydsl_lowering_fallback'
        elif name in eligible:
            direction, origin = 'unknown', 'no_recorded_selection'
        else:
            direction, origin = metadata.get('backend', 'unknown'), 'direct_lowering_no_selector'
        ops = operations(metadata)
        buffers = metadata.get('buffers') or {}
        shapes = sorted({str(value.get('shape')) for value in buffers.values()})
        dtypes = sorted({str(value.get('dtype')) for value in buffers.values()})
        row = dict(model=record['model'], suite=record['suite'], autotune=record['autotune'],
                   tuning='expanded' if record['autotune'] else 'standard', world_size=record['world_size'],
                   gpu_group=record['physical_gpu'], rank=0, model_status=record['status'],
                   completed_training=record['status'] in SUCCESS,
                   validation_tier='eager_validated' if record['status']=='ok' else 'training_only' if record['status'] in SUCCESS else record['status'],
                   kernel_name=name, stage=metadata.get('stage') or chosen.get('stage'),
                   is_backward=metadata.get('is_backward'), selected_backend=direction, decision_source=origin,
                   ops=';'.join(ops), fused_op_count=len(ops), dtypes=';'.join(dtypes),
                   shape_summary='; '.join(shapes[:8]), buffers_json=json.dumps(buffers),
                   selection_skip_reason=skipped.get(name, {}).get('reason', ''),
                   fallback_reason=metadata.get('reason'), timing_available=bool(timed),
                   cache_hit=chosen.get('cache_hit'), selection_events=len(selected),
                   diagnostic_file=str(path), selection_line=chosen.get('_line'), lowering_line=metadata.get('_line'),
                   record_source=record['_source'], original_aten=metadata.get('origins'))
        if timed and len(winners) == 1:
            values = chosen['candidate_times_ms']
            fly, tri = values
            delta = 100 * (tri - fly) / tri
            row.update(flydsl_us=fly*1000, triton_us=tri*1000, flydsl_time_saved_us=(tri-fly)*1000,
                       flydsl_speedup_percent=delta, triton_over_flydsl=tri/fly,
                       measured_winner='flydsl' if tri/fly>1.03 else 'triton' if tri/fly<1/1.03 else 'within_3_percent',
                       timing_reason=chosen.get('reason', 'measured'), rounds=chosen.get('rounds'))
        else:
            row.update(flydsl_us=None, triton_us=None, flydsl_time_saved_us=None, flydsl_speedup_percent=None,
                       triton_over_flydsl=None, measured_winner='unknown',
                       timing_reason='conflicting choices' if len(winners)>1 else 'cached choice; timing not logged here' if selected and chosen.get('cache_hit') else chosen.get('reason') or origin)
        rows.append(row)
    return rows, dict(record=record['_source'], diagnostic=str(path), malformed_lines=malformed,
                      selected_names=len(choices), lowered_names=len(lowered), rows=len(rows))


def grouped(rows, key):
    groups = defaultdict(list)
    for row in rows:
        if key == 'ops':
            labels = row['ops'].split(';') if row['ops'] else ['unknown_origin']
        else:
            labels = [str(row.get(key) or 'unknown')]
        for label in labels:
            groups[row['tuning'], row['validation_tier'], label].append(row)
    result = []
    for (tuning, tier, label), members in groups.items():
        performance = [row for row in members if row['decision_source']=='performance_selection']
        timed = [row for row in performance if row['triton_over_flydsl']]
        ratios = [row['triton_over_flydsl'] for row in timed]
        result.append(dict(tuning=tuning, validation_tier=tier, group=label, kernel_contexts=len(members),
            models=len({row['model'] for row in members}), performance_selected=len(performance),
            selected_flydsl=sum(row['selected_backend']=='flydsl' for row in performance),
            selected_triton=sum(row['selected_backend']=='triton' for row in performance),
            timed_contexts=len(timed), timing_coverage_percent=100*len(timed)/len(performance) if performance else None, clear_flydsl_wins=sum(row['measured_winner']=='flydsl' for row in timed),
            clear_triton_wins=sum(row['measured_winner']=='triton' for row in timed),
            within3percent=sum(row['measured_winner']=='within_3_percent' for row in timed),
            geomean_triton_over_flydsl=statistics.geometric_mean(ratios) if ratios else None,
            median_flydsl_time_saved_us=statistics.median(row['flydsl_time_saved_us'] for row in timed) if timed else None,
            selection_skipped=sum(row['decision_source']=='selection_skipped_uses_flydsl' for row in members)))
    return sorted(result,key=lambda row:(row['tuning'],row['validation_tier'],-row['timed_contexts'],row['group']))


def write_csv(path, rows):
    fields = list(rows[0]) + sorted(set().union(*(row.keys() for row in rows)) - set(rows[0])) if rows else ['model','kernel_name']
    with path.open('w',newline='') as output:
        writer=csv.DictWriter(output,fieldnames=fields)
        writer.writeheader();writer.writerows(rows)


def main(output):
    records=read_records(ROOT/'training_results_mixed_single_v5')
    records.update({key:value for key,value in read_records(ROOT/'training_results_mixed_multi_v6').items() if value['status']!='started'})
    rows, issues, inputs=[],[],{}
    for record in records.values():
        found, issue=inspect_record(record)
        rows.extend(found);issues.append(issue);inputs[record['_source']]=record['_source_sha256']
    good=[row for row in rows if row['completed_training']]
    measured=[row for row in good if row['decision_source']=='performance_selection' and row['triton_over_flydsl']]
    fly=sorted([row for row in measured if row['measured_winner']=='flydsl'],key=lambda row:row['flydsl_time_saved_us'],reverse=True)
    tri=sorted([row for row in measured if row['measured_winner']=='triton'],key=lambda row:row['flydsl_time_saved_us'])
    output.mkdir(parents=True,exist_ok=True)
    write_csv(output/'per_kernel_routes.csv',rows)
    write_csv(output/'by_stage.csv',grouped(good,'stage'))
    write_csv(output/'kernels_containing_each_aten_op.csv',grouped(good,'ops'))
    write_csv(output/'largest_flydsl_wins.csv',fly)
    write_csv(output/'largest_triton_wins.csv',tri)
    write_csv(output/'selection_skips.csv',[row for row in rows if row['decision_source']=='selection_skipped_uses_flydsl'])
    summary=dict(generated_utc=datetime.now(timezone.utc).isoformat(),scope='Current mixed run, final current placement, rank0, warmup/timing only, unique kernel name per model/tuning/placement; not runtime launch counts',
        all_kernel_contexts=len(rows),completed_training_contexts=len(good),
        selected_backends=dict(Counter(row['selected_backend'] for row in good if row['decision_source']=='performance_selection')),
        cached_or_untimed_selected=sum(row['decision_source']=='performance_selection' and not row['triton_over_flydsl'] for row in good),
        timing_coverage_note='The timed subset is not representative of all selected kernels: cached choices omit timings. Do not infer overall backend win rates from timed subset counts.',
        timed_comparisons=len(measured),measured_winners=dict(Counter(row['measured_winner'] for row in measured)),
        timed_by_stage=grouped(good,'stage'),issues=[issue for issue in issues if issue.get('issue') or issue.get('malformed_lines')])
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    inputs[str(Path(__file__).resolve())] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (output/'input_provenance.json').write_text(json.dumps(inputs,indent=2)+'\n')
    (output/'README.txt').write_text('Per-kernel backend selection with joined lowering metadata, original ATen ancestry, buffer shapes/dtypes and autotuner times. Timings are kernel microbenchmarks, not full-model time contributions. Kernel ops are fused: an op appearing in a winning kernel does not prove a standalone implementation win. Stage/op summaries include completed successful training, split eager-validated/training-only, and exclude warnings/failed records. The timed subset is not representative because cached choices omit timings; never infer overall backend win rates from that subset. Cached choices without timings remain unknown speed; near ties can select FlyDSL and are not counted as clear wins. Skips use FlyDSL without a performance comparison and are separate. Per-op counts overlap across fused origins; never sum them as independent kernels. Rank0 only; no dynamic frequency or invocation weighting.\n')
    print(json.dumps({key:value for key,value in summary.items() if key!='timed_by_stage'},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'kernel_routes_v9')
    args=parser.parse_args();main(args.output)
