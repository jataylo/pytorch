"""Read-only static wrapper inventory; it never imports or executes cached code."""
import argparse
import ast
from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re


@dataclass(frozen=True)
class Binding:
    kernels: frozenset = frozenset()
    symbols: frozenset = frozenset()
    uncertain: bool = False

    def merge(self, other, uncertain=False):
        return Binding(self.kernels | other.kernels, self.symbols | other.symbols,
                       self.uncertain or other.uncertain or uncertain)


def normalize_metadata(value):
    return '\n'.join(' '.join(line.split()) for line in (value or '').splitlines() if line.strip())


def native_category(symbol):
    name = symbol.replace('torch.ops.aten.', 'aten.').replace('extern_kernels.', 'aten.')
    if not name.startswith('aten.'):
        return 'other_external' if symbol.startswith('torch.ops.') else None
    operation = name.split('.')[1]
    mandated = {'mm', 'addmm', 'bmm', 'baddbmm', 'matmul', 'linear', 'convolution', 'convolution_backward',
                '_convolution', 'conv1d', 'conv2d', 'conv3d', '_scaled_mm', '_grouped_mm', 'grouped_mm'}
    return 'mandated_aten_gemm_conv' if operation in mandated else 'other_aten_external'


class WrapperInventory:
    def __init__(self, source):
        self.source = source
        self.sha256 = hashlib.sha256(source.encode()).hexdigest()
        self.tree = ast.parse(source)
        self.lines = source.splitlines(keepends=True)
        self.offsets = [0]
        for line in self.lines:
            self.offsets.append(self.offsets[-1] + len(line))
        self.definitions = []
        self.definition_nodes = {}
        self.constants = {}
        self.env = {}
        self.functions = {}
        self.class_methods = {}
        self.launches = {}
        self.native_calls = {}
        self.unresolved = {}
        self.pending = []
        self.visited = set()
        self.entrypoints = []
        self.collect_functions(self.tree.body)

    def collect_functions(self, body, prefix=''):
        for node in body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                name = prefix + node.name
                self.functions[name] = (node, {})
                if not prefix:
                    self.env[node.name] = Binding(symbols=frozenset([name]))
                else:
                    self.class_methods[name] = node
            elif isinstance(node, ast.ClassDef):
                self.env[node.name] = Binding(symbols=frozenset([node.name]))
                self.collect_functions(node.body, node.name + '.')

    def string(self, node):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.NamedExpr):
            value = self.string(node.value)
            if isinstance(node.target, ast.Name) and value is not None:
                self.constants[node.target.id] = value
            return value
        if isinstance(node, ast.Name):
            return self.constants.get(node.id)
        return None

    def metadata(self, line):
        end = self.offsets[line - 1]
        start = self.source.rfind('\n# Topologically Sorted Source Nodes:', 0, end)
        if start < 0:
            return None, None
        text = self.source[start + 1:end]
        if any(value.strip() and not value.lstrip().startswith('#') for value in text.splitlines()):
            return None, None
        parts = text.splitlines()
        return normalize_metadata(parts[0]), normalize_metadata('\n'.join(parts))

    def compiled(self, value, name, scope, env=None):
        if not isinstance(value, ast.Call):
            return None
        api = ast.unparse(value.func)
        symbols = self.resolve(value.func, self.env if env is None else env).symbols
        kind = None
        label_index, source_index = 0, 1
        if api == 'fdp_rt.compiled' or any(symbol.endswith('flydsl_simd_runtime.compiled') for symbol in symbols):
            kind, label_index, source_index = 'flydsl', 1, 2
        elif (api.startswith('async_compile.') or any('.AsyncCompile.' in symbol for symbol in symbols)) and api.rsplit('.', 1)[1] in {
            'triton', 'flydsl', 'cpp', 'cpp_pybinding', 'cuda', 'rocm', 'halide', 'cutedsl'
        }:
            kind = api.rsplit('.', 1)[1]
        if kind is None:
            return None
        if id(value) in self.definition_nodes:
            return Binding(kernels=frozenset([self.definition_nodes[id(value)]]))
        label = self.string(value.args[label_index]) if len(value.args) > label_index else None
        code = self.string(value.args[source_index]) if len(value.args) > source_index else None
        if code is None:
            candidates = [self.string(arg) for arg in value.args]
            code = max((item for item in candidates if item and '\n' in item), key=len, default=None)
        origins, metadata = self.metadata(value.lineno)
        identifier = f'{self.sha256[:20]}:{value.lineno}:{name}'
        precompile = None
        for item in value.keywords:
            if item.arg == 'precompile_metadata':
                try:
                    precompile = ast.literal_eval(item.value)
                except (ValueError, TypeError):
                    precompile = ast.unparse(item.value)
        entrypoints = re.findall(r'^def ([A-Za-z_][A-Za-z_0-9]*)\(', code or '', re.M)
        item = {
            'id': identifier, 'binding': name, 'label': label or name, 'backend': kind,
            'compile_api': api, 'line': value.lineno, 'definition_scope': scope,
            'source_sha256': hashlib.sha256(code.encode()).hexdigest() if code is not None else None,
            'source_available': code is not None, 'entrypoints': entrypoints,
            'precompile_metadata': precompile, 'origins': origins, 'metadata': metadata,
            '_source': code,
        }
        self.definitions.append(item)
        self.definition_nodes[id(value)] = identifier
        return Binding(kernels=frozenset([identifier]))

    def resolve(self, node, env):
        if isinstance(node, ast.Name):
            return env.get(node.id, self.env.get(node.id, Binding(symbols=frozenset([node.id]))))
        if isinstance(node, ast.NamedExpr):
            return self.resolve(node.value, env)
        if isinstance(node, ast.Attribute):
            key = ast.unparse(node)
            if key in env:
                return env[key]
            base = self.resolve(node.value, env)
            symbols = frozenset(f'{name}.{node.attr}' for name in base.symbols)
            kernels = base.kernels if node.attr in {'run', 'launch', 'call', '__call__'} else frozenset()
            for symbol in symbols:
                if symbol in self.env:
                    return self.env[symbol]
            return Binding(kernels, symbols, base.uncertain)
        if isinstance(node, ast.Subscript):
            if isinstance(node.value, (ast.List, ast.Tuple)):
                try:
                    index = ast.literal_eval(node.slice)
                    if type(index) is int:
                        return self.resolve(node.value.elts[index], env)
                except (ValueError, TypeError, IndexError):
                    pass
                value = Binding()
                for child in node.value.elts:
                    value = value.merge(self.resolve(child, env), uncertain=True)
                return value
            return self.resolve(node.value, env)
        if isinstance(node, ast.Call):
            api = ast.unparse(node.func)
            if api in {'async_compile.multi_kernel', 'fdp_rt.backend_choice', 'fdp_rt.select_backend'} or 'MultiKernel' in api:
                result = Binding(uncertain=True)
                for arg in node.args:
                    result = result.merge(self.resolve(arg, env), uncertain=True)
                return result
            symbols = self.resolve(node.func, env).symbols
            if any(symbol.endswith('.partial') for symbol in symbols) and node.args:
                return self.resolve(node.args[0], env)
            classes = {name.rsplit('.', 1)[0] for name in self.class_methods}
            constructors = frozenset(symbol for symbol in symbols if symbol in classes or symbol.endswith('.AsyncCompile'))
            return Binding(symbols=constructors)
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            result = Binding()
            for child in node.elts:
                result = result.merge(self.resolve(child, env), uncertain=len(node.elts) > 1)
            return result
        if isinstance(node, ast.Dict):
            result = Binding()
            for child in node.values:
                result = result.merge(self.resolve(child, env), uncertain=True)
            return result
        return Binding()

    def bind(self, target, value, env, scope):
        key = ast.unparse(target)
        if isinstance(value, ast.Lambda):
            name = f'{scope}.lambda@{value.lineno}:{value.col_offset}'
            function = ast.FunctionDef(name=name, args=value.args, body=[ast.Return(value.body)], decorator_list=[], type_params=[])
            self.functions[name] = (function, dict(env))
            env[key] = Binding(symbols=frozenset([name]))
            return
        compiled = self.compiled(value, key, scope, env)
        env[key] = compiled if compiled is not None else self.resolve(value, env)
        if isinstance(target, ast.Name):
            constant = self.string(value)
            if constant is not None:
                self.constants[target.id] = constant
        if isinstance(target, (ast.Tuple, ast.List)) and isinstance(value, (ast.Tuple, ast.List)):
            for child, expression in zip(target.elts, value.elts):
                self.bind(child, expression, env, scope)

    def expression(self, node, env, scope, conditional):
        if isinstance(node, ast.Call):
            binding = self.resolve(node.func, env)
            method = node.func.attr if isinstance(node.func, ast.Attribute) else 'callable'
            key = (scope, node.lineno, node.col_offset)
            if binding.kernels:
                previous = self.launches.get(key)
                identities = binding.kernels | (frozenset(previous['definition_ids']) if previous else frozenset())
                self.launches[key] = {
                    'scope': scope, 'line': node.lineno, 'column': node.col_offset,
                    'reference': ast.unparse(node.func), 'method': method,
                    'definition_ids': sorted(identities),
                    'dispatch_uncertain': binding.uncertain or len(identities) > 1,
                    'conditional_context': sorted(set(conditional) | set(previous['conditional_context'] if previous else [])),
                }
            else:
                for symbol in binding.symbols:
                    category = native_category(symbol)
                    if category:
                        self.native_calls[(scope, node.lineno, node.col_offset, symbol)] = {
                            'scope': scope, 'line': node.lineno, 'operation': symbol,
                            'category': category, 'call': ast.unparse(node),
                            'conditional_context': list(conditional),
                        }
                    if symbol in self.functions:
                        function, closure = self.functions[symbol]
                        arguments = function.args.posonlyargs + function.args.args
                        bindings = dict(closure)
                        actual = list(node.args)
                        if isinstance(node.func, ast.Attribute) and arguments and arguments[0].arg == 'self':
                            actual = [node.func.value] + actual
                        for parameter, value in zip(arguments, actual):
                            bindings[parameter.arg] = self.resolve(value, env)
                        for keyword in node.keywords:
                            if keyword.arg:
                                bindings[keyword.arg] = self.resolve(keyword.value, env)
                        self.pending.append((symbol, bindings, conditional))
                if isinstance(node.func, ast.Attribute) and method in {'run', 'launch'}:
                    self.unresolved[key] = {'scope': scope, 'line': node.lineno, 'reference': ast.unparse(node.func),
                                            'conditional_context': list(conditional)}
            for child in ast.iter_child_nodes(node):
                self.expression(child, env, scope, conditional)
        elif not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            for child in ast.iter_child_nodes(node):
                self.expression(child, env, scope, conditional)

    def merge_branches(self, env, branches):
        for name in set().union(*(branch.keys() for branch in branches)):
            values = [branch.get(name, Binding()) for branch in branches]
            value = values[0]
            for other in values[1:]:
                if value != other:
                    value = value.merge(other, uncertain=True)
            env[name] = value

    def statements(self, body, env, scope, conditional=(), scan_calls=True):
        for node in body:
            if isinstance(node, ast.Import):
                for alias in node.names:
                    env[alias.asname or alias.name.split('.')[0]] = Binding(symbols=frozenset([alias.name if alias.asname else alias.name.split('.')[0]]))
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    symbol = f'{node.module}.{alias.name}'
                    if symbol == 'torch._inductor.select_algorithm.extern_kernels':
                        symbol = 'extern_kernels'
                    env[alias.asname or alias.name] = Binding(symbols=frozenset([symbol]))
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                if node.value is None:
                    continue
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                for target in targets:
                    self.bind(target, node.value, env, scope)
                if scan_calls and self.compiled(node.value, ast.unparse(targets[0]), scope, env) is None:
                    self.expression(node.value, env, scope, conditional)
            elif isinstance(node, ast.If):
                if scan_calls:
                    self.expression(node.test, env, scope, conditional)
                branches = []
                for label, block in [('if', node.body), ('else', node.orelse)]:
                    branch = dict(env)
                    self.statements(block, branch, scope, conditional + (f'{label}@{node.lineno}',), scan_calls)
                    branches.append(branch)
                for name in set(branches[0]) | set(branches[1]):
                    left, right = branches[0].get(name, Binding()), branches[1].get(name, Binding())
                    env[name] = left if left == right else left.merge(right, uncertain=True)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if scope == '<module>':
                    env[node.name] = Binding(symbols=frozenset([node.name]))
                    continue
                name = scope + '.' + node.name
                self.functions[name] = (node, dict(env))
                env[node.name] = Binding(symbols=frozenset([name]))
            elif isinstance(node, ast.ClassDef):
                if scope == '<module>':
                    env[node.name] = Binding(symbols=frozenset([node.name]))
                continue
            elif isinstance(node, (ast.With, ast.AsyncWith)):
                if scan_calls:
                    for item in node.items:
                        self.expression(item.context_expr, env, scope, conditional)
                self.statements(node.body, env, scope, conditional, scan_calls)
            elif isinstance(node, (ast.For, ast.AsyncFor, ast.While)):
                before = dict(env)
                loop = dict(env)
                if isinstance(node, (ast.For, ast.AsyncFor)):
                    self.bind(node.target, node.iter, loop, scope)
                    if scan_calls:
                        self.expression(node.iter, env, scope, conditional)
                elif scan_calls:
                    self.expression(node.test, env, scope, conditional)
                self.statements(node.body, loop, scope, conditional + (f'loop@{node.lineno}',), scan_calls)
                self.merge_branches(env, [before, loop])
                normal = dict(env)
                self.statements(node.orelse, normal, scope, conditional + (f'loop_else@{node.lineno}',), scan_calls)
                self.merge_branches(env, [dict(env), normal])
            elif isinstance(node, ast.Try):
                before = dict(env)
                normal = dict(env)
                self.statements(node.body, normal, scope, conditional + (f'try@{node.lineno}',), scan_calls)
                exceptional = dict(env)
                self.merge_branches(exceptional, [before, normal])
                self.statements(node.orelse, normal, scope, conditional + (f'try_else@{node.lineno}',), scan_calls)
                branches = [normal]
                for handler in node.handlers:
                    branch = dict(exceptional)
                    self.statements(handler.body, branch, scope, conditional + (f'except@{handler.lineno}',), scan_calls)
                    branches.append(branch)
                self.merge_branches(env, branches)
                self.statements(node.finalbody, env, scope, conditional, scan_calls)
            elif scan_calls:
                self.expression(node, env, scope, conditional)

    def run(self):
        self.statements(self.tree.body, self.env, '<module>', scan_calls=False)
        for name, function in self.class_methods.items():
            if name.endswith('.__init__'):
                env = dict(self.env)
                env['self'] = Binding(symbols=frozenset([name.rsplit('.', 1)[0]]))
                self.statements(function.body, env, name, scan_calls=False)
                for key, value in env.items():
                    if key.startswith('self.'):
                        self.env[name.rsplit('.', 1)[0] + key[4:]] = value
        names = self.env.get('call', Binding()).symbols
        self.entrypoints = sorted(name for name in names if name in self.functions)
        if not self.entrypoints and 'Runner.call' in self.functions:
            self.entrypoints = ['Runner.call']
        for name in self.entrypoints:
            env = {}
            if '.' in name and not name.startswith('<module>'):
                env['self'] = Binding(symbols=frozenset([name.rsplit('.', 1)[0]]))
            self.pending.append((name, env, ()))
        while self.pending:
            name, bindings, conditional = self.pending.pop()
            signature = (name, tuple(sorted((key, tuple(sorted(value.kernels)), tuple(sorted(value.symbols))) for key, value in bindings.items())))
            if signature in self.visited:
                continue
            self.visited.add(signature)
            function, closure = self.functions[name]
            env = {**self.env, **closure, **bindings}
            self.statements(function.body, env, name, conditional)
        for definition in self.definitions:
            if definition['metadata'] is None:
                for parent in self.definitions:
                    if parent['metadata'] and parent['label'] == definition['label'] and parent['source_sha256'] == definition['source_sha256']:
                        definition['origins'], definition['metadata'] = parent['origins'], parent['metadata']
                        definition['metadata_inherited_from'] = parent['id']
                        break
        aot = re.search(r'^# AOT ID: (.+)$', self.source, re.M)
        token = aot.group(1) if aot else None
        result = {'sha256': self.sha256, 'aot_id': token, 'definitions': self.definitions,
                  'launch_sites': list(self.launches.values()), 'native_calls': list(self.native_calls.values()),
                  'unresolved_launch_sites': list(self.unresolved.values()),
                  'entrypoint_scopes': self.entrypoints}
        return result


def context_key(value, path=None):
    filename = Path(path).name if path else ''
    mode = re.match(r'(flydsl|triton)_autotune([01])', filename)
    location = re.search(r'world(\d+)\.rank(\d+)', filename)
    requested = value.get('requested_backend') or (mode.group(1) if mode else value.get('backend'))
    return (str(value.get('attempt_id', 'unknown')), requested,
            int(value.get('autotune', mode.group(2) if mode else -1)),
            int(value.get('rank', location.group(2) if location else 0)),
            int(value.get('world_size', location.group(1) if location else 1)), value.get('model'), value.get('suite'))


def read_records(roots):
    records = {}
    errors = []
    files = 0
    for root in roots:
        for path in root.rglob('*autotune*.json'):
            if path.parent.name == 'codegen' or not re.match(r'^(flydsl|triton)_autotune[01](?:\.world\d+\.rank\d+)?\.json$', path.name):
                continue
            try:
                value = json.loads(path.read_text())
                if not isinstance(value, dict) or 'model' not in value:
                    continue
                key = context_key(value, path)
            except (ValueError, OSError, TypeError) as exc:
                errors.append({'path': str(path), 'error': str(exc)})
                continue
            files += 1
            cache = value.get('inductor_cache')
            identity = (*key, cache, value.get('model'), value.get('suite'))
            uid = hashlib.sha256(json.dumps(identity).encode()).hexdigest()[:24]
            if uid not in records:
                records[uid] = {
                    'id': uid, 'attempt_id': key[0], 'requested_backend': key[1], 'autotune': key[2],
                    'rank': key[3], 'world_size': key[4], 'model': value.get('model'), 'suite': value.get('suite'),
                    'inductor_cache': cache, 'source_fingerprint': value.get('source_fingerprint', {}).get('sha256')
                    if isinstance(value.get('source_fingerprint'), dict) else value.get('source_fingerprint'),
                    'records': [], '_key': key,
                }
            records[uid]['records'].append({'path': str(path), 'dataset': root.name,
                                           'status': value.get('status'), 'phase': value.get('phase'),
                                           'record_mtime_ns': path.stat().st_mtime_ns,
                                           'source_fingerprint': value.get('source_fingerprint', {}).get('sha256')
                                           if isinstance(value.get('source_fingerprint'), dict) else value.get('source_fingerprint')})
    return records, files, errors


def read_diagnostics(roots, relevant_keys):
    events = {}
    index = defaultdict(list)
    paths = set()
    parse_errors = []
    for root in roots:
        paths.update(path for path in root.rglob('*.jsonl') if path.parent.name == 'kernels')
    for path in sorted(paths):
        try:
            stream = path.open()
        except OSError as exc:
            parse_errors.append({'path': str(path), 'error': str(exc)})
            continue
        with stream:
            for line, raw in enumerate(stream, 1):
                try:
                    value = json.loads(raw)
                    key = context_key(value, path)
                except (ValueError, TypeError) as exc:
                    parse_errors.append({'path': str(path), 'line': line, 'error': str(exc)})
                    continue
                if key not in relevant_keys or value.get('category') != 'lowered' or not value.get('kernel_name'):
                    continue
                identity = {name: value.get(name) for name in ['kernel_name', 'backend', 'reason', 'graph_id', 'is_backward',
                            'origins', 'nodes', 'phase']}
                identity['detailed_origins_sha256'] = hashlib.sha256(normalize_metadata(value.get('detailed_origins')).encode()).hexdigest()
                signature = hashlib.sha256((json.dumps(key) + json.dumps(identity, sort_keys=True)).encode()).hexdigest()
                if signature not in events:
                    events[signature] = {'id': signature, **identity, 'context_key': list(key), 'locations': []}
                    index[(key, str(value.get('graph_id')), bool(value.get('is_backward')), value['kernel_name'])].append(signature)
                events[signature]['locations'].append({'path': str(path), 'line': line})
    return events, index, parse_errors


def graph_identity(aot_id):
    match = re.search(r'(\d+)_(forward|backward|inference)', aot_id or '')
    return (match.group(1), match.group(2) == 'backward') if match else (None, None)


def write_jsonl(stream, value):
    stream.write(json.dumps(value, sort_keys=True) + '\n')


def collect_inventory(results, additional_results, output, include_baseline=False):
    from datetime import datetime, timezone
    import time
    started = time.monotonic()
    collector_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    roots = list(dict.fromkeys(Path(root).resolve() for root in [results, *additional_results]))
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    source_dir = output / 'triton_sources'
    source_dir.mkdir(exist_ok=True)
    records, record_files, record_errors = read_records(roots)
    selected = {key: value for key, value in records.items() if include_baseline or value['requested_backend'] == 'flydsl'}
    caches = defaultdict(list)
    for uid, record in selected.items():
        if record['inductor_cache']:
            caches[str(Path(record['inductor_cache']).resolve())].append(uid)
    relevant_keys = {tuple(value['_key']) for value in selected.values()}
    events, event_index, diagnostic_errors = read_diagnostics(roots, relevant_keys)
    event_backend_counts = Counter(value['backend'] for value in events.values())
    print(json.dumps({'stage': 'indexed', 'record_files': record_files, 'contexts': len(selected),
                      'cache_paths': len(caches), 'named_lowered_diagnostics': dict(event_backend_counts)}), flush=True)
    wrapper_paths = set()
    missing_caches = []
    for cache in caches:
        directory = Path(cache)
        if not directory.exists():
            missing_caches.append(cache)
            continue
        wrapper_paths.update(directory.rglob('*.py'))
    graph_snapshots = defaultdict(list)
    missing_snapshot_sources = []
    for root in roots:
        for path in root.rglob('*.json'):
            if path.parent.name != 'codegen':
                continue
            try:
                value = json.loads(path.read_text())
            except (ValueError, OSError):
                continue
            for graph in value.get('graphs', []):
                wrapper = graph.get('wrapper')
                if wrapper:
                    graph_snapshots[str(Path(wrapper).resolve())].append({'manifest': str(path), 'sha256': graph.get('sha256')})
                    if not Path(wrapper).exists():
                        missing_snapshot_sources.append({'manifest': str(path), 'wrapper': wrapper, 'sha256': graph.get('sha256')})
    totals = Counter()
    native_totals = Counter()
    native_operations = Counter()
    seen_wrappers = {}
    seen_sources = set()
    wrapper_errors = []
    missing = []
    uncertain = []
    unmatched_definitions = []
    unresolved = []
    preexisting = 0
    wrapper_path_count = 0
    missing_associations = 0
    records_with_wrappers = set()
    streams = {name: (output / (name + '.jsonl')).open('w') for name in [
        'wrappers', 'definitions', 'sources', 'launch_sites', 'native_calls', 'triton_diagnostic_matches'
    ]}
    def audit_triton_context(path, wrapper_hash, aot_id, launch, target, contexts):
        graph, backward = graph_identity(aot_id)
        for context in contexts:
            uid = context['record_id']
            record = selected[uid]
            key = tuple(record['_key'])
            labels = set([target['label'], target['binding']])
            ids = []
            if graph is not None:
                for label in labels:
                    ids.extend(event_index.get((key, graph, backward, label), []))
            matched = [events[identity] for identity in set(ids)]
            reasons = [event for event in matched if event['backend'] == 'triton' and event.get('reason')]
            if record['requested_backend'] != 'flydsl':
                status = 'requested_triton_baseline'
            elif reasons:
                status = 'named_flydsl_fallback'
            elif launch['dispatch_uncertain']:
                status = 'possible_dispatch_candidate_no_definitive_launch'
            elif matched:
                status = 'named_triton_lowering_without_fallback_reason'
            else:
                status = 'unknown_missing_diagnostic'
            evidence = {'wrapper': str(path), 'wrapper_sha256': wrapper_hash, 'aot_id': aot_id,
                        'graph_id': graph, 'is_backward': backward, 'launch_line': launch['line'],
                        'reference': launch['reference'], 'definition_id': target['id'],
                        'target_label': target['label'], 'record_id': uid,
                        'status': status, **context, 'diagnostic_event_ids': sorted(set(ids)),
                        'diagnostic_match_scope': 'many_to_many_context_graph_direction_name_coverage',
                        'reasons': sorted({event['reason'] for event in reasons})}
            write_jsonl(streams['triton_diagnostic_matches'], evidence)
            if status == 'unknown_missing_diagnostic':
                missing.append(evidence)
            elif status not in {'named_flydsl_fallback', 'requested_triton_baseline'}:
                uncertain.append(evidence)

    try:
        for path in sorted(wrapper_paths):
            try:
                source = path.read_text(errors='replace')
                mtime = path.stat().st_mtime_ns
            except OSError as exc:
                wrapper_errors.append({'path': str(path), 'error': str(exc)})
                continue
            if 'def call(' not in source:
                continue
            cache_matches = [cache for cache in caches if path.is_relative_to(cache)]
            if not cache_matches:
                missing_associations += 1
                continue
            wrapper_path_count += 1
            cache = max(cache_matches, key=len)
            associations = caches[cache]
            wrapper_hash = hashlib.sha256(source.encode()).hexdigest()
            contexts = []
            for uid in associations:
                record = selected[uid]
                attempt = record['attempt_id']
                old = attempt.isdigit() and mtime < int(attempt)
                preexisting += int(old)
                contexts.append({'record_id': uid, 'source_predates_attempt': old,
                                 'cache_shared_with_other_contexts': len(associations) > 1,
                                 'cache_mixed_source_fingerprints': len({selected[item]['source_fingerprint'] for item in associations}) > 1,
                                 'source_newer_than_all_record_files': all(mtime > item['record_mtime_ns'] for item in record['records']),
                                 'has_primary_result_record': any(item['dataset'] == roots[0].name for item in record['records'])})
            records_with_wrappers.update(associations)
            if wrapper_hash in seen_wrappers:
                write_jsonl(streams['wrappers'], {'sha256': wrapper_hash, 'path_alias': str(path), 'contexts': contexts,
                                                 'deduplicated_source': True, 'source_mtime_ns': mtime})
                previous = seen_wrappers[wrapper_hash]
                for launch, target in previous['triton_sites']:
                    audit_triton_context(path, wrapper_hash, previous['aot_id'], launch, target, contexts)
                continue
            try:
                parsed = WrapperInventory(source).run()
            except (SyntaxError, ValueError, TypeError, RecursionError) as exc:
                wrapper_errors.append({'path': str(path), 'error': str(exc)})
                continue
            graph, backward = graph_identity(parsed['aot_id'])
            definitions = {item['id']: item for item in parsed['definitions']}
            launched_ids = {identity for launch in parsed['launch_sites'] for identity in launch['definition_ids']}
            seen_wrappers[wrapper_hash] = {'aot_id': parsed['aot_id'], 'triton_sites': [
                (launch, {key: definitions[identity][key] for key in ['id', 'label', 'binding']})
                for launch in parsed['launch_sites'] for identity in launch['definition_ids']
                if definitions[identity]['backend'] == 'triton']}
            for definition in definitions.values():
                totals['definitions_' + definition['backend']] += 1
                digest = definition['source_sha256']
                if digest and digest not in seen_sources:
                    seen_sources.add(digest)
                    saved_source = None
                    if definition['backend'] == 'triton':
                        saved_source = str(source_dir / (digest + '.py'))
                        Path(saved_source).write_text(definition['_source'])
                    write_jsonl(streams['sources'], {'sha256': digest, 'backend': definition['backend'],
                                                     'entrypoints': definition['entrypoints'], 'saved_source': saved_source})
                clean = {key: value for key, value in definition.items() if key not in {'_source', 'entrypoints', 'metadata'}}
                clean.update(wrapper_sha256=wrapper_hash, has_static_launch=definition['id'] in launched_ids,
                             metadata_sha256=hashlib.sha256((definition['metadata'] or '').encode()).hexdigest())
                write_jsonl(streams['definitions'], clean)
                if definition['backend'] == 'triton' and definition['id'] not in launched_ids:
                    unmatched_definitions.append({'wrapper': str(path), 'definition': clean})
            for launch in parsed['launch_sites']:
                targets = [definitions[identity] for identity in launch['definition_ids']]
                backends = sorted({item['backend'] for item in targets})
                category = backends[0] if len(backends) == 1 else 'mixed_possible_dispatch'
                totals['static_launch_sites_' + category] += 1
                launch_record = {**launch, 'wrapper_sha256': wrapper_hash, 'backends': backends}
                write_jsonl(streams['launch_sites'], launch_record)
                for target in targets:
                    if target['backend'] != 'triton':
                        continue
                    audit_triton_context(path, wrapper_hash, parsed['aot_id'], launch, target, contexts)
            for call in parsed['native_calls']:
                native_totals[call['category']] += 1
                native_operations[(call['category'], call['operation'])] += 1
                write_jsonl(streams['native_calls'], {**call, 'wrapper_sha256': wrapper_hash})
            for call in parsed['unresolved_launch_sites']:
                unresolved.append({'wrapper': str(path), **call})
            write_jsonl(streams['wrappers'], {
                'sha256': wrapper_hash, 'path': str(path), 'cache': cache, 'source_mtime_ns': mtime,
                'aot_id': parsed['aot_id'], 'graph_id': graph, 'is_backward': backward,
                'contexts': contexts, 'entrypoint_scopes': parsed['entrypoint_scopes'],
                'definitions': len(definitions), 'static_launch_sites': len(parsed['launch_sites']),
                'snapshots': graph_snapshots.get(str(path), []),
            })
            if len(seen_wrappers) % 100 == 0:
                print(json.dumps({'stage': 'wrappers', 'parsed': len(seen_wrappers), 'static_sites': dict(totals),
                                  'unknown_triton_context_sites': len(missing)}), flush=True)
    finally:
        for stream in streams.values():
            stream.close()
    with (output / 'record_contexts.jsonl').open('w') as stream:
        for value in records.values():
            write_jsonl(stream, {key: item for key, item in value.items() if not key.startswith('_')})
    with (output / 'named_lowered_diagnostics.jsonl').open('w') as stream:
        for value in events.values():
            write_jsonl(stream, {key: item for key, item in value.items() if key != 'detailed_origins'})
    report = {
        'captured_utc': datetime.now(timezone.utc).isoformat(), 'live_snapshot': True, 'collector_sha256': collector_sha,
        'results_roots': [str(root) for root in roots], 'timing_data_used': False,
        'scope': 'Static definitions and reachable wrapper callsites in associated caches; not dynamic launch counts or proof that failed attempts executed these graphs',
        'record_files': record_files, 'unique_record_contexts': len(records), 'selected_contexts': len(selected),
        'cache_paths': len(caches), 'missing_caches': missing_caches,
        'selected_contexts_without_cache_field': [uid for uid, item in selected.items() if not item['inductor_cache']],
        'selected_contexts_without_wrapper_source': sorted(set(selected) - records_with_wrappers),
        'cache_paths_shared_between_contexts': sum(len(items) > 1 for items in caches.values()),
        'cache_paths_with_mixed_source_fingerprints': sum(len({selected[item]['source_fingerprint'] for item in items}) > 1 for items in caches.values()),
        'unique_wrapper_sources': len(seen_wrappers), 'wrapper_source_paths': wrapper_path_count, 'unique_kernel_sources': len(seen_sources),
        'wrapper_contexts_predating_attempt': preexisting, 'missing_associations': missing_associations,
        'counts': dict(totals), 'native_counts': dict(native_totals),
        'native_operations': [{'category': key[0], 'operation': key[1], 'static_callsites': value}
                              for key, value in sorted(native_operations.items())],
        'triton_static_context_sites_without_matching_diagnostic': missing,
        'unknown_primary_context_sites': [item for item in missing if item['has_primary_result_record']],
        'unknown_additional_only_context_sites': [item for item in missing if not item['has_primary_result_record']],
        'uncertain_triton_context_sites': uncertain,
        'triton_definitions_without_reachable_static_launch': unmatched_definitions,
        'unresolved_launch_sites': unresolved, 'wrapper_errors': wrapper_errors,
        'record_errors': record_errors, 'diagnostic_errors': diagnostic_errors,
        'missing_snapshot_sources': missing_snapshot_sources,
        'elapsed_seconds': time.monotonic() - started,
        'limits': [
            'A matching named event requires attempt/model/suite/requested-backend/autotune/rank/world/AOT-graph/direction/name.',
            'Reused kernel names match many-to-many within that graph context; this is coverage, not exact per-node/per-call attribution.',
            'Preexisting/shared caches may contain old graphs; absence of events is unknown, not a proven new missing lowering.',
            'Static branches and dispatch candidates do not establish which path executed; definitions alone are not launches.',
            'Python/eager graph breaks and kernels outside retained Inductor wrappers are outside this source inventory.',
            'Native operator callsites can be views or metadata operations; they are not necessarily GPU launches or unsupported FlyDSL operations.',
            'Live/failed/archived contexts are retained for coverage only; their timing values are not combined.',
        ],
    }
    (output / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    (output / 'REPORT.md').write_text(
        '# Supplemental static kernel inventory\n\n' + report['scope'] + '.\n\n'
        + f"Scanned {len(seen_wrappers)} unique wrapper sources from {len(caches)} cache paths and {record_files} record files.\n\n"
        + 'Counts: `' + json.dumps(dict(totals), sort_keys=True) + '`.\n\n'
        + f"Unmatched Triton context sites: {len(missing)}; uncertain dispatch sites: {len(uncertain)}; unresolved launch references: {len(unresolved)}.\n\n"
        + 'These are static source counts. Unknown or preexisting-cache associations are not evidence of a new unsupported FlyDSL operation. Native GEMM/convolution policy calls and other native operations are separated in native_calls.jsonl.\n\n'
        + 'Full provenance, limitations, missing sources and parse errors are in summary.json; per-site named fallback matches are in triton_diagnostic_matches.jsonl.\n'
    )
    print(json.dumps({'output': str(output), 'wrappers': len(seen_wrappers), 'counts': dict(totals),
                      'missing_triton_context_sites': len(missing), 'uncertain_triton_context_sites': len(uncertain),
                      'unresolved_launch_sites': len(unresolved), 'wrapper_errors': len(wrapper_errors),
                      'elapsed_seconds': report['elapsed_seconds']}, indent=2), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--additional-results', type=Path, action='extend', nargs='+', default=[])
    parser.add_argument('--output', type=Path)
    parser.add_argument('--include-triton-baseline', action='store_true')
    args = parser.parse_args()
    output = args.output or args.results.parent / (args.results.name + '_kernel_inventory_v3')
    collect_inventory(args.results, args.additional_results, output, args.include_triton_baseline)


if __name__ == '__main__':
    main()
