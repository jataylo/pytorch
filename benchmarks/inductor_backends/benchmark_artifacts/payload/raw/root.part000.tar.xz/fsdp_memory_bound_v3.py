import hashlib
import inspect
from pathlib import Path

import torch


VERIFIED_SOURCES = {
    'transformers.models.deepseek_v4.modeling_deepseek_v4': 'a1a4ce517460a8961a74109e5870fa6249d56e7c455753ddcdbc138061079a5d',
    'torch.distributed.fsdp._runtime_utils': '35e923ca8d8424d7db1bb71b3e2781ad367d81ccf65e92af7554df09fb95b29c',
    'torch.distributed.fsdp._flat_param': 'ea287f8d6b64f3bf9c1f32bd04a64b156775682fe7b93ec7391909d80d90e98e',
    'torch.distributed.fsdp.wrap': '6c58144e60e23f3c05dec5a6ff9429aa8c0e549d2e44af8f5efb4112e86d4aaa',
}


def fsdp_backward_memory_bound(
    model: torch.nn.Module,
    world_size: int,
    *,
    master_dtype=torch.float32,
    compute_dtype=torch.bfloat16,
    reduce_dtype=torch.float32,
    cpu_offload=False,
    keep_low_precision_grads=False,
    use_orig_params=True,
    sharding_strategy='FULL_SHARD',
    free_bytes_per_rank=None,
):
    """Return a conservative bound for verified DeepseekV4 FSDP, or None for unknown protocols.

    This proves only inability to fit. A bound below free memory does not prove
    that activations, communication workspaces, and optimizer execution fit.
    """
    import importlib

    kind = type(model)
    if kind.__module__ != 'transformers.models.deepseek_v4.modeling_deepseek_v4' or kind.__name__ != 'DeepseekV4ForCausalLM':
        return None
    if type(world_size) is not int or world_size < 2:
        return None
    if (master_dtype, compute_dtype, reduce_dtype) != (torch.float32, torch.bfloat16, torch.float32):
        return None
    if cpu_offload or keep_low_precision_grads or not use_orig_params or sharding_strategy != 'FULL_SHARD':
        return None
    if set(getattr(model, '_no_split_modules', [])) != {'DeepseekV4DecoderLayer'}:
        return None
    source_files = {}
    for name, expected in VERIFIED_SOURCES.items():
        module = importlib.import_module(name)
        path = Path(inspect.getsourcefile(module)).resolve()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != expected:
            return None
        source_files[name] = {'path': str(path), 'sha256': digest}
    backbone = getattr(model, 'model', None)
    if type(backbone).__module__ != kind.__module__ or type(backbone).__name__ != 'DeepseekV4Model':
        return None
    layers = getattr(backbone, 'layers', None)
    if not isinstance(layers, torch.nn.ModuleList) or len(layers) != model.config.num_hidden_layers or not layers:
        return None
    if any(type(layer).__module__ != kind.__module__ or type(layer).__name__ != 'DeepseekV4DecoderLayer' for layer in layers):
        return None
    if any(getattr(module, 'gradient_checkpointing', False) for module in model.modules()):
        return None
    if sum(type(module).__name__ == 'DeepseekV4DecoderLayer' for module in model.modules()) != len(layers):
        return None
    entries = list(model.named_parameters(remove_duplicate=False))
    if not entries or len({id(value) for _, value in entries}) != len(entries):
        return None
    if any(not p.is_meta or p.dtype != master_dtype or not p.requires_grad or not p.is_contiguous() or p.storage_offset() != 0 for _, p in entries):
        return None
    if len({p.untyped_storage()._cdata for _, p in entries}) != len(entries):
        return None
    owned = set()
    blocks = []
    for index, layer in enumerate(layers):
        parameters = list(layer.parameters())
        ids = {id(value) for value in parameters}
        if ids & owned:
            return None
        owned.update(ids)
        # Every block invokes the official packed expert parameters. Their
        # dense gradients imply a full flat gradient even for sparse routing.
        experts = getattr(getattr(layer, 'mlp', None), 'experts', None)
        if type(experts).__module__ != kind.__module__ or type(experts).__name__ != 'DeepseekV4Experts':
            return None
        if not all(getattr(experts, name, None) is not None for name in ['gate_up_proj', 'down_proj']):
            return None
        blocks.append({'path': f'model.layers.{index}', 'numel': sum(p.numel() for p in parameters)})
    root_numel = sum(p.numel() for _, p in entries if id(p) not in owned)
    master_shards = sum(group['numel'] // world_size * 4 for group in blocks) + root_numel // world_size * 4
    # Other decoder gradients retain at least their shard bytes at the last
    # event, even if they are still full BF16 buffers (world_size >= 2).
    gradient_shards = sum(group['numel'] // world_size * 4 for group in blocks)
    cast_last = min(blocks, key=lambda group: group['numel'] * 6 - group['numel'] // world_size * 4)
    reduce_last = min(blocks, key=lambda group: group['numel'])
    cast_increment = cast_last['numel'] * 6 - cast_last['numel'] // world_size * 4
    reduce_increment = reduce_last['numel'] * 4
    cast_bound = master_shards + gradient_shards + cast_increment
    reduce_bound = master_shards + gradient_shards + reduce_increment
    later_gradients = 0
    stages = []
    for group in reversed(blocks):
        count = group['numel']
        shard = count // world_size * 4
        common = master_shards + later_gradients
        stages.append({
            **group, 'master_shards_bytes': master_shards,
            'later_decoder_grad_shards_bytes': later_gradients,
            'current_full_fp32_gradient_bytes': count * 4,
            'current_full_bf16_gradient_bytes': count * 2,
            'current_reduce_output_shard_bytes': shard,
            'cast_peak_lower_bound_bytes': common + count * 6,
            'reduce_peak_lower_bound_bytes': common + count * 4 + shard,
        })
        later_gradients += shard
    cast_stage = max(stages, key=lambda stage: stage['cast_peak_lower_bound_bytes'])
    reduce_stage = max(stages, key=lambda stage: stage['reduce_peak_lower_bound_bytes'])
    bound = max(cast_bound, reduce_bound)
    result = {
        'proof': 'verified_deepseek_v4_full_shard_fp32_master_bf16_compute_fp32_reduce_order_independent_v2',
        'model_class': f'{kind.__module__}.{kind.__name__}',
        'world_size': world_size, 'unique_parameter_numel': sum(p.numel() for _, p in entries),
        'decoder_blocks': len(blocks), 'root_parameter_numel': root_numel,
        'master_shards_bytes': master_shards,
        'decoder_gradient_shards_bytes': gradient_shards,
        'guaranteed_cast_lower_bound_bytes': cast_bound,
        'guaranteed_reduce_lower_bound_bytes': reduce_bound,
        'minimum_last_decoder_cast': {**cast_last, 'increment_above_all_decoder_shards_bytes': cast_increment},
        'minimum_last_decoder_reduce': {**reduce_last, 'increment_above_all_decoder_shards_bytes': reduce_increment},
        'completion_order_assumption': 'none; use the last decoder gradient event in any order',
        'inflight_gradient_condition': 'Other decoder gradients retain a FP32 shard or a full buffer; BF16 full bytes 2*n >= 4*floor(n/world_size) for world_size >= 2.',
        'per_rank_lower_bound_bytes': bound,
        'expected_reverse_order_diagnostics': {
            'used_for_capacity_decision': False,
            'cast_peak_stage': cast_stage, 'reduce_peak_stage': reduce_stage,
            'stages_in_backward_order': stages,
        },
        'source_files': source_files,
        'ignored_memory': ['all padding', 'all root gradients', 'all full parameters', 'activations', 'buffers', 'allocator and communication workspaces'],
    }
    if free_bytes_per_rank is not None:
        if len(free_bytes_per_rank) != world_size or any(type(value) is not int or value < 0 for value in free_bytes_per_rank):
            raise ValueError('free_bytes_per_rank must contain one nonnegative integer per rank')
        result['free_bytes_per_rank'] = list(free_bytes_per_rank)
        result['insufficient_capacity'] = any(bound > value for value in free_bytes_per_rank)
        if result['insufficient_capacity']:
            result['reason'] = (
                f'Verified order-independent FSDP backward storage lower bound {bound} bytes per rank exceeds '
                f'available memory on at least one rank (minimum {min(free_bytes_per_rank)} bytes); '
                'FP32 master shards, retained gradients of the other decoder handles, and the last decoder '
                'full-gradient cast/reduction storages must coexist before optimizer.step, regardless of completion order.'
            )
    return result
