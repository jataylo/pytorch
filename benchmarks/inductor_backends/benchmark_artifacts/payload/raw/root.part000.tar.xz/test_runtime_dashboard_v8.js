const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync(__dirname + '/three_backend_preview_v8/runtime_dashboard.html', 'utf8');
const script = source.match(/<script>([\s\S]*)<\/script>/)[1];
const elements = {};
const defaults = {mode:'expanded',suite:'all',gpus:'all',evidence:'validated',sort:'runtime',scale:'linear',search:''};
for (const id of ['mode','suite','gpus','evidence','sort','scale','search','status','chart','table','download']) {
  elements[id] = {value:defaults[id] || '', innerHTML:'', textContent:'', add(){}, addEventListener(){}};
}
const context = {document:{getElementById:id=>elements[id],createElement:()=>({click(){}})},
  Option:function(text,value){this.text=text;this.value=value;},setTimeout,URL,Blob};
vm.createContext(context);
vm.runInContext(script, context);
function check(value, message) { if (!value) throw new Error(message); }
check(elements.chart.innerHTML.includes('Full training runtime'), 'Initial chart missing');
check(!/NaN|Infinity/.test(elements.chart.innerHTML), 'Invalid numeric chart values');
for(const color of ['#64748b','#d97706','#059669']) check(elements.chart.innerHTML.includes(color), 'Missing backend color');
elements.search.value='bertformaskedlm';context.render();
check(elements.table.innerHTML.includes('BertForMaskedLM'), 'Search did not retain BERT');
check(!elements.table.innerHTML.includes('repvgg_a2'), 'Search retained unrelated model');
elements.scale.value='log';context.render();
check(!/NaN|Infinity/.test(elements.chart.innerHTML), 'Log axis invalid');
elements.mode.value='standard';context.render();
check(elements.chart.innerHTML.includes('standard tuning'), 'Mode control did not update chart');
elements.search.value='no_such_model';context.render();
check(!/NaN|Infinity/.test(elements.chart.innerHTML), 'Empty filter invalid');
elements.search.value='';elements.evidence.value='all';elements.gpus.value='multi';context.render();
check(!/NaN|Infinity/.test(elements.chart.innerHTML), 'Partial/multi chart invalid');
console.log('PASS: dashboard execution, initial three-series chart, search, log axis, tuning, empty and multi-GPU filters');
