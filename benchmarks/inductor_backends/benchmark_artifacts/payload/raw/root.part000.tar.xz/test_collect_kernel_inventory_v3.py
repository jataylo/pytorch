import json
import os
from pathlib import Path
import tempfile
from contextlib import redirect_stdout
import io

from collect_kernel_inventory_v3 import collect_inventory, context_key, WrapperInventory
from torch.testing._internal.common_utils import run_tests, TestCase


TRITON = 'import triton\n@triton.jit\ndef tri(a):\n    pass\n'
FLY = 'def fly_kernel(a):\n    pass\n'


def header():
    return ('# AOT ID: [\'0_forward\']\n'
            'from torch._inductor.async_compile import AsyncCompile\n'
            'from torch._inductor.codegen.flydsl import flydsl_simd_runtime as rt\n'
            'from torch._inductor.select_algorithm import extern_kernels as ek\n'
            'async_compile = AsyncCompile()\n'
            f't = async_compile.triton("tri", {TRITON!r})\n')


class TestWrapperKernelInventory(TestCase):
    def test_runner_aliases_sources_and_unlaunched_candidates(self):
        source = header() + (
            f'f = rt.compiled(async_compile, "fly", (fly_source := {FLY!r}), precompile_metadata={{"only":0}})\n'
            'f_v1 = rt.compiled(async_compile, "fly", fly_source, precompile_metadata={"only":1})\n'
            't_unused = async_compile.triton("tri_unused", "def tri_unused(): pass")\n'
            'alias = t\n'
            'class Runner:\n'
            '    def __init__(self):\n'
            '        self.fly = f\n'
            '    def call(self, args):\n'
            '        alias.run(args)\n'
            '        self.fly.run(args)\n'
        )
        result = WrapperInventory(source).run()
        self.assertEqual(len(result['definitions']), 4)
        self.assertEqual(len(result['launch_sites']), 2)
        launched = {key for call in result['launch_sites'] for key in call['definition_ids']}
        definitions = {value['binding']: value for value in result['definitions']}
        self.assertIn(definitions['t']['id'], launched)
        self.assertIn(definitions['f']['id'], launched)
        self.assertNotIn(definitions['f_v1']['id'], launched)
        self.assertNotIn(definitions['t_unused']['id'], launched)
        self.assertEqual(definitions['f']['source_sha256'], definitions['f_v1']['source_sha256'])
        self.assertEqual(result['unresolved_launch_sites'], [])

    def test_helpers_preserve_all_possible_targets_without_dynamic_counts(self):
        source = header() + (
            'u = async_compile.triton("other", "def other():pass")\n'
            'def launch(kernel, x):\n'
            '    kernel.run(x)\n'
            'def call(args):\n'
            '    launch(t, args)\n'
            '    launch(t, args)\n'
            '    launch(u, args)\n'
        )
        result = WrapperInventory(source).run()
        self.assertEqual(len(result['launch_sites']), 1)
        self.assertEqual(len(result['launch_sites'][0]['definition_ids']), 2)
        self.assertTrue(result['launch_sites'][0]['dispatch_uncertain'])

    def test_native_import_and_function_aliases_preserve_policy_split(self):
        source = header() + (
            'aten = torch.ops.aten\n'
            'matrix = ek.mm\n'
            'normalization = aten._softmax.default\n'
            'def call(args):\n'
            '    matrix(args)\n'
            '    normalization(args)\n'
        )
        calls = WrapperInventory(source).run()['native_calls']
        self.assertEqual({call['operation'] for call in calls}, {'extern_kernels.mm', 'torch.ops.aten._softmax.default'})
        self.assertEqual({call['category'] for call in calls}, {'mandated_aten_gemm_conv', 'other_aten_external'})

    def test_branch_aliases_and_multi_kernel_dispatch_are_possible_targets(self):
        source = header() + (
            'u = async_compile.triton("other", "def other():pass")\n'
            'choice = async_compile.multi_kernel("choice", [t, u])\n'
            'def call(args):\n'
            '    if args:\n'
            '        selected = t\n'
            '    else:\n'
            '        selected = u\n'
            '    selected.run(args)\n'
            '    choice.run(args)\n'
        )
        sites = WrapperInventory(source).run()['launch_sites']
        self.assertEqual(len(sites), 2)
        self.assertTrue(all(len(site['definition_ids']) == 2 for site in sites))
        self.assertTrue(all(site['dispatch_uncertain'] for site in sites))

    def test_subscript_and_bound_method_aliases(self):
        source = header() + ('def call(args):\n'
                             '    launch = t.run\n'
                             '    launch(args)\n'
                             '    t[(1,)](args)\n')
        result = WrapperInventory(source).run()
        self.assertEqual(len(result['launch_sites']), 2)
        self.assertEqual(result['unresolved_launch_sites'], [])

    def test_nested_unused_function_is_not_a_launch(self):
        source = header() + ('def call(args):\n'
                             '    def unused():\n'
                             '        t.run(args)\n'
                             '    return args\n')
        self.assertEqual(WrapperInventory(source).run()['launch_sites'], [])

    def test_unknown_run_is_retained(self):
        result = WrapperInventory('# AOT ID: [\'0_forward\']\ndef call(args):\n    unknown.run(args)\n').run()
        self.assertEqual(len(result['unresolved_launch_sites']), 1)

    def test_compiler_alias_and_native_partial(self):
        source = header() + ('compiler = async_compile\n'
                             'u = compiler.triton("other", "def other():pass")\n'
                             'run = functools.partial(u.run, 1)\n'
                             'def call(args):\n'
                             '    run(args)\n')
        result = WrapperInventory(source).run()
        self.assertEqual(len(result['definitions']), 2)
        self.assertEqual(len(result['launch_sites']), 1)
        self.assertEqual(result['launch_sites'][0]['definition_ids'], [result['definitions'][1]['id']])

    def test_try_aliases_preserve_both_paths(self):
        source = header() + (
            f'f = rt.compiled(async_compile, "fly", {FLY!r})\n'
            'def call(args):\n'
            '    selected = t\n'
            '    try:\n'
            '        selected = t\n'
            '    except Exception:\n'
            '        selected = f\n'
            '    selected.run(args)\n'
        )
        sites = WrapperInventory(source).run()['launch_sites']
        self.assertEqual(len(sites), 1)
        self.assertEqual(len(sites[0]['definition_ids']), 2)
        self.assertTrue(sites[0]['dispatch_uncertain'])

    def test_zero_loop_iterations_preserve_original_alias(self):
        source = header() + (
            f'f = rt.compiled(async_compile, "fly", {FLY!r})\n'
            'def call(args):\n'
            '    selected = t\n'
            '    for item in args:\n'
            '        selected = f\n'
            '    selected.run(args)\n'
        )
        sites = WrapperInventory(source).run()['launch_sites']
        self.assertEqual(len(sites), 1)
        self.assertEqual(len(sites[0]['definition_ids']), 2)
        self.assertTrue(sites[0]['dispatch_uncertain'])

    def test_reachable_lambda_alias_is_scanned(self):
        source = header() + ('launch = lambda args: t.run(args)\n'
                             'def call(args):\n'
                             '    launch(args)\n')
        result = WrapperInventory(source).run()
        self.assertEqual(len(result['launch_sites']), 1)
        self.assertEqual(result['unresolved_launch_sites'], [])

    def test_unconstructed_other_call_method_is_not_an_entrypoint(self):
        source = header() + ('class NeverConstructed:\n'
                             '    def call(self, args):\n'
                             '        t.run(args)\n'
                             'def call(args):\n'
                             '    return args\n')
        result = WrapperInventory(source).run()
        self.assertEqual(result['entrypoint_scopes'], ['call'])
        self.assertEqual(result['launch_sites'], [])

    def test_later_module_function_definition_overwrites_old_alias(self):
        source = header() + (
            f'f = rt.compiled(async_compile, "fly", {FLY!r})\n'
            'launch = t\n'
            'def launch(args):\n'
            '    f.run(args)\n'
            'def call(args):\n'
            '    launch(args)\n'
        )
        result = WrapperInventory(source).run()
        self.assertEqual(len(result['launch_sites']), 1)
        self.assertEqual(result['launch_sites'][0]['definition_ids'], [result['definitions'][1]['id']])

    def test_native_tensor_result_methods_are_not_operator_aliases(self):
        source = header() + ('def call(args):\n'
                             '    output = torch.ops.aten._fft_c2c.default(args)\n'
                             '    output.copy_(args)\n')
        calls = WrapperInventory(source).run()['native_calls']
        self.assertEqual([item['operation'] for item in calls], ['torch.ops.aten._fft_c2c.default'])

    def test_context_key_separates_models_and_suites(self):
        base = {'attempt_id': '1', 'backend': 'flydsl', 'autotune': 1, 'rank': 0, 'world_size': 1}
        self.assertNotEqual(context_key({**base, 'model': 'a', 'suite': 'test'}),
                            context_key({**base, 'model': 'b', 'suite': 'test'}))
        self.assertNotEqual(context_key({**base, 'model': 'a', 'suite': 'one'}),
                            context_key({**base, 'model': 'a', 'suite': 'two'}))

    def test_corrupt_wrapper_is_explicit_parse_failure(self):
        with self.assertRaises(SyntaxError):
            WrapperInventory('def call( broken')


class TestWrapperInventoryAttribution(TestCase):
    def test_rank_archive_shared_source_and_missing_cache_are_preserved(self):
        with tempfile.TemporaryDirectory(dir='/tmp') as directory:
            root = Path(directory)
            results = root / 'results'
            extra = root / 'old_aborted_results'
            records = results / 'raw/model/ranks'
            archive = extra / 'archive/attempt/model/ranks'
            records.mkdir(parents=True)
            archive.mkdir(parents=True)
            source = header() + 'class Runner:\n    def call(self,args):\n        t.run(args)\n'
            cache = root / 'cache_a/rank1'
            cache.mkdir(parents=True)
            wrapper = cache / 'wrapper.py'
            wrapper.write_text(source)
            other_cache = root / 'cache_b/rank1'
            other_cache.mkdir(parents=True)
            other_wrapper = other_cache / 'wrapper.py'
            other_wrapper.write_text(source)
            os.utime(other_wrapper, ns=(1, 1))
            base = {'model': 'model', 'suite': 'test', 'backend': 'flydsl', 'autotune': 1, 'rank': 1, 'world_size': 2}
            first = {**base, 'attempt_id': '100', 'inductor_cache': str(cache)}
            second = {**base, 'attempt_id': '200', 'inductor_cache': str(other_cache)}
            (records / 'flydsl_autotune1.world2.rank1.json').write_text(json.dumps(first))
            (archive / 'flydsl_autotune1.world2.rank1.json').write_text(json.dumps(second))
            missing = {**base, 'rank': 0, 'attempt_id': '300', 'inductor_cache': str(root / 'missing')}
            (results / 'raw/model/flydsl_autotune1.json').write_text(json.dumps(missing))
            kernels = results / 'raw/model/kernels'
            kernels.mkdir()
            event = {**first, 'requested_backend': 'flydsl', 'backend': 'triton', 'category': 'lowered',
                     'kernel_name': 'tri', 'reason': 'known layout refusal', 'graph_id': 0, 'is_backward': False}
            (kernels / 'flydsl_autotune1.world2.rank1.jsonl').write_text(json.dumps(event) + '\n')
            with redirect_stdout(io.StringIO()):
                result = collect_inventory(results, [extra], root / 'audit')
            self.assertEqual(result['record_files'], 3)
            self.assertEqual(result['unique_wrapper_sources'], 1)
            self.assertEqual(result['counts']['definitions_triton'], 1)
            self.assertEqual(result['counts']['static_launch_sites_triton'], 1)
            self.assertEqual(len(result['missing_caches']), 1)
            self.assertEqual(len(result['triton_static_context_sites_without_matching_diagnostic']), 1)
            unknown = result['triton_static_context_sites_without_matching_diagnostic'][0]
            self.assertTrue(unknown['source_predates_attempt'])
            self.assertEqual(unknown['status'], 'unknown_missing_diagnostic')
            self.assertEqual(result['wrapper_errors'], [])


if __name__ == '__main__':
    run_tests()
