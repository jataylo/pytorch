import csv
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
records = json.loads((ROOT / 'training_results/outlier_rechecks.json').read_text())
pairs = {}
for record in records:
    key = (record['model'], record['autotune'])
    row = pairs.setdefault(key, {'model': key[0], 'autotune': key[1]})
    backend = record['backend']
    runs = record['runs']
    if len(runs) != 3 or any(r['status'] != 'ok' for r in runs):
        raise RuntimeError(f'Incomplete or unvalidated rechecks: {key}/{backend}')
    if len({r['physical_gpu'] for r in runs}) != 1:
        raise RuntimeError(f'Rechecks span different GPUs: {key}/{backend}')
    row['physical_gpu'] = runs[0]['physical_gpu']
    for index, run in enumerate(runs):
        label = ['original', 'recheck1', 'recheck2'][index]
        row[f'{backend}_{label}_ms'] = run['milliseconds']
    row[f'{backend}_median_of_process_medians_ms'] = statistics.median(r['milliseconds'] for r in runs)
for row in pairs.values():
    for label in ['original', 'recheck1', 'recheck2']:
        row[f'{label}_triton_over_flydsl'] = row[f'triton_{label}_ms'] / row[f'flydsl_{label}_ms']
    winners = ['flydsl' if row[f'{label}_triton_over_flydsl'] > 1.03 else 'triton' if row[f'{label}_triton_over_flydsl'] < 1 / 1.03 else 'within_3_percent' for label in ['original', 'recheck1', 'recheck2']]
    row['observed_winners'] = ','.join(winners)
    row['winner_consistent'] = len(set(winners)) == 1
    row['median_triton_over_flydsl'] = row['triton_median_of_process_medians_ms'] / row['flydsl_median_of_process_medians_ms']
rows = sorted(pairs.values(), key=lambda r: (r['model'], r['autotune']))
with (ROOT / 'training_results/outlier_rechecks.csv').open('w') as output:
    writer = csv.DictWriter(output, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
lines = ['Independent performance rechecks on original GPUs, one model at a time.',
         'Each process reports median of five synchronized repeats of ten full training steps.',
         'Original and two recheck process medians retained separately; primary matrix unchanged.',
         'Selected large wins/regressions and the shared GhostNet autotuning slowdown; not a random sample.',
         'Ratio = Triton time / FlyDSL time; >1 favors FlyDSL.', '',
         'model | autotune | original ratio | recheck1 ratio | recheck2 ratio | median-of-process-medians ratio | consistent winner']
for row in rows:
    lines.append(f"{row['model']} | {row['autotune']} | {row['original_triton_over_flydsl']:.4f} | {row['recheck1_triton_over_flydsl']:.4f} | {row['recheck2_triton_over_flydsl']:.4f} | {row['median_triton_over_flydsl']:.4f} | {row['winner_consistent']}")
primary = list(csv.DictReader((ROOT / 'training_results/comparison.csv').open()))
rechecked = {(r['model'], r['autotune']): r['median_triton_over_flydsl'] for r in rows}
sensitivity = []
lines += ['', 'Sensitivity summary: original validated pairs versus replacing only rechecked',
          'cases with ratios of three process medians. Primary matrix is unchanged.',
          'This selected subset is not a random sample of model variability.']
for suite in ['all', 'priority', 'huggingface-dashboard', 'timm-dashboard']:
    for tune in [0, 1]:
        selected = [r for r in primary if r['triton_over_flydsl'] and int(r['autotune']) == tune and (suite == 'all' or r['suite'] == suite)]
        original = [float(r['triton_over_flydsl']) for r in selected]
        revised = [rechecked.get((r['model'], tune), float(r['triton_over_flydsl'])) for r in selected]
        if not original:
            continue
        old = math.exp(statistics.mean(math.log(x) for x in original))
        new = math.exp(statistics.mean(math.log(x) for x in revised))
        count = sum((r['model'], tune) in rechecked for r in selected)
        sensitivity.append({'suite': suite, 'autotune': tune, 'validated_pairs': len(selected),
                            'rechecked_pairs': count, 'primary_geomean': old, 'rechecked_geomean': new})
        lines.append(f'{suite}, autotune={tune}: pairs={len(selected)}, rechecked={count}, primary={old:.4f}x, rechecked={new:.4f}x')
with (ROOT / 'training_results/sensitivity_summary.csv').open('w') as output:
    writer = csv.DictWriter(output, fieldnames=list(sensitivity[0]))
    writer.writeheader()
    writer.writerows(sensitivity)
(ROOT / 'training_results/outlier_rechecks.txt').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
