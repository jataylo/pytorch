# Automatic review rejected this action. Explicit user approval is required.
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time


root = Path(__file__).resolve().parent
destination = root / 'training_results_v2'
controller = 757309


def processes():
    entries = {}
    for line in subprocess.check_output(['ps', '-eo', 'pid=,ppid=,pgid=,stat=,args='], text=True).splitlines():
        pid, parent, group, state, command = line.strip().split(None, 4)
        entries[int(pid)] = {'parent': int(parent), 'group': int(group), 'state': state, 'command': command}
    return entries


entries = processes()
if controller not in entries or not entries[controller]['command'].endswith('benchmark_all_v2.py'):
    raise RuntimeError('The expected owned benchmark controller is not running')
owned = {controller}
while True:
    children = {pid for pid, entry in entries.items() if entry['parent'] in owned}
    if children <= owned:
        break
    owned.update(children)
coordinators = sorted(pid for pid in owned if any(name in entries[pid]['command'] for name in
                      ['benchmark_all_v2.py', 'run_fsdp_v2.py', 'run_suite_v2.py']))
workers = [pid for pid in owned if '-m torch.distributed.run ' in entries[pid]['command']]
if len(workers) != 1 or 'DeepSeek-V4-Flash-0731' not in entries[workers[0]]['command']:
    raise RuntimeError('The expected unmeasured DeepSeek retry is not the active worker')
worker = workers[0]
if entries[worker]['group'] != worker:
    raise RuntimeError('Worker does not own an isolated process group')
active = [(path, json.loads(path.read_text())) for path in destination.glob('raw/*/*.json')]
active = [(path, record) for path, record in active if record['status'] == 'started']
if len(active) != 1 or active[0][1]['model'] != 'deepseek-ai/DeepSeek-V4-Flash-0731':
    raise RuntimeError('Unexpected active benchmark record')
folder = active[0][0].parent
if any(json.loads(path.read_text()).get('milliseconds', 0) for path in folder.glob('*.json')):
    raise RuntimeError('This transition must not replace measured configurations')
reason = ('Close the superseded baseline retry phase after actual eight-GPU allocator OOMs and a verified '
          'FSDP backward memory bound. Preserve every attempt. Complete the final 131-model/four-mode '
          'comparison using the finalized compiler, recovered inputs and explicit capacity checks.')
stopped = []
try:
    for pid in coordinators:
        os.kill(pid, signal.SIGSTOP)
        stopped.append(pid)
    for pid, entry in entries.items():
        if str(root) in entry['command'] and (
            entry['command'].endswith('finish_benchmarks_v2.py 757309') or
            entry['command'].endswith('finish_inventory_v2.py 2810217')
        ):
            os.kill(pid, signal.SIGTERM)
    os.killpg(worker, signal.SIGTERM)
    deadline = time.monotonic() + 25
    while any(entry['group'] == worker and not entry['state'].startswith('Z') for entry in processes().values()) and time.monotonic() < deadline:
        time.sleep(0.25)
    if any(entry['group'] == worker and not entry['state'].startswith('Z') for entry in processes().values()):
        os.killpg(worker, signal.SIGKILL)
    if any(entry['group'] == worker and not entry['state'].startswith('Z') for entry in processes().values()):
        time.sleep(1)
    if any(entry['group'] == worker and not entry['state'].startswith('Z') for entry in processes().values()):
        raise RuntimeError('Owned distributed workers have not exited')
    archive = destination / 'archive' / f'baseline_transition_{time.time_ns()}' / folder.name
    archive.parent.mkdir(parents=True)
    shutil.copytree(folder, archive)
    interrupted = []
    for path in archive.rglob('*.json'):
        record = json.loads(path.read_text())
        if record.get('status') == 'started':
            record.update(status='interrupted', interruption_reason=reason)
            path.write_text(json.dumps(record, indent=2) + '\n')
            interrupted.append(str(path))
    snapshot = root / 'training_results_v2_single/raw' / folder.name
    originals = list(snapshot.glob('*.json'))
    if len(originals) != 4:
        raise RuntimeError('Four original terminal single-GPU records are required')
    for path in originals:
        shutil.copy2(path, folder / path.name)
        if path.with_suffix('.log').exists():
            shutil.copy2(path.with_suffix('.log'), folder / path.with_suffix('.log').name)
    for path in folder.glob('ranks/*.json'):
        record = json.loads(path.read_text())
        if record.get('status') == 'started':
            record.update(status='interrupted', interruption_reason=reason)
            path.write_text(json.dumps(record, indent=2) + '\n')
    remaining = [str(path) for path in destination.glob('raw/*/*.json')
                 if json.loads(path.read_text())['status'] == 'started']
    if remaining:
        raise RuntimeError(f'Unexpected incomplete baseline records: {remaining}')
    evidence = {'time': time.time(), 'reason': reason, 'controller': controller,
                'stopped_coordinators': coordinators, 'worker_group': worker,
                'archived_attempts': str(archive), 'interrupted_records': interrupted,
                'restored_single_gpu_records': [str(path) for path in originals],
                'distributed_retry_phase_complete': False, 'final_full_support_sweep_required': True}
    (destination / 'RETRY_PHASE_STOPPED.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps(evidence, indent=2), flush=True)
finally:
    for pid in stopped:
        try:
            os.kill(pid, signal.SIGTERM)
            os.kill(pid, signal.SIGCONT)
        except ProcessLookupError:
            pass
