import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


ROOT = Path(__file__).resolve().parent
COUNTS = {'symbolic_chunk_numeric': 4, 'global_tail_numeric': 8, 'scheduler_recursive_numeric': 8, 'subword_tail_numeric': 5, 'ocml_math_numeric': 4,
          'rng_geometry_numeric': 8, 'scheduler_dino_xcit_numeric': 4, 'tuple_softmax_numeric': 6,
          'multi_axis_layout_numeric': 9, 'mix_order_numeric': 2, 'autotune17_regression': 17,
          'simd128_regression': 128}


@instantiate_parametrized_tests
class TestSchedulerValidationVerifier(TestCase):
    @parametrize('case', ['valid', 'missing_recursive', 'wrong_recursive_count', 'skipped_recursive',
                         'bad_source_root', 'changed_fnuz_cause', 'legacy_ocml_error', 'numeric_failure'])
    def test_synthetic_reserved_result(self, case):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            script = root / 'verify_fallback_validation_v4.py'
            shutil.copyfile(ROOT / script.name, script)
            (root / 'test_flydsl_genuine_original.log').symlink_to(ROOT / 'test_flydsl_genuine_original.log')
            previous = json.loads((ROOT / 'fallback_validation_v3_tail/VERIFIED.json').read_text())
            causes = previous['permitted_remaining_error_causes']
            broad = '\n'.join(f'ERROR: {name}\n' + '\n'.join(lines) for name, lines in causes.items())
            if case == 'changed_fnuz_cause':
                broad = broad.replace('on gfx950)', 'on gfx950 changed)', 1)
            if case == 'legacy_ocml_error':
                name = next(name for name in previous['original_baseline_error_excerpts'] if name.startswith('test_device_library_ops '))
                broad += f'\nERROR: {name}\n' + '\n'.join(previous['original_baseline_error_excerpts'][name])
            worktree = root / 'fallback_fixes_v4'
            source = worktree / 'test/inductor/test_scheduler_recursive_mix.py'
            source.parent.mkdir(parents=True)
            source.write_text('synthetic test source\n')
            overlay = worktree / 'agent_space/run_overlay.py'
            overlay.parent.mkdir()
            overlay.write_text('synthetic overlay\n')
            hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in [source, overlay]}
            freeze = {'files': {str(source.relative_to(worktree)): hashes[str(source)]}, 'overlay_sha256': hashes[str(overlay)]}
            if case == 'bad_source_root':
                hashes = {name.replace('/fallback_fixes_v4/', '/fallback_fixes/'): digest for name, digest in hashes.items()}
            results = root / 'results'
            results.mkdir()
            commands = []
            for label in [*COUNTS, 'positive_gpu_guards']:
                if label == 'scheduler_recursive_numeric' and case == 'missing_recursive':
                    continue
                count = COUNTS.get(label)
                code = 1 if label == 'simd128_regression' else 0
                log = f'Ran {count} tests in 0.1s\nOK\n' if count else 'guard passed\n'
                if label == 'simd128_regression':
                    log = f'{broad}\nRan 128 tests in 0.1s\nFAILED (errors=5)\n'
                if label == 'scheduler_recursive_numeric':
                    if case == 'wrong_recursive_count':
                        log = 'Ran 7 tests in 0.1s\nOK\n'
                    elif case == 'skipped_recursive':
                        log = 'Ran 8 tests in 0.1s\nOK (skipped=1)\n'
                    elif case == 'numeric_failure':
                        log = 'FAIL: test_recursive_mix (NumericTest)\nAssertionError: mismatch\nRan 8 tests in 0.1s\nFAILED (failures=1)\n'
                        code = 1
                path = results / f'{label}.log'
                path.write_text(log)
                commands.append({'label': label, 'log': str(path), 'returncode': code})
            status = {'finished': 2, 'acquired': 1, 'state': 'test_failure', 'source_drift': [],
                      'physical_gpu': 'synthetic_cpu_fixture', 'freeze_manifest': freeze, 'source_hashes': hashes,
                      'commands': commands}
            (results / 'status.json').write_text(json.dumps(status))
            process = subprocess.run([sys.executable, '-S', str(script), '--results', 'results'], capture_output=True, text=True)
            if case == 'valid':
                self.assertEqual(process.returncode, 0, process.stderr)
                verified = json.loads((results / 'VERIFIED.json').read_text())
                self.assertEqual(len(verified['remaining_baseline_errors']), 5)
                self.assertEqual(len(verified['resolved_baseline_errors']), 3)
            else:
                self.assertNotEqual(process.returncode, 0)
                self.assertIn('RuntimeError:', process.stderr)
                self.assertFalse((results / 'VERIFIED.json').exists())


if __name__ == '__main__':
    run_tests()
