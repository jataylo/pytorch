from pathlib import Path
root=Path(__file__).resolve().parent
s=(root/'train_worker.py').read_text()
s=s.replace('import gc\n', 'import gc\nimport fcntl\nimport functools\nimport hashlib\n')
s=s.replace("    args = parser.parse_args()", "    parser.add_argument('--fsdp', action='store_true')\n    parser.add_argument('--backend-selection', action='store_true')\n    args = parser.parse_args()\n    rank = int(os.environ.get('RANK', '0')) if args.fsdp else 0\n    world_size = int(os.environ.get('WORLD_SIZE', '1')) if args.fsdp else 1\n    local_rank = int(os.environ.get('LOCAL_RANK', '0')) if args.fsdp else 0\n    base_output = Path(args.output)\n    if args.fsdp and rank:\n        args.output = str(base_output.parent / 'ranks' / f'{base_output.stem}.rank{rank}.json')\n    diagnostics = base_output.parent / 'kernels' / f'{base_output.stem}.rank{rank}.jsonl'\n    os.environ['TORCHINDUCTOR_FLYDSL_SIMD_DIAGNOSTICS'] = str(diagnostics)\n    timing_lock = Path('/dev/shm/pytorch-simd-v2-benchmark.lock').open('a')\n    fcntl.flock(timing_lock, fcntl.LOCK_SH)")
s=s.replace("    result['physical_gpu'] = os.environ.get('CUDA_VISIBLE_DEVICES')", "    result['physical_gpu'] = os.environ.get('CUDA_VISIBLE_DEVICES')\n    result.update(rank=rank, world_size=world_size, parallelism='fsdp' if args.fsdp else 'single_gpu',\n                  diagnostics_file=str(diagnostics), benchmark_variant='autotune_v2_aten')\n    fingerprint = Path(__file__).with_name('source_fingerprint_v2.json')\n    if fingerprint.exists(): result['source_fingerprint'] = json.loads(fingerprint.read_text())")
s=s.replace("        result['wall_seconds'] =", "        os.environ['TORCHINDUCTOR_FLYDSL_DIAGNOSTIC_CONTEXT'] = json.dumps({\n            'suite': args.suite, 'model': args.model, 'backend': args.backend,\n            'autotune': args.autotune, 'rank': rank, 'phase': result.get('phase'),\n        })\n        result['wall_seconds'] =")
s=s.replace("Path('/dev/shm/pytorch-simd-compiled-artifacts')", "Path('/dev/shm/pytorch-simd-v2-compiled-artifacts')")
s=s.replace("        os.environ['TORCHINDUCTOR_COMPILE_THREADS'] = '32'", "        os.environ['TORCHINDUCTOR_COMPILE_THREADS'] = '8' if args.fsdp else '24'")
s=s.replace("        torch.set_num_threads(8)", "        dist = None\n        if args.fsdp:\n            import torch.distributed as dist\n            from datetime import timedelta\n            torch.cuda.set_device(local_rank)\n            dist.init_process_group('nccl', timeout=timedelta(minutes=30))\n        torch.set_num_threads(8)")
s=s.replace("        config.max_autotune = bool(args.autotune)", "        config.flydsl.simd_autotune_backend = args.backend_selection\n        config.flydsl.simd_diagnostics_path = str(diagnostics)\n        config.max_autotune = False\n        config.max_autotune_gemm = False\n        config.max_autotune_gemm_backends = 'ATEN'\n        config.max_autotune_conv_backends = 'ATEN'\n        config.conv_1x1_as_mm = False")
s=s.replace("            'max_autotune': config.max_autotune,", "            'flydsl.simd_autotune_backend': config.flydsl.simd_autotune_backend,\n            'max_autotune': config.max_autotune,\n            'max_autotune_gemm': config.max_autotune_gemm,\n            'conv_1x1_as_mm': config.conv_1x1_as_mm,")
s=s.replace('props = torch.cuda.get_device_properties(0)', 'props = torch.cuda.get_device_properties(local_rank)')
s=s.replace("        free, _ = torch.cuda.mem_get_info()", "        if getattr(meta, 'config', None) is not None:\n            model_config = meta.config.to_dict()\n            result['model_config_sha256'] = hashlib.sha256(json.dumps(model_config, sort_keys=True, default=str).encode()).hexdigest()\n            result['model_config_commit'] = getattr(meta.config, '_commit_hash', None)\n        free, _ = torch.cuda.mem_get_info()\n        total_free = free\n        if args.fsdp:\n            capacities = [None] * world_size\n            dist.all_gather_object(capacities, {'free': free, 'uuid': str(props.uuid), 'pci': props.pci_bus_id})\n            total_free = sum(c['free'] for c in capacities)\n            result['gpu_group'] = capacities")
s=s.replace('if parameter_bytes * 2 > free:', 'if parameter_bytes * 2 > total_free:')
s=s.replace("error='FP32 weights plus gradients alone exceed free GPU memory'", "error='FP32 weights plus gradients alone exceed aggregate free GPU memory'")
s=s.replace("        model = load_model(args.model, spec, 'cuda', pretrained=False).eval()\n        inputs, kwargs = make_model_input(model, args.model, args.batch_size, spec, 'cuda')", """        if args.fsdp:
            from torch.distributed.fsdp import FullyShardedDataParallel as FSDP, MixedPrecision
            from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy
            model = (load_model(args.model, spec, 'cpu', pretrained=False) if rank == 0
                     else load_model_meta(args.model, spec).to(spec.param_dtype)).eval()
            split_names = set(getattr(model, '_no_split_modules', None) or [])
            block_types = {type(m) for m in model.modules() if type(m).__name__ in split_names}
            if not block_types:
                block_types = {type(child) for m in model.modules() if isinstance(m, torch.nn.ModuleList)
                               for child in m if sum(p.numel() for p in child.parameters()) > 1000000}
            if not block_types:
                raise RuntimeError('No safe transformer/denoiser block boundary found for FSDP')
            local_batch = args.batch_size // world_size if args.batch_size % world_size == 0 else args.batch_size
            replicated = args.batch_size % world_size != 0
            result.update(local_batch_size=local_batch, batch_distribution='replicated' if replicated else 'data_parallel',
                          fsdp_block_types=sorted(t.__name__ for t in block_types))
            torch.manual_seed(2026 if replicated else 2026 + rank)
            inputs, kwargs = make_model_input(model, args.model, local_batch, spec, 'cuda')
            model = FSDP(model, device_id=local_rank, use_orig_params=True, sync_module_states=True,
                         param_init_fn=lambda m: m.to_empty(device=torch.device('cuda', local_rank), recurse=False),
                         auto_wrap_policy=functools.partial(transformer_auto_wrap_policy, transformer_layer_cls=block_types),
                         mixed_precision=MixedPrecision(param_dtype=torch.bfloat16, reduce_dtype=torch.float32))
            args.skip_eager_reference = True
        else:
            model = load_model(args.model, spec, 'cuda', pretrained=False).eval()
            inputs, kwargs = make_model_input(model, args.model, args.batch_size, spec, 'cuda')""")
s=s.replace("        result['phase'] = 'timing'\n        save()", """        result['phase'] = 'waiting_for_isolated_timing'
        save()
        fcntl.flock(timing_lock, fcntl.LOCK_UN)
        if args.fsdp: dist.barrier()
        if rank == 0: fcntl.flock(timing_lock, fcntl.LOCK_EX)
        if args.fsdp: dist.barrier()
        result['phase'] = 'timing'
        save()""")
s=s.replace("            begin = time.perf_counter()", "            if args.fsdp: dist.barrier()\n            begin = time.perf_counter()")
s=s.replace("            samples.append((time.perf_counter() - begin) * 1000 / args.iterations)", "            elapsed = (time.perf_counter() - begin) * 1000 / args.iterations\n            if args.fsdp:\n                elapsed_tensor = torch.tensor(elapsed, device='cuda')\n                dist.all_reduce(elapsed_tensor, op=dist.ReduceOp.MAX)\n                elapsed = elapsed_tensor.item()\n            samples.append(elapsed)")
s=s.replace("        if not torch.isfinite(last_loss).item():", "        if args.fsdp: dist.barrier()\n        if rank == 0: fcntl.flock(timing_lock, fcntl.LOCK_UN)\n        if not torch.isfinite(last_loss).item():")
s=s.replace("    finally:\n        save()", "    finally:\n        save()\n        timing_lock.close()\n        if args.fsdp and result['status'] == 'error':\n            raise SystemExit(1)\n        if args.fsdp and dist is not None and dist.is_initialized():\n            dist.destroy_process_group()")
(root/'train_worker_v2.py').write_text(s)
s=(root/'run_suite.py').read_text().replace("ROOT / 'train_worker.py'", "ROOT / 'train_worker_v2.py'")
s=s.replace("default='training_results'", "default='training_results_v2'")
s=s.replace("(ROOT / 'model_manifest.json')", "(ROOT / args.manifest)")
s=s.replace("    parser.add_argument('--models'", "    parser.add_argument('--manifest', default='model_manifest_v2.json')\n    parser.add_argument('--models'")
(root/'run_suite_v2.py').write_text(s)
