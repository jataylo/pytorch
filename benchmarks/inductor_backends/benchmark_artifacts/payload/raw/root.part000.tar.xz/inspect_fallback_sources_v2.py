import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


root = Path(__file__).resolve().parent
destination = root / 'fallback_review_v2'
events = [json.loads(line) for line in (destination / 'events.jsonl').open()]
wanted = {(event['suite'], event['model'], event['autotune'], event['kernel_name']) for event in events}
found = []
for record_path in (root / 'training_results_v2/raw').glob('*/flydsl_autotune*.json'):
    record = json.loads(record_path.read_text())
    identity = record['suite'], record['model'], record['autotune']
    names = {key[3] for key in wanted if key[:3] == identity}
    if not names:
        continue
    audit = record.get('codegen_audit', {}).get('file')
    if not audit or not Path(audit).exists():
        continue
    seen = set()
    for graph in json.loads(Path(audit).read_text())['graphs']:
        wrapper = Path(graph['wrapper'])
        for node in ast.walk(ast.parse(wrapper.read_text())):
            if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute) or node.func.attr != 'triton':
                continue
            if len(node.args) < 2 or not isinstance(node.args[0], ast.Constant) or node.args[0].value not in names:
                continue
            if not isinstance(node.args[1], ast.Constant) or not isinstance(node.args[1].value, str):
                continue
            name, source = node.args[0].value, node.args[1].value
            digest = hashlib.sha256(source.encode()).hexdigest()
            if (name, digest) in seen:
                continue
            seen.add((name, digest))
            dimensions = dict(re.findall(r'^\s*((?:x|y|z|r\d+_)numel)\s*=\s*([0-9]+)', source, re.M))
            size_hints = re.search(r'size_hints=(\{[^}]+\})', source)
            path = destination / 'triton_sources' / f'{digest[:20]}.py'
            path.parent.mkdir(exist_ok=True)
            path.write_text(source)
            found.append(dict(suite=identity[0], model=identity[1], autotune=identity[2], kernel_name=name,
                              wrapper=str(wrapper), source_file=str(path), sha256=digest,
                              dimensions=dimensions, size_hints=size_hints.group(1) if size_hints else None,
                              partial_softmax='online_softmax_reduce' in source,
                              mixed_order='partial_accumulate' in source))
(destination / 'triton_source_index.json').write_text(json.dumps(found, indent=2) + '\n')
print(json.dumps({'kernel_sources': len(found), 'models': len({item['model'] for item in found}),
                  'dimension_patterns': dict(Counter(','.join(sorted(item['dimensions'])) for item in found))}, indent=2))
