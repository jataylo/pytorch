from pathlib import Path
root=Path(__file__).resolve().parent/'pytorch_codegen_v13'
p=root/'torch/_inductor/codegen/amd_kernel_optimizations.py';s=p.read_text().replace('assignments.get("x0")','assignments.get("x0", ast.Constant(None))').replace('assignments.get("x1")','assignments.get("x1", ast.Constant(None))');p.write_text(s)
p=root/'torch/_inductor/config.py';s=p.read_text().replace('class triton:\n    """','class triton:\n    """',1);needle='    # Use cudagraphs on output code\n';s=s.replace(needle,'    # Opt-in wave64 layout and reduction tuning experiments on gfx950.\n    amd_kernel_optimizations = False\n\n'+needle,1);p.write_text(s)
p=root/'torch/_inductor/codegen/triton.py';s=p.read_text();needle='        return code.getvalue()\n\n    @staticmethod\n    def _get_persistent_RBLOCK';s=s.replace(needle,'''        source = code.getvalue()
        if config.triton.amd_kernel_optimizations and triton_meta["device"].cc == "gfx950":
            from .amd_kernel_optimizations import optimize_pointwise_source

            source = optimize_pointwise_source(source)
        return source

    @staticmethod
    def _get_persistent_RBLOCK''',1)
needle='            **self.inductor_meta_common(),\n        }\n\n        # Triton compiler includes'
s=s.replace(needle,'''            **self.inductor_meta_common(),
        }
        if config.triton.amd_kernel_optimizations and triton_meta["device"].cc == "gfx950":
            inductor_meta["amd_reduction_tuning"] = True

        # Triton compiler includes''',1);p.write_text(s)
p=root/'torch/_inductor/runtime/triton_heuristics.py';s=p.read_text();s=s.replace('        compile_args = (\n            ASTSource(','''        source_type = ASTSource
        if self.inductor_meta.get("use_gluon"):
            from triton.experimental.gluon import GluonASTSource

            source_type = GluonASTSource
        compile_args = (
            source_type(''',1)
needle='    configs = _handle_combo_kernel_per_subkernel_blocks(\n'
pos=s.index(needle,s.index('\ndef pointwise('))
s=s[:pos]+'''    if inductor_meta.get("amd_gluon_family"):
        configs = _amd_layout_configs(inductor_meta["amd_gluon_family"])
        if return_configs:
            return configs
        return cached_autotune(
            size_hints, configs, triton_meta=triton_meta,
            inductor_meta=inductor_meta, heuristic_type=HeuristicType.POINTWISE,
            filename=filename,
        )

'''+s[pos:]
needle='    configs = _maybe_filter_configs_for_tma_restrictions(inductor_meta, configs)'
pos=s.index(needle,s.index('\ndef reduction('));s=s[:pos]+'''    configs = _amd_reduction_configs(configs, size_hints, inductor_meta, persistent=False)
'''+s[pos:]
needle='    # This key is not added to the inductor meta';pos=s.index(needle,s.index('\ndef persistent_reduction('));s=s[:pos]+'''    configs = _amd_reduction_configs(configs, size_hints, inductor_meta, persistent=True)

'''+s[pos:]
helper='''
def _amd_layout_configs(family: str) -> list[Config]:
    if family == "transpose":
        choices = [(2048, w, v, 1) for w, v in [(1, 8), (2, 4), (4, 2), (4, 4), (8, 4)]]
        choices += [(block, 4, 4, 1) for block in (512, 1024, 4096)]
    else:
        choices = [(512, 1, 2, 2), (512, 1, 4, 2), (1024, 2, 8, 1),
                   (2048, 2, 4, 2), (2048, 1, 4, 8), (4096, 2, 8, 4),
                   (4096, 4, 4, 1), (8192, 4, 8, 1)]
    return [Config({"XBLOCK": block, "AMD_VEC": vec, "AMD_UNROLL": unroll,
                    "AMD_WARPS": warps}, num_warps=warps, num_stages=1)
            for block, warps, vec, unroll in choices]


def _amd_reduction_configs(configs, size_hints, inductor_meta, *, persistent):
    if not inductor_meta.get("amd_reduction_tuning") or set(size_hints) != {"x", "r0_"} or inductor_meta.get("RSPLIT_SIZE") or inductor_meta.get("deterministic"):
        return configs
    extra = []
    if persistent:
        for x, warps in [(1, 1), (2, 2), (4, 1), (4, 2), (8, 2), (8, 4), (16, 1)]:
            if x <= size_hints["x"] and x * size_hints["r0_"] <= 32768:
                extra.append(Config({"XBLOCK": x}, num_warps=warps, num_stages=1))
    else:
        for x, r, warps in [(1, 512, 8), (1, 1024, 4), (1, 2048, 4), (1, 4096, 8), (1, 8192, 8), (32, 64, 4), (32, 64, 8)]:
            if x <= size_hints["x"] and r <= size_hints["r0_"]:
                extra.append(Config({"XBLOCK": x, "R0_BLOCK": r}, num_warps=warps, num_stages=1))
    seen = {(*sorted(c.kwargs.items()), c.num_warps, c.num_stages) for c in configs}
    result = list(configs)
    for cfg in extra:
        key = (*sorted(cfg.kwargs.items()), cfg.num_warps, cfg.num_stages)
        if key not in seen:
            seen.add(key)
            result.append(cfg)
    return result

'''
pos=s.index('\ndef pointwise(');s=s[:pos]+'\n'+helper+s[pos:];p.write_text(s)
p=root/'torch/_inductor/runtime/hints.py';s=p.read_text();needle='    # Global inductor config snapshot';s=s.replace(needle,'    amd_reduction_tuning: bool\n    amd_gluon_family: str\n    use_gluon: bool\n\n'+needle,1);p.write_text(s)
