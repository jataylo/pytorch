import itertools
from types import SimpleNamespace
from unittest import mock

import torch
from fsdp_memory_bound_v3 import fsdp_backward_memory_bound, VERIFIED_SOURCES
from test_deepseek_meta_init_feasibility_v3 import meta_model, tiny_config
from transformers.models.deepseek_v4.modeling_deepseek_v4 import DeepseekV4ForCausalLM
from torch.distributed.fsdp._runtime_utils import _get_reduce_scatter_tensors
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


@instantiate_parametrized_tests
class TestFSDPMemoryBound(TestCase):
    @parametrize('world', [2, 4, 8])
    def test_actual_meta_counts_and_disjoint_floor_terms(self, world):
        model = meta_model().to(torch.float32)
        result = fsdp_backward_memory_bound(model, world)
        self.assertIsNotNone(result)
        blocks = [sum(p.numel() for p in layer.parameters()) for layer in model.model.layers]
        total = sum(p.numel() for p in model.parameters())
        root = total - sum(blocks)
        masters = sum(n // world * 4 for n in blocks) + root // world * 4
        self.assertEqual(result['unique_parameter_numel'], total)
        self.assertEqual(result['root_parameter_numel'], root)
        self.assertEqual(result['master_shards_bytes'], masters)
        self.assertEqual(result['decoder_blocks'], len(blocks))
        gradients = sum(n // world * 4 for n in blocks)
        cast = masters + gradients + min(n * 6 - n // world * 4 for n in blocks)
        reduce = masters + gradients + min(blocks) * 4
        self.assertEqual(result['decoder_gradient_shards_bytes'], gradients)
        self.assertEqual(result['guaranteed_cast_lower_bound_bytes'], cast)
        self.assertEqual(result['guaranteed_reduce_lower_bound_bytes'], reduce)
        self.assertEqual(result['per_rank_lower_bound_bytes'], max(cast, reduce))
        self.assertFalse(result['expected_reverse_order_diagnostics']['used_for_capacity_decision'])
        for stage in result['expected_reverse_order_diagnostics']['stages_in_backward_order']:
            index = int(stage['path'].split('.')[-1])
            previous = sum(n // world * 4 for n in blocks[index + 1:])
            self.assertEqual(stage['later_decoder_grad_shards_bytes'], previous)
            self.assertEqual(stage['cast_peak_lower_bound_bytes'], masters + previous + blocks[index] * 6)
            self.assertEqual(stage['reduce_peak_lower_bound_bytes'], masters + previous + blocks[index] * 4 + blocks[index] // world * 4)
        self.assertTrue(all(p.is_meta for p in model.parameters()))
        self.assertFalse(torch.cuda.is_initialized())

    @parametrize('world', [2, 4, 8])
    def test_exhaustive_completion_orders_and_inflight_storage_states(self, world):
        config = tiny_config()
        config.num_hidden_layers = 3
        config.layer_types = ['compressed_sparse_attention', 'heavily_compressed_attention', 'compressed_sparse_attention']
        config.mlp_layer_types = ['hash_moe', 'moe', 'moe']
        with torch.device('meta'):
            model = DeepseekV4ForCausalLM(config)
        result = fsdp_backward_memory_bound(model.to(torch.float32), world)
        self.assertIsNotNone(result)
        counts = [sum(p.numel() for p in layer.parameters()) for layer in model.model.layers]
        root = sum(p.numel() for p in model.parameters()) - sum(counts)
        masters = [torch.empty(n // world, dtype=torch.float32) for n in [root, *counts]]
        for order in itertools.permutations(range(len(counts))):
            last = order[-1]
            for states in itertools.product(['shard_fp32', 'full_bf16', 'full_fp32'], repeat=len(order) - 1):
                previous = []
                for index, state in zip(order[:-1], states):
                    size = counts[index] // world if state == 'shard_fp32' else counts[index]
                    dtype = torch.bfloat16 if state == 'full_bf16' else torch.float32
                    previous.append(torch.empty(size, dtype=dtype))
                full_bf16 = torch.ones(counts[last], dtype=torch.bfloat16)
                full_fp32 = full_bf16.to(torch.float32)
                cast_storage = {tensor.untyped_storage()._cdata: tensor.untyped_storage().nbytes()
                                for tensor in [*masters, *previous, full_bf16, full_fp32]}
                self.assertLessEqual(result['guaranteed_cast_lower_bound_bytes'], sum(cast_storage.values()))
                padded, output = _get_reduce_scatter_tensors(SimpleNamespace(world_size=world), full_fp32)
                reduce_storage = {tensor.untyped_storage()._cdata: tensor.untyped_storage().nbytes()
                                  for tensor in [*masters, *previous, full_fp32, padded, output]}
                self.assertLessEqual(result['guaranteed_reduce_lower_bound_bytes'], sum(reduce_storage.values()))
                self.assertLessEqual(result['per_rank_lower_bound_bytes'], max(sum(cast_storage.values()), sum(reduce_storage.values())))
        self.assertFalse(torch.cuda.is_initialized())

    @parametrize('kwargs', [
        {'master_dtype': torch.bfloat16}, {'compute_dtype': torch.float32},
        {'reduce_dtype': torch.bfloat16}, {'cpu_offload': True},
        {'keep_low_precision_grads': True}, {'use_orig_params': False},
        {'sharding_strategy': 'SHARD_GRAD_OP'},
    ])
    def test_unknown_protocol_is_not_rejected_by_this_bound(self, kwargs):
        self.assertIsNone(fsdp_backward_memory_bound(meta_model().to(torch.float32), 8, **kwargs))

    @parametrize('world', [0, 1, 2.0, True])
    def test_unknown_world(self, world):
        self.assertIsNone(fsdp_backward_memory_bound(meta_model(), world))

    def test_actual_dtype_must_match_master_dtype(self):
        self.assertIsNone(fsdp_backward_memory_bound(meta_model().to(torch.bfloat16), 8))

    def test_parameter_aliases_and_frozen_parameters_are_unknown(self):
        self.assertIsNone(fsdp_backward_memory_bound(meta_model(tied=True), 8))
        model = meta_model()
        next(model.parameters()).requires_grad_(False)
        self.assertIsNone(fsdp_backward_memory_bound(model, 8))

    def test_nonmeta_and_other_architectures_are_unknown(self):
        model = meta_model()
        model.to_empty(device='cpu')
        self.assertIsNone(fsdp_backward_memory_bound(model, 8))
        self.assertIsNone(fsdp_backward_memory_bound(torch.nn.Linear(4, 4), 8))

    def test_unknown_wrap_boundaries_and_checkpointing_are_unknown(self):
        model = meta_model()
        model._no_split_modules = ['DeepseekV4Experts']
        self.assertIsNone(fsdp_backward_memory_bound(model, 8))
        model = meta_model()
        model.model.gradient_checkpointing = True
        self.assertIsNone(fsdp_backward_memory_bound(model, 8))

    def test_source_revision_guard(self):
        with mock.patch.dict(VERIFIED_SOURCES, {'torch.distributed.fsdp._runtime_utils': 'unverified'}):
            self.assertIsNone(fsdp_backward_memory_bound(meta_model(), 8))

    def test_capacity_rejection_is_one_way_and_reports_evidence(self):
        model = meta_model()
        result = fsdp_backward_memory_bound(model, 8, free_bytes_per_rank=[0] * 8)
        self.assertTrue(result['insufficient_capacity'])
        self.assertIn('lower bound', result['reason'])
        self.assertEqual(result['world_size'], 8)
        result = fsdp_backward_memory_bound(model, 8, free_bytes_per_rank=[1 << 50] * 8)
        self.assertFalse(result['insufficient_capacity'])
        self.assertNotIn('reason', result)
        with self.assertRaisesRegex(ValueError, 'one nonnegative integer per rank'):
            fsdp_backward_memory_bound(model, 8, free_bytes_per_rank=[0])


if __name__ == '__main__':
    run_tests()
