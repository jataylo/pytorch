from pathlib import Path
root=Path(__file__).resolve().parent/'pytorch_codegen_v13'
p=root/'torch/_inductor/codegen/triton.py';s=p.read_text().replace('            source = optimize_pointwise_source(source)','            placeholder = str(Placeholder.KERNEL_NAME)\n            source = optimize_pointwise_source(source.replace(placeholder, "AMD_KERNEL_NAME"))\n            source = source.replace("AMD_KERNEL_NAME", placeholder)');p.write_text(s)
p=root/'torch/_inductor/codegen/amd_kernel_optimizations.py';s=p.read_text();needle='    expression = ast.dump(expand(store.args[1]))';s=s.replace(needle,'''    valid_masks = {"None", "xmask"}
    xmask = ast.unparse(assignments.get("xmask", ast.Constant(None)))
    if xmask not in ("xindex < xnumel", "tl.full([XBLOCK], True, tl.int1)[:]"):
        return source
    if len(store.args) > 2 and ast.unparse(store.args[2]) not in valid_masks:
        return source
    if any(len(load.args) > 1 and ast.unparse(load.args[1]) not in valid_masks for load in loads):
        return source
    if any(keyword.arg == "mask" and ast.unparse(keyword.value) not in valid_masks for call in [store, *loads] for keyword in call.keywords):
        return source

'''+needle);p.write_text(s)
