
def use_triton_language(source: str) -> str:
    """Let Triton infer layouts for a recognized AMD specialization."""
    tree = ast.parse(source)
    if not any(isinstance(node, ast.ImportFrom) and node.module and 'gluon' in node.module for node in tree.body):
        return source

    class Convert(ast.NodeTransformer):
        def visit_ImportFrom(self, node):
            if node.module == 'triton.experimental.gluon.language.extra':
                node.module = 'triton.language.extra'
                return node
            if node.module in ('triton.experimental', 'triton.experimental.gluon'):
                return None
            return node

        def visit_AnnAssign(self, node):
            if isinstance(node.target, ast.Name) and node.target.id == '_amd_layout':
                return None
            return self.generic_visit(node)

        def visit_Name(self, node):
            if node.id in ('gl', 'gluon'):
                node.id = 'tl' if node.id == 'gl' else 'triton'
            return node

        def visit_Call(self, node):
            node.keywords = [keyword for keyword in node.keywords if keyword.arg != 'layout']
            return self.generic_visit(node)

    tree = Convert().visit(tree)
    for fn in (node for node in tree.body if isinstance(node, ast.FunctionDef)):
        used = {node.id for statement in fn.body for node in ast.walk(statement) if isinstance(node, ast.Name)}
        removed = {arg.arg for arg in fn.args.args if arg.arg.startswith('AMD_') and arg.arg not in used}
        fn.args.args = [arg for arg in fn.args.args if arg.arg not in removed]
        for decorator in fn.decorator_list:
            if not isinstance(decorator, ast.Call):
                continue
            keywords = {kw.arg: kw.value for kw in decorator.keywords}
            meta = keywords.get('triton_meta')
            if isinstance(meta, ast.Dict):
                for key, value in zip(meta.keys, meta.values):
                    if ast.literal_eval(key) == 'signature':
                        pairs = [(key, val) for key, val in zip(value.keys, value.values) if ast.literal_eval(key) not in removed]
                        value.keys = [key for key, _ in pairs]
                        value.values = [val for _, val in pairs]
            meta = keywords.get('inductor_meta')
            if isinstance(meta, ast.Dict):
                for index, key in enumerate(meta.keys):
                    if ast.literal_eval(key) == 'use_gluon':
                        meta.values[index] = ast.Constant(False)
                    elif ast.literal_eval(key) == 'amd_gluon_family':
                        meta.keys[index] = ast.Constant('amd_native_family')
    ast.fix_missing_locations(tree)
    return ast.unparse(tree) + '\n'
