from pathlib import Path
p=Path(__file__).parent/'pytorch/torch/_inductor/codegen/flydsl/flydsl_simd.py'
s=p.read_text()
a=s.index('    @staticmethod\n    def _candidates(')
b=s.index('    def _with_candidates(',a)
s=s[:a]+'''    @staticmethod
    def _candidates(kernel: FlyDSLKernel) -> list[dict[str, int]]:
        """A bounded search over launch geometry and reduction algorithms."""
        stage = kernel.stage
        numel = kernel.xnumel * kernel.ynumel * kernel.rnumel
        tuned = _tune_table()
        if (
            kernel.in_combo
            or numel < config.flydsl.simd_autotune_min_numel
            or kernel._has_atomic()
            or not _tune("autotune", 1)
        ):
            return []
        cands = []
        if stage == "pointwise":
            w = kernel.ept
            for threads, ept, unroll in (
                (128, w, 1), (256, w, 1), (64, w, 4),
                (128, w, 2), (256, w, 2), (64, max(1, w // 2), 2),
                (128, max(1, w // 2), 2), (512, w, 1),
                (64, w, 8), (256, w, 4), (64, 1, 2), (128, w, 4),
            ):
                cands.append({"threads": threads, "ept": ept, "unroll": unroll})
        elif stage == "tile":
            for fast, slow, threads in (
                (32, 32, 64), (64, 32, 128), (32, 64, 128),
                (64, 64, 256), (16, 32, 64), (32, 16, 64),
            ):
                cands.append({"tile_f": fast, "tile_s": slow, "threads": threads})
        elif stage == "column":
            for threads in [64, 128, 256, 512, 1024]:
                cands.append({"threads": threads})
            for stride in [16, 32, 64]:
                if kernel.threads % stride == 0:
                    cands.append({"col_stride": stride})
            for unroll in [1, 2, 4, 8]:
                cands.append({"col_unroll": unroll})
            cands.append({"col_pair": 0 if kernel.cpair == 2 else 1})
        elif stage in ("row", "norm"):
            lanes = sorted({max(1, kernel.tpr // 2), kernel.tpr, min(1024, 2 * kernel.tpr), 64, 128, 256})
            # Try both algorithms before spending the budget on nearby geometries.
            if kernel.persistent:
                cands.append({"persistent": 0})
            for tpr in lanes:
                cands.append({"row_tpr": tpr})
            for ept in sorted({1, max(1, kernel.ept // 2), kernel.ept}):
                cands.append({"ept": ept})
            if kernel.persistent:
                for rows in [1, 2, 4, 8]:
                    cands.append({"xunroll": rows})
            else:
                for unroll in [1, 2, 4, 8]:
                    cands.append({"row_unroll": unroll})
                for threads in [64, 128, 256, 512]:
                    cands.append({"threads": threads, "row_tpr": threads})
        # Explicit developer overrides remain fixed throughout the search.
        seen = set()
        result = []
        for candidate in cands:
            if candidate.keys() & tuned.keys():
                continue
            key = tuple(sorted(candidate.items()))
            if key not in seen:
                seen.add(key)
                result.append(candidate)
        return result[: max(0, config.flydsl.simd_autotune_max_configs - 1)]

''' +s[b:]
s=s.replace('self.persistent = iters * self.ept <= PERSISTENT_MAX_UNROLL', 'self.persistent = (\n            iters * self.ept <= PERSISTENT_MAX_UNROLL and bool(_tune("persistent", 1))\n        )')
a=s.index('    def _lower_candidates(')
b=s.index('    def _define_flydsl_kernel(',a)
s=s[:a]+'''    def _lower_candidates(
        self, cands, kernel, src_code, kernel_features, node_schedule, tiling
    ) -> str:
        from .flydsl_diagnostics import record_kernel_decision

        arg_names = kernel.arg_names()
        warm = self._warm_args(kernel, kernel_features, arg_names)
        srcs = [src_code]
        count = metrics.generated_kernel_count
        try:
            for cand in cands:
                try:
                    with _tune_override(cand):
                        k = FlyDSLKernel(tiling, features=kernel_features)
                        self.codegen_node_schedule_with_kernel(node_schedule, k)
                        with V.set_kernel_handler(k):
                            source = k.codegen_kernel()
                    if k.arg_names() != arg_names or source in srcs:
                        continue
                    srcs.append(source)
                except (FlyDSLUnsupported, NotImplementedError, TypeError, KeyError, AssertionError) as exc:
                    record_kernel_decision({
                        "category": "candidate_rejected", "stage": kernel.stage,
                        "candidate": cand, "reason": str(exc),
                    })
        finally:
            metrics.generated_kernel_count = count
        if len(srcs) == 1:
            return src_code
        return _autotune_source(srcs, arg_names, warm)

''' +s[b:]
p.write_text(s)
