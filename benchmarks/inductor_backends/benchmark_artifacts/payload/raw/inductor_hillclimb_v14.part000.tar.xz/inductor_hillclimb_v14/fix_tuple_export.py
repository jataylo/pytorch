from pathlib import Path
b=Path(__file__).resolve().parent.parent/'pytorch_codegen_v13'
p=b/'benchmarks/inductor_backends/amd_kernel_hillclimb.py';s=p.read_text().replace('return value if _returns_tuple else value[0] if isinstance(value,(tuple,list)) else value','return tuple(value) if _returns_tuple and isinstance(value,(tuple,list)) else value if _returns_tuple else value[0] if isinstance(value,(tuple,list)) else value');p.write_text(s)
