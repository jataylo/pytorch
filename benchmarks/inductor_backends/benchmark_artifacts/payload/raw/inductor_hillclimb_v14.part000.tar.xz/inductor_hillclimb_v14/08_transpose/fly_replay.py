
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=8 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 16, 8):
        xindex = _b * 1024 + (_j // 8) * 512 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
    for _j in range_constexpr(16):
        xindex = _b * 1024 + (_j // 8) * 512 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_kernel_0", 64, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 10240, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_compiled(10240, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=8 unroll=1
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(8):
        xindex = _b * 1024 + (_j // 8) * 1024 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_kernel_0", 128, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 10240, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_compiled(10240, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=8 unroll=1
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(8):
        xindex = _b * 2048 + (_j // 8) * 2048 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_kernel_0", 256, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 5120, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_compiled(5120, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=8 unroll=4
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 32, 8):
        xindex = _b * 2048 + (_j // 8) * 512 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
    for _j in range_constexpr(32):
        xindex = _b * 2048 + (_j // 8) * 512 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_kernel_0", 64, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 5120, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_compiled(5120, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=8 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 16, 8):
        xindex = _b * 2048 + (_j // 8) * 1024 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
    for _j in range_constexpr(16):
        xindex = _b * 2048 + (_j // 8) * 1024 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_kernel_0", 128, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 5120, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_compiled(5120, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=8 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 16, 8):
        xindex = _b * 4096 + (_j // 8) * 2048 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
    for _j in range_constexpr(16):
        xindex = _b * 4096 + (_j // 8) * 2048 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_kernel_0", 256, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 2560, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_compiled(2560, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=4 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 8, 4):
        xindex = _b * 512 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 4, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
    for _j in range_constexpr(8):
        xindex = _b * 512 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 4, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 4, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_kernel_0", 64, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 20480, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_compiled(20480, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=4 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 8, 4):
        xindex = _b * 1024 + (_j // 4) * 512 + _t * 4 + _j % 4
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 4, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
    for _j in range_constexpr(8):
        xindex = _b * 1024 + (_j // 4) * 512 + _t * 4 + _j % 4
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 4, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 4, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_kernel_0", 128, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 10240, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_compiled(10240, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=8 unroll=1
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(8):
        xindex = _b * 4096 + (_j // 8) * 4096 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(512, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_kernel = flyc.kernel(known_block_size=[512, 1, 1])(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_kernel_0", 512, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 2560, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_compiled(2560, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=8 unroll=8
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 64, 8):
        xindex = _b * 4096 + (_j // 8) * 512 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
    for _j in range_constexpr(64):
        xindex = _b * 4096 + (_j // 8) * 512 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_kernel_0", 64, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 2560, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_compiled(2560, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=8 unroll=4
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 32, 8):
        xindex = _b * 8192 + (_j // 8) * 2048 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
    for _j in range_constexpr(32):
        xindex = _b * 8192 + (_j // 8) * 2048 + _t * 8 + _j % 8
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', '80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80))', 0), _j, 8, _r_in_ptr0, lambda: 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_kernel_0", 256, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 1280, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_compiled(1280, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # pointwise xnumel=10485760 ept=1 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 20971520)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 20971520)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(2):
        xindex = _b * 128 + (_j // 1) * 64 + _t * 1 + _j % 1
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.load(_r_in_ptr0, 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
    for _j in range_constexpr(2):
        xindex = _b * 128 + (_j // 1) * 64 + _t * 1 + _j % 1
        x0 = fdp.imod(xindex, 2560)
        x1 = fdp.idiv(xindex, 2560)
        x2 = xindex
        tmp0 = fdp.load(_r_in_ptr0, 80*(fdp.imod(x1, 128)) + 10240*(fdp.idiv(x0, 80)) + 327680*(fdp.idiv(x1, 128)) + (fdp.imod(x0, 80)), 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp2 = fdp.to(tmp1, 'f32')
        fdp.store(_r_out_ptr0, x2, tmp2, 'bf16')


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_launch = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_kernel, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_launch
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_launch is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_kernel = flyc.kernel(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_kernel)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_launch = flyc.jit(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_launch_fn)
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_launch


flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_compiled = None
flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_binary = '/dev/shm/pytorch-simd-training-cache/b3d9ae7e193f820e7528/inductor/4l/c4ls5uhydgryb6ejl6bhpun4xgcdwundqh6zfmo3xbirwwp5kkwb.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11.hsaco"


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_compiled
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_compiled is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_compiled = fdp.load_binary(
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_kernel_0", 64, 'OO'
        )
        if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 81920, 0 if stream is None else stream)
            flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_compiled(81920, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_binary):
        return
    launch = flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_binary, "flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_kernel_0")

flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_best = None


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_best
    if flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_best is None:
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_best = fdp.pick_fastest(
            [flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_main, flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_main], (in_ptr0, out_ptr0,), (1,), stream,
            warm=(0,), metadata={'kernel_name': 'flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56', 'stage': 'pointwise', 'candidate_descriptions': ['pointwise xnumel=10485760 ept=8 unroll=2', 'pointwise xnumel=10485760 ept=8 unroll=1', 'pointwise xnumel=10485760 ept=8 unroll=1', 'pointwise xnumel=10485760 ept=8 unroll=4', 'pointwise xnumel=10485760 ept=8 unroll=2', 'pointwise xnumel=10485760 ept=8 unroll=2', 'pointwise xnumel=10485760 ept=4 unroll=2', 'pointwise xnumel=10485760 ept=4 unroll=2', 'pointwise xnumel=10485760 ept=8 unroll=1', 'pointwise xnumel=10485760 ept=8 unroll=8', 'pointwise xnumel=10485760 ept=8 unroll=4', 'pointwise xnumel=10485760 ept=1 unroll=2']},
        )
        return
    flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_best(in_ptr0, out_ptr0, stream=stream)


def flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_precompile(only=None, **kw):
    if only in (None, 0):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c0_precompile(**kw)
    if only in (None, 1):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c1_precompile(**kw)
    if only in (None, 2):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c2_precompile(**kw)
    if only in (None, 3):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c3_precompile(**kw)
    if only in (None, 4):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c4_precompile(**kw)
    if only in (None, 5):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c5_precompile(**kw)
    if only in (None, 6):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c6_precompile(**kw)
    if only in (None, 7):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c7_precompile(**kw)
    if only in (None, 8):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c8_precompile(**kw)
    if only in (None, 9):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c9_precompile(**kw)
    if only in (None, 10):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c10_precompile(**kw)
    if only in (None, 11):
        flydsl_fused__to_copy__unsafe_view_clone_transpose_view_f6355f56_c11_precompile(**kw)
