from pathlib import Path
b=Path(__file__).resolve().parent.parent/'pytorch_codegen_v13'
p=b/'torch/_inductor/codegen/amd_kernel_optimizations.py';s=p.read_text();old='    for name in ("AMD_VEC", "AMD_UNROLL", "AMD_WARPS"):';new='''    extra_args = ["AMD_VEC", "AMD_UNROLL", "AMD_WARPS"]
    if family == "transpose":
        input_linear = "\\n".join("    " + line for line in body.strip().splitlines()[1:])
        body = f"""
i = gl.program_id(0) * XBLOCK + lane
if AMD_READ_ORDER == 0:
    x0 = i % {c}
    x1 = i // {c}
    offset = {d} * (x1 % {s}) + {s*d} * (x0 // {d}) + {s*c} * (x1 // {s}) + x0 % {d}
    value = gl.load(in_ptr0 + offset, i < {n}, other=0)
    gl.store(out_ptr0 + i, value, i < {n})
else:
{input_linear}
"""
        extra_args.append("AMD_READ_ORDER")
    for name in extra_args:''';s=s.replace(old,new,1);p.write_text(s)
p=b/'torch/_inductor/runtime/triton_heuristics.py';s=p.read_text();start=s.index('    if family == "transpose":',s.index('def _amd_layout_configs'));end=s.index('\n\ndef _amd_reduction_configs',start)
s=s[:start]+'''    if family == "transpose":
        choices = [(2048, warps, vec, 1) for warps, vec in [(1,8),(2,4),(4,2),(4,4),(8,4)]]
        choices += [(block,4,4,1) for block in (512,1024,4096)]
        choices += [(1024,4,4,0),(4096,4,8,0)]
        return [Config({"XBLOCK":block,"AMD_VEC":vec,"AMD_UNROLL":1,"AMD_WARPS":warps,"AMD_READ_ORDER":order},num_warps=warps,num_stages=1)
                for block,warps,vec,order in choices]
    choices = [(512,1,2,2),(512,1,4,2),(1024,2,8,1),(1024,4,4,1),
               (2048,2,4,2),(2048,1,4,8),(4096,2,8,4),
               (4096,4,4,1),(8192,4,8,1),(8192,4,32,1)]
    return [Config({"XBLOCK":block,"AMD_VEC":vec,"AMD_UNROLL":unroll,"AMD_WARPS":warps},num_warps=warps,num_stages=1)
            for block,warps,vec,unroll in choices]
'''+s[end:];p.write_text(s)
p=b/'torch/_inductor/runtime/amd_autotune.py';s=p.read_text().replace("    options['waves_per_eu']=[0,1,2]", "    options['waves_per_eu']=[0,1,2]\n    if 'AMD_READ_ORDER' in config.kwargs:\n        options['AMD_READ_ORDER']=[0,1]").replace("kw.get('AMD_VEC',1)>8", "kw.get('AMD_VEC',1)>32");p.write_text(s)
p=b/'test/inductor/test_amd_kernel_autotune.py';s=p.read_text().replace('        optimized=copy.deepcopy(eager)','        baseline=copy.deepcopy(eager)\n        optimized=copy.deepcopy(eager)',1)
s=s.replace('        expected.float().square().mean().backward()\n        with config.patch', '''        expected.float().square().mean().backward()
        with config.patch({'triton.amd_kernel_optimizations':False,'max_autotune_pointwise':True,'max_autotune_gemm_backends':'ATEN','fx_graph_cache':False,'autotune_local_cache':False}):
            standard=torch.compile(baseline,fullgraph=True)(x)
            standard.float().square().mean().backward()
        self.assertEqual(standard,expected,atol=.02 if dtype==torch.bfloat16 else 2e-5,rtol=.02 if dtype==torch.bfloat16 else 2e-5)
        with config.patch''',1)
s=s.replace('        self.assertEqual(actual,expected,atol=.003 if dtype==torch.bfloat16 else 2e-5,rtol=.02 if dtype==torch.bfloat16 else 2e-5)','        self.assertEqual(actual,standard,atol=.003 if dtype==torch.bfloat16 else 2e-5,rtol=.02 if dtype==torch.bfloat16 else 2e-5)',1)
s=s.replace('zip(optimized.parameters(),eager.parameters())','zip(optimized.parameters(),baseline.parameters())');p.write_text(s)
