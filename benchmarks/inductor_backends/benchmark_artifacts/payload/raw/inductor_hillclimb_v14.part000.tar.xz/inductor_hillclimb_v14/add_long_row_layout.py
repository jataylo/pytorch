from pathlib import Path
b=Path(__file__).resolve().parent.parent/'pytorch_codegen_v13'
p=b/'torch/_inductor/codegen/amd_kernel_optimizations.py';s=p.read_text().replace("for name in ('AMD_LANES','AMD_VEC','AMD_WARPS'):","for name in ('AMD_LANES','AMD_VEC','AMD_WARPS','AMD_SPLIT_WARPS'):").replace("[AMD_WARPS, 1], [1, 0])').body[0]", "([1, AMD_WARPS] if AMD_SPLIT_WARPS else [AMD_WARPS, 1]), [1, 0])').body[0]");p.write_text(s)
p=b/'torch/_inductor/runtime/triton_heuristics.py';s=p.read_text();old='''        configs = [Config({"XBLOCK": rows, "AMD_LANES": lanes, "AMD_VEC": vec, "AMD_WARPS": warps}, num_warps=warps, num_stages=1)
                   for rows, lanes, vec, warps in [(1,64,4,1),(2,32,4,1),(4,16,4,1),(4,16,8,2),(8,16,8,2),(8,32,4,2),(4,64,4,4)]
                   if rows*r <= 32768 and inductor_meta["amd_row_count"] % rows == 0]''';new='''        choices = [(rows,lanes,vec,warps,0) for rows,lanes,vec,warps in [(1,64,4,1),(2,32,4,1),(4,16,4,1),(4,16,8,2),(8,16,8,2),(8,32,4,2),(4,64,4,4)]]
        if r >= 512:
            choices += [(1,64,4,2,1),(1,64,4,4,1),(1,64,4,8,1),(2,64,4,4,1)]
        configs = [Config({"XBLOCK":rows,"AMD_LANES":lanes,"AMD_VEC":vec,"AMD_WARPS":warps,"AMD_SPLIT_WARPS":split},num_warps=warps,num_stages=1)
                   for rows,lanes,vec,warps,split in choices
                   if rows*r<=32768 and inductor_meta["amd_row_count"]%rows==0]'''
if old not in s:raise RuntimeError('row config source mismatch')
s=s.replace(old,new,1);p.write_text(s)
p=b/'torch/_inductor/runtime/amd_autotune.py';s=p.read_text().replace("    if 'AMD_READ_ORDER' in config.kwargs:\n        options['AMD_READ_ORDER']=[0,1]", "    if 'AMD_READ_ORDER' in config.kwargs:\n        options['AMD_READ_ORDER']=[0,1]\n    if 'AMD_SPLIT_WARPS' in config.kwargs:\n        options['AMD_SPLIT_WARPS']=[0,1]");p.write_text(s)
