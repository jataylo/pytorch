import torch,json
from torch._inductor import config
from torch._inductor.utils import run_and_get_code
from pathlib import Path
root=Path(__file__).resolve().parent
x=torch.randn(2,5,37,64,device='cuda',dtype=torch.bfloat16)
fn=lambda x:x.permute(0,2,1,3).contiguous()
for enabled in [False,True]:
 with config.patch({'triton.amd_kernel_optimizations':enabled,'triton.amd_autotune_diagnostics_path':str(root/'transpose_debug.jsonl'),'max_autotune_pointwise':True,'fx_graph_cache':False,'autotune_local_cache':False}):
  torch._dynamo.reset();out,src=run_and_get_code(torch.compile(fn,fullgraph=True),x);print(enabled,torch.equal(out,fn(x)),flush=True);(root/f'transpose_{enabled}.py').write_text('\n'.join(src))
