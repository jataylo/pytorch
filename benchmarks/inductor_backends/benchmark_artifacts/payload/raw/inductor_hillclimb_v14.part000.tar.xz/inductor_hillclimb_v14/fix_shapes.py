from pathlib import Path
b=Path(__file__).resolve().parent.parent/'pytorch_codegen_v13'
p=b/'torch/_inductor/codegen/amd_kernel_optimizations.py';s=p.read_text();s=s.replace("or hints['r0_'] > 8192:","or not 32 <= hints['r0_'] <= 8192:")
s=s.replace("    softmax = 'triton_helpers.fmax2' in calls and 'libdevice.exp' in calls", "    assignments = {node.targets[0].id:node.value for node in fn.body if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)}\n    xnumel = assignments.get('xnumel')\n    if not isinstance(xnumel,ast.Constant) or not isinstance(xnumel.value,int) or xnumel.value<=0:\n        return source\n    softmax = 'triton_helpers.fmax2' in calls and 'libdevice.exp' in calls")
s=s.replace("            if node.id == 'tl':", "            if node.id in ('tl','tl_math'):")
s=s.replace("            if original == 'tl.arange':", "            if original == 'tl.broadcast_to':\n                zero = ast.Call(func=ast.parse('gl.full',mode='eval').body,args=[node.args[1],ast.Constant(0),ast.Attribute(value=node.args[0],attr='dtype',ctx=ast.Load())],keywords=[ast.keyword(arg='layout',value=ast.Name(id='_amd_layout',ctx=ast.Load()))])\n                return ast.Subscript(value=ast.Call(func=ast.parse('gl.broadcast',mode='eval').body,args=[node.args[0],zero],keywords=[]),slice=ast.Constant(0),ctx=ast.Load())\n            if original == 'tl.arange':")
s=s.replace("ast.Constant('amd_reduction_extent')])", "ast.Constant('amd_reduction_extent'),ast.Constant('amd_row_count')])").replace("ast.Constant(hints['r0_'])])", "ast.Constant(hints['r0_']),ast.Constant(xnumel.value)])")
p.write_text(s)
p=b/'torch/_inductor/runtime/triton_heuristics.py';s=p.read_text().replace('if rows*r <= 32768]', 'if rows*r <= 32768 and inductor_meta["amd_row_count"] % rows == 0]');p.write_text(s)
p=b/'torch/_inductor/runtime/hints.py';s=p.read_text().replace('    amd_reduction_extent: int','    amd_row_count: int\n    amd_reduction_extent: int',1);p.write_text(s)
p=b/'torch/_inductor/runtime/amd_autotune.py';s=p.read_text().replace("            if kw['XBLOCK']%kw.get('AMD_UNROLL',1):", "            if tuner.inductor_meta.get('amd_gluon_family')=='transpose' and kw.get('AMD_UNROLL',1)!=1:\n                continue\n            if kw['XBLOCK']%kw.get('AMD_UNROLL',1):")
s=s.replace("if isinstance(xnumel,int) and not gluon and xnumel%kw['XBLOCK']:","if isinstance(xnumel,int) and (not gluon or tuner.inductor_meta.get('amd_gluon_family')=='row_reduction') and xnumel%kw['XBLOCK']:")
s=s.replace("    for launcher in launchers:\n        before();call(launcher)\n    torch.cuda.synchronize()", """    outputs=[value for name,value in scratch_values.items() if isinstance(value,torch.Tensor) and name.startswith(('out_ptr','in_out_ptr'))]
    before();call(launchers[0]);torch.cuda.synchronize()
    reference=[value.clone() for value in outputs]
    valid=[]
    for launcher in launchers:
        before();call(launcher);torch.cuda.synchronize()
        try:
            for actual,expected in zip(outputs,reference):
                low=actual.dtype in (torch.float16,torch.bfloat16)
                floating=actual.is_floating_point()
                torch.testing.assert_close(actual,expected,atol=.02 if low else 1e-4 if floating else 0,rtol=.02 if low else 1e-4 if floating else 0,equal_nan=True)
        except AssertionError:
            continue
        valid.append(launcher)
    del reference
    if not valid:
        raise RuntimeError('No numerically valid AMD kernel configuration')
    rejected=[launcher for launcher in launchers if launcher not in valid]
    launchers=valid
    events=[[(torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)) for _ in range(repeats)] for _ in launchers]""")
s=s.replace("    return {launcher:statistics.median(values) for launcher,values in samples.items()},samples", "    return {launcher:statistics.median(values) if values else float('inf') for launcher,values in samples.items()},samples")
s=s.replace("median_ms=value,samples_ms", "median_ms=value if math.isfinite(value) else None,samples_ms")
p.write_text(s)
