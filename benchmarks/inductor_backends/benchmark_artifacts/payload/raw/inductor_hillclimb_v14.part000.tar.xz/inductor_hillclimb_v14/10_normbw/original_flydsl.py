
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0__Smem:
    words: fx.Array[fx.Int32, 384, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0__Smem).peek().words.view(fx.make_layout(384, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 96
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 2 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
        for r0_offset in range_constexpr(0, 1536, 768):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, None))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        fdp.widen(_lc, (('in_ptr1', 'r0_1'),))
        tmp4 = fdp.group_reduce('sum', _acc1, 96, _smem, 192, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 96, _smem, 192, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32', seed=(_lc, ('out_ptr2', 'r0_1 + 1536*x0', r0_offset)))
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 8, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16', seed=(_lc, ('out_ptr3', 'r0_1 + 1536*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')
        fdp.forget(_lc, 'out_ptr3')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(192, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_kernel_0", 192, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 512, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_compiled(512, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1__Smem:
    words: fx.Array[fx.Int32, 384, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1__Smem).peek().words.view(fx.make_layout(384, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 96
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 2 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(1536), fx.Int32(768)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_vc, ('in_ptr0', 'r0_1 + 1536*x0', 0), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_vc, ('in_ptr1', 'r0_1', 0), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_vc, ('in_ptr2', 'r0_1 + 1536*x0', 0), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, None))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp4 = fdp.group_reduce('sum', _acc1, 96, _smem, 192, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 96, _smem, 192, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(1536), fx.Int32(768)):
            r0_offset = fdp.idx(_ro)
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_vc, ('in_ptr0', 'r0_1 + 1536*x0', 1), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_vc, ('in_ptr1', 'r0_1', 1), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_vc, ('in_ptr2', 'r0_1 + 1536*x0', 1), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_vc, ('in_ptr4', 'r0_1 + 1536*x0', 1), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32')
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 8, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(192, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_kernel_0", 192, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 512, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_compiled(512, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2__Smem:
    words: fx.Array[fx.Int32, 384, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=2 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2__Smem).peek().words.view(fx.make_layout(384, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 96
    _lane0 = _rl == 0
    _caches = []
    for _xr in range_constexpr(2):
        _vc, _sc, _lc = {}, {}, {}
        xindex = _b * 4 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
        _caches.append((_vc, _sc, _lc))
    for _xr in range_constexpr(2):
        _vc, _sc, _lc = _caches[_xr]
        xindex = _b * 4 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, None))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        fdp.widen(_lc, (('in_ptr1', 'r0_1'),))
        tmp4 = fdp.group_reduce('sum', _acc1, 96, _smem, 192, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 96, _smem, 192, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32', seed=(_lc, ('out_ptr2', 'r0_1 + 1536*x0', r0_offset)))
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 8, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16', seed=(_lc, ('out_ptr3', 'r0_1 + 1536*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')
        fdp.forget(_lc, 'out_ptr3')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(192, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_kernel_0", 192, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 256, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_compiled(256, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3__Smem:
    words: fx.Array[fx.Int32, 384, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=4 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3__Smem).peek().words.view(fx.make_layout(384, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 96
    _lane0 = _rl == 0
    _caches = []
    for _xr in range_constexpr(4):
        _vc, _sc, _lc = {}, {}, {}
        xindex = _b * 8 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
        _caches.append((_vc, _sc, _lc))
    for _xr in range_constexpr(4):
        _vc, _sc, _lc = _caches[_xr]
        xindex = _b * 8 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, None))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        fdp.widen(_lc, (('in_ptr1', 'r0_1'),))
        tmp4 = fdp.group_reduce('sum', _acc1, 96, _smem, 192, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 96, _smem, 192, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32', seed=(_lc, ('out_ptr2', 'r0_1 + 1536*x0', r0_offset)))
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 8, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16', seed=(_lc, ('out_ptr3', 'r0_1 + 1536*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')
        fdp.forget(_lc, 'out_ptr3')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(192, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_kernel_0", 192, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 128, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_compiled(128, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4__Smem:
    words: fx.Array[fx.Int32, 384, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=8 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4__Smem).peek().words.view(fx.make_layout(384, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 96
    _lane0 = _rl == 0
    _caches = []
    for _xr in range_constexpr(8):
        _vc, _sc, _lc = {}, {}, {}
        xindex = _b * 16 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
        _caches.append((_vc, _sc, _lc))
    for _xr in range_constexpr(8):
        _vc, _sc, _lc = _caches[_xr]
        xindex = _b * 16 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, None))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        fdp.widen(_lc, (('in_ptr1', 'r0_1'),))
        tmp4 = fdp.group_reduce('sum', _acc1, 96, _smem, 192, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 96, _smem, 192, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 768):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 768 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32', seed=(_lc, ('out_ptr2', 'r0_1 + 1536*x0', r0_offset)))
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 8, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16', seed=(_lc, ('out_ptr3', 'r0_1 + 1536*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')
        fdp.forget(_lc, 'out_ptr3')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(192, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_kernel_0", 192, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 64, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_compiled(64, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=64 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 64
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(1536), fx.Int32(512)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 512 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_vc, ('in_ptr0', 'r0_1 + 1536*x0', 0), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_vc, ('in_ptr1', 'r0_1', 0), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_vc, ('in_ptr2', 'r0_1 + 1536*x0', 0), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, None))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp4 = fdp.group_reduce('sum', _acc1, 64, None, 64, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 64, None, 64, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(1536), fx.Int32(512)):
            r0_offset = fdp.idx(_ro)
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 512 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_vc, ('in_ptr0', 'r0_1 + 1536*x0', 1), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_vc, ('in_ptr1', 'r0_1', 1), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_vc, ('in_ptr2', 'r0_1 + 1536*x0', 1), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_vc, ('in_ptr4', 'r0_1 + 1536*x0', 1), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32')
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 8, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_kernel_0", 64, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 1024, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_compiled(1024, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=128 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 128
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 2 + _xr * 2 + _t // 128
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 1024):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1024 + _rl * 8 + _j % 8
                r0_mask = r0_index < 1536
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16', mask=r0_mask)
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32', mask=r0_mask)
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32', mask=r0_mask)
        for r0_offset in range_constexpr(0, 1536, 1024):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1024 + _rl * 8 + _j % 8
                r0_mask = r0_index < 1536
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16', mask=r0_mask)
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32', mask=r0_mask)
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 1536, 1024):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1024 + _rl * 8 + _j % 8
                r0_mask = r0_index < 1536
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16', mask=r0_mask)
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32', mask=r0_mask)
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32', mask=r0_mask)
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, r0_mask))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        fdp.widen(_lc, (('in_ptr1', 'r0_1'),))
        tmp4 = fdp.group_reduce('sum', _acc1, 128, _smem, 256, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 128, _smem, 256, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 1024):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1024 + _rl * 8 + _j % 8
                r0_mask = r0_index < 1536
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16', mask=r0_mask)
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32', mask=r0_mask)
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1', mask=r0_mask)
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32', mask=r0_mask, seed=(_lc, ('out_ptr2', 'r0_1 + 1536*x0', r0_offset)))
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 8, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16', mask=r0_mask, seed=(_lc, ('out_ptr3', 'r0_1 + 1536*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')
        fdp.forget(_lc, 'out_ptr3')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_kernel_0", 256, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 512, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_compiled(512, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7__Smem:
    words: fx.Array[fx.Int32, 384, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=192 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7__Smem).peek().words.view(fx.make_layout(384, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 192
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 192
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 1536):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1536 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 1536):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1536 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
        for r0_offset in range_constexpr(0, 1536, 1536):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1536 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, None))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        fdp.widen(_lc, (('in_ptr1', 'r0_1'),))
        tmp4 = fdp.group_reduce('sum', _acc1, 192, _smem, 192, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 192, _smem, 192, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 1536):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 1536 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32', seed=(_lc, ('out_ptr2', 'r0_1 + 1536*x0', r0_offset)))
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 8, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16', seed=(_lc, ('out_ptr3', 'r0_1 + 1536*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')
        fdp.forget(_lc, 'out_ptr3')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(192, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_kernel_0", 192, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 1024, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_compiled(1024, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=256 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 256
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 2048):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 2048 + _rl * 8 + _j % 8
                r0_mask = r0_index < 1536
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16', mask=r0_mask)
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32', mask=r0_mask)
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32', mask=r0_mask)
        for r0_offset in range_constexpr(0, 1536, 2048):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 2048 + _rl * 8 + _j % 8
                r0_mask = r0_index < 1536
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16', mask=r0_mask)
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32', mask=r0_mask)
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1', mask=r0_mask)
        for r0_offset in range_constexpr(0, 1536, 2048):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 2048 + _rl * 8 + _j % 8
                r0_mask = r0_index < 1536
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16', mask=r0_mask)
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32', mask=r0_mask)
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32', mask=r0_mask)
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, r0_mask))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        fdp.widen(_lc, (('in_ptr1', 'r0_1'),))
        tmp4 = fdp.group_reduce('sum', _acc1, 256, _smem, 256, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 256, _smem, 256, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 2048):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 2048 + _rl * 8 + _j % 8
                r0_mask = r0_index < 1536
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16', mask=r0_mask)
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32', mask=r0_mask)
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32', mask=r0_mask)
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 8, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1', mask=r0_mask)
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32', mask=r0_mask, seed=(_lc, ('out_ptr2', 'r0_1 + 1536*x0', r0_offset)))
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 8, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16', mask=r0_mask, seed=(_lc, ('out_ptr3', 'r0_1 + 1536*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')
        fdp.forget(_lc, 'out_ptr3')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_kernel_0", 256, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 1024, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_compiled(1024, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9__Smem:
    words: fx.Array[fx.Int32, 384, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=1 unroll=1 tpr=96 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9__Smem).peek().words.view(fx.make_layout(384, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 96
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 2 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 96):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 96 + _rl * 1 + _j % 1
                r0_1 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 1536*x0, 'bf16'))
                tmp2 = fdp.memo(_lc, (('in_ptr1', 'r0_1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_1, 'f32'))
                tmp5 = fdp.memo(_lc, (('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, r0_1 + 1536*x0, 'f32'))
        for r0_offset in range_constexpr(0, 1536, 96):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 96 + _rl * 1 + _j % 1
                r0_1 = r0_index
                tmp9 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 1536*x0, 'bf16'))
                tmp11 = fdp.memo(_lc, (('in_ptr1', 'r0_1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_1, 'f32'))
                tmp16 = fdp.memo(_lc, (('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, r0_1 + 1536*x0, 'f32'))
                tmp21 = fdp.memo(_lc, (('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr4, r0_1 + 1536*x0, 'b1'))
        for r0_offset in range_constexpr(0, 1536, 96):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 96 + _rl * 1 + _j % 1
                r0_1 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 1536*x0, 'bf16'))
                tmp2 = fdp.memo(_lc, (('in_ptr1', 'r0_1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_1, 'f32'))
                tmp5 = fdp.memo(_lc, (('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, r0_1 + 1536*x0, 'f32'))
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, None))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp4 = fdp.group_reduce('sum', _acc1, 96, _smem, 192, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 96, _smem, 192, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 96):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 96 + _rl * 1 + _j % 1
                r0_1 = r0_index
                tmp9 = fdp.memo(_lc, (('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, r0_1 + 1536*x0, 'bf16'))
                tmp11 = fdp.memo(_lc, (('in_ptr1', 'r0_1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, r0_1, 'f32'))
                tmp16 = fdp.memo(_lc, (('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, r0_1 + 1536*x0, 'f32'))
                tmp21 = fdp.memo(_lc, (('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j), lambda: fdp.load(_r_in_ptr4, r0_1 + 1536*x0, 'b1'))
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.store(_r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32')
                fdp.store(_r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16')
        fdp.forget(_lc, 'out_ptr2')
        fdp.forget(_lc, 'out_ptr3')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(192, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_kernel_0", 192, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 512, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_compiled(512, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10__Smem:
    words: fx.Array[fx.Int32, 384, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=1024 rnumel=1536 ept=4 unroll=1 tpr=96 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3145728)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 6144)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 6291456)
    _r_in_ptr3 = fdp.rsrc(in_ptr3, 4096)
    _r_in_ptr4 = fdp.rsrc(in_ptr4, 1572864)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 6291456)
    _r_out_ptr3 = fdp.rsrc(out_ptr3, 3145728)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10__Smem).peek().words.view(fx.make_layout(384, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 96
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 2 + _xr * 2 + _t // 96
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 1536, 384):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 384 + _rl * 4 + _j % 4
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 384):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 384 + _rl * 4 + _j % 4
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
        for r0_offset in range_constexpr(0, 1536, 384):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 384 + _rl * 4 + _j % 4
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp5 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.mul(tmp1, tmp2)
                _acc1_items.append((tmp3, None))
                tmp6 = fdp.mul(tmp3, tmp5)
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        fdp.widen(_lc, (('in_ptr1', 'r0_1'),))
        tmp4 = fdp.group_reduce('sum', _acc1, 96, _smem, 192, 1)
        tmp7 = fdp.group_reduce('sum', _acc2, 96, _smem, 192, 1)
        tmp8 = fdp.load(_r_in_ptr3, x0, 'f32')
        for r0_offset in range_constexpr(0, 1536, 384):
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 384 + _rl * 4 + _j % 4
                r0_1 = r0_index
                tmp9 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr0, lambda: r0_1 + 1536*x0, 'bf16')
                tmp11 = fdp.vload(_lc, ('in_ptr1', 'r0_1', r0_offset), _j, 4, _r_in_ptr1, lambda: r0_1, 'f32')
                tmp16 = fdp.vload(_lc, ('in_ptr2', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr2, lambda: r0_1 + 1536*x0, 'f32')
                tmp21 = fdp.vload(_lc, ('in_ptr4', 'r0_1 + 1536*x0', r0_offset), _j, 4, _r_in_ptr4, lambda: r0_1 + 1536*x0, 'b1')
                tmp10 = fdp.to(tmp9, 'f32')
                tmp12 = fdp.mul(tmp10, tmp11)
                tmp13 = fdp.const(1536.0, 'f32')
                tmp14 = fdp.mul(tmp12, tmp13)
                tmp15 = fdp.sub(tmp14, tmp4)
                tmp17 = fdp.mul(tmp16, tmp7)
                tmp18 = fdp.sub(tmp15, tmp17)
                tmp19 = fdp.mul(tmp8, tmp18)
                tmp20 = fdp.to(tmp19, 'f32')
                tmp22 = fdp.to(tmp21, 'f32')
                tmp23 = fdp.const(1.1111111111111112, 'f32')
                tmp24 = fdp.mul(tmp22, tmp23)
                tmp25 = fdp.mul(tmp20, tmp24)
                fdp.vstore(_sc, 'st9_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 1536*x0, tmp19, 'f32', seed=(_lc, ('out_ptr2', 'r0_1 + 1536*x0', r0_offset)))
                fdp.vstore(_sc, 'st11_out_ptr3', _j, 4, _r_out_ptr3, r0_1 + 1536*x0, tmp25, 'bf16', seed=(_lc, ('out_ptr3', 'r0_1 + 1536*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')
        fdp.forget(_lc, 'out_ptr3')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, in_ptr3: fx.Int64, in_ptr4: fx.Int64, out_ptr2: fx.Int64, out_ptr3: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_kernel(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3).launch(grid=(_grid, 1, 1), block=(192, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_kernel_0", 192, 'OOOOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), in_ptr3.data_ptr(), in_ptr4.data_ptr(), out_ptr2.data_ptr(), out_ptr3.data_ptr(), 512, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_compiled(512, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_kernel_0")

flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_best = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_main(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_best
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_best is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_best = fdp.pick_fastest(
            [flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_main], (in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3,), (5, 6), stream,
            warm=(0,), metadata={'kernel_name': 'flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052', 'stage': 'norm', 'candidate_descriptions': ["row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=2 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=4 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=96 stride=1 xunroll=8 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=64 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=128 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=192 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=8 unroll=1 tpr=256 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=1 unroll=1 tpr=96 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=1024 rnumel=1536 ept=4 unroll=1 tpr=96 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}"]},
        )
        return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_best(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr2, out_ptr3, stream=stream)


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_precompile(only=None, **kw):
    if only in (None, 0):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c0_precompile(**kw)
    if only in (None, 1):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c1_precompile(**kw)
    if only in (None, 2):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c2_precompile(**kw)
    if only in (None, 3):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c3_precompile(**kw)
    if only in (None, 4):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c4_precompile(**kw)
    if only in (None, 5):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c5_precompile(**kw)
    if only in (None, 6):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c6_precompile(**kw)
    if only in (None, 7):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c7_precompile(**kw)
    if only in (None, 8):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c8_precompile(**kw)
    if only in (None, 9):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c9_precompile(**kw)
    if only in (None, 10):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_9356a052_c10_precompile(**kw)
