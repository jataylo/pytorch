import ast,fcntl,hashlib,importlib.util,json,shutil,statistics,sys
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent
V12=ROOT.parent/'triton_hillclimb_v12'
sys.path.insert(0,str(V12))
from search import Case,measure,conf
from torch._inductor.codegen.amd_kernel_optimizations import optimize_pointwise_source,simplify_masked_modulo

def load(path):
    name='v14_'+hashlib.sha256(str(path).encode()).hexdigest()[:12];spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def lower(source):
    tree=ast.parse(source)
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef));dec=next(n for n in fn.decorator_list if isinstance(n,ast.Call));meta=next(k.value for k in dec.keywords if k.arg=='inductor_meta')
    meta.keys.extend([ast.Constant('amd_reduction_tuning'),ast.Constant('amd_kernel_autotune'),ast.Constant('amd_warm_arg_names'),ast.Constant('amd_autotune_diagnostics_path'),ast.Constant('force_disable_caches'),ast.Constant('autotune_local_cache')]);meta.values.extend([ast.Constant(True),ast.Constant(True),ast.parse(repr(WARM),mode='eval').body,ast.Constant(str(ROOT/'autotuning.jsonl')),ast.Constant(True),ast.Constant(False)])
    ast.fix_missing_locations(tree);source=ast.unparse(tree)+'\n';return optimize_pointwise_source(simplify_masked_modulo(source))

def pin(source,cfg):
    tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef));dec=next(n for n in fn.decorator_list if isinstance(n,ast.Call));kw={k.arg:k.value for k in dec.keywords};kind='POINTWISE' if dec.func.attr=='pointwise' else 'PERSISTENT_REDUCTION' if dec.func.attr=='persistent_reduction' else 'REDUCTION'
    config={k:v for k,v in cfg.items() if k not in ['num_warps','num_stages','simplify','kind','READ_ORDER','unroll']}
    expr=f'triton.Config({config!r},num_warps={cfg["num_warps"]},num_stages={cfg.get("num_stages",1)})'
    fn.decorator_list[0]=ast.Call(func=ast.parse('triton_heuristics.cached_autotune',mode='eval').body,args=[],keywords=[ast.keyword(arg='size_hints',value=kw['size_hints']),ast.keyword(arg='configs',value=ast.List(elts=[ast.parse(expr,mode='eval').body],ctx=ast.Load())),ast.keyword(arg='triton_meta',value=kw['triton_meta']),ast.keyword(arg='inductor_meta',value=kw['inductor_meta']),ast.keyword(arg='heuristic_type',value=ast.parse('triton_heuristics.HeuristicType.'+kind,mode='eval').body),ast.keyword(arg='filename',value=ast.Name(id='__file__',ctx=ast.Load()))]);ast.fix_missing_locations(tree);return ast.unparse(tree)+'\n'

if __name__=='__main__':
    rows=json.loads((V12/'manifest.json').read_text());summaries=[]
    with open('/dev/shm/pytorch-simd-v2-entry.lock','a') as entry,open('/dev/shm/pytorch-simd-v2-benchmark.lock','a') as timing:
        fcntl.flock(entry,fcntl.LOCK_EX);fcntl.flock(timing,fcntl.LOCK_EX)
        for row in rows:
            i=row['index'];folder=ROOT/'tuned'/f'{i:02d}_{row["category"]}';folder.parent.mkdir(exist_ok=True);folder.mkdir(exist_ok=True)
            for filename in ['original_triton.py','original_flydsl.py']:shutil.copy2(Path(row['folder'])/filename,folder/filename)
            row=dict(row,folder=str(folder));case=Case(row);prior=json.loads((V12/'confirmation'/f'{i:02d}.json').read_text())['result'];cfg=prior['config'];WARM=tuple(case.pointer_names[index] for index in row['warm_indices']);source=lower((folder/'original_triton.py').read_text());(folder/'integrated.py').write_text(source);kernel=getattr(load(folder/'integrated.py'),row['triton_name']);integrated=lambda:kernel.run(*case.args,*case.dimargs,stream=torch.cuda.current_stream().cuda_stream)
            case.validate(integrated);chosen=[dict(l.config.kwargs,num_warps=l.config.num_warps,num_stages=l.config.num_stages) for l in kernel.launchers]
            mapped=dict(cfg)
            if cfg.get('kind')=='gl' and row['category'] in ['transpose','broadcast']:
                mapped=dict(XBLOCK=cfg['XBLOCK']*cfg.get('unroll',1),AMD_VEC=cfg['VEC'],AMD_UNROLL=cfg.get('unroll',1),AMD_WARPS=cfg['num_warps'],num_warps=cfg['num_warps'],num_stages=1)
            if cfg.get('kind')=='gl' and row['category'] not in ['transpose','broadcast']:
                pinned=None
            else:
                (folder/'pinned.py').write_text(pin(source,mapped));pinned_kernel=getattr(load(folder/'pinned.py'),row['triton_name']);pinned=lambda:pinned_kernel.run(*case.args,*case.dimargs,stream=torch.cuda.current_stream().cuda_stream)
            entries=[dict(label='original',fn=case.native),dict(label='flydsl',fn=case.fly_fn),dict(label='standalone',fn=case.callable(cfg)),dict(label='integrated_auto',fn=integrated)]
            if pinned:entries.append(dict(label='integrated_pinned',fn=pinned))
            errors={e['label']:case.validate(e['fn'])[1] for e in entries};measured=measure(case,entries,15,5);base=measured[0]['median_us'];result=dict(index=i,category=row['category'],model=row['model'],standalone_config=cfg,integrated_config=chosen,entries=[dict(label=e['label'],error=errors[e['label']],**m,time_saved_percent=100*(1-m['median_us']/base)) for e,m in zip(entries,measured)])
            (folder/'diagnosis.json').write_text(json.dumps(result,indent=2));summaries.append(result);print(json.dumps({k:v for k,v in result.items() if k!='entries'}),[(e['label'],round(m['median_us'],3)) for e,m in zip(entries,measured)],flush=True)
            del entries,case,kernel;torch.cuda.empty_cache()
    (ROOT/'TUNED_DIAGNOSIS.json').write_text(json.dumps(summaries,indent=2))
