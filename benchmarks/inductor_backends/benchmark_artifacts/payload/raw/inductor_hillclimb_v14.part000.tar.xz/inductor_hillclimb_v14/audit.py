import csv
import hashlib
import json
import statistics
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

h = Path(__file__).resolve().parent
fp = json.loads((h / 'source_fingerprint.json').read_text())
b = Path(fp['worktree'])
def check(condition, message):
    if not condition:
        raise RuntimeError(message)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
for name, expected in fp['sources'].items():
    check(sha(b / name) == expected, f'Changed source: {name}')
counts = {}
for suite, expected_count in [('reference_final', 18), ('broad_final', 96)]:
    root = h / suite
    check(json.loads((root / 'failures.json').read_text()) == [], suite + ' failures')
    cases = list(root.glob('*/result.json'))
    check(len(cases) == expected_count, suite + ' case count')
    rows = list(csv.DictReader((root / 'per_case.csv').open()))
    check(len(rows) == expected_count * 16, suite + ' CSV row count')
    for path in cases:
        data = json.loads(path.read_text())
        check(data['failures'] == [], str(path) + ' failures')
        check(data['frozen_backend_callbacks'] == [1, 1, 1, 1], 'Backend isolation')
        check(len(data['rows']) == 16, 'Incomplete variants')
        for name, expected in data['source_fingerprint'].items():
            check(sha(Path(name)) == expected, 'Per-case source changed: ' + name)
        for row in data['rows']:
            key = '_'.join(row[k] for k in ['variant', 'cache', 'invocation'])
            samples = data['samples_us'][key]
            check(len(samples) == 15, 'Missing timing rounds')
            check(abs(statistics.median(samples) - row['runtime_us']) < 1e-8, 'Timing median mismatch')
            check(sha(path.parent / (row['variant'] + '.py')) == row['source_sha256'], 'Generated source mismatch')
    counts[suite] = {'cases': len(cases), 'timing_rows': len(rows)}
for name, count in [('MATCHED_FINAL_RESULTS.json', 15), ('INITIAL_FINAL_RESULTS.json', 3)]:
    cases = json.loads((h / name).read_text())
    check(len(cases) == count, name + ' count')
    for case in cases:
        for row in case['entries']:
            samples = row.get('samples_us', case.get('samples_us', {}).get(row['label']))
            check(samples is not None and len(samples) == 30, name + ' replay samples')
            check(abs(statistics.median(samples) - row['median_us']) < 1e-8, name + ' replay median')
svg_files = [h / 'matched_kernel_runtime.svg']
for suite in counts:
    svg_files.extend((h / suite).rglob('*.svg'))
for path in svg_files:
    ET.parse(path)
tests = {'test_codegen_verified.log': 27, 'test_autotune_verified.log': 15, 'test_cache_release.log': 2}
for name, count in tests.items():
    text = (h / name).read_text()
    check(f'Ran {count} tests' in text and '\nOK' in text, name + ' not passed')
subprocess.run(['git', 'diff', '--check'], cwd=b, check=True)
patch = subprocess.run(['git', 'diff', '--binary'], cwd=b, check=True, capture_output=True).stdout
names = subprocess.run(['git', 'ls-files', '--others', '--exclude-standard'], cwd=b, check=True, capture_output=True, text=True).stdout.splitlines()
for name in names:
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=b, capture_output=True)
    check(result.returncode in (0, 1), 'Patch generation: ' + name)
    patch += result.stdout
(h / 'branch_changes.patch').write_bytes(patch)
result = {'status': 'passed', 'source_fingerprints_verified': len(fp['sources']), 'compiled_benchmarks': counts, 'compiled_cases': 114, 'timing_rows': 1824, 'variants_per_case': 4, 'accuracy_input_seeds': [2026, 1701, 2027], 'original_kernel_replay_cases': 18, 'original_kernel_replay_rounds': 30, 'tests_passed': sum(tests.values()), 'test_logs': tests, 'svg_files_parsed': len(svg_files), 'git_diff_check': 'passed', 'patch_bytes': len(patch), 'limits': ['Kernel and operation-graph timings; no new full-model training benchmark or convergence claim.', 'gfx950 MI355X only; one GPU and one compiler thread.', 'Approximate math is separately opt-in and default-disabled.', 'Asynchronous compiler workers not validated.', 'Repository lint unavailable: spin missing after activating existing environment.', 'Wider-sweep regressions remain in results.'], 'source_fingerprint': fp}
(h / 'VALIDATION.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k != 'source_fingerprint'}, indent=2))
