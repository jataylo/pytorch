from pathlib import Path
b=Path(__file__).resolve().parent.parent/'pytorch_codegen_v13'
p=b/'test/inductor/test_amd_kernel_autotune.py';s=p.read_text().replace('import math\n','import math\nimport copy\nimport importlib.util\nimport tempfile\nfrom pathlib import Path\nfrom unittest.mock import patch\n')
pos=s.index("\n\ninstantiate_device_type_tests(TestAMDExecutionTuning")
extra='''
    @onlyCUDA
    def test_frozen_backend_survives_dynamo_reset(self,device):
        if torch.version.hip is None or torch.cuda.get_device_properties(device).gcnArchName.split(':')[0]!='gfx950':
            self.skipTest('gfx950 specialization')
        path=Path(__file__).resolve().parents[2]/'benchmarks/inductor_backends/amd_kernel_hillclimb.py'
        spec=importlib.util.spec_from_file_location('amd_benchmark_for_test',path)
        benchmark=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(benchmark)
        case=dict(family='broadcast',dtype='float32',shape=[4099],case='frozen_backend')
        with tempfile.TemporaryDirectory() as directory,patch.object(benchmark,'VARIANTS',('triton','optimized_triton','optimized_triton_approx')):
            report=benchmark.run_case(case,Path(directory),2,2)
        self.assertEqual(report['failures'],[])
        self.assertEqual(report['frozen_backend_callbacks'],[1,1,1])
        self.assertEqual(len(report['rows']),12)
        self.assertEqual({row['invocation'] for row in report['rows']},{'direct','graph_replay'})

    @onlyCUDA
    @parametrize('dtype',[torch.bfloat16,torch.float32])
    @parametrize('approximate',[False,True])
    def test_training_forward_and_backward(self,device,dtype,approximate):
        if torch.version.hip is None or torch.cuda.get_device_properties(device).gcnArchName.split(':')[0]!='gfx950':
            self.skipTest('gfx950 specialization')
        torch.manual_seed(23)
        eager=torch.nn.Sequential(torch.nn.Linear(128,256),torch.nn.LayerNorm(256),torch.nn.GELU(),torch.nn.Linear(256,64)).to(device=device,dtype=dtype)
        optimized=copy.deepcopy(eager)
        x=torch.randn(512,128,device=device,dtype=dtype)
        expected=eager(x)
        expected.float().square().mean().backward()
        with config.patch({'triton.amd_kernel_optimizations':True,'triton.amd_approximate_math':approximate,'max_autotune_pointwise':True,'max_autotune_gemm_backends':'ATEN','fx_graph_cache':False,'autotune_local_cache':False}):
            actual=torch.compile(optimized,fullgraph=True)(x)
            actual.float().square().mean().backward()
        self.assertEqual(actual,expected,atol=.003 if dtype==torch.bfloat16 else 2e-5,rtol=.02 if dtype==torch.bfloat16 else 2e-5)
        for parameter,reference in zip(optimized.parameters(),eager.parameters()):
            self.assertEqual(parameter.grad,reference.grad,atol=2e-5 if dtype==torch.bfloat16 else 2e-6,rtol=.02 if dtype==torch.bfloat16 else 2e-4)
'''
s=s[:pos]+'\n'+extra+s[pos:];p.write_text(s)
