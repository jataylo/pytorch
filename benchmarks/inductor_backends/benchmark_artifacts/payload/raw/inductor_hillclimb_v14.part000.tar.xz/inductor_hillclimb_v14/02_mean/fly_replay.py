
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c0__Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c0_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=1024 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c0__Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 1024
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 1024
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(8192)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 1) * 1024 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 1024, _smem, 1024, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=_lane0)


def flydsl_fused__to_copy_mean_pow_238b8eb5_c0_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c0_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c0_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c0_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c0_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c0_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c0_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c0_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused__to_copy_mean_pow_238b8eb5_c0_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c0_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c0_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c0_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c0_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c0_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c0_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c0.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c0_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c0_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c0_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c0_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c0_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c0_kernel_0", 1024, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c0_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c0_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 251, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c0_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c0_compiled(251, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c0_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c0_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c0_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c0_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c0_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c1__Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c1_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=1 tpr=1024 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c1__Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 1024
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 1024
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(1024)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 1024 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 1024, _smem, 1024, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=_lane0)


def flydsl_fused__to_copy_mean_pow_238b8eb5_c1_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c1_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c1_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c1_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c1_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c1_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c1_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c1_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused__to_copy_mean_pow_238b8eb5_c1_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c1_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c1_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c1_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c1_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c1_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c1_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c1.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c1_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c1_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c1_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c1_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c1_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c1_kernel_0", 1024, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c1_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c1_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 251, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c1_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c1_compiled(251, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c1_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c1_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c1_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c1_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c1_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c2__Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c2_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=2 tpr=1024 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c2__Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 1024
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 1024
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(2048)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(2):
                r0_index = r0_offset + (_j // 1) * 1024 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 1024, _smem, 1024, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=_lane0)


def flydsl_fused__to_copy_mean_pow_238b8eb5_c2_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c2_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c2_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c2_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c2_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c2_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c2_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c2_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused__to_copy_mean_pow_238b8eb5_c2_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c2_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c2_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c2_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c2_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c2_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c2_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c2.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c2_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c2_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c2_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c2_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c2_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c2_kernel_0", 1024, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c2_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c2_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 251, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c2_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c2_compiled(251, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c2_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c2_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c2_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c2_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c2_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c3__Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c3_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=4 tpr=1024 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c3__Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 1024
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 1024
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(4096)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 1) * 1024 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 1024, _smem, 1024, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=_lane0)


def flydsl_fused__to_copy_mean_pow_238b8eb5_c3_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c3_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c3_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c3_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c3_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c3_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c3_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c3_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused__to_copy_mean_pow_238b8eb5_c3_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c3_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c3_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c3_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c3_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c3_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c3_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c3.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c3_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c3_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c3_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c3_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c3_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c3_kernel_0", 1024, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c3_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c3_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 251, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c3_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c3_compiled(251, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c3_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c3_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c3_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c3_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c3_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_mean_pow_238b8eb5_c4_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=64 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 64
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(512)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 1) * 64 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 64, None, 64, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=_lane0)


def flydsl_fused__to_copy_mean_pow_238b8eb5_c4_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c4_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c4_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c4_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c4_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c4_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c4_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c4_kernel = flyc.kernel(flydsl_fused__to_copy_mean_pow_238b8eb5_c4_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c4_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c4_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c4_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c4_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c4_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c4_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c4.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c4_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c4_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c4_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c4_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c4_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c4_kernel_0", 64, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c4_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c4_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 251, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c4_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c4_compiled(251, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c4_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c4_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c4_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c4_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c4_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c5__Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c5_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=128 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c5__Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 128
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 8 + _xr * 8 + _t // 128
        xmask = xindex < 251
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(1024)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(xmask, r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 128, _smem, 1024, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=fdp.land(xmask, _lane0))


def flydsl_fused__to_copy_mean_pow_238b8eb5_c5_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c5_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c5_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c5_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c5_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c5_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c5_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c5_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused__to_copy_mean_pow_238b8eb5_c5_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c5_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c5_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c5_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c5_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c5_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c5_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c5.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c5_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c5_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c5_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c5_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c5_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c5_kernel_0", 1024, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c5_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c5_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 32, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c5_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c5_compiled(32, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c5_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c5_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c5_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c5_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c5_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c6__Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c6_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c6__Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 4 + _xr * 4 + _t // 256
        xmask = xindex < 251
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(2048)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 1) * 256 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(xmask, r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 256, _smem, 1024, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=fdp.land(xmask, _lane0))


def flydsl_fused__to_copy_mean_pow_238b8eb5_c6_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c6_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c6_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c6_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c6_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c6_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c6_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c6_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused__to_copy_mean_pow_238b8eb5_c6_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c6_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c6_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c6_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c6_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c6_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c6_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c6.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c6_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c6_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c6_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c6_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c6_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c6_kernel_0", 1024, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c6_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c6_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 63, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c6_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c6_compiled(63, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c6_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c6_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c6_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c6_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c6_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c7__Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c7_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=512 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c7__Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 512
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 2 + _xr * 2 + _t // 512
        xmask = xindex < 251
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(4096)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 1) * 512 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(xmask, r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 512, _smem, 1024, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=fdp.land(xmask, _lane0))


def flydsl_fused__to_copy_mean_pow_238b8eb5_c7_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c7_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c7_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c7_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c7_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c7_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c7_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c7_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused__to_copy_mean_pow_238b8eb5_c7_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c7_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c7_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c7_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c7_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c7_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c7_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c7.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c7_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c7_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c7_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c7_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c7_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c7_kernel_0", 1024, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c7_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c7_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 126, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c7_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c7_compiled(126, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c7_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c7_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c7_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c7_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c7_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c8__Smem:
    words: fx.Array[fx.Int32, 256, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c8_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=128 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c8__Smem).peek().words.view(fx.make_layout(256, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 128
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 128
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(1024)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 1) * 128 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 128, _smem, 128, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=_lane0)


def flydsl_fused__to_copy_mean_pow_238b8eb5_c8_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c8_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c8_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c8_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c8_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c8_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c8_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c8_kernel = flyc.kernel(flydsl_fused__to_copy_mean_pow_238b8eb5_c8_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c8_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c8_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c8_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c8_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c8_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c8_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c8.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c8_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c8_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c8_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c8_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c8_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c8_kernel_0", 128, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c8_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c8_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 251, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c8_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c8_compiled(251, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c8_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c8_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c8_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c8_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c8_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c9__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c9_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c9__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 256
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(2048)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 1) * 256 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 256, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=_lane0)


def flydsl_fused__to_copy_mean_pow_238b8eb5_c9_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c9_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c9_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c9_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c9_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c9_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c9_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c9_kernel = flyc.kernel(flydsl_fused__to_copy_mean_pow_238b8eb5_c9_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c9_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c9_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c9_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c9_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c9_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c9_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c9.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c9_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c9_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c9_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c9_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c9_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c9_kernel_0", 256, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c9_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c9_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 251, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c9_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c9_compiled(251, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c9_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c9_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c9_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c9_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c9_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_mean_pow_238b8eb5_c10__Smem:
    words: fx.Array[fx.Int32, 1024, 16]

def flydsl_fused__to_copy_mean_pow_238b8eb5_c10_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime ecbdad25f30f02a5
    # row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=512 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16398336)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 1004)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_mean_pow_238b8eb5_c10__Smem).peek().words.view(fx.make_layout(1024, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 512
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 512
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(32667), fx.Int32(4096)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 1) * 512 + _rl * 1 + _j % 1
                r0_mask = r0_index < 32667
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 32667*x0, 'i32')
                tmp1 = fdp.const(8199168, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 32667*x0, 8199168), 'bf16', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.to(tmp3, 'f32')
                tmp5 = fdp.mul(tmp4, tmp4)
                tmp6 = fdp.const(0.0, 'f32')
                tmp7 = fdp.where(tmp2, tmp5, tmp6)
                _acc1_items.append((tmp7, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp8 = fdp.group_reduce('sum', _acc1, 512, _smem, 512, 1)
        fdp.store(_r_out_ptr0, x0, tmp8, 'f32', mask=_lane0)


def flydsl_fused__to_copy_mean_pow_238b8eb5_c10_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_mean_pow_238b8eb5_c10_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(512, 1, 1), stream=stream)


flydsl_fused__to_copy_mean_pow_238b8eb5_c10_launch = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_c10_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c10_kernel, flydsl_fused__to_copy_mean_pow_238b8eb5_c10_launch
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c10_launch is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c10_kernel = flyc.kernel(known_block_size=[512, 1, 1])(flydsl_fused__to_copy_mean_pow_238b8eb5_c10_kernel)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c10_launch = flyc.jit(flydsl_fused__to_copy_mean_pow_238b8eb5_c10_launch_fn)
        flydsl_fused__to_copy_mean_pow_238b8eb5_c10_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_mean_pow_238b8eb5_c10_launch


flydsl_fused__to_copy_mean_pow_238b8eb5_c10_compiled = None
flydsl_fused__to_copy_mean_pow_238b8eb5_c10_binary = '/dev/shm/pytorch-simd-training-cache/f1aab8daa984d20934c9/inductor/6m/c6mygdpsbs4ii4qwo3ebtiozvuhbsi4wykq3q7uc3e4ytfkckpxi.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_mean_pow_238b8eb5_c10.hsaco"


def flydsl_fused__to_copy_mean_pow_238b8eb5_c10_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_c10_compiled
    if flydsl_fused__to_copy_mean_pow_238b8eb5_c10_compiled is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_c10_compiled = fdp.load_binary(
            flydsl_fused__to_copy_mean_pow_238b8eb5_c10_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c10_kernel_0", 512, 'OO'
        )
        if flydsl_fused__to_copy_mean_pow_238b8eb5_c10_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_mean_pow_238b8eb5_c10_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 251, 0 if stream is None else stream)
            flydsl_fused__to_copy_mean_pow_238b8eb5_c10_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_mean_pow_238b8eb5_c10_compiled(251, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused__to_copy_mean_pow_238b8eb5_c10_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_mean_pow_238b8eb5_c10_binary):
        return
    launch = flydsl_fused__to_copy_mean_pow_238b8eb5_c10_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_mean_pow_238b8eb5_c10_binary, "flydsl_fused__to_copy_mean_pow_238b8eb5_c10_kernel_0")

flydsl_fused__to_copy_mean_pow_238b8eb5_best = None


def flydsl_fused__to_copy_mean_pow_238b8eb5_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused__to_copy_mean_pow_238b8eb5_best
    if flydsl_fused__to_copy_mean_pow_238b8eb5_best is None:
        flydsl_fused__to_copy_mean_pow_238b8eb5_best = fdp.pick_fastest(
            [flydsl_fused__to_copy_mean_pow_238b8eb5_c0_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c1_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c2_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c3_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c4_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c5_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c6_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c7_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c8_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c9_main, flydsl_fused__to_copy_mean_pow_238b8eb5_c10_main], (in_ptr0, out_ptr0,), (1,), stream,
            warm=(), metadata={'kernel_name': 'flydsl_fused__to_copy_mean_pow_238b8eb5', 'stage': 'row', 'candidate_descriptions': ["row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=1024 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=1 tpr=1024 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=2 tpr=1024 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=4 tpr=1024 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=64 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=128 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=512 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=128 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=251 rnumel=32667 ept=1 unroll=8 tpr=512 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}"]},
        )
        return
    flydsl_fused__to_copy_mean_pow_238b8eb5_best(in_ptr0, out_ptr0, stream=stream)


def flydsl_fused__to_copy_mean_pow_238b8eb5_precompile(only=None, **kw):
    if only in (None, 0):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c0_precompile(**kw)
    if only in (None, 1):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c1_precompile(**kw)
    if only in (None, 2):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c2_precompile(**kw)
    if only in (None, 3):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c3_precompile(**kw)
    if only in (None, 4):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c4_precompile(**kw)
    if only in (None, 5):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c5_precompile(**kw)
    if only in (None, 6):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c6_precompile(**kw)
    if only in (None, 7):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c7_precompile(**kw)
    if only in (None, 8):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c8_precompile(**kw)
    if only in (None, 9):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c9_precompile(**kw)
    if only in (None, 10):
        flydsl_fused__to_copy_mean_pow_238b8eb5_c10_precompile(**kw)
