# AOT ID: ['383_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/lh/clhbpxfjksf5biiewv6mgx6scuck3zvwfehfn3ymu6zze7mvjekk.py
# Topologically Sorted Source Nodes: [gelu_backward], Original ATen: [aten.gelu_backward]
# Source node to ATen node mapping:
#   gelu_backward => add, add_1, erf, exp, mul, mul_1, mul_2, mul_3, mul_4, mul_5, mul_6
# Graph fragment:
#   %arg0_1 : Tensor "f32[268435456][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "f32[268435456][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %mul : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, 0.7071067811865476), kwargs = {})
#   %erf : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.erf.default](args = (%mul,), kwargs = {})
#   %add : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%erf, 1), kwargs = {})
#   %mul_1 : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add, 0.5), kwargs = {})
#   %mul_2 : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, %arg1_1), kwargs = {})
#   %mul_3 : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_2, -0.5), kwargs = {})
#   %exp : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%mul_3,), kwargs = {})
#   %mul_4 : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%exp, 0.3989422804014327), kwargs = {})
#   %mul_5 : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, %mul_4), kwargs = {})
#   %add_1 : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_1, %mul_5), kwargs = {})
#   %mul_6 : Tensor "f32[268435456][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg0_1, %add_1), kwargs = {})
#   return %mul_6
triton_poi_fused_gelu_backward_0 = async_compile.triton('triton_poi_fused_gelu_backward_0', '''
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(size_hints={'x': 268435456}, filename=__file__, triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr', 'AMD_UNROLL': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16]]}]}, inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_gelu_backward_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4294967296}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': False, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True, 'amd_reduction_tuning': True, 'amd_kernel_autotune': True, 'amd_kernel_tuning_version': 2, 'amd_autotune_diagnostics_path': 'agent_space/simd_bench/inductor_hillclimb_v14/broad_final/gelu_backward_float32_5/optimized_triton_approx.tuning.jsonl', 'amd_warm_arg_names': (), 'amd_pointwise_family': 'gelu_cdf', 'amd_approximate_math': True}, min_elem_per_thread=0)
@triton.jit
def triton_poi_fused_gelu_backward_0(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK: tl.constexpr, AMD_UNROLL: tl.constexpr):
    for u in tl.static_range(AMD_UNROLL):
        i = tl.program_id(0) * XBLOCK + u * (XBLOCK // AMD_UNROLL) + tl.arange(0, XBLOCK // AMD_UNROLL)
        a = tl.load(in_ptr0 + i, i < 268435456, other=0).to(tl.float32)
        b = tl.load(in_ptr1 + i, i < 268435456, other=0).to(tl.float32)
        ex = tl.exp(-0.5 * b * b)
        t = tl.inline_asm_elementwise('v_rcp_f32 $0, $1', constraints='=v,v', args=[1.0 + 0.3275911 * tl.abs(b) * 0.7071067811865476], dtype=tl.float32, is_pure=True, pack=1)
        poly = t * (0.254829592 + t * (-0.284496736 + t * (1.421413741 + t * (-1.453152027 + t * 1.061405429))))
        tail = 0.5 * poly * ex
        cdf = tl.where(b < 0.0, tail, 1.0 - tail)
        value = a * (cdf + b * (0.3989422804014327 * ex))
        tl.store(out_ptr0 + i, value, i < 268435456)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1), ((268435456, ), (268435456, )), ((1, ), (1, )), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf0 = empty_strided_cuda((268435456, ), (1, ), torch.float32)
            # Topologically Sorted Source Nodes: [gelu_backward], Original ATen: [aten.gelu_backward]
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_gelu_backward_0.run(arg0_1, arg1_1, buf0, 268435456, stream=raw_stream0)
            del arg0_1
            del arg1_1
        return (buf0, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((268435456, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg1_1 = rand_strided((268435456, ), (1, ), device='cuda:0', dtype=torch.float32)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
