# AOT ID: ['302_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c0.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/xb/cxbmil2qtjarymagxla6rda3qiplw72jcj5c7ei4cackwle75gmp.py
# Topologically Sorted Source Nodes: [float_1, float_2, add], Original ATen: [aten._to_copy, aten.add]
# Source node to ATen node mapping:
#   add => add
#   float_1 => convert_element_type
#   float_2 => convert_element_type_1
# Graph fragment:
#   %arg0_1 : Tensor "bf16[41943040][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[41943040][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %convert_element_type : Tensor "f32[41943040][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[41943040][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg1_1, torch.float32), kwargs = {})
#   %add : Tensor "f32[41943040][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type, %convert_element_type_1), kwargs = {})
#   return %add
flydsl_fused__to_copy_add_e7aee1ba = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', (flydsl_fused__to_copy_add_e7aee1ba_source := r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c0_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=4 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 8, 4):
        xindex = _b * 512 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
    for _j in range_constexpr(8):
        xindex = _b * 512 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c0_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c0_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c0_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c0_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c0_kernel, flydsl_fused__to_copy_add_e7aee1ba_c0_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c0_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c0_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c0_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c0_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c0_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c0_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c0_launch


flydsl_fused__to_copy_add_e7aee1ba_c0_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c0_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c0.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c0_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c0_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c0_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c0_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c0_binary, "flydsl_fused__to_copy_add_e7aee1ba_c0_kernel_0", 64, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c0_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c0_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 81920, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c0_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c0_compiled(81920, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c0_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c0_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c0_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c0_binary, "flydsl_fused__to_copy_add_e7aee1ba_c0_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c1_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=4 unroll=1
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(4):
        xindex = _b * 512 + (_j // 4) * 512 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c1_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c1_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c1_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c1_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c1_kernel, flydsl_fused__to_copy_add_e7aee1ba_c1_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c1_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c1_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c1_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c1_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c1_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c1_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c1_launch


flydsl_fused__to_copy_add_e7aee1ba_c1_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c1_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c1.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c1_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c1_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c1_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c1_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c1_binary, "flydsl_fused__to_copy_add_e7aee1ba_c1_kernel_0", 128, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c1_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c1_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 81920, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c1_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c1_compiled(81920, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c1_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c1_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c1_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c1_binary, "flydsl_fused__to_copy_add_e7aee1ba_c1_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c2_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=4 unroll=1
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(4):
        xindex = _b * 1024 + (_j // 4) * 1024 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c2_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c2_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c2_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c2_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c2_kernel, flydsl_fused__to_copy_add_e7aee1ba_c2_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c2_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c2_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c2_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c2_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c2_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c2_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c2_launch


flydsl_fused__to_copy_add_e7aee1ba_c2_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c2_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c2.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c2_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c2_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c2_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c2_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c2_binary, "flydsl_fused__to_copy_add_e7aee1ba_c2_kernel_0", 256, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c2_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c2_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 40960, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c2_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c2_compiled(40960, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c2_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c2_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c2_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c2_binary, "flydsl_fused__to_copy_add_e7aee1ba_c2_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c3_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=4 unroll=4
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 16, 4):
        xindex = _b * 1024 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
    for _j in range_constexpr(16):
        xindex = _b * 1024 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c3_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c3_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c3_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c3_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c3_kernel, flydsl_fused__to_copy_add_e7aee1ba_c3_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c3_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c3_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c3_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c3_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c3_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c3_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c3_launch


flydsl_fused__to_copy_add_e7aee1ba_c3_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c3_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c3.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c3_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c3_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c3_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c3_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c3_binary, "flydsl_fused__to_copy_add_e7aee1ba_c3_kernel_0", 64, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c3_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c3_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 40960, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c3_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c3_compiled(40960, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c3_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c3_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c3_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c3_binary, "flydsl_fused__to_copy_add_e7aee1ba_c3_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c4_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=4 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 8, 4):
        xindex = _b * 1024 + (_j // 4) * 512 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
    for _j in range_constexpr(8):
        xindex = _b * 1024 + (_j // 4) * 512 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c4_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c4_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c4_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c4_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c4_kernel, flydsl_fused__to_copy_add_e7aee1ba_c4_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c4_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c4_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c4_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c4_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c4_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c4_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c4_launch


flydsl_fused__to_copy_add_e7aee1ba_c4_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c4_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c4.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c4_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c4_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c4_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c4_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c4_binary, "flydsl_fused__to_copy_add_e7aee1ba_c4_kernel_0", 128, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c4_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c4_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 40960, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c4_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c4_compiled(40960, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c4_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c4_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c4_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c4_binary, "flydsl_fused__to_copy_add_e7aee1ba_c4_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c5_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=4 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 8, 4):
        xindex = _b * 2048 + (_j // 4) * 1024 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
    for _j in range_constexpr(8):
        xindex = _b * 2048 + (_j // 4) * 1024 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c5_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c5_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c5_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c5_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c5_kernel, flydsl_fused__to_copy_add_e7aee1ba_c5_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c5_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c5_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c5_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c5_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c5_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c5_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c5_launch


flydsl_fused__to_copy_add_e7aee1ba_c5_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c5_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c5.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c5_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c5_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c5_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c5_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c5_binary, "flydsl_fused__to_copy_add_e7aee1ba_c5_kernel_0", 256, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c5_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c5_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 20480, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c5_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c5_compiled(20480, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c5_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c5_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c5_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c5_binary, "flydsl_fused__to_copy_add_e7aee1ba_c5_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c6_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=2 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 4, 2):
        xindex = _b * 256 + (_j // 2) * 128 + _t * 2 + _j % 2
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 2, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 2, _r_in_ptr1, lambda: x0, 'bf16')
    for _j in range_constexpr(4):
        xindex = _b * 256 + (_j // 2) * 128 + _t * 2 + _j % 2
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 2, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 2, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 2, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c6_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c6_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c6_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c6_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c6_kernel, flydsl_fused__to_copy_add_e7aee1ba_c6_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c6_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c6_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c6_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c6_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c6_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c6_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c6_launch


flydsl_fused__to_copy_add_e7aee1ba_c6_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c6_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c6.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c6_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c6_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c6_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c6_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c6_binary, "flydsl_fused__to_copy_add_e7aee1ba_c6_kernel_0", 64, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c6_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c6_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 163840, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c6_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c6_compiled(163840, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c6_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c6_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c6_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c6_binary, "flydsl_fused__to_copy_add_e7aee1ba_c6_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c7_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=2 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 4, 2):
        xindex = _b * 512 + (_j // 2) * 256 + _t * 2 + _j % 2
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 2, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 2, _r_in_ptr1, lambda: x0, 'bf16')
    for _j in range_constexpr(4):
        xindex = _b * 512 + (_j // 2) * 256 + _t * 2 + _j % 2
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 2, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 2, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 2, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c7_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c7_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c7_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c7_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c7_kernel, flydsl_fused__to_copy_add_e7aee1ba_c7_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c7_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c7_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c7_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c7_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c7_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c7_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c7_launch


flydsl_fused__to_copy_add_e7aee1ba_c7_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c7_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c7.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c7_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c7_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c7_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c7_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c7_binary, "flydsl_fused__to_copy_add_e7aee1ba_c7_kernel_0", 128, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c7_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c7_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 81920, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c7_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c7_compiled(81920, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c7_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c7_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c7_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c7_binary, "flydsl_fused__to_copy_add_e7aee1ba_c7_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c8_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=4 unroll=1
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(4):
        xindex = _b * 2048 + (_j // 4) * 2048 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c8_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c8_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(512, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c8_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c8_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c8_kernel, flydsl_fused__to_copy_add_e7aee1ba_c8_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c8_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c8_kernel = flyc.kernel(known_block_size=[512, 1, 1])(flydsl_fused__to_copy_add_e7aee1ba_c8_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c8_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c8_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c8_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c8_launch


flydsl_fused__to_copy_add_e7aee1ba_c8_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c8_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c8.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c8_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c8_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c8_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c8_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c8_binary, "flydsl_fused__to_copy_add_e7aee1ba_c8_kernel_0", 512, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c8_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c8_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 20480, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c8_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c8_compiled(20480, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c8_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c8_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c8_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c8_binary, "flydsl_fused__to_copy_add_e7aee1ba_c8_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c9_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=4 unroll=8
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 32, 4):
        xindex = _b * 2048 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
    for _j in range_constexpr(32):
        xindex = _b * 2048 + (_j // 4) * 256 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c9_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c9_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c9_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c9_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c9_kernel, flydsl_fused__to_copy_add_e7aee1ba_c9_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c9_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c9_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c9_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c9_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c9_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c9_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c9_launch


flydsl_fused__to_copy_add_e7aee1ba_c9_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c9_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c9.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c9_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c9_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c9_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c9_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c9_binary, "flydsl_fused__to_copy_add_e7aee1ba_c9_kernel_0", 64, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c9_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c9_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 20480, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c9_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c9_compiled(20480, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c9_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c9_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c9_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c9_binary, "flydsl_fused__to_copy_add_e7aee1ba_c9_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c10_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=4 unroll=4
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(0, 16, 4):
        xindex = _b * 4096 + (_j // 4) * 1024 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
    for _j in range_constexpr(16):
        xindex = _b * 4096 + (_j // 4) * 1024 + _t * 4 + _j % 4
        x0 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0', 0), _j, 4, _r_in_ptr0, lambda: x0, 'bf16')
        tmp2 = fdp.vload(_vc, ('in_ptr1', 'x0', 0), _j, 4, _r_in_ptr1, lambda: x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.vstore(_sc, 'st2_out_ptr0', _j, 4, _r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c10_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c10_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c10_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c10_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c10_kernel, flydsl_fused__to_copy_add_e7aee1ba_c10_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c10_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c10_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c10_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c10_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c10_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c10_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c10_launch


flydsl_fused__to_copy_add_e7aee1ba_c10_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c10_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c10.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c10_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c10_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c10_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c10_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c10_binary, "flydsl_fused__to_copy_add_e7aee1ba_c10_kernel_0", 256, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c10_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c10_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 10240, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c10_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c10_compiled(10240, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c10_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c10_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c10_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c10_binary, "flydsl_fused__to_copy_add_e7aee1ba_c10_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_add_e7aee1ba_c11_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=41943040 ept=1 unroll=2
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 83886080)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 83886080)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 167772160)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(2):
        xindex = _b * 128 + (_j // 1) * 64 + _t * 1 + _j % 1
        x0 = xindex
        tmp0 = fdp.load(_r_in_ptr0, x0, 'bf16')
        tmp2 = fdp.load(_r_in_ptr1, x0, 'bf16')
    for _j in range_constexpr(2):
        xindex = _b * 128 + (_j // 1) * 64 + _t * 1 + _j % 1
        x0 = xindex
        tmp0 = fdp.load(_r_in_ptr0, x0, 'bf16')
        tmp2 = fdp.load(_r_in_ptr1, x0, 'bf16')
        tmp1 = fdp.to(tmp0, 'f32')
        tmp3 = fdp.to(tmp2, 'f32')
        tmp4 = fdp.add(tmp1, tmp3)
        fdp.store(_r_out_ptr0, x0, tmp4, 'f32')


def flydsl_fused__to_copy_add_e7aee1ba_c11_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_add_e7aee1ba_c11_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy_add_e7aee1ba_c11_launch = None


def flydsl_fused__to_copy_add_e7aee1ba_c11_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_add_e7aee1ba_c11_kernel, flydsl_fused__to_copy_add_e7aee1ba_c11_launch
    if flydsl_fused__to_copy_add_e7aee1ba_c11_launch is None:
        flydsl_fused__to_copy_add_e7aee1ba_c11_kernel = flyc.kernel(flydsl_fused__to_copy_add_e7aee1ba_c11_kernel)
        flydsl_fused__to_copy_add_e7aee1ba_c11_launch = flyc.jit(flydsl_fused__to_copy_add_e7aee1ba_c11_launch_fn)
        flydsl_fused__to_copy_add_e7aee1ba_c11_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused__to_copy_add_e7aee1ba_c11_launch


flydsl_fused__to_copy_add_e7aee1ba_c11_compiled = None
flydsl_fused__to_copy_add_e7aee1ba_c11_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_add_e7aee1ba_c11.hsaco"


def flydsl_fused__to_copy_add_e7aee1ba_c11_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_c11_compiled
    if flydsl_fused__to_copy_add_e7aee1ba_c11_compiled is None:
        flydsl_fused__to_copy_add_e7aee1ba_c11_compiled = fdp.load_binary(
            flydsl_fused__to_copy_add_e7aee1ba_c11_binary, "flydsl_fused__to_copy_add_e7aee1ba_c11_kernel_0", 64, 'OOO'
        )
        if flydsl_fused__to_copy_add_e7aee1ba_c11_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_add_e7aee1ba_c11_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 327680, 0 if stream is None else stream)
            flydsl_fused__to_copy_add_e7aee1ba_c11_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_add_e7aee1ba_c11_compiled(327680, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused__to_copy_add_e7aee1ba_c11_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_add_e7aee1ba_c11_binary):
        return
    launch = flydsl_fused__to_copy_add_e7aee1ba_c11_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_add_e7aee1ba_c11_binary, "flydsl_fused__to_copy_add_e7aee1ba_c11_kernel_0")

flydsl_fused__to_copy_add_e7aee1ba_best = None


def flydsl_fused__to_copy_add_e7aee1ba_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused__to_copy_add_e7aee1ba_best
    if flydsl_fused__to_copy_add_e7aee1ba_best is None:
        flydsl_fused__to_copy_add_e7aee1ba_best = fdp.pick_fastest(
            [flydsl_fused__to_copy_add_e7aee1ba_c0_main, flydsl_fused__to_copy_add_e7aee1ba_c1_main, flydsl_fused__to_copy_add_e7aee1ba_c2_main, flydsl_fused__to_copy_add_e7aee1ba_c3_main, flydsl_fused__to_copy_add_e7aee1ba_c4_main, flydsl_fused__to_copy_add_e7aee1ba_c5_main, flydsl_fused__to_copy_add_e7aee1ba_c6_main, flydsl_fused__to_copy_add_e7aee1ba_c7_main, flydsl_fused__to_copy_add_e7aee1ba_c8_main, flydsl_fused__to_copy_add_e7aee1ba_c9_main, flydsl_fused__to_copy_add_e7aee1ba_c10_main, flydsl_fused__to_copy_add_e7aee1ba_c11_main], (in_ptr0, in_ptr1, out_ptr0,), (2,), stream,
            warm=(), metadata={'kernel_name': 'flydsl_fused__to_copy_add_e7aee1ba', 'stage': 'pointwise', 'candidate_descriptions': ['pointwise xnumel=41943040 ept=4 unroll=2', 'pointwise xnumel=41943040 ept=4 unroll=1', 'pointwise xnumel=41943040 ept=4 unroll=1', 'pointwise xnumel=41943040 ept=4 unroll=4', 'pointwise xnumel=41943040 ept=4 unroll=2', 'pointwise xnumel=41943040 ept=4 unroll=2', 'pointwise xnumel=41943040 ept=2 unroll=2', 'pointwise xnumel=41943040 ept=2 unroll=2', 'pointwise xnumel=41943040 ept=4 unroll=1', 'pointwise xnumel=41943040 ept=4 unroll=8', 'pointwise xnumel=41943040 ept=4 unroll=4', 'pointwise xnumel=41943040 ept=1 unroll=2']},
        )
        return
    flydsl_fused__to_copy_add_e7aee1ba_best(in_ptr0, in_ptr1, out_ptr0, stream=stream)


def flydsl_fused__to_copy_add_e7aee1ba_precompile(only=None, **kw):
    if only in (None, 0):
        flydsl_fused__to_copy_add_e7aee1ba_c0_precompile(**kw)
    if only in (None, 1):
        flydsl_fused__to_copy_add_e7aee1ba_c1_precompile(**kw)
    if only in (None, 2):
        flydsl_fused__to_copy_add_e7aee1ba_c2_precompile(**kw)
    if only in (None, 3):
        flydsl_fused__to_copy_add_e7aee1ba_c3_precompile(**kw)
    if only in (None, 4):
        flydsl_fused__to_copy_add_e7aee1ba_c4_precompile(**kw)
    if only in (None, 5):
        flydsl_fused__to_copy_add_e7aee1ba_c5_precompile(**kw)
    if only in (None, 6):
        flydsl_fused__to_copy_add_e7aee1ba_c6_precompile(**kw)
    if only in (None, 7):
        flydsl_fused__to_copy_add_e7aee1ba_c7_precompile(**kw)
    if only in (None, 8):
        flydsl_fused__to_copy_add_e7aee1ba_c8_precompile(**kw)
    if only in (None, 9):
        flydsl_fused__to_copy_add_e7aee1ba_c9_precompile(**kw)
    if only in (None, 10):
        flydsl_fused__to_copy_add_e7aee1ba_c10_precompile(**kw)
    if only in (None, 11):
        flydsl_fused__to_copy_add_e7aee1ba_c11_precompile(**kw)
'''), '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c0.hsaco', precompile_metadata={'only': 0})


flydsl_fused__to_copy_add_e7aee1ba_v1 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c1.hsaco', precompile_metadata={'only': 1})


flydsl_fused__to_copy_add_e7aee1ba_v2 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c2.hsaco', precompile_metadata={'only': 2})


flydsl_fused__to_copy_add_e7aee1ba_v3 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c3.hsaco', precompile_metadata={'only': 3})


flydsl_fused__to_copy_add_e7aee1ba_v4 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c4.hsaco', precompile_metadata={'only': 4})


flydsl_fused__to_copy_add_e7aee1ba_v5 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c5.hsaco', precompile_metadata={'only': 5})


flydsl_fused__to_copy_add_e7aee1ba_v6 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c6.hsaco', precompile_metadata={'only': 6})


flydsl_fused__to_copy_add_e7aee1ba_v7 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c7.hsaco', precompile_metadata={'only': 7})


flydsl_fused__to_copy_add_e7aee1ba_v8 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c8.hsaco', precompile_metadata={'only': 8})


flydsl_fused__to_copy_add_e7aee1ba_v9 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c9.hsaco', precompile_metadata={'only': 9})


flydsl_fused__to_copy_add_e7aee1ba_v10 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c10.hsaco', precompile_metadata={'only': 10})


flydsl_fused__to_copy_add_e7aee1ba_v11 = fdp_rt.compiled(async_compile, 'flydsl_fused__to_copy_add_e7aee1ba', flydsl_fused__to_copy_add_e7aee1ba_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/7g/c7gxcycptxi2ct4luvagnz7cgvdsnpkizr4olkvjt4t2davvrvt7.flydsl_fused__to_copy_add_e7aee1ba_c11.hsaco', precompile_metadata={'only': 11})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1), ((41943040, ), (41943040, )), ((1, ), (1, )), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf0 = empty_strided_cuda((41943040, ), (1, ), torch.float32)
            # Topologically Sorted Source Nodes: [float_1, float_2, add], Original ATen: [aten._to_copy, aten.add]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused__to_copy_add_e7aee1ba.run(arg0_1, arg1_1, buf0, stream=raw_stream0)
            del arg0_1
            del arg1_1
        return (buf0, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((41943040, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((41943040, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
