# AOT ID: ['46_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c0.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/xh/cxhlggfj3u2cnpohkiyxpoq5ztf3p3yfpiv4x55dhowwzt4vxdb4.py
# Topologically Sorted Source Nodes: [square, mean], Original ATen: [aten.pow, aten.mean]
# Source node to ATen node mapping:
#   mean => mean
#   square => pow_1
# Graph fragment:
#   %arg0_1 : Tensor "f32[16384, 50265][50265, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %pow_1 : Tensor "f32[16384, 50265][50265, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%arg0_1, 2), kwargs = {})
#   %mean : Tensor "f32[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.default](args = (%pow_1,), kwargs = {})
#   return %buf1
flydsl_fused_mean_pow_07b7e2c9 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', (flydsl_fused_mean_pow_07b7e2c9_source := r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused_mean_pow_07b7e2c9_c0__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused_mean_pow_07b7e2c9_c0_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(flydsl_fused_mean_pow_07b7e2c9_c0__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 256
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(4096)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(16):
                r0_index = r0_offset + (_j // 4) * 1024 + _rl * 4 + _j % 4
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 256, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c0_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c0_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c0_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c0_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c0_kernel, flydsl_fused_mean_pow_07b7e2c9_c0_launch
    if flydsl_fused_mean_pow_07b7e2c9_c0_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c0_kernel = flyc.kernel(flydsl_fused_mean_pow_07b7e2c9_c0_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c0_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c0_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c0_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c0_launch


flydsl_fused_mean_pow_07b7e2c9_c0_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c0_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c0.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c0_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c0_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c0_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c0_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c0_binary, "flydsl_fused_mean_pow_07b7e2c9_c0_kernel_0", 256, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c0_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c0_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 3142, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c0_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c0_compiled(3142, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c0_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c0_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c0_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c0_binary, "flydsl_fused_mean_pow_07b7e2c9_c0_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused_mean_pow_07b7e2c9_c1__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused_mean_pow_07b7e2c9_c1_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=4 unroll=1 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(flydsl_fused_mean_pow_07b7e2c9_c1__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 256
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(1024)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 4) * 1024 + _rl * 4 + _j % 4
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 256, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c1_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c1_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c1_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c1_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c1_kernel, flydsl_fused_mean_pow_07b7e2c9_c1_launch
    if flydsl_fused_mean_pow_07b7e2c9_c1_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c1_kernel = flyc.kernel(flydsl_fused_mean_pow_07b7e2c9_c1_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c1_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c1_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c1_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c1_launch


flydsl_fused_mean_pow_07b7e2c9_c1_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c1_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c1.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c1_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c1_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c1_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c1_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c1_binary, "flydsl_fused_mean_pow_07b7e2c9_c1_kernel_0", 256, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c1_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c1_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 3142, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c1_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c1_compiled(3142, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c1_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c1_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c1_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c1_binary, "flydsl_fused_mean_pow_07b7e2c9_c1_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused_mean_pow_07b7e2c9_c2__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused_mean_pow_07b7e2c9_c2_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=4 unroll=2 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(flydsl_fused_mean_pow_07b7e2c9_c2__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 256
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(2048)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 4) * 1024 + _rl * 4 + _j % 4
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 256, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c2_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c2_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c2_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c2_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c2_kernel, flydsl_fused_mean_pow_07b7e2c9_c2_launch
    if flydsl_fused_mean_pow_07b7e2c9_c2_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c2_kernel = flyc.kernel(flydsl_fused_mean_pow_07b7e2c9_c2_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c2_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c2_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c2_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c2_launch


flydsl_fused_mean_pow_07b7e2c9_c2_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c2_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c2.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c2_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c2_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c2_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c2_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c2_binary, "flydsl_fused_mean_pow_07b7e2c9_c2_kernel_0", 256, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c2_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c2_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 3142, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c2_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c2_compiled(3142, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c2_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c2_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c2_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c2_binary, "flydsl_fused_mean_pow_07b7e2c9_c2_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused_mean_pow_07b7e2c9_c3__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused_mean_pow_07b7e2c9_c3_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=4 unroll=8 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(flydsl_fused_mean_pow_07b7e2c9_c3__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 256
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(8192)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(32):
                r0_index = r0_offset + (_j // 4) * 1024 + _rl * 4 + _j % 4
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 256, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c3_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c3_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c3_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c3_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c3_kernel, flydsl_fused_mean_pow_07b7e2c9_c3_launch
    if flydsl_fused_mean_pow_07b7e2c9_c3_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c3_kernel = flyc.kernel(flydsl_fused_mean_pow_07b7e2c9_c3_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c3_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c3_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c3_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c3_launch


flydsl_fused_mean_pow_07b7e2c9_c3_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c3_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c3.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c3_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c3_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c3_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c3_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c3_binary, "flydsl_fused_mean_pow_07b7e2c9_c3_kernel_0", 256, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c3_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c3_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 3142, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c3_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c3_compiled(3142, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c3_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c3_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c3_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c3_binary, "flydsl_fused_mean_pow_07b7e2c9_c3_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused_mean_pow_07b7e2c9_c4_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=64 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 64
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(1024)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(16):
                r0_index = r0_offset + (_j // 4) * 256 + _rl * 4 + _j % 4
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 64, None, 64, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c4_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c4_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c4_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c4_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c4_kernel, flydsl_fused_mean_pow_07b7e2c9_c4_launch
    if flydsl_fused_mean_pow_07b7e2c9_c4_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c4_kernel = flyc.kernel(flydsl_fused_mean_pow_07b7e2c9_c4_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c4_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c4_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c4_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c4_launch


flydsl_fused_mean_pow_07b7e2c9_c4_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c4_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c4.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c4_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c4_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c4_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c4_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c4_binary, "flydsl_fused_mean_pow_07b7e2c9_c4_kernel_0", 64, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c4_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c4_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 3142, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c4_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c4_compiled(3142, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c4_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c4_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c4_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c4_binary, "flydsl_fused_mean_pow_07b7e2c9_c4_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused_mean_pow_07b7e2c9_c5__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused_mean_pow_07b7e2c9_c5_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=128 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(flydsl_fused_mean_pow_07b7e2c9_c5__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 128
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 2 + _xr * 2 + _t // 128
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(2048)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(16):
                r0_index = r0_offset + (_j // 4) * 512 + _rl * 4 + _j % 4
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 128, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c5_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c5_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c5_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c5_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c5_kernel, flydsl_fused_mean_pow_07b7e2c9_c5_launch
    if flydsl_fused_mean_pow_07b7e2c9_c5_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c5_kernel = flyc.kernel(flydsl_fused_mean_pow_07b7e2c9_c5_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c5_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c5_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c5_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c5_launch


flydsl_fused_mean_pow_07b7e2c9_c5_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c5_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c5.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c5_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c5_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c5_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c5_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c5_binary, "flydsl_fused_mean_pow_07b7e2c9_c5_kernel_0", 256, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c5_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c5_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 1571, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c5_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c5_compiled(1571, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c5_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c5_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c5_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c5_binary, "flydsl_fused_mean_pow_07b7e2c9_c5_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused_mean_pow_07b7e2c9_c6__Smem:
    words: fx.Array[fx.Int32, 1024, 16]

def flydsl_fused_mean_pow_07b7e2c9_c6_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=512 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(flydsl_fused_mean_pow_07b7e2c9_c6__Smem).peek().words.view(fx.make_layout(1024, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 512
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 512
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(8192)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(16):
                r0_index = r0_offset + (_j // 4) * 2048 + _rl * 4 + _j % 4
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 512, _smem, 512, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c6_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c6_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(512, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c6_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c6_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c6_kernel, flydsl_fused_mean_pow_07b7e2c9_c6_launch
    if flydsl_fused_mean_pow_07b7e2c9_c6_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c6_kernel = flyc.kernel(known_block_size=[512, 1, 1])(flydsl_fused_mean_pow_07b7e2c9_c6_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c6_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c6_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c6_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c6_launch


flydsl_fused_mean_pow_07b7e2c9_c6_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c6_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c6.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c6_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c6_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c6_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c6_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c6_binary, "flydsl_fused_mean_pow_07b7e2c9_c6_kernel_0", 512, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c6_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c6_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 3142, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c6_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c6_compiled(3142, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c6_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c6_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c6_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c6_binary, "flydsl_fused_mean_pow_07b7e2c9_c6_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused_mean_pow_07b7e2c9_c7__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused_mean_pow_07b7e2c9_c7_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=1 unroll=4 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(flydsl_fused_mean_pow_07b7e2c9_c7__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 256
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(1024)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 1) * 256 + _rl * 1 + _j % 1
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 256, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c7_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c7_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c7_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c7_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c7_kernel, flydsl_fused_mean_pow_07b7e2c9_c7_launch
    if flydsl_fused_mean_pow_07b7e2c9_c7_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c7_kernel = flyc.kernel(flydsl_fused_mean_pow_07b7e2c9_c7_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c7_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c7_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c7_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c7_launch


flydsl_fused_mean_pow_07b7e2c9_c7_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c7_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c7.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c7_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c7_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c7_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c7_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c7_binary, "flydsl_fused_mean_pow_07b7e2c9_c7_kernel_0", 256, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c7_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c7_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 3142, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c7_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c7_compiled(3142, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c7_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c7_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c7_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c7_binary, "flydsl_fused_mean_pow_07b7e2c9_c7_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused_mean_pow_07b7e2c9_c8__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused_mean_pow_07b7e2c9_c8_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=2 unroll=4 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(flydsl_fused_mean_pow_07b7e2c9_c8__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 256
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 256
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(2048)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 2) * 512 + _rl * 2 + _j % 2
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 256, _smem, 256, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c8_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c8_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c8_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c8_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c8_kernel, flydsl_fused_mean_pow_07b7e2c9_c8_launch
    if flydsl_fused_mean_pow_07b7e2c9_c8_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c8_kernel = flyc.kernel(flydsl_fused_mean_pow_07b7e2c9_c8_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c8_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c8_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c8_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c8_launch


flydsl_fused_mean_pow_07b7e2c9_c8_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c8_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c8.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c8_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c8_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c8_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c8_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c8_binary, "flydsl_fused_mean_pow_07b7e2c9_c8_kernel_0", 256, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c8_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c8_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 3142, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c8_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c8_compiled(3142, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c8_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c8_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c8_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c8_binary, "flydsl_fused_mean_pow_07b7e2c9_c8_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused_mean_pow_07b7e2c9_c9__Smem:
    words: fx.Array[fx.Int32, 256, 16]

def flydsl_fused_mean_pow_07b7e2c9_c9_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=128 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 3294167040)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(flydsl_fused_mean_pow_07b7e2c9_c9__Smem).peek().words.view(fx.make_layout(256, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 128
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 128
        x0 = xindex
        _acc1 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(262108), fx.Int32(2048)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            for _j in range_constexpr(16):
                r0_index = r0_offset + (_j // 4) * 512 + _rl * 4 + _j % 4
                r0_mask = r0_index < 262108
                r0_1 = r0_index
                tmp0 = fdp.to(r0_1 + 262108*x0, 'i32')
                tmp1 = fdp.const(823541760, 'i32')
                tmp2 = fdp.lt(tmp0, tmp1)
                tmp3 = fdp.load(_r_in_ptr0, fdp.imod(r0_1 + 262108*x0, 823541760), 'f32', mask=fdp.land(r0_mask, tmp2))
                tmp4 = fdp.mul(tmp3, tmp3)
                tmp5 = fdp.const(0.0, 'f32')
                tmp6 = fdp.where(tmp2, tmp4, tmp5)
                _acc1_items.append((tmp6, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        tmp7 = fdp.group_reduce('sum', _acc1, 128, _smem, 128, 1)
        fdp.store(_r_out_ptr0, x0, tmp7, 'f32', mask=_lane0)


def flydsl_fused_mean_pow_07b7e2c9_c9_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_07b7e2c9_c9_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused_mean_pow_07b7e2c9_c9_launch = None


def flydsl_fused_mean_pow_07b7e2c9_c9_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_07b7e2c9_c9_kernel, flydsl_fused_mean_pow_07b7e2c9_c9_launch
    if flydsl_fused_mean_pow_07b7e2c9_c9_launch is None:
        flydsl_fused_mean_pow_07b7e2c9_c9_kernel = flyc.kernel(flydsl_fused_mean_pow_07b7e2c9_c9_kernel)
        flydsl_fused_mean_pow_07b7e2c9_c9_launch = flyc.jit(flydsl_fused_mean_pow_07b7e2c9_c9_launch_fn)
        flydsl_fused_mean_pow_07b7e2c9_c9_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_07b7e2c9_c9_launch


flydsl_fused_mean_pow_07b7e2c9_c9_compiled = None
flydsl_fused_mean_pow_07b7e2c9_c9_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_07b7e2c9_c9.hsaco"


def flydsl_fused_mean_pow_07b7e2c9_c9_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_c9_compiled
    if flydsl_fused_mean_pow_07b7e2c9_c9_compiled is None:
        flydsl_fused_mean_pow_07b7e2c9_c9_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_07b7e2c9_c9_binary, "flydsl_fused_mean_pow_07b7e2c9_c9_kernel_0", 128, 'OO'
        )
        if flydsl_fused_mean_pow_07b7e2c9_c9_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_07b7e2c9_c9_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 3142, 0 if stream is None else stream)
            flydsl_fused_mean_pow_07b7e2c9_c9_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_07b7e2c9_c9_compiled(3142, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_mean_pow_07b7e2c9_c9_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_07b7e2c9_c9_binary):
        return
    launch = flydsl_fused_mean_pow_07b7e2c9_c9_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_07b7e2c9_c9_binary, "flydsl_fused_mean_pow_07b7e2c9_c9_kernel_0")

flydsl_fused_mean_pow_07b7e2c9_best = None


def flydsl_fused_mean_pow_07b7e2c9_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_mean_pow_07b7e2c9_best
    if flydsl_fused_mean_pow_07b7e2c9_best is None:
        flydsl_fused_mean_pow_07b7e2c9_best = fdp.pick_fastest(
            [flydsl_fused_mean_pow_07b7e2c9_c0_main, flydsl_fused_mean_pow_07b7e2c9_c1_main, flydsl_fused_mean_pow_07b7e2c9_c2_main, flydsl_fused_mean_pow_07b7e2c9_c3_main, flydsl_fused_mean_pow_07b7e2c9_c4_main, flydsl_fused_mean_pow_07b7e2c9_c5_main, flydsl_fused_mean_pow_07b7e2c9_c6_main, flydsl_fused_mean_pow_07b7e2c9_c7_main, flydsl_fused_mean_pow_07b7e2c9_c8_main, flydsl_fused_mean_pow_07b7e2c9_c9_main], (in_ptr0, out_ptr0,), (1,), stream,
            warm=(), metadata={'kernel_name': 'flydsl_fused_mean_pow_07b7e2c9', 'stage': 'row', 'candidate_descriptions': ["row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=3142 rnumel=262108 ept=4 unroll=1 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=3142 rnumel=262108 ept=4 unroll=2 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=3142 rnumel=262108 ept=4 unroll=8 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=64 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=128 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=512 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=3142 rnumel=262108 ept=1 unroll=4 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=3142 rnumel=262108 ept=2 unroll=4 tpr=256 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "row reduction xnumel=3142 rnumel=262108 ept=4 unroll=4 tpr=128 stride=1 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}"]},
        )
        return
    flydsl_fused_mean_pow_07b7e2c9_best(in_ptr0, out_ptr0, stream=stream)


def flydsl_fused_mean_pow_07b7e2c9_precompile(only=None, **kw):
    if only in (None, 0):
        flydsl_fused_mean_pow_07b7e2c9_c0_precompile(**kw)
    if only in (None, 1):
        flydsl_fused_mean_pow_07b7e2c9_c1_precompile(**kw)
    if only in (None, 2):
        flydsl_fused_mean_pow_07b7e2c9_c2_precompile(**kw)
    if only in (None, 3):
        flydsl_fused_mean_pow_07b7e2c9_c3_precompile(**kw)
    if only in (None, 4):
        flydsl_fused_mean_pow_07b7e2c9_c4_precompile(**kw)
    if only in (None, 5):
        flydsl_fused_mean_pow_07b7e2c9_c5_precompile(**kw)
    if only in (None, 6):
        flydsl_fused_mean_pow_07b7e2c9_c6_precompile(**kw)
    if only in (None, 7):
        flydsl_fused_mean_pow_07b7e2c9_c7_precompile(**kw)
    if only in (None, 8):
        flydsl_fused_mean_pow_07b7e2c9_c8_precompile(**kw)
    if only in (None, 9):
        flydsl_fused_mean_pow_07b7e2c9_c9_precompile(**kw)
'''), '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c0.hsaco', precompile_metadata={'only': 0})


flydsl_fused_mean_pow_07b7e2c9_v1 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', flydsl_fused_mean_pow_07b7e2c9_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c1.hsaco', precompile_metadata={'only': 1})


flydsl_fused_mean_pow_07b7e2c9_v2 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', flydsl_fused_mean_pow_07b7e2c9_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c2.hsaco', precompile_metadata={'only': 2})


flydsl_fused_mean_pow_07b7e2c9_v3 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', flydsl_fused_mean_pow_07b7e2c9_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c3.hsaco', precompile_metadata={'only': 3})


flydsl_fused_mean_pow_07b7e2c9_v4 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', flydsl_fused_mean_pow_07b7e2c9_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c4.hsaco', precompile_metadata={'only': 4})


flydsl_fused_mean_pow_07b7e2c9_v5 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', flydsl_fused_mean_pow_07b7e2c9_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c5.hsaco', precompile_metadata={'only': 5})


flydsl_fused_mean_pow_07b7e2c9_v6 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', flydsl_fused_mean_pow_07b7e2c9_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c6.hsaco', precompile_metadata={'only': 6})


flydsl_fused_mean_pow_07b7e2c9_v7 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', flydsl_fused_mean_pow_07b7e2c9_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c7.hsaco', precompile_metadata={'only': 7})


flydsl_fused_mean_pow_07b7e2c9_v8 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', flydsl_fused_mean_pow_07b7e2c9_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c8.hsaco', precompile_metadata={'only': 8})


flydsl_fused_mean_pow_07b7e2c9_v9 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_07b7e2c9', flydsl_fused_mean_pow_07b7e2c9_source, '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/bd/cbdabyfjoaquvkbcqry63enna273lolkbrgnghiyucpsymrvk3gj.flydsl_fused_mean_pow_07b7e2c9_c9.hsaco', precompile_metadata={'only': 9})


# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/4i/c4i2o62fp5pbiiklafphrosmdratcfxkwm6uc3z3ndhjpriezh2x.py
# Topologically Sorted Source Nodes: [square, mean], Original ATen: [aten.pow, aten.mean]
# Source node to ATen node mapping:
#   mean => mean
#   square => pow_1
# Graph fragment:
#   %buf1 : Tensor "f32[3142][1]cuda:0" = PlaceHolder[target=buf1]
#   %buf2 : Tensor "f32[][]cuda:0" = PlaceHolder[target=buf2]
#   %pow_1 : Tensor "f32[16384, 50265][50265, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%arg0_1, 2), kwargs = {})
#   %mean : Tensor "f32[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.default](args = (%pow_1,), kwargs = {})
#   return %buf2,%mean
flydsl_fused_mean_pow_d5320466 = fdp_rt.compiled(async_compile, 'flydsl_fused_mean_pow_d5320466', r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class _Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused_mean_pow_d5320466_kernel(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=1 rnumel=3142 ept=2 unroll=1 tpr=1024 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_out_ptr0 = fdp.rsrc(in_out_ptr0, 4)
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 12568)
    _smem = fx.SharedAllocator().allocate(_Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 1024
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 1 + _xr * 1 + _t // 1024
        _acc1 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 3142, 2048):
            for _j in range_constexpr(2):
                r0_index = r0_offset + (_j // 2) * 2048 + _rl * 2 + _j % 2
                r0_mask = r0_index < 3142
                r0_0 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_0', r0_offset), _j, 2, _r_in_ptr0, lambda: r0_0, 'f32', mask=r0_mask)
        for r0_offset in range_constexpr(0, 3142, 2048):
            _acc1_items = []
            for _j in range_constexpr(2):
                r0_index = r0_offset + (_j // 2) * 2048 + _rl * 2 + _j % 2
                r0_mask = r0_index < 3142
                r0_0 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_0', r0_offset), _j, 2, _r_in_ptr0, lambda: r0_0, 'f32', mask=r0_mask)
                _acc1_items.append((tmp0, r0_mask))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
        fdp.widen(_lc, (('in_ptr0', 'r0_0'),))
        tmp1 = fdp.group_reduce('sum', _acc1, 1024, _smem, 1024, 1)
        tmp2 = fdp.const(823541760.0, 'f32')
        tmp3 = fdp.truediv(tmp1, tmp2)
        fdp.store(_r_in_out_ptr0, 0, tmp3, 'f32', mask=_lane0)
        fdp.forget(_lc, 'in_out_ptr0')


def flydsl_fused_mean_pow_d5320466_launch_fn(in_out_ptr0: fx.Int64, in_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_mean_pow_d5320466_kernel(in_out_ptr0, in_ptr0).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused_mean_pow_d5320466_launch = None


def flydsl_fused_mean_pow_d5320466_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_mean_pow_d5320466_kernel, flydsl_fused_mean_pow_d5320466_launch
    if flydsl_fused_mean_pow_d5320466_launch is None:
        flydsl_fused_mean_pow_d5320466_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused_mean_pow_d5320466_kernel)
        flydsl_fused_mean_pow_d5320466_launch = flyc.jit(flydsl_fused_mean_pow_d5320466_launch_fn)
        flydsl_fused_mean_pow_d5320466_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused_mean_pow_d5320466_launch


flydsl_fused_mean_pow_d5320466_compiled = None
flydsl_fused_mean_pow_d5320466_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_mean_pow_d5320466.hsaco"


def flydsl_fused_mean_pow_d5320466_main(in_out_ptr0, in_ptr0, stream=None):
    global flydsl_fused_mean_pow_d5320466_compiled
    if flydsl_fused_mean_pow_d5320466_compiled is None:
        flydsl_fused_mean_pow_d5320466_compiled = fdp.load_binary(
            flydsl_fused_mean_pow_d5320466_binary, "flydsl_fused_mean_pow_d5320466_kernel_0", 1024, 'OO'
        )
        if flydsl_fused_mean_pow_d5320466_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_mean_pow_d5320466_flydsl(), in_out_ptr0.data_ptr(), in_ptr0.data_ptr(), 1, 0 if stream is None else stream)
            flydsl_fused_mean_pow_d5320466_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_mean_pow_d5320466_compiled(1, 1, 1, 0 if stream is None else stream, in_out_ptr0, in_ptr0, )


def flydsl_fused_mean_pow_d5320466_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_mean_pow_d5320466_binary):
        return
    launch = flydsl_fused_mean_pow_d5320466_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_mean_pow_d5320466_binary, "flydsl_fused_mean_pow_d5320466_kernel_0")
''', '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/u2/cu2tfmaiisgnpmu6gbzewckouteiyvpnktpyxjnvcdhpwvchjypx.flydsl_fused_mean_pow_d5320466.hsaco', precompile_metadata={})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, = args
        args.clear()
        assert_size_stride(arg0_1, (16384, 50265), (50265, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf1 = empty_strided_cuda((3142, ), (1, ), torch.float32)
            # Topologically Sorted Source Nodes: [square, mean], Original ATen: [aten.pow, aten.mean]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused_mean_pow_07b7e2c9.run(arg0_1, buf1, stream=raw_stream0)
            del arg0_1
            buf2 = empty_strided_cuda((), (), torch.float32)
            buf3 = buf2; del buf2  # reuse
            # Topologically Sorted Source Nodes: [square, mean], Original ATen: [aten.pow, aten.mean]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused_mean_pow_d5320466.run(buf3, buf1, stream=raw_stream0)
            del buf1
        return (buf3, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((16384, 50265), (50265, 1), device='cuda:0', dtype=torch.float32)
    return [arg0_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
