# AOT ID: ['242_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/ao/cao25yvahvkban5vm636ed6pbgfyznds3muj32z5ncbf5dm3c7am.flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/lx/clxxosfqncy3rzylyy34hckpnifhzder5faips7i2yvcz32xy35d.py
# Topologically Sorted Source Nodes: [invert, masked_fill, float_1, softmax], Original ATen: [aten.bitwise_not, aten.masked_fill, aten._to_copy, prims.prepare_softmax_online, aten._softmax]
# Source node to ATen node mapping:
#   float_1 => convert_element_type
#   invert => bitwise_not
#   masked_fill => full_default, where
#   softmax => div, exp_default, sub_tensor
# Graph fragment:
#   %arg1_1 : Tensor "b8[37, 64][64, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[37, 64][64, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %getitem : Tensor "f32[37, 1][1, 37]cuda:0" = PlaceHolder[target=getitem]
#   %getitem_1 : Tensor "f32[37, 1][1, 37]cuda:0" = PlaceHolder[target=getitem_1]
#   %bitwise_not : Tensor "b8[37, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.bitwise_not.default](args = (%arg1_1,), kwargs = {})
#   %full_default : Tensor "f32[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float32, layout: torch.strided, device: cuda:0, pin_memory: False})
#   %convert_element_type : Tensor "f32[37, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %where : Tensor "f32[37, 64][64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%bitwise_not, %full_default, %convert_element_type), kwargs = {})
#   %prepare_softmax_online_default : [num_users=2] = call_function[target=torch.ops.prims.prepare_softmax_online.default](args = (%where, -1), kwargs = {})
#   %sub_tensor : Tensor "f32[37, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%where, %getitem), kwargs = {})
#   %exp_default : Tensor "f32[37, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%sub_tensor,), kwargs = {})
#   %div : Tensor "f32[37, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_default, %getitem_1), kwargs = {})
#   return %getitem,%getitem_1,%div
flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba = fdp_rt.compiled(async_compile, 'flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba', r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr2: fx.Int64):
    # runtime a1a935225a4ec695
    # row reduction xnumel=37 rnumel=64 ept=8 unroll=1 tpr=8 stride=1 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 2368)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 4736)
    _r_out_ptr2 = fdp.rsrc(out_ptr2, 9472)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t % 8
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 8 + _xr * 8 + _t // 8
        xmask = xindex < 37
        x0 = xindex
        _acc1_items = []
        for r0_offset in range_constexpr(0, 64, 64):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 64 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 64*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 64*x0, 'b1', mask=xmask)
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1 + 64*x0', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_1 + 64*x0, 'bf16', mask=xmask)
        for r0_offset in range_constexpr(0, 64, 64):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 64 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp8 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 64*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 64*x0, 'b1', mask=xmask)
                tmp10 = fdp.vload(_lc, ('in_ptr1', 'r0_1 + 64*x0', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_1 + 64*x0, 'bf16', mask=xmask)
        for r0_offset in range_constexpr(0, 64, 64):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 64 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp0 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 64*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 64*x0, 'b1', mask=xmask)
                tmp2 = fdp.vload(_lc, ('in_ptr1', 'r0_1 + 64*x0', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_1 + 64*x0, 'bf16', mask=xmask)
                tmp1 = fdp.logical_not(tmp0)
                tmp3 = fdp.to(tmp2, 'f32')
                tmp4 = fdp.const(float('-inf'), 'f32')
                tmp5 = fdp.where(tmp1, tmp4, tmp3)
                _acc1_items.append((tmp5, None))
        tmp6, tmp7 = fdp.group_softmax_twopass(_acc1_items, 8, None, 64, 1)
        for r0_offset in range_constexpr(0, 64, 64):
            for _j in range_constexpr(8):
                r0_index = r0_offset + (_j // 8) * 64 + _rl * 8 + _j % 8
                r0_1 = r0_index
                tmp8 = fdp.vload(_lc, ('in_ptr0', 'r0_1 + 64*x0', r0_offset), _j, 8, _r_in_ptr0, lambda: r0_1 + 64*x0, 'b1', mask=xmask)
                tmp10 = fdp.vload(_lc, ('in_ptr1', 'r0_1 + 64*x0', r0_offset), _j, 8, _r_in_ptr1, lambda: r0_1 + 64*x0, 'bf16', mask=xmask)
                tmp9 = fdp.logical_not(tmp8)
                tmp11 = fdp.to(tmp10, 'f32')
                tmp12 = fdp.const(float('-inf'), 'f32')
                tmp13 = fdp.where(tmp9, tmp12, tmp11)
                tmp14 = fdp.sub(tmp13, tmp6)
                tmp15 = fdp.exp(tmp14)
                tmp16 = fdp.truediv(tmp15, tmp7)
                fdp.vstore(_sc, 'st6_out_ptr2', _j, 4, _r_out_ptr2, r0_1 + 64*x0, tmp16, 'f32', mask=xmask, seed=(_lc, ('out_ptr2', 'r0_1 + 64*x0', r0_offset)))
        fdp.forget(_lc, 'out_ptr2')


def flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr2: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_kernel(in_ptr0, in_ptr1, out_ptr2).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_launch = None


def flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_kernel, flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_launch
    if flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_launch is None:
        flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_kernel = flyc.kernel(flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_kernel)
        flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_launch = flyc.jit(flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_launch_fn)
        flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_launch


flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_compiled = None
flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba.hsaco"


def flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_main(in_ptr0, in_ptr1, out_ptr2, stream=None):
    global flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_compiled
    if flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_compiled is None:
        flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_compiled = fdp.load_binary(
            flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_binary, "flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_kernel_0", 64, 'OOO'
        )
        if flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr2.data_ptr(), 5, 0 if stream is None else stream)
            flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_compiled(5, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr2, )


def flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_binary):
        return
    launch = flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_binary, "flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba_kernel_0")
''', '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/ao/cao25yvahvkban5vm636ed6pbgfyznds3muj32z5ncbf5dm3c7am.flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba.hsaco', precompile_metadata={})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride_grouped((arg1_1, arg0_1), ((37, 64), (37, 64)), ((64, 1), (64, 1)), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf2 = empty_strided_cuda((37, 64), (64, 1), torch.float32)
            # Topologically Sorted Source Nodes: [invert, masked_fill, float_1, softmax], Original ATen: [aten.bitwise_not, aten.masked_fill, aten._to_copy, prims.prepare_softmax_online, aten._softmax]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused__softmax__to_copy_bitwise_not_masked_fill_prepare_softmax_online_b97eedba.run(arg1_1, arg0_1, buf2, stream=raw_stream0)
            del arg0_1
            del arg1_1
        return (buf2, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((37, 64), (64, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((37, 64), (64, 1), device='cuda:0', dtype=torch.bool)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
