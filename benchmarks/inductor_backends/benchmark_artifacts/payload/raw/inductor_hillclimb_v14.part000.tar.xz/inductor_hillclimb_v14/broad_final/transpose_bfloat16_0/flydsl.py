# AOT ID: ['98_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/i5/ci5ek3l4zncmhqu4qfg3aix5wephruaizz5no4yfejtcghqkgspb.flydsl_fused_clone_permute_727cdf72.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/jy/cjyvospw55l4rlneyxkdvga4fkawyl4avbsjduvz2gicpqntgs2y.py
# Topologically Sorted Source Nodes: [permute, contiguous], Original ATen: [aten.permute, aten.clone]
# Source node to ATen node mapping:
#   contiguous => clone
#   permute => permute
# Graph fragment:
#   %arg0_1 : Tensor "bf16[2, 3, 37, 64][7104, 2368, 64, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %permute : Tensor "bf16[2, 37, 3, 64][7104, 64, 2368, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg0_1, [0, 2, 1, 3]), kwargs = {})
#   %clone : Tensor "bf16[2, 37, 3, 64][7104, 192, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone
flydsl_fused_clone_permute_727cdf72 = fdp_rt.compiled(async_compile, 'flydsl_fused_clone_permute_727cdf72', r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused_clone_permute_727cdf72_kernel(in_ptr0: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=14208 ept=8 unroll=1
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 28416)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 28416)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(8):
        xindex = _b * 512 + (_j // 8) * 512 + _t * 8 + _j % 8
        xmask = xindex < 14208
        x0 = fdp.imod(xindex, 64)
        x1 = fdp.imod(fdp.idiv(xindex, 64), 3)
        x2 = fdp.imod(fdp.idiv(xindex, 192), 37)
        x3 = fdp.idiv(xindex, 7104)
        x4 = xindex
        tmp0 = fdp.vload(_vc, ('in_ptr0', 'x0 + 64*x2 + 2368*x1 + 7104*x3', 0), _j, 8, _r_in_ptr0, lambda: x0 + 64*x2 + 2368*x1 + 7104*x3, 'bf16', mask=xmask)
        fdp.vstore(_sc, 'st1_out_ptr0', _j, 8, _r_out_ptr0, x4, tmp0, 'bf16', mask=xmask)


def flydsl_fused_clone_permute_727cdf72_launch_fn(in_ptr0: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_clone_permute_727cdf72_kernel(in_ptr0, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused_clone_permute_727cdf72_launch = None


def flydsl_fused_clone_permute_727cdf72_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_clone_permute_727cdf72_kernel, flydsl_fused_clone_permute_727cdf72_launch
    if flydsl_fused_clone_permute_727cdf72_launch is None:
        flydsl_fused_clone_permute_727cdf72_kernel = flyc.kernel(flydsl_fused_clone_permute_727cdf72_kernel)
        flydsl_fused_clone_permute_727cdf72_launch = flyc.jit(flydsl_fused_clone_permute_727cdf72_launch_fn)
        flydsl_fused_clone_permute_727cdf72_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused_clone_permute_727cdf72_launch


flydsl_fused_clone_permute_727cdf72_compiled = None
flydsl_fused_clone_permute_727cdf72_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_clone_permute_727cdf72.hsaco"


def flydsl_fused_clone_permute_727cdf72_main(in_ptr0, out_ptr0, stream=None):
    global flydsl_fused_clone_permute_727cdf72_compiled
    if flydsl_fused_clone_permute_727cdf72_compiled is None:
        flydsl_fused_clone_permute_727cdf72_compiled = fdp.load_binary(
            flydsl_fused_clone_permute_727cdf72_binary, "flydsl_fused_clone_permute_727cdf72_kernel_0", 64, 'OO'
        )
        if flydsl_fused_clone_permute_727cdf72_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_clone_permute_727cdf72_flydsl(), in_ptr0.data_ptr(), out_ptr0.data_ptr(), 28, 0 if stream is None else stream)
            flydsl_fused_clone_permute_727cdf72_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_clone_permute_727cdf72_compiled(28, 1, 1, 0 if stream is None else stream, in_ptr0, out_ptr0, )


def flydsl_fused_clone_permute_727cdf72_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_clone_permute_727cdf72_binary):
        return
    launch = flydsl_fused_clone_permute_727cdf72_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_clone_permute_727cdf72_binary, "flydsl_fused_clone_permute_727cdf72_kernel_0")
''', '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/i5/ci5ek3l4zncmhqu4qfg3aix5wephruaizz5no4yfejtcghqkgspb.flydsl_fused_clone_permute_727cdf72.hsaco', precompile_metadata={})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, = args
        args.clear()
        assert_size_stride(arg0_1, (2, 3, 37, 64), (7104, 2368, 64, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf0 = empty_strided_cuda((2, 37, 3, 64), (7104, 192, 64, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [permute, contiguous], Original ATen: [aten.permute, aten.clone]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused_clone_permute_727cdf72.run(arg0_1, buf0, stream=raw_stream0)
            del arg0_1
        return (buf0, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((2, 3, 37, 64), (7104, 2368, 64, 1), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
