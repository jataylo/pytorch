# AOT ID: ['314_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp_rt
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


if not os.path.exists('/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/aj/caj3dpcbwa5gwej3vj7r4fzmbi3hvjsfgz2crtdb7lkk3mqkzmck.flydsl_fused_add_2902aeed.hsaco'):
    async_compile.wait_process_pool_ready()
# kernel path: /dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/66/c66ogiiq5sxfusmxijll5iz6ebjqx3ljxd3d6ws2uqzn4234fzue.py
# Topologically Sorted Source Nodes: [add], Original ATen: [aten.add]
# Source node to ATen node mapping:
#   add => add
# Graph fragment:
#   %arg0_1 : Tensor "f32[4099][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "f32[4099][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %add : Tensor "f32[4099][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg0_1, %arg1_1), kwargs = {})
#   return %add
flydsl_fused_add_2902aeed = fdp_rt.compiled(async_compile, 'flydsl_fused_add_2902aeed', r'''
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused_add_2902aeed_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64):
    # runtime a1a935225a4ec695
    # pointwise xnumel=4099 ept=1 unroll=1
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 16396)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 16396)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 16396)
    _t = fdp.tid()
    _b = fdp.bid()
    _vc = {}
    _sc = {}
    for _j in range_constexpr(1):
        xindex = _b * 64 + (_j // 1) * 64 + _t * 1 + _j % 1
        xmask = xindex < 4099
        x0 = xindex
        tmp0 = fdp.load(_r_in_ptr0, x0, 'f32', mask=xmask)
        tmp1 = fdp.load(_r_in_ptr1, x0, 'f32', mask=xmask)
        tmp2 = fdp.add(tmp0, tmp1)
        fdp.store(_r_out_ptr0, x0, tmp2, 'f32', mask=xmask)


def flydsl_fused_add_2902aeed_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, out_ptr0: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused_add_2902aeed_kernel(in_ptr0, in_ptr1, out_ptr0).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused_add_2902aeed_launch = None


def flydsl_fused_add_2902aeed_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused_add_2902aeed_kernel, flydsl_fused_add_2902aeed_launch
    if flydsl_fused_add_2902aeed_launch is None:
        flydsl_fused_add_2902aeed_kernel = flyc.kernel(flydsl_fused_add_2902aeed_kernel)
        flydsl_fused_add_2902aeed_launch = flyc.jit(flydsl_fused_add_2902aeed_launch_fn)
        flydsl_fused_add_2902aeed_launch.compile_hints = {'fastmath': 'contract'}
    return flydsl_fused_add_2902aeed_launch


flydsl_fused_add_2902aeed_compiled = None
flydsl_fused_add_2902aeed_binary = __file__.rsplit(".", 1)[0] + ".flydsl_fused_add_2902aeed.hsaco"


def flydsl_fused_add_2902aeed_main(in_ptr0, in_ptr1, out_ptr0, stream=None):
    global flydsl_fused_add_2902aeed_compiled
    if flydsl_fused_add_2902aeed_compiled is None:
        flydsl_fused_add_2902aeed_compiled = fdp.load_binary(
            flydsl_fused_add_2902aeed_binary, "flydsl_fused_add_2902aeed_kernel_0", 64, 'OOO'
        )
        if flydsl_fused_add_2902aeed_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused_add_2902aeed_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), out_ptr0.data_ptr(), 65, 0 if stream is None else stream)
            flydsl_fused_add_2902aeed_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused_add_2902aeed_compiled(65, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, out_ptr0, )


def flydsl_fused_add_2902aeed_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused_add_2902aeed_binary):
        return
    launch = flydsl_fused_add_2902aeed_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused_add_2902aeed_binary, "flydsl_fused_add_2902aeed_kernel_0")
''', '/dockerx/pytorch-flex/agent_space/simd_bench/codegen_bench_v13/cache/inductor/aj/caj3dpcbwa5gwej3vj7r4fzmbi3hvjsfgz2crtdb7lkk3mqkzmck.flydsl_fused_add_2902aeed.hsaco', precompile_metadata={})


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1), ((4099, ), (4099, )), ((1, ), (1, )), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf0 = empty_strided_cuda((4099, ), (1, ), torch.float32)
            # Topologically Sorted Source Nodes: [add], Original ATen: [aten.add]
            raw_stream0 = get_raw_stream(0)
            flydsl_fused_add_2902aeed.run(arg0_1, arg1_1, buf0, stream=raw_stream0)
            del arg0_1
            del arg1_1
        return (buf0, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((4099, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg1_1 = rand_strided((4099, ), (1, ), device='cuda:0', dtype=torch.float32)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
