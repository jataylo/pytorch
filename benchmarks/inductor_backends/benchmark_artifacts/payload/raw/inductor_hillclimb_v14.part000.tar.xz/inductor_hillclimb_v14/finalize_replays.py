from pathlib import Path
p=Path(__file__).with_name('replay_v14.py');s=p.read_text();s=s.replace("ROOT/'matched'", "ROOT/'matched_final'")
old="""            errors={e['label']:case.validate(e['fn'])[1] for e in entries};measured=measure(case,entries,15,5);base=measured[0]['median_us'];chosen=[dict(l.config.kwargs,num_warps=l.config.num_warps) for l in kernel.launchers]"""
new="""            all_samples={e['label']:[] for e in entries};all_errors={e['label']:[] for e in entries}
            for seed in [1701,2027]:
                case.refresh(seed);case.reset();case.native();torch.cuda.synchronize();case.expected=[case.args[index].clone() for index in case.outputs]
                for e in entries:all_errors[e['label']].append(case.validate(e['fn'])[1])
                for e,m in zip(entries,measure(case,entries,15,5)):all_samples[e['label']]+=m['samples_us']
            errors={label:max(values) for label,values in all_errors.items()}
            measured=[dict(median_us=__import__('statistics').median(all_samples[e['label']]),samples_us=all_samples[e['label']]) for e in entries];base=measured[0]['median_us'];chosen=[dict(l.config.kwargs,num_warps=l.config.num_warps) for l in kernel.launchers]"""
if old not in s:raise RuntimeError('replay source changed')
s=s.replace(old,new).replace("(ROOT/'MATCHED_RESULTS.json')", "(ROOT/'MATCHED_FINAL_RESULTS.json')")
p.with_name('replay_final.py').write_text(s)
p=Path(__file__).with_name('initial_replay.py');s=p.read_text().replace("ROOT/'initial'", "ROOT/'initial_final'").replace("ROOT/'INITIAL_RESULTS.json'", "ROOT/'INITIAL_FINAL_RESULTS.json'");p.with_name('initial_final_replay.py').write_text(s)
