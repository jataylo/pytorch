from pathlib import Path
import json
b=Path(__file__).resolve().parent.parent/'pytorch_codegen_v13'
p=b/'benchmarks/inductor_backends/amd_kernel_hillclimb.py';s=p.read_text()
s=s.replace('    if family == "gelu_backward":','''    if family == "gelu_backward_inplace":
        def gelu_backward_inplace(x,g):
            g.copy_(torch.ops.aten.gelu_backward(g,x,approximate='none'))
            return g
        return gelu_backward_inplace,(x,torch.randn_like(x))
    if family == "gelu_backward":''')
s=s.replace('def measure(entries, inputs, rounds, repeats, cache, invocation):','def measure(entries, inputs, rounds, repeats, cache, invocation, originals):')
s=s.replace('                flush.zero_()\n                if cache == "warm":','                flush.zero_()\n                for index,original in originals.items():\n                    inputs[index].copy_(original)\n                if cache == "warm":')
s=s.replace('    expected = fn(*inputs)\n    entries, failures = [], []', '''    originals={index:inputs[index].clone() for index in case.get('mutated_input_indices',[])}
    def restore():
        for index,original in originals.items():
            inputs[index].copy_(original)
    def reference():
        restore()
        value=fn(*inputs)
        return tuple(item.clone() for item in value) if isinstance(value,(tuple,list)) else value.clone()
    expected=reference()
    entries, failures = [], []''')
s=s.replace('            with patch(variant, folder / f"{variant}.jsonl"):\n                records=[]','            with patch(variant, folder / f"{variant}.jsonl"):\n                restore()\n                records=[]')
s=s.replace('                validate(frozen(*inputs),expected,case["family"]', '                restore()\n                validate(frozen(*inputs),expected,case["family"]')
s=s.replace('                for _ in range(3):\n                    actual = frozen(*inputs)', '                for _ in range(3):\n                    restore()\n                    actual = frozen(*inputs)')
s=s.replace('                with torch.cuda.graph(graph):','                restore()\n                with torch.cuda.graph(graph):')
s=s.replace('        expected = fn(*inputs)\n        for entry in entries:', '''        for index in originals:
            originals[index].copy_(fresh[index])
        expected=reference()
        for entry in entries:
            restore()''')
s=s.replace('measure(entries, inputs, rounds, repeats, cache,invocation)', 'measure(entries, inputs, rounds, repeats, cache,invocation,originals)')
p.write_text(s)
p=b/'benchmarks/inductor_backends/amd_kernel_reference_cases.json';cases=json.loads(p.read_text());cases[16].update(family='gelu_backward_inplace',mutated_input_indices=[1],case='reference_16_gelu_backward_inplace_bfloat16_0');p.write_text(json.dumps(cases,indent=2)+'\n')
p=b/'torch/_inductor/runtime/amd_autotune.py';s=p.read_text().replace("if name in warm_names and isinstance(value,torch.Tensor)","if (name in warm_names or name in tuner.mutated_arg_names) and isinstance(value,torch.Tensor)");p.write_text(s)
