from pathlib import Path
b=Path(__file__).resolve().parent.parent/'pytorch_codegen_v13'
p=b/'benchmarks/inductor_backends/amd_kernel_hillclimb.py';s=p.read_text().replace('import hashlib\n','import hashlib\nimport inspect\n')
s=s.replace('                compiled = torch.compile(fn, fullgraph=True)', '''                records=[]
                parameter_names=list(inspect.signature(fn).parameters)
                def backend(gm,example_inputs):
                    from torch._inductor.compile_fx import compile_fx
                    order=[]
                    for node in gm.graph.nodes:
                        if node.op!='placeholder':
                            continue
                        grapharg=node.meta.get('grapharg')
                        local=getattr(getattr(grapharg,'source',None),'local_name',None)
                        if local is None:
                            name=str(node.target)
                            local=name[2:-1] if name.startswith('L_') and name.endswith('_') else name
                        if local not in parameter_names:
                            raise RuntimeError(f'Cannot freeze compiled input {node.target}: {local}')
                        order.append(parameter_names.index(local))
                    lowered=compile_fx(gm,example_inputs)
                    records.append((lowered,tuple(order)))
                    return lowered
                compiled = torch.compile(fn, backend=backend,fullgraph=True,dynamic=False)''')
s=s.replace('                for _ in range(3):\n                    actual = compiled(*inputs)', '''                if len(records)!=1:
                    raise RuntimeError(f'Expected one compiled graph, got {len(records)}')
                lowered,order=records[0]
                returns_tuple=isinstance(expected,tuple)
                def frozen(*args,_lowered=lowered,_order=order,_returns_tuple=returns_tuple):
                    value=_lowered(*[args[index] for index in _order])
                    return value if _returns_tuple else value[0] if isinstance(value,(tuple,list)) else value
                validate(frozen(*inputs),expected,case["family"] in ("transpose","broadcast","cast_add"))
                for _ in range(3):
                    actual = frozen(*inputs)''')
s=s.replace('                    captured = compiled(*inputs)','                    captured = frozen(*inputs)').replace('fn=compiled, graph=graph','fn=frozen, graph=graph')
s=s.replace('fieldnames=list(rows[0])','fieldnames=list(dict.fromkeys(key for row in rows for key in row))')
s=s.replace('    if family == "softmax":','''    if family == "softmax_saved_stats":
        from torch._inductor import inductor_prims
        keep=torch.rand((shape[0],1,shape[2],shape[3]),device='cuda')>.1
        keep[:,:,0]=False
        def saved_softmax(x,keep):
            value=x+torch.where(keep,0.,-float('inf'))
            maximum,total=inductor_prims.prepare_softmax_online(value,-1)
            invalid=(value==-float('inf')).all(-1,keepdim=True)
            probability=torch.where(invalid,0.,torch.exp(value-maximum)/total)
            return invalid,maximum,total,probability
        return saved_softmax,(x,keep)
    if family == "softmax":''')
p.write_text(s)
p=b/'benchmarks/inductor_backends/amd_kernel_reference_cases.json';import json;rows=json.loads(p.read_text());rows[15].update(family='softmax_saved_stats',shape=[8,16,128,128],case='reference_15_softmax_saved_stats_float32_0');p.write_text(json.dumps(rows,indent=2)+'\n')
p=b/'torch/_inductor/runtime/amd_autotune.py';s=p.read_text().replace('from typing import Any\n','');s=s.replace("    output_items=[", "    scratch_mutations={copy.untyped_storage()._cdata for original,copy in storages.values()}\n    output_items=[").replace("            if name not in tuner.mutated_arg_names:","            if actual.untyped_storage()._cdata not in scratch_mutations:").replace('                    actual.copy_(~expected)','                    actual.copy_(expected)\n                    raw=torch.empty(0,device=actual.device,dtype=torch.uint8).set_(actual.untyped_storage())\n                    raw.bitwise_not_()')
p.write_text(s)
