from pathlib import Path
r=Path(__file__).resolve().parent.parent
for path in [r/'codegen_bench_v13/run_overlay.py',r/'codegen_startup_v13/sitecustomize.py']:
    s=path.read_text().replace("'torch._inductor.runtime.hints'","'torch._inductor.runtime.hints','torch._inductor.runtime.amd_autotune'");path.write_text(s)
