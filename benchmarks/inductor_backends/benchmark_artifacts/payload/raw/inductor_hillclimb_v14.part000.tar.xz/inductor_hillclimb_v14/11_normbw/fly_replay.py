
import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0__Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64):
    # runtime ecbdad25f30f02a5
    # column reduction xnumel=4096 rnumel=256 ept=1 unroll=1 tpr=16 stride=64 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 2097152)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 1048576)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 4194304)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 16384)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 16384)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0__Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t // 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 64 + _xr * 64 + _t % 64
        x0 = fdp.imod(xindex, 128)
        x1 = fdp.idiv(xindex, 128)
        _acc1 = fdp.default('sum', 'f32')
        x3 = xindex
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 256, 16):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 16 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16'))
                tmp2 = fdp.memo(_lc, (('in_ptr1', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1'))
                tmp7 = fdp.memo(_lc, (('in_ptr2', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32'))
        for r0_offset in range_constexpr(0, 256, 16):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 16 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16'))
                tmp2 = fdp.memo(_lc, (('in_ptr1', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1'))
                tmp7 = fdp.memo(_lc, (('in_ptr2', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32'))
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.to(tmp2, 'f32')
                tmp4 = fdp.const(1.1111111111111112, 'f32')
                tmp5 = fdp.mul(tmp3, tmp4)
                tmp6 = fdp.mul(tmp1, tmp5)
                tmp8 = fdp.mul(tmp6, tmp7)
                _acc1_items.append((tmp8, None))
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp9 = fdp.group_reduce('sum', _acc1, 16, _smem, 1024, 64)
        fdp.store(_r_out_ptr0, x3, tmp9, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        tmp10 = fdp.group_reduce('sum', _acc2, 16, _smem, 1024, 64)
        fdp.store(_r_out_ptr1, x3, tmp10, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_kernel(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_binary = '/dev/shm/pytorch-simd-training-cache/34d82ef08ad0e41daa1f/inductor/kh/ckhonfmamp2qurr3bvbc27qjg222zsxutyxsaqhyor3ggfghwhma.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_main(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_kernel_0", 1024, 'OOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), 64, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_compiled(64, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64):
    # runtime ecbdad25f30f02a5
    # column reduction xnumel=4096 rnumel=256 ept=1 unroll=4 tpr=1 stride=64 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 2097152)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 1048576)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 4194304)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 16384)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 16384)
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t // 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 64 + _xr * 64 + _t % 64
        x0 = fdp.imod(xindex, 128)
        x1 = fdp.idiv(xindex, 128)
        _acc1 = fdp.default('sum', 'f32')
        x3 = xindex
        _acc2 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(256), fx.Int32(4)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 1) * 1 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16')
                tmp2 = fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1')
                tmp7 = fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32')
                tmp10 = fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.to(tmp2, 'f32')
                tmp4 = fdp.const(1.1111111111111112, 'f32')
                tmp5 = fdp.mul(tmp3, tmp4)
                tmp6 = fdp.mul(tmp1, tmp5)
                tmp8 = fdp.mul(tmp6, tmp7)
                _acc1_items.append((tmp8, None))
                tmp11 = fdp.to(tmp10, 'f32')
                tmp12 = fdp.mul(tmp11, tmp5)
                _acc2_items.append((tmp12, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp9 = fdp.group_reduce('sum', _acc1, 1, None, 64, 64)
        fdp.store(_r_out_ptr0, x3, tmp9, 'f32')
        tmp13 = fdp.group_reduce('sum', _acc2, 1, None, 64, 64)
        fdp.store(_r_out_ptr1, x3, tmp13, 'f32')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_kernel(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1).launch(grid=(_grid, 1, 1), block=(64, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_binary = '/dev/shm/pytorch-simd-training-cache/34d82ef08ad0e41daa1f/inductor/kh/ckhonfmamp2qurr3bvbc27qjg222zsxutyxsaqhyor3ggfghwhma.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_main(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_kernel_0", 64, 'OOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), 64, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_compiled(64, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2__Smem:
    words: fx.Array[fx.Int32, 256, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64):
    # runtime ecbdad25f30f02a5
    # column reduction xnumel=4096 rnumel=256 ept=1 unroll=4 tpr=2 stride=64 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 2097152)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 1048576)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 4194304)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 16384)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 16384)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2__Smem).peek().words.view(fx.make_layout(256, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t // 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 64 + _xr * 64 + _t % 64
        x0 = fdp.imod(xindex, 128)
        x1 = fdp.idiv(xindex, 128)
        _acc1 = fdp.default('sum', 'f32')
        x3 = xindex
        _acc2 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(256), fx.Int32(8)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 1) * 2 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16')
                tmp2 = fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1')
                tmp7 = fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32')
                tmp10 = fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.to(tmp2, 'f32')
                tmp4 = fdp.const(1.1111111111111112, 'f32')
                tmp5 = fdp.mul(tmp3, tmp4)
                tmp6 = fdp.mul(tmp1, tmp5)
                tmp8 = fdp.mul(tmp6, tmp7)
                _acc1_items.append((tmp8, None))
                tmp11 = fdp.to(tmp10, 'f32')
                tmp12 = fdp.mul(tmp11, tmp5)
                _acc2_items.append((tmp12, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp9 = fdp.group_reduce('sum', _acc1, 2, _smem, 128, 64)
        fdp.store(_r_out_ptr0, x3, tmp9, 'f32', mask=_lane0)
        tmp13 = fdp.group_reduce('sum', _acc2, 2, _smem, 128, 64)
        fdp.store(_r_out_ptr1, x3, tmp13, 'f32', mask=_lane0)


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_kernel(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1).launch(grid=(_grid, 1, 1), block=(128, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_binary = '/dev/shm/pytorch-simd-training-cache/34d82ef08ad0e41daa1f/inductor/kh/ckhonfmamp2qurr3bvbc27qjg222zsxutyxsaqhyor3ggfghwhma.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_main(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_kernel_0", 128, 'OOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), 64, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_compiled(64, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64):
    # runtime ecbdad25f30f02a5
    # column reduction xnumel=4096 rnumel=256 ept=1 unroll=4 tpr=4 stride=64 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 2097152)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 1048576)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 4194304)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 16384)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 16384)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t // 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 64 + _xr * 64 + _t % 64
        x0 = fdp.imod(xindex, 128)
        x1 = fdp.idiv(xindex, 128)
        _acc1 = fdp.default('sum', 'f32')
        x3 = xindex
        _acc2 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(256), fx.Int32(16)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 1) * 4 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16')
                tmp2 = fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1')
                tmp7 = fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32')
                tmp10 = fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.to(tmp2, 'f32')
                tmp4 = fdp.const(1.1111111111111112, 'f32')
                tmp5 = fdp.mul(tmp3, tmp4)
                tmp6 = fdp.mul(tmp1, tmp5)
                tmp8 = fdp.mul(tmp6, tmp7)
                _acc1_items.append((tmp8, None))
                tmp11 = fdp.to(tmp10, 'f32')
                tmp12 = fdp.mul(tmp11, tmp5)
                _acc2_items.append((tmp12, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp9 = fdp.group_reduce('sum', _acc1, 4, _smem, 256, 64)
        fdp.store(_r_out_ptr0, x3, tmp9, 'f32', mask=_lane0)
        tmp13 = fdp.group_reduce('sum', _acc2, 4, _smem, 256, 64)
        fdp.store(_r_out_ptr1, x3, tmp13, 'f32', mask=_lane0)


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_kernel(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_binary = '/dev/shm/pytorch-simd-training-cache/34d82ef08ad0e41daa1f/inductor/kh/ckhonfmamp2qurr3bvbc27qjg222zsxutyxsaqhyor3ggfghwhma.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_main(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_kernel_0", 256, 'OOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), 64, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_compiled(64, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4__Smem:
    words: fx.Array[fx.Int32, 1024, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64):
    # runtime ecbdad25f30f02a5
    # column reduction xnumel=4096 rnumel=256 ept=1 unroll=4 tpr=8 stride=64 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 2097152)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 1048576)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 4194304)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 16384)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 16384)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4__Smem).peek().words.view(fx.make_layout(1024, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t // 64
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 64 + _xr * 64 + _t % 64
        x0 = fdp.imod(xindex, 128)
        x1 = fdp.idiv(xindex, 128)
        _acc1 = fdp.default('sum', 'f32')
        x3 = xindex
        _acc2 = fdp.default('sum', 'f32')
        for _ro in range(fx.Int32(0), fx.Int32(256), fx.Int32(32)):
            r0_offset = fdp.idx(_ro)
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(4):
                r0_index = r0_offset + (_j // 1) * 8 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16')
                tmp2 = fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1')
                tmp7 = fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32')
                tmp10 = fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16')
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.to(tmp2, 'f32')
                tmp4 = fdp.const(1.1111111111111112, 'f32')
                tmp5 = fdp.mul(tmp3, tmp4)
                tmp6 = fdp.mul(tmp1, tmp5)
                tmp8 = fdp.mul(tmp6, tmp7)
                _acc1_items.append((tmp8, None))
                tmp11 = fdp.to(tmp10, 'f32')
                tmp12 = fdp.mul(tmp11, tmp5)
                _acc2_items.append((tmp12, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp9 = fdp.group_reduce('sum', _acc1, 8, _smem, 512, 64)
        fdp.store(_r_out_ptr0, x3, tmp9, 'f32', mask=_lane0)
        tmp13 = fdp.group_reduce('sum', _acc2, 8, _smem, 512, 64)
        fdp.store(_r_out_ptr1, x3, tmp13, 'f32', mask=_lane0)


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_kernel(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1).launch(grid=(_grid, 1, 1), block=(512, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_kernel = flyc.kernel(known_block_size=[512, 1, 1])(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_binary = '/dev/shm/pytorch-simd-training-cache/34d82ef08ad0e41daa1f/inductor/kh/ckhonfmamp2qurr3bvbc27qjg222zsxutyxsaqhyor3ggfghwhma.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_main(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_kernel_0", 512, 'OOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), 64, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_compiled(64, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5__Smem:
    words: fx.Array[fx.Int32, 512, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64):
    # runtime ecbdad25f30f02a5
    # column reduction xnumel=4096 rnumel=256 ept=1 unroll=1 tpr=16 stride=16 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 2097152)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 1048576)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 4194304)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 16384)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 16384)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5__Smem).peek().words.view(fx.make_layout(512, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t // 16
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 16 + _xr * 16 + _t % 16
        x0 = fdp.imod(xindex, 128)
        x1 = fdp.idiv(xindex, 128)
        _acc1 = fdp.default('sum', 'f32')
        x3 = xindex
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 256, 16):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 16 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16'))
                tmp2 = fdp.memo(_lc, (('in_ptr1', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1'))
                tmp7 = fdp.memo(_lc, (('in_ptr2', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32'))
        for r0_offset in range_constexpr(0, 256, 16):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 16 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16'))
                tmp2 = fdp.memo(_lc, (('in_ptr1', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1'))
                tmp7 = fdp.memo(_lc, (('in_ptr2', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32'))
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.to(tmp2, 'f32')
                tmp4 = fdp.const(1.1111111111111112, 'f32')
                tmp5 = fdp.mul(tmp3, tmp4)
                tmp6 = fdp.mul(tmp1, tmp5)
                tmp8 = fdp.mul(tmp6, tmp7)
                _acc1_items.append((tmp8, None))
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp9 = fdp.group_reduce('sum', _acc1, 16, _smem, 256, 16)
        fdp.store(_r_out_ptr0, x3, tmp9, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        tmp10 = fdp.group_reduce('sum', _acc2, 16, _smem, 256, 16)
        fdp.store(_r_out_ptr1, x3, tmp10, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_kernel(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1).launch(grid=(_grid, 1, 1), block=(256, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_kernel = flyc.kernel(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_binary = '/dev/shm/pytorch-simd-training-cache/34d82ef08ad0e41daa1f/inductor/kh/ckhonfmamp2qurr3bvbc27qjg222zsxutyxsaqhyor3ggfghwhma.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_main(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_kernel_0", 256, 'OOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), 256, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_compiled(256, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_kernel_0")

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import range_constexpr
from torch._inductor.codegen.flydsl import flydsl_simd_runtime as fdp

@fx.struct
class flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6__Smem:
    words: fx.Array[fx.Int32, 2048, 16]

def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_kernel(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64):
    # runtime ecbdad25f30f02a5
    # column reduction xnumel=4096 rnumel=256 ept=1 unroll=1 tpr=32 stride=32 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}
    fdp.kernel_begin()
    _r_in_ptr0 = fdp.rsrc(in_ptr0, 2097152)
    _r_in_ptr1 = fdp.rsrc(in_ptr1, 1048576)
    _r_in_ptr2 = fdp.rsrc(in_ptr2, 4194304)
    _r_out_ptr0 = fdp.rsrc(out_ptr0, 16384)
    _r_out_ptr1 = fdp.rsrc(out_ptr1, 16384)
    _smem = fx.SharedAllocator().allocate(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6__Smem).peek().words.view(fx.make_layout(2048, 1))
    _t = fdp.tid()
    _b = fdp.bid()
    _rl = _t // 32
    _lane0 = _rl == 0
    for _xr in range_constexpr(1):
        _vc = {}
        _sc = {}
        _lc = {}
        xindex = _b * 32 + _xr * 32 + _t % 32
        x0 = fdp.imod(xindex, 128)
        x1 = fdp.idiv(xindex, 128)
        _acc1 = fdp.default('sum', 'f32')
        x3 = xindex
        _acc2 = fdp.default('sum', 'f32')
        for r0_offset in range_constexpr(0, 256, 32):
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 32 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16'))
                tmp2 = fdp.memo(_lc, (('in_ptr1', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1'))
                tmp7 = fdp.memo(_lc, (('in_ptr2', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32'))
        for r0_offset in range_constexpr(0, 256, 32):
            _acc1_items = []
            _acc2_items = []
            for _j in range_constexpr(1):
                r0_index = r0_offset + (_j // 1) * 32 + _rl * 1 + _j % 1
                r0_2 = r0_index
                tmp0 = fdp.memo(_lc, (('in_ptr0', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr0, x0 + 128*r0_2 + 32768*x1, 'bf16'))
                tmp2 = fdp.memo(_lc, (('in_ptr1', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr1, x0 + 128*r0_2 + 32768*x1, 'b1'))
                tmp7 = fdp.memo(_lc, (('in_ptr2', 'x0 + 128*r0_2 + 32768*x1', r0_offset), _j), lambda: fdp.load(_r_in_ptr2, x0 + 128*r0_2 + 32768*x1, 'f32'))
                tmp1 = fdp.to(tmp0, 'f32')
                tmp3 = fdp.to(tmp2, 'f32')
                tmp4 = fdp.const(1.1111111111111112, 'f32')
                tmp5 = fdp.mul(tmp3, tmp4)
                tmp6 = fdp.mul(tmp1, tmp5)
                tmp8 = fdp.mul(tmp6, tmp7)
                _acc1_items.append((tmp8, None))
                _acc2_items.append((tmp6, None))
            _acc1 = fdp.sum_block(_acc1, _acc1_items)
            _acc2 = fdp.sum_block(_acc2, _acc2_items)
        tmp9 = fdp.group_reduce('sum', _acc1, 32, _smem, 1024, 32)
        fdp.store(_r_out_ptr0, x3, tmp9, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr0')
        tmp10 = fdp.group_reduce('sum', _acc2, 32, _smem, 1024, 32)
        fdp.store(_r_out_ptr1, x3, tmp10, 'f32', mask=_lane0)
        fdp.forget(_lc, 'out_ptr1')


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_launch_fn(in_ptr0: fx.Int64, in_ptr1: fx.Int64, in_ptr2: fx.Int64, out_ptr0: fx.Int64, out_ptr1: fx.Int64, _grid: fx.Int32, stream: fx.Stream = fx.Stream(None)):
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_kernel(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1).launch(grid=(_grid, 1, 1), block=(1024, 1, 1), stream=stream)


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_launch = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_flydsl():
    # Decorating rewrites the kernel's AST: only the compile worker, or a
    # process without the saved code object, needs it.
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_kernel, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_launch
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_launch is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_kernel = flyc.kernel(known_block_size=[1024, 1, 1])(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_kernel)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_launch = flyc.jit(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_launch_fn)
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_launch.compile_hints = {'fastmath': 'contract', 'llvm_options': {'vectorize-slp': False}}
    return flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_launch


flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_compiled = None
flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_binary = '/dev/shm/pytorch-simd-training-cache/34d82ef08ad0e41daa1f/inductor/kh/ckhonfmamp2qurr3bvbc27qjg222zsxutyxsaqhyor3ggfghwhma.py'.rsplit(".", 1)[0] + ".flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6.hsaco"


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_main(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_compiled
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_compiled is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_compiled = fdp.load_binary(
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_kernel_0", 1024, 'OOOOO'
        )
        if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_compiled is None:
            # flyc.compile launches once while compiling, so this call is done.
            jit = flyc.compile(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_flydsl(), in_ptr0.data_ptr(), in_ptr1.data_ptr(), in_ptr2.data_ptr(), out_ptr0.data_ptr(), out_ptr1.data_ptr(), 128, 0 if stream is None else stream)
            flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_compiled = lambda _gx, _gy, _gz, _s, *a: jit(*(x if isinstance(x, int) else x.data_ptr() for x in a), _gx, _s)
            return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_compiled(128, 1, 1, 0 if stream is None else stream, in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, )


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_precompile(**_):
    # Compiles into FlyDSL's disk cache, launching nothing; the code object is
    # kept beside this module for _main.
    if fdp.have_binary(flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_binary):
        return
    launch = flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_flydsl()
    fdp.compile_only(launch, 0, 0, 0, 0, 0, 0, 0, arch='gfx950')
    fdp.save_binary(launch, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_binary, "flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_kernel_0")

flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_best = None


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_main(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=None):
    global flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_best
    if flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_best is None:
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_best = fdp.pick_fastest(
            [flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_main, flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_main], (in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1,), (3, 4), stream,
            warm=(0,), metadata={'kernel_name': 'flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005', 'stage': 'column', 'candidate_descriptions': ["column reduction xnumel=4096 rnumel=256 ept=1 unroll=1 tpr=16 stride=64 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "column reduction xnumel=4096 rnumel=256 ept=1 unroll=4 tpr=1 stride=64 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "column reduction xnumel=4096 rnumel=256 ept=1 unroll=4 tpr=2 stride=64 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "column reduction xnumel=4096 rnumel=256 ept=1 unroll=4 tpr=4 stride=64 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "column reduction xnumel=4096 rnumel=256 ept=1 unroll=4 tpr=8 stride=64 xunroll=1 persistent=False outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "column reduction xnumel=4096 rnumel=256 ept=1 unroll=1 tpr=16 stride=16 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}", "column reduction xnumel=4096 rnumel=256 ept=1 unroll=1 tpr=32 stride=32 xunroll=1 persistent=True outer=1 axes={'x': 'x', 'y': 'y', 'z': 'z'}"]},
        )
        return
    flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_best(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, stream=stream)


def flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_precompile(only=None, **kw):
    if only in (None, 0):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c0_precompile(**kw)
    if only in (None, 1):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c1_precompile(**kw)
    if only in (None, 2):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c2_precompile(**kw)
    if only in (None, 3):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c3_precompile(**kw)
    if only in (None, 4):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c4_precompile(**kw)
    if only in (None, 5):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c5_precompile(**kw)
    if only in (None, 6):
        flydsl_fused__to_copy_native_dropout_backward_native_layer_norm_backward_view_683a2005_c6_precompile(**kw)
