import copy,torch
from torch._inductor import config
from torch.testing._internal.common_utils import TestCase

torch.manual_seed(23)
eager=torch.nn.Sequential(torch.nn.Linear(128,256),torch.nn.LayerNorm(256),torch.nn.GELU(),torch.nn.Linear(256,64)).cuda().bfloat16()
models=[copy.deepcopy(eager),copy.deepcopy(eager)]
x=torch.randn(512,128,device='cuda',dtype=torch.bfloat16)
expected=eager(x);expected.float().square().mean().backward();outs=[]
for enabled,model in zip([False,True],models):
 with config.patch({'triton.amd_kernel_optimizations':enabled,'triton.amd_approximate_math':False,'max_autotune_pointwise':True,'max_autotune_gemm_backends':'ATEN','fx_graph_cache':False,'autotune_local_cache':False}):
  torch._dynamo.reset();actual=torch.compile(model,fullgraph=True)(x);actual.float().square().mean().backward();outs.append(actual)
 try:TestCase().assertEqual(actual,expected,atol=.003,rtol=.02)
 except AssertionError as e:print(enabled,str(e).splitlines()[-3:],flush=True)
 print('grad max error eager',enabled,[float((p.grad.float()-q.grad.float()).abs().max()) for p,q in zip(model.parameters(),eager.parameters())],flush=True)
print('optimized vs baseline max error',float((outs[0].float()-outs[1].float()).abs().max()),flush=True)
print('optimized vs baseline grad max error',[float((p.grad.float()-q.grad.float()).abs().max()) for p,q in zip(models[0].parameters(),models[1].parameters())],flush=True)
