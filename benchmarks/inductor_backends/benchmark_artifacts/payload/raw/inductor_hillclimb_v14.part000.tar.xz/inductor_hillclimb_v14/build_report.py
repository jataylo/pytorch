import csv,html,json,math,statistics
from pathlib import Path
from xml.etree import ElementTree
ROOT=Path(__file__).resolve().parent
rows=[]
for case in json.loads((ROOT/'MATCHED_FINAL_RESULTS.json').read_text()):
    entries={e['label']:e for e in case['entries']}
    original=entries['original']['median_us'];new=entries['integrated']['median_us'];prototype=entries['standalone']['median_us'];fly=entries['flydsl']['median_us']
    rows.append(dict(case=str(case['index']),op=case['category'],model=case['model'],math_policy='unchanged_functions',original_triton_us=original,standalone_winner_us=prototype,standalone_winner_approximate=False,integrated_triton_us=new,flydsl_us=fly,time_saved_percent=100*(1-new/original),speedup_factor=original/new,integrated_vs_standalone_time_saved_percent=100*(1-new/prototype),max_abs_error=entries['integrated']['error'],selected_config=json.dumps(case['integrated_config'],sort_keys=True)))
for case in json.loads((ROOT/'INITIAL_FINAL_RESULTS.json').read_text()):
    entries={e['label']:e for e in case['entries']}
    for label in ['integrated_exact',*(['integrated_approx'] if case['case'] in ['softmax','gelu'] else [])]:
        e=entries[label];original=entries['original']['median_us'];prototype=entries['standalone']['median_us'];new=e['median_us'];fly=entries['flydsl']['median_us']
        rows.append(dict(case='initial_'+case['case'],op=case['case'],model=case['model'],math_policy='approximate' if label.endswith('approx') else 'unchanged_functions',original_triton_us=original,standalone_winner_us=prototype,standalone_winner_approximate=case['case'] in ['softmax','gelu'],integrated_triton_us=new,flydsl_us=fly,time_saved_percent=100*(1-new/original),speedup_factor=original/new,integrated_vs_standalone_time_saved_percent=100*(1-new/prototype),max_abs_error=e['max_abs_error'],selected_config=json.dumps(case['configs'][label],sort_keys=True)))
with (ROOT/'matched_kernel_results.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
summary=[]
for op in sorted(set(r['op'] for r in rows)):
    for policy in ['unchanged_functions','approximate']:
        selected=[r for r in rows if r['op']==op and r['math_policy']==policy]
        if not selected:continue
        ratios=[r['integrated_triton_us']/r['original_triton_us'] for r in selected]
        summary.append(dict(op=op,math_policy=policy,cases=len(selected),geomean_time_saved_percent=100*(1-math.exp(statistics.mean(math.log(x) for x in ratios))),minimum_time_saved_percent=min(r['time_saved_percent'] for r in selected),maximum_time_saved_percent=max(r['time_saved_percent'] for r in selected)))
with (ROOT/'matched_kernel_summary.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
chosen=[]
for key in dict.fromkeys(r['case'] for r in rows):
    available=[r for r in rows if r['case']==key]
    chosen.append(next((r for r in available if r['math_policy']=='approximate'),available[0]))
width,left,right=1600,580,1330;height=170+len(chosen)*88
maximum=max(max(r[k] for k in ['original_triton_us','standalone_winner_us','integrated_triton_us','flydsl_us']) for r in chosen)*1.3
xpos=lambda v:left+(right-left)*(math.log10(max(v,.1))+1)/(math.log10(maximum)+1)
esc=lambda x:html.escape(str(x),quote=True)
text=lambda x,y,t,size=13,anchor='start':f'<text x="{x}" y="{y}" font-size="{size}" text-anchor="{anchor}">{esc(t)}</text>'
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"><rect width="100%" height="100%" fill="white"/><g font-family="Arial,sans-serif" fill="#263648">',text(24,32,'Original hill-climb cases through updated Inductor codegen',23),text(24,57,'Same recorded kernel shapes and modeled cache context; fixed original baseline; two fresh input seeds.',13),text(24,78,'* Softmax/GELU integrated-best and standalone-winner bars use opt-in approximate math. Exact results remain in the CSV.',12)]
variants=[('original_triton_us','Original Triton','#3976bd'),('standalone_winner_us','Standalone winner','#24a6b2'),('integrated_triton_us','Integrated best','#15966a'),('flydsl_us','FlyDSL','#e58b28')]
for i,(key,label,color) in enumerate(variants):
    x=28+i*280;parts +=[f'<rect x="{x}" y="94" width="14" height="12" fill="{color}"/>',text(x+22,105,label)]
for exponent in range(-1,math.ceil(math.log10(maximum))+1):
    for factor in [1,3]:
        value=10**exponent*factor
        if value>maximum:continue
        x=xpos(value);parts +=[f'<path d="M{x:.2f},125 V{height-45}" stroke="#e1e6ed"/>',text(round(x,2),height-27,f'{value:g}',11,'middle')]
for i,row in enumerate(chosen):
    y=135+i*88;star=' *' if row['math_policy']=='approximate' else ''
    parts.append(text(left-18,y+25,row['model']+' | '+row['op']+star,12,'end'))
    for j,(key,label,color) in enumerate(variants):
        value=row[key];x=xpos(value);bar_y=y+j*18
        parts +=[f'<rect x="{left}" y="{bar_y}" width="{x-left:.2f}" height="13" fill="{color}"/>',text(round(x+6,2),bar_y+11,f'{value:.3g} us',11)]
    parts.append(text(1380,y+43,f'{row["time_saved_percent"]:+.1f}% saved',12))
parts +=[text((left+right)//2,height-6,'GPU kernel time (microseconds, log scale; shorter is faster)',12,'middle'),'</g></svg>']
(ROOT/'matched_kernel_runtime.svg').write_text('\n'.join(parts));ElementTree.parse(ROOT/'matched_kernel_runtime.svg')
head='<table><tr><th>Op / fusion</th><th>Math</th><th>Cases</th><th>Geomean time saved</th><th>Per-case range</th></tr>'
for s in summary:head+=f'<tr><td>{esc(s["op"])}</td><td>{esc(s["math_policy"])}</td><td>{s["cases"]}</td><td>{s["geomean_time_saved_percent"]:+.1f}%</td><td>{s["minimum_time_saved_percent"]:+.1f}% to {s["maximum_time_saved_percent"]:+.1f}%</td></tr>'
head+='</table>'
body='''<h1>Inductor lowering hill climb: transferred improvements</h1>
<p>The compiler now emits the optimized layouts and optional math formulations, and tunes GPU execution after restoring aliases and cache state outside the timed interval. A bounded coordinate search considers workgroup size, elements per lane, unrolling, wave layouts, traversal order and occupancy settings. Both compiler options remain disabled by default.</p>
<h2>Original kernel cases</h2><p>This comparison uses the original recorded kernel bodies, shapes, strides and dtypes, with the updated compiler lowering passes and production tuner. It compares the frozen original selected configuration, the independently found standalone winner, FlyDSL, and the integrated selected implementation. Timings use the original modeled buffer-restoration/cache context, two new input seeds, 30 rotating rounds and five invocations per round. These are kernel-codegen replays, not whole-model runtime.</p>
<p><a href="matched_kernel_results.csv">Per-kernel results and configs CSV</a> | <a href="matched_kernel_summary.csv">Op summary CSV</a></p>'''+head+'''<img src="matched_kernel_runtime.svg" style="width:100%"/>
<h2>Actual torch.compile graphs</h2><p>The following benchmarks compile operation graphs through Inductor. The 18 reference cases retain recorded model geometry/layout, including in-place GELU gradient mutation and saved softmax statistics. The broad sweep covers 96 shape/dtype cases. Exact and approximate math are separate variants. Direct calls use frozen compile_fx callables so resetting Dynamo cannot change a previously compiled variant. CUDA graph replay is measured separately. Every case checks three input seeds. Mandatory input mutation restores occur before timing and can warm those buffers; cold/warm labels otherwise describe a 256 MiB flush followed by optional input warming.</p>
<ul><li><a href="reference_final/report.html">18 reference operation graphs: figures and CSVs</a></li><li><a href="broad_final/report.html">96-case broader sweep: figures and CSVs</a></li><li><a href="reference_final/direct/graphs/summary_warm.svg">Reference graph summary, warm inputs</a></li><li><a href="broad_final/direct/graphs/summary_cold.svg">Broad graph summary, cold inputs</a></li></ul>
<p>Geomeans in the broad sweep are not invocation-weighted model speedups. Cache-dependent regressions remain visible. The source fingerprints, raw samples, selected configs, generated code and all failures are preserved. All 114 cases completed all four variants without compilation or numerical failures. This does not establish training convergence or full-model speedups.</p>
<h2>Review and validation</h2><p><a href="VALIDATION.json">Validation and source hashes</a> | <a href="branch_changes.patch">Reviewable branch patch</a></p><p>Branch: flydsl/triton-hillclimb. Changes are uncommitted. Tests cover source guards, alias-preserving restoration, partial-write rejection, precise/approximate numerical checks, frozen-backend isolation and BF16/FP32 forward/backward training. The accepted measurements use one MI355X and one compiler thread. Asynchronous compilation and repository lint are not validated here; spin is absent from the existing environment.</p>'''
(ROOT/'report.html').write_text('<!doctype html><meta charset="utf-8"><title>Inductor lowering improvements</title><style>body{max-width:1600px;margin:32px auto;font:16px Arial;color:#263648;padding:0 20px}table{border-collapse:collapse}td,th{padding:9px 16px;border-bottom:1px solid #ddd;text-align:left}img{height:auto}</style>'+body)
print(json.dumps(summary,indent=2))
