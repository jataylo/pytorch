"""Freeze compiler sources and serially compare stock/previous/new native kernels.

No model checkpoints or full-model training are involved. Each variant runs in a
fresh subprocess, so previous and candidate compiler overlays cannot mix.
"""

import argparse
import csv
import fcntl
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import signal
import subprocess
import time


HERE = Path(__file__).resolve().parent
TASK_ROOT = HERE.parent
OVERLAY_MODULES = (
    'torch._inductor.config', 'torch._inductor.scheduler', 'torch._inductor.codegen.simd',
    'torch._inductor.codegen.triton', 'torch._inductor.codegen.amd_kernel_optimizations',
    'torch._inductor.runtime.triton_heuristics', 'torch._inductor.runtime.hints',
    'torch._inductor.runtime.amd_autotune',
)
BENCHMARK_FILES = (
    'amd_kernel_hillclimb.py', 'amd_extended_kernel_hillclimb.py',
    'amd_next_kernel_hillclimb.py', 'amd_benchmark_protocol.py',
)
VARIANTS = ('stock', 'previous_native', 'new_native')


def hashes(paths):
    return {str(path.resolve()): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}


def verify(fingerprint):
    actual = hashes(Path(name) for name in fingerprint['sources'])
    if actual != fingerprint['sources']:
        raise RuntimeError('Frozen source changed: use a fresh output directory')


def freeze_source(source, destination):
    files = [source / (name.replace('.', '/') + '.py') for name in OVERLAY_MODULES]
    flydsl = source / 'torch/_inductor/codegen/flydsl'
    if flydsl.exists():
        files.extend(sorted(flydsl.rglob('*.py')))
    before = hashes(files)
    for path in files:
        target = destination / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    if hashes(files) != before:
        raise RuntimeError('Source changed while freezing: retry after the compiler source freeze')
    return dict(original_root=str(source), original_sources=before)



def seed_cache(source, destination):
    suffixes = {'.json', '.so', '.hsaco', '.cubin', '.ptx', '.amdgcn', '.llir', '.ttgir', '.ttir', '.source', '.bc', '.c', '.cpp'}
    files = [path for path in source.rglob('*') if path.is_file() and path.suffix in suffixes
             and 'best_config' not in path.name and 'autotune' not in path.name and 'tuning' not in path.name]
    original = hashes(files)
    copied = []
    for path in files:
        target = destination / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        copied.append(target)
    rewrites = []

    def relocate(value):
        if isinstance(value, str) and value.startswith(str(source.resolve()) + '/'):
            replacement = str(destination.resolve()) + value[len(str(source.resolve())):]
            rewrites.append(dict(original=value, copied=replacement))
            return replacement
        if isinstance(value, dict):
            return {key: relocate(item) for key, item in value.items()}
        if isinstance(value, list):
            return [relocate(item) for item in value]
        return value

    for path in copied:
        if path.suffix == '.json':
            value = json.loads(path.read_text())
            relocated = relocate(value)
            if relocated != value:
                path.write_text(json.dumps(relocated, sort_keys=True) + '\n')
    if hashes(files) != original:
        raise RuntimeError('Original compiler cache changed while seeding')
    return dict(
        source=str(source.resolve()), destination=str(destination.resolve()),
        source_artifacts=original, copied_artifacts=hashes(copied), group_path_rewrites=rewrites,
        artifact_count=len(copied), indutor_cache_seeded=False, autotune_results_seeded=False,
        note='Content-addressed compiler artifacts only; fresh source lowering, tuning selections and timing samples',
    )

def export(output, cases):
    rows, failures, workers = [], [], []
    for case in cases:
        for variant in VARIANTS:
            path = output / 'runs' / case['case'] / variant / 'worker_result.json'
            if not path.exists():
                continue
            report = json.loads(path.read_text())
            workers.append(dict(case=case['case'], variant=variant, status=report['status'], wall_seconds=report.get('wall_seconds')))
            for row in report.get('rows', []):
                rows.append(dict(row, split=case.get('split', 'unspecified')))
            failures.extend(dict(case=case['case'], **failure) for failure in report.get('failures', []))
    if rows:
        with (output / 'raw.csv').open('w', newline='') as target:
            writer = csv.DictWriter(target, fieldnames=list(dict.fromkeys(key for row in rows for key in row)))
            writer.writeheader()
            writer.writerows(rows)
    (output / 'failures.json').write_text(json.dumps(failures, indent=2) + '\n')
    (output / 'worker_status.json').write_text(json.dumps(workers, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-root', type=Path, default=TASK_ROOT / 'pytorch_triton_only')
    parser.add_argument('--baseline-root', type=Path, default=TASK_ROOT / 'native_triton_v2/baseline_source')
    parser.add_argument('--compiler-cache-source', type=Path, default=TASK_ROOT / 'native_triton_v2/results_final_v3')
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rounds', type=int, default=5)
    parser.add_argument('--repeats', type=int, default=5)
    parser.add_argument('--gpu', default='3')
    parser.add_argument('--timeout', type=int, default=1200)
    parser.add_argument('--freeze-only', action='store_true')
    args = parser.parse_args()
    if min(args.rounds, args.repeats, args.timeout) < 1:
        parser.error('rounds, repeats and timeout must be positive')
    args.output = args.output.resolve()
    candidate = args.candidate_root.resolve()
    baseline = args.baseline_root.resolve()
    cases = json.loads(args.cases.read_text())
    names = [case['case'] for case in cases]
    if not cases or len(names) != len(set(names)):
        parser.error('cases must be nonempty and names must be unique')
    if any(Path(name).name != name or name in ('.', '..') for name in names):
        parser.error('case names must be single directory names')
    protocol = dict(
        cases=cases, variants=VARIANTS, rounds=args.rounds, repeats=args.repeats,
        gpu=args.gpu, candidate_root=str(candidate), baseline_root=str(baseline),
        variant_order_seed=2028, compile_threads=1, approximate_math=False, use_gluon=False,
        orchestrator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        run_environment_sha256=hashlib.sha256((TASK_ROOT / 'run_env.sh').read_bytes()).hexdigest(),
        compiler_cache_source=str(args.compiler_cache_source.resolve()),
        autotune_selections='fresh; compiler artifacts only are seeded',
    )
    protocol = json.loads(json.dumps(protocol))
    args.output.mkdir(parents=True, exist_ok=True)
    manifest_path = args.output / 'manifest.json'
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        if manifest['protocol'] != protocol:
            raise RuntimeError('Protocol changed: use a fresh output directory')
    else:
        if any(args.output.iterdir()):
            raise RuntimeError('Output is not empty and has no manifest')
        harness = args.output / 'harness'
        harness.mkdir()
        for name in BENCHMARK_FILES:
            shutil.copy2(candidate / 'benchmarks/inductor_backends' / name, harness / name)
        for name in ('worker.py', 'run.py'):
            shutil.copy2(HERE / name, harness / name)
        shutil.copy2(TASK_ROOT / 'run_source_overlay.py', harness / 'run_source_overlay.py')
        shutil.copy2(TASK_ROOT / 'run_env.sh', harness / 'run_env.sh')
        shutil.copytree(
            TASK_ROOT / 'codegen_startup_v13', args.output / 'sources/codegen_startup_v13',
            ignore=shutil.ignore_patterns('__pycache__', '*.pyc'),
        )
        sources = {}
        for tag, source in (('previous_native', baseline), ('candidate', candidate)):
            destination = args.output / 'sources' / tag
            provenance = freeze_source(source, destination)
            files = [*destination.rglob('*.py'), *[path for path in harness.iterdir() if path.is_file()]]
            files.extend((args.output / 'sources/codegen_startup_v13').glob('*.py'))
            fingerprint = dict(
                sources=hashes(files), overlay_modules=OVERLAY_MODULES,
                original_provenance=provenance,
            )
            fingerprint_path = args.output / f'{tag}_source_fingerprint.json'
            fingerprint_path.write_text(json.dumps(fingerprint, indent=2) + '\n')
            sources[tag] = dict(root=str(destination), fingerprint=str(fingerprint_path))
        (args.output / 'cases.json').write_text(json.dumps(cases, indent=2) + '\n')
        manifest = dict(protocol=protocol, sources=sources, created_ns=time.time_ns())
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    for source in manifest['sources'].values():
        verify(json.loads(Path(source['fingerprint']).read_text()))
    if args.freeze_only:
        print('FROZEN', manifest_path, flush=True)
        return
    pause_request = args.output / 'PAUSE_REQUEST.json'
    paused_marker = args.output / 'PAUSED.json'
    if not pause_request.exists() and paused_marker.exists():
        paused_marker.unlink()
    with open('/dev/shm/pytorch-simd-v2-entry.lock', 'a') as entry, open(
        '/dev/shm/pytorch-simd-v2-benchmark.lock', 'a'
    ) as timing:
        fcntl.flock(entry, fcntl.LOCK_EX)
        fcntl.flock(timing, fcntl.LOCK_EX)
        for index, case in enumerate(cases):
            variants = list(VARIANTS)
            random.Random(2028 + index).shuffle(variants)
            for variant in variants:
                if pause_request.exists():
                    export(args.output, cases)
                    paused_marker.write_text(json.dumps(dict(
                        paused_ns=time.time_ns(), reason='Paused by request at a completed-worker boundary',
                        request_file=str(pause_request), inflight_workers=0,
                    ), indent=2) + '\n')
                    print('PAUSED at worker boundary', args.output, flush=True)
                    return
                folder = args.output / 'runs' / case['case'] / variant
                folder.mkdir(parents=True, exist_ok=True)
                result_path = folder / 'worker_result.json'
                tag = 'previous_native' if variant == 'previous_native' else 'candidate'
                source = manifest['sources'][tag]
                fingerprint = json.loads(Path(source['fingerprint']).read_text())
                verify(fingerprint)
                if result_path.exists():
                    previous = json.loads(result_path.read_text())
                    if previous.get('source_fingerprint') != fingerprint:
                        raise RuntimeError('Per-run source fingerprint mismatch')
                    if previous['status'] not in ('process_failure', 'timeout'):
                        continue
                case_file = folder / 'case.json'
                case_file.write_text(json.dumps(case, indent=2) + '\n')
                cache_manifest = folder / 'compiler_cache_provenance.json'
                if not cache_manifest.exists():
                    origin = args.compiler_cache_source / 'runs' / case['case'] / variant / 'cache/triton'
                    provenance = seed_cache(origin, folder / 'cache/triton')
                    cache_manifest.write_text(json.dumps(provenance, indent=2) + '\n')
                env = os.environ.copy()
                env.update(
                    CUDA_VISIBLE_DEVICES=args.gpu, AMD_CODEGEN_SOURCE_ROOT=source['root'],
                    NATIVE_BENCHMARK_HARNESS_ROOT=str(args.output / 'harness'),
                    TORCHINDUCTOR_COMPILE_THREADS='1', OMP_NUM_THREADS='8', MKL_NUM_THREADS='8',
                    TRITON_DEFAULT_FP_FUSION='1', TORCHINDUCTOR_DISABLE_MULTI_KERNEL_CACHE='1', TORCHINDUCTOR_CACHE_DIR=str(folder / 'cache/inductor'),
                    TRITON_CACHE_DIR=str(folder / 'cache/triton'),
                )
                command = [
                    'bash', str(args.output / 'harness/run_env.sh'), str(args.output / 'harness/run_source_overlay.py'),
                    str(args.output / 'harness/worker.py'), '--variant', variant,
                    '--case-file', str(case_file), '--output', str(folder),
                    '--fingerprint', source['fingerprint'], '--rounds', str(args.rounds), '--repeats', str(args.repeats),
                ]
                print('START', case['case'], variant, flush=True)
                started = time.monotonic()
                timed_out = False
                with (folder / 'worker.log').open('w') as log:
                    process = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                    try:
                        process.wait(timeout=args.timeout)
                    except subprocess.TimeoutExpired:
                        timed_out = True
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=30)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                if timed_out or process.returncode or not result_path.exists():
                    status = 'timeout' if timed_out else 'process_failure'
                    error = f'{status}; returncode={process.returncode}; see {folder / "worker.log"}'
                    report = dict(
                        case=case, variant=variant, rows=[], status=status,
                        failures=[dict(variant=variant, error=error)], source_fingerprint=fingerprint,
                        wall_seconds=time.monotonic() - started,
                    )
                    result_path.write_text(json.dumps(report, indent=2) + '\n')
                verify(fingerprint)
                report = json.loads(result_path.read_text())
                report['subprocess_wall_seconds'] = time.monotonic() - started
                report['compiler_cache_provenance'] = str(cache_manifest)
                result_path.write_text(json.dumps(report, indent=2) + '\n')
                export(args.output, cases)
                print('DONE', case['case'], variant, report['status'], round(time.monotonic() - started, 2), flush=True)
    export(args.output, cases)


if __name__ == '__main__':
    main()
