"""Reproduce pinned V3 stock/native scan outputs against eager FP32 and FP64."""

import hashlib
import inspect
import json
import os
from pathlib import Path

import torch
import triton
from torch._inductor.runtime import triton_heuristics


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'native_triton_v2/results_final_v3'
CASE = 'heldout_cumsum_257x32768_float32'
OUTPUT = HERE / 'stock_scan_precision'
OUTPUT.mkdir(exist_ok=True)
reports = {
    variant: json.loads((SOURCE / 'runs' / CASE / variant / 'worker_result.json').read_text())
    for variant in ('stock', 'previous_native', 'new_native')
}
profiles = {
    variant: next(item for item in report['kernel_launcher_profiles'] if item['selected_for_execution'])
    for variant, report in reports.items()
}
pinned_by_name = {item['kernel_name']: item['config'] for item in profiles.values()}
original_cached = triton_heuristics.cached_autotune
signature = inspect.signature(original_cached)


def cached_autotune(*args, **kwargs):
    bound = signature.bind(*args, **kwargs)
    metadata = dict(bound.arguments.get('inductor_meta') or {})
    pinned = pinned_by_name.get(metadata.get('kernel_name'))
    if pinned is not None:
        bound.arguments['configs'] = [triton.Config(
            {name: value for name, value in pinned.items() if name not in ('num_warps', 'num_stages')},
            num_warps=pinned['num_warps'], num_stages=pinned['num_stages'],
        )]
        metadata.update(dynamic_scale_rblock=False, autotune_local_cache=False, autotune_remote_cache=False,
                        amd_kernel_autotune=False, amd_reduction_tuning=False)
        bound.arguments['inductor_meta'] = metadata
    return original_cached(*bound.args, **bound.kwargs)


triton_heuristics.cached_autotune = cached_autotune
kernels, modules = {}, {}
for variant, profile in profiles.items():
    path = Path(profile['module'])
    source = path.read_bytes()
    namespace = dict(__file__=str(path), __name__='isolated_scan_precision_' + variant)
    exec(compile(source, str(path), 'exec'), namespace)
    kernels[variant] = namespace[profile['kernel_name']]
    modules[variant] = dict(path=str(path), sha256=hashlib.sha256(source).hexdigest())


def errors(actual, reference):
    actual = actual.double()
    reference = reference.double()
    difference = (actual - reference).abs()
    violation = difference > (2e-4 + 1e-4 * reference.abs())
    indices = violation.nonzero()
    maximum = difference.argmax().item()
    row, column = divmod(maximum, difference.shape[1])
    examples = []
    for position in indices[:32].cpu().tolist():
        key = tuple(position)
        examples.append(dict(index=position, actual=actual[key].item(), reference=reference[key].item(), absolute_error=difference[key].item()))
    return dict(maximum_absolute_error=difference.max().item(), max_error_index=[row, column],
                violating_elements=indices.shape[0], total_elements=actual.numel(), violations=examples)


records = []
for seed in (2026, 1701, 2027):
    torch.manual_seed(seed)
    value = torch.randn((257, 32768), device='cuda', dtype=torch.float32)
    eager = torch.cumsum(value, -1)
    truth = torch.cumsum(value.double(), -1)
    results = {}
    for variant, kernel in kernels.items():
        actual = torch.empty_like(value)
        kernel.run(value, actual, 257, 32768, stream=torch.cuda.current_stream().cuda_stream)
        torch.cuda.synchronize()
        results[variant] = dict(vs_eager_fp32=errors(actual, eager), vs_fp64=errors(actual, truth))
    records.append(dict(seed=seed, input_sha256=hashlib.sha256(value.cpu().numpy().tobytes()).hexdigest(),
                        variants=results, eager_fp32_vs_fp64=errors(eager, truth)))
    print('seed', seed, {variant: item['vs_eager_fp32']['violating_elements'] for variant, item in results.items()}, flush=True)
actual_configs = {}
for variant, kernel in kernels.items():
    configs = [dict(item.config.kwargs, num_warps=item.config.num_warps, num_stages=item.config.num_stages) for item in kernel.launchers]
    if configs != [profiles[variant]['config']]:
        raise RuntimeError(f'Pinned configuration changed: {variant}: {configs}')
    actual_configs[variant] = configs
result = dict(
    case=CASE, modules=modules, original_failure=reports['stock']['failures'],
    source_fingerprints={variant: report['source_fingerprint'] for variant, report in reports.items()},
    probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    gpu=torch.cuda.get_device_name(), physical_gpu=os.environ.get('CUDA_VISIBLE_DEVICES'),
    pinned_configs={variant: profile['config'] for variant, profile in profiles.items()}, actual_configs=actual_configs,
    validation_atol=2e-4, validation_rtol=1e-4, tolerance_changed=False, records=records,
)
(OUTPUT / 'precision.json').write_text(json.dumps(result, indent=2) + '\n')
print('SAVED', OUTPUT / 'precision.json', flush=True)
