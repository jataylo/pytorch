
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'z': 131072, 'y': 16, 'x': 16}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'znumel': 'i32', 'ynumel': 'i32', 'xnumel': 'i32', 'ZBLOCK': 'constexpr', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid3D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_clone_permute_transpose_unfold_backward_view_0', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': True, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'z': 18874368, 'y': 47185920, 'x': 4718592}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_clone_permute_transpose_unfold_backward_view_0(in_ptr0, in_ptr1, out_ptr0, znumel, ynumel, xnumel, ZBLOCK : tl.constexpr, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    znumel = 81920
    ynumel = 12
    xnumel = 12
    zoffset = tl.program_id(2) * ZBLOCK
    zindex = zoffset + tl.arange(0, ZBLOCK)[:, None, None]
    zmask = tl.full([ZBLOCK], True, tl.int1)[:, None, None]
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[None, :, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, None, :]
    xmask = xindex < xnumel
    z4 = zindex
    x3 = xindex
    y2 = yindex
    z0 = (zindex % 640)
    z1 = zindex // 640
    tmp0 = ((z4 % 80)).to(tl.int32)
    tmp1 = tl.full([1, 1, 1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = ((z4 % 80)).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1, 1, 1], 16, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tl.load(in_ptr0 + (x3 + 12*y2 + 144*((z0 % 80)) + 2304*(z0 // 80) + 18432*z1), tmp7 & xmask & ymask, other=0.0).to(tl.float32)
    tmp9 = tmp0 >= tmp5
    tmp10 = tl.full([1, 1, 1], 80, tl.int64)
    tmp11 = tmp0 < tmp10
    tmp12 = tmp9.to(tl.int1)
    tmp13 = tl.load(in_ptr1 + (64*x3 + 768*y2 + 9216*(z0 // 80) + 73728*z1 + ((-16) + ((z0 % 80)))), tmp12 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp14 = tl.where(tmp6, tmp8, tmp13)
    tl.atomic_add(out_ptr0 + (y2 + 12*x3 + 144*z4), tmp14, xmask & ymask, sem='relaxed')
