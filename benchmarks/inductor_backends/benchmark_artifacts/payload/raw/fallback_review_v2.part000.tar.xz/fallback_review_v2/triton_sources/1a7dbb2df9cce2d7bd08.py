
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'y': 8192, 'x': 2, 'r0_': 256},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'r0_numel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_red_fused__to_copy_add_native_layer_norm_backward_select_backward_slice_transpose_view_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'y': 6422528, 'x': 25088, 'r0_': 13109248}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_red_fused__to_copy_add_native_layer_norm_backward_select_backward_slice_transpose_view_0(in_ptr0, in_ptr1, in_ptr2, out_ptr0, ynumel, xnumel, r0_numel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    ynumel = 6272
    xnumel = 2
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, None, :]
    rbase = r0_base
    y0 = (yindex % 49)
    x2 = xindex
    y1 = yindex // 49
    _tmp21 = tl.full([YBLOCK, XBLOCK, R0_BLOCK], 0, tl.float32)
    y4 = yindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp18 = tl.load(in_ptr2 + (r0_3 + 256*x2), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp0 = (1 + y0).to(tl.int64)
        tmp1 = (tmp0).to(tl.int64)
        tmp2 = tl.full([1, 1, 1], 1, tl.int64)
        tmp3 = tmp1 >= tmp2
        tmp4 = tmp3.to(tl.int1)
        tmp5 = tl.load(in_ptr0 + (512 + r0_3 + 256*x2 + 512*y0 + 25600*y1), r0_mask & tmp4 & xmask & ymask, eviction_policy='evict_last', other=0.0)
        tmp6 = tl.load(in_ptr1 + (y0 + 49*r0_3 + 12544*x2 + 25088*y1), r0_mask & tmp4 & xmask & ymask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp5 + tmp7
        tmp9 = tl.full(tmp8.shape, 0.0, tmp8.dtype)
        tmp10 = tl.where(tmp4, tmp8, tmp9)
        tmp11 = tl.full([1, 1, 1], 0.0, tl.float32)
        tmp12 = tl.where(tmp3, tmp10, tmp11)
        tmp13 = tmp1 < tmp2
        tmp14 = tmp13.to(tl.int1)
        tmp15 = tl.load(in_ptr0 + (r0_3 + 256*x2 + 25600*y1), r0_mask & tmp14 & xmask & ymask, eviction_policy='evict_last', other=0.0)
        tmp16 = tl.where(tmp13, tmp15, tmp11)
        tmp17 = tmp12 + tmp16
        tmp19 = tmp17 * tmp18
        tmp20 = tl.broadcast_to(tmp19, [YBLOCK, XBLOCK, R0_BLOCK])
        tmp22 = _tmp21 + tmp20
        _tmp21 = tl.where(r0_mask & xmask & ymask, tmp22, _tmp21)
    tmp21 = tl.sum(_tmp21, 2)[:, :, None]
    tl.store(out_ptr0 + (x2 + 2*y4), tmp21, xmask & ymask)
