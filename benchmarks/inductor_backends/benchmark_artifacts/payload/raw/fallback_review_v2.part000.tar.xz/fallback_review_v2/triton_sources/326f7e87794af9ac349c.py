
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'y': 1024, 'x': 128, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'r0_numel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_per_fused__to_copy_add_native_layer_norm_backward_slice_slice_backward_transpose_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'y': 205586432, 'x': 805376, 'r0_': 105971712}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy_add_native_layer_norm_backward_slice_slice_backward_transpose_view_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, ynumel, xnumel, r0_numel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 832
    xnumel = 121
    r0_numel = 256
    R0_BLOCK: tl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_3 = r0_index
    x2 = xindex
    y1 = yindex // 64
    y0 = (yindex % 64)
    y4 = yindex
    tmp0 = (r0_3 + 256*x2).to(tl.int32)
    tmp1 = tl.full([1, 1, 1], 30878, tl.int32)
    tmp2 = tmp0 < tmp1
    tmp3 = tmp2.to(tl.int1)
    tmp4 = (r0_3 + 256*x2 + 30878*y1).to(tl.int32)
    tmp5 = tl.full([1, 1, 1], 401408, tl.int32)
    tmp6 = tmp4 < tmp5
    tmp7 = tmp6.to(tl.int1)
    tmp8 = tmp7 & tmp3
    tmp9 = (1 + (((r0_3 + 256*x2 + 30878*y1) % 3136))).to(tl.int64)
    tmp10 = (tmp9).to(tl.int64)
    tmp11 = tl.full([1, 1, 1], 1, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = tmp12.to(tl.int1)
    tmp14 = tmp13 & tmp8
    tmp15 = tl.load(in_ptr0 + (64 + y0 + 64*(((r0_3 + 256*x2 + 30878*y1) % 3136)) + 200768*((((r0_3 + 256*x2 + 30878*y1) // 3136) % 128))), tmp14 & xmask & ymask, eviction_policy='evict_last', other=0.0)
    tmp16 = tl.load(in_ptr1 + (3136*y0 + 200704*((((r0_3 + 256*x2 + 30878*y1) // 3136) % 128)) + (((r0_3 + 256*x2 + 30878*y1) % 3136))), tmp14 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp15 + tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp14, tmp18, tmp19)
    tmp21 = tl.full([1, 1, 1], 0.0, tl.float32)
    tmp22 = tl.where(tmp12, tmp20, tmp21)
    tmp23 = tmp10 < tmp11
    tmp24 = tmp23.to(tl.int1)
    tmp25 = tmp24 & tmp8
    tmp26 = tl.load(in_ptr0 + (y0 + 200768*((((r0_3 + 256*x2 + 30878*y1) // 3136) % 128))), tmp25 & xmask & ymask, eviction_policy='evict_first', other=0.0)
    tmp27 = tl.where(tmp23, tmp26, tmp21)
    tmp28 = tmp22 + tmp27
    tmp29 = tl.load(in_ptr2 + (3136*y0 + 200704*((((r0_3 + 256*x2 + 30878*y1) // 3136) % 128)) + (((r0_3 + 256*x2 + 30878*y1) % 3136))), tmp8 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp30 = tmp29.to(tl.float32)
    tmp31 = tl.load(in_ptr3 + (((r0_3 + 256*x2 + 30878*y1) % 401408)), tmp8 & xmask & ymask, eviction_policy='evict_last', other=0.0)
    tmp32 = tmp30 - tmp31
    tmp33 = tl.load(in_ptr4 + (((r0_3 + 256*x2 + 30878*y1) % 401408)), tmp8 & xmask & ymask, eviction_policy='evict_last', other=0.0)
    tmp34 = tmp32 * tmp33
    tmp35 = tmp28 * tmp34
    tmp36 = tl.full(tmp35.shape, 0, tmp35.dtype)
    tmp37 = tl.where(tmp8, tmp35, tmp36)
    tmp38 = tl.full(tmp37.shape, 0, tmp37.dtype)
    tmp39 = tl.where(tmp3, tmp37, tmp38)
    tmp40 = tl.broadcast_to(tmp39, [YBLOCK, XBLOCK, R0_BLOCK])
    tmp42 = tl.where(xmask & ymask, tmp40, 0)
    tmp43 = tl.sum(tmp42, 2)[:, :, None].to(tl.float32)
    tl.store(out_ptr0 + (x2 + 121*y4), tmp43, xmask & ymask)
