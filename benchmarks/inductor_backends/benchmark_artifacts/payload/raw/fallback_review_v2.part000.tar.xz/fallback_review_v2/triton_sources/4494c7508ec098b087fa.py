
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'y': 2048, 'x': 256, 'r0_': 256},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*i1', 'in_ptr3': '*bf16', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'in_ptr6': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'r0_numel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_red_fused__softmax__to_copy_add_mul_permute_prepare_softmax_online_rsub_sigmoid_sub_view_0', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 3, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'y': 157352000, 'x': 14852096, 'r0_': 786759680}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_red_fused__softmax__to_copy_add_mul_permute_prepare_softmax_online_rsub_sigmoid_sub_view_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, out_ptr1, out_ptr2, ynumel, xnumel, r0_numel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    ynumel = 2048
    xnumel = 196
    r0_numel = 196
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None, None]
    ymask = tl.full([YBLOCK], True, tl.int1)[:, None, None]
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, None, :]
    rbase = r0_base
    x2 = xindex
    y0 = (yindex % 16)
    y1 = yindex // 16
    _tmp3_max = tl.full([YBLOCK, XBLOCK, R0_BLOCK], float('-inf'), tl.float32)
    _tmp3_sum = tl.zeros([YBLOCK, XBLOCK, R0_BLOCK], tl.float32)
    y4 = yindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp0 = tl.load(in_ptr0 + (y0 + 16*r0_3 + 3136*x2 + 614656*y1), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tl.broadcast_to(tmp1, [YBLOCK, XBLOCK, R0_BLOCK])

        _tmp3_max_next, _tmp3_sum_next = triton_helpers.online_softmax_combine(
            _tmp3_max, _tmp3_sum, tmp2, False
        )

        _tmp3_max = tl.where(r0_mask & xmask, _tmp3_max_next, _tmp3_max)
        _tmp3_sum = tl.where(r0_mask & xmask, _tmp3_sum_next, _tmp3_sum)

    tmp3, tmp4 = triton_helpers.online_softmax_reduce(
        _tmp3_max, _tmp3_sum, 2, False)
    tmp3 = tmp3[:, :, None]
    tmp4 = tmp4[:, :, None]
    tl.store(out_ptr0 + (x2 + 196*y4), tmp3, xmask)
    tl.store(out_ptr1 + (x2 + 196*y4), tmp4, xmask)
    tmp5 = tl.load(in_ptr1 + ((y4 % 16)), None, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (3200*(y4 // 16) + (((x2 + 196*y4) % 3136))), xmask, eviction_policy='evict_last')
    tmp13 = tl.load(in_ptr4 + (x2 + 196*y4), xmask, eviction_policy='evict_last')
    tmp19 = tl.load(in_ptr5 + (x2 + 196*y4), xmask, eviction_policy='evict_last')
    tmp23 = tl.load(in_ptr6 + (x2 + 196*y4), xmask, eviction_policy='evict_last')
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp10 = tl.load(in_ptr3 + (r0_3 + 196*x2 + 38416*y4), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp26 = tl.load(in_ptr0 + (16*r0_3 + 3136*x2 + 614656*(y4 // 16) + ((y4 % 16))), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp6 = tl.sigmoid(tmp5)
        tmp7 = tl.full([1, 1, 1], 1.0, tl.float32)
        tmp8 = tmp7 - tmp6
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tmp11 * tmp7
        tmp14 = tmp12 - tmp13
        tmp15 = tl.full([1, 1, 1], 0.14433756729740643, tl.float32)
        tmp16 = tmp14 * tmp15
        tmp17 = tmp10 * tmp15
        tmp18 = tmp17.to(tl.float32)
        tmp20 = tmp18 - tmp19
        tmp21 = tl.where(tmp9, tmp16, tmp20)
        tmp22 = libdevice.exp(tmp21)
        tmp24 = (tmp22 / tmp23)
        tmp25 = tmp8 * tmp24
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tmp27 - tmp3
        tmp29 = libdevice.exp(tmp28)
        tmp30 = (tmp29 / tmp4)
        tmp31 = tmp6 * tmp30
        tmp32 = tmp25 + tmp31
        tl.store(out_ptr2 + (r0_3 + 196*x2 + 38432*y4), tmp32, r0_mask & xmask)
