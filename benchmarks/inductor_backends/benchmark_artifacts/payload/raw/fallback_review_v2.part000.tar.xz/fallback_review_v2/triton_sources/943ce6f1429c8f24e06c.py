
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'y': 2048, 'x': 256, 'r0_': 256},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'in_ptr7': '*bf16', 'in_ptr8': '*fp32', 'in_ptr9': '*fp32', 'in_ptr10': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'out_ptr4': '*bf16', 'out_ptr5': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'r0_numel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (10,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (11,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (12,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (13,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (14,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (15,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (16,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_red_fused__softmax__softmax_backward_data__to_copy_add_bmm_div_expand_mul_neg_permute_rsub_sigmoid_squeeze_sub_sum_unsqueeze_view_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 18, 'num_store': 5, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'y': 157352000, 'x': 14852096, 'r0_': 1258815488}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_red_fused__softmax__softmax_backward_data__to_copy_add_bmm_div_expand_mul_neg_permute_rsub_sigmoid_squeeze_sub_sum_unsqueeze_view_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, in_ptr7, in_ptr8, in_ptr9, in_ptr10, out_ptr0, out_ptr1, out_ptr2, out_ptr4, out_ptr5, ynumel, xnumel, r0_numel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    ynumel = 2048
    xnumel = 196
    r0_numel = 196
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None, None]
    ymask = tl.full([YBLOCK], True, tl.int1)[:, None, None]
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, None, :]
    rbase = r0_base
    x2 = xindex
    y0 = (yindex % 16)
    y1 = yindex // 16
    tmp0 = tl.load(in_ptr0 + (x2 + 196*y0 + 3200*y1), xmask, eviction_policy='evict_last')
    y4 = yindex
    tmp5 = tl.load(in_ptr2 + (x2 + 196*y4), xmask, eviction_policy='evict_last')
    tmp11 = tl.load(in_ptr3 + (x2 + 196*y4), xmask, eviction_policy='evict_last')
    tmp15 = tl.load(in_ptr4 + (x2 + 196*y4), xmask, eviction_policy='evict_last')
    tmp20 = tl.load(in_ptr6 + (y0), None, eviction_policy='evict_last')
    tmp26 = tl.load(in_ptr8 + (x2 + 196*y4), xmask, eviction_policy='evict_last')
    tmp29 = tl.load(in_ptr9 + (x2 + 196*y4), xmask, eviction_policy='evict_last')
    tmp33 = tl.load(in_ptr10 + (x2 + 196*y4), xmask, eviction_policy='evict_last')
    _tmp38 = tl.full([YBLOCK, XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp1 = tl.load(in_ptr1 + (r0_3 + 200*x2 + 40000*y4), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tl.load(in_ptr5 + (r0_3 + 196*x2 + 38416*y4), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp24 = tl.load(in_ptr7 + (y0 + 16*r0_3 + 3136*x2 + 614656*y1), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tmp1.to(tl.float32)
        tmp3 = tl.full([1, 1, 1], 1.0, tl.float32)
        tmp4 = tmp2 * tmp3
        tmp6 = tmp4 - tmp5
        tmp7 = tl.full([1, 1, 1], 0.14433756729740643, tl.float32)
        tmp8 = tmp6 * tmp7
        tmp9 = tmp1 * tmp7
        tmp10 = tmp9.to(tl.float32)
        tmp12 = tmp10 - tmp11
        tmp13 = tl.where(tmp0, tmp8, tmp12)
        tmp14 = libdevice.exp(tmp13)
        tmp16 = (tmp14 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = -tmp18
        tmp21 = tl.sigmoid(tmp20)
        tmp22 = tmp3 - tmp21
        tmp23 = tmp22 * tmp16
        tmp25 = tmp24.to(tl.float32)
        tmp27 = tmp25 - tmp26
        tmp28 = libdevice.exp(tmp27)
        tmp30 = (tmp28 / tmp29)
        tmp31 = tmp21 * tmp30
        tmp32 = tmp23 + tmp31
        tmp34 = (tmp32 / tmp33)
        tmp35 = (tmp34 / tmp33)
        tmp36 = tmp19 * tmp35
        tmp37 = tl.broadcast_to(tmp36, [YBLOCK, XBLOCK, R0_BLOCK])
        tmp39 = _tmp38 + tmp37
        _tmp38 = tl.where(r0_mask & xmask, tmp39, _tmp38)
        tl.store(out_ptr0 + (r0_3 + 196*x2 + 38432*y4), tmp16, r0_mask & xmask)
    tmp38 = tl.sum(_tmp38, 2)[:, :, None]
    tl.store(out_ptr1 + (x2 + 196*y4), tmp38, xmask)
    _tmp51 = tl.full([YBLOCK, XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp40 = tl.load(in_ptr5 + (r0_3 + 196*x2 + 38416*y4), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.debug_barrier()
        tmp48 = tl.load(out_ptr0 + (r0_3 + 196*x2 + 38432*y4), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp41 = tmp40.to(tl.float32)
        tmp42 = (tmp41 / tmp33)
        tmp43 = tmp42 + tmp38
        tmp44 = tl.sigmoid(tmp20)
        tmp45 = tl.full([1, 1, 1], 1.0, tl.float32)
        tmp46 = tmp45 - tmp44
        tmp47 = tmp43 * tmp46
        tmp49 = tmp47 * tmp48
        tmp50 = tl.broadcast_to(tmp49, [YBLOCK, XBLOCK, R0_BLOCK])
        tmp52 = _tmp51 + tmp50
        _tmp51 = tl.where(r0_mask & xmask, tmp52, _tmp51)
        tl.store(out_ptr2 + (r0_3 + 196*x2 + 38432*y4), tmp49, r0_mask & xmask)
    tmp51 = tl.sum(_tmp51, 2)[:, :, None]
    tmp64 = tl.load(in_ptr6 + ((y4 % 16)), None, eviction_policy='evict_last')
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tl.debug_barrier()
        tmp53 = tl.load(out_ptr0 + (r0_3 + 196*x2 + 38432*y4), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.debug_barrier()
        tmp55 = tl.load(out_ptr2 + (r0_3 + 196*x2 + 38432*y4), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp60 = tl.load(in_ptr5 + (r0_3 + 196*x2 + 38416*y4), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp67 = tl.load(in_ptr7 + (16*r0_3 + 3136*x2 + 614656*(y4 // 16) + ((y4 % 16))), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp54 = -tmp53
        tmp56 = tl.fma(tmp54, tmp51, tmp55)
        tmp57 = tmp56.to(tl.float32)
        tmp58 = tl.full([1, 1, 1], 0.14433756729740643, tl.float32)
        tmp59 = tmp57 * tmp58
        tmp61 = tmp60.to(tl.float32)
        tmp62 = (tmp61 / tmp33)
        tmp63 = tmp62 + tmp38
        tmp65 = tl.sigmoid(tmp64)
        tmp66 = tmp63 * tmp65
        tmp68 = tmp67.to(tl.float32)
        tmp69 = tmp68 - tmp26
        tmp70 = libdevice.exp(tmp69)
        tmp71 = (tmp70 / tmp29)
        tmp72 = tmp66 * tmp71
        tl.store(out_ptr4 + (r0_3 + 196*x2 + 38416*y4), tmp59, r0_mask & xmask)
        tl.store(out_ptr5 + (r0_3 + 196*x2 + 38432*y4), tmp72, r0_mask & xmask)
