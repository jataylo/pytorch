
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'y': 256, 'x': 128, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*i1', 'in_ptr0': '*fp32', 'in_ptr1': '*i1', 'in_ptr2': '*i1', 'in_ptr3': '*fp32', 'in_ptr4': '*i64', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr3': '*i1', 'out_ptr4': '*fp32', 'load_seed_offset': 'constexpr', 'ynumel': 'i32', 'xnumel': 'i32', 'r0_numel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {'load_seed_offset': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (7,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (8,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (9,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (11,): [['tt.divisibility', 16]], (12,): [['tt.divisibility', 16]], (13,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_per_fused__safe_softmax__to_copy_add_bitwise_and_clone_expand_native_dropout_permute_prepare_softmax_online_scalar_tensor_unsqueeze_view_where_0', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 5, 'num_reduction': 5, 'autotune_hints': set(), 'tiling_scores': {'y': 393216, 'x': 442496, 'r0_': 44044288}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': True, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__safe_softmax__to_copy_add_bitwise_and_clone_expand_native_dropout_permute_prepare_softmax_online_scalar_tensor_unsqueeze_view_where_0(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, out_ptr1, out_ptr3, out_ptr4, load_seed_offset, ynumel, xnumel, r0_numel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 192
    xnumel = 128
    r0_numel = 128
    R0_BLOCK: tl.constexpr = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_3 = r0_index
    x2 = xindex
    y4 = yindex
    y1 = yindex // 6
    y0 = (yindex % 6)
    tmp0 = tl.load(in_ptr0 + (r0_3 + 128*x2 + 16384*y4), xmask & ymask, eviction_policy='evict_first', other=0.0)
    tmp1 = tl.load(in_ptr1 + (x2), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (r0_3 + 128*y1), ymask, eviction_policy='evict_last', other=0.0)
    tmp4 = tl.load(in_ptr3 + (y0 + 6*r0_3 + 768*x2), xmask & ymask, eviction_policy='evict_last', other=0.0)
    tmp3 = tmp1 & tmp2
    tmp5 = tl.full([1, 1, 1], -3.3895313892515355e+38, tl.float32)
    tmp6 = tl.where(tmp3, tmp4, tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp7.to(tl.float32)
    tmp9 = tmp0 + tmp8
    tmp10 = tl.broadcast_to(tmp9, [YBLOCK, XBLOCK, R0_BLOCK])
    tmp12 = tl.broadcast_to(tmp10, [YBLOCK, XBLOCK, R0_BLOCK])
    tmp14 = tl.where(xmask & ymask, tmp12, float("-inf"))
    tmp15 = triton_helpers.fmax2(tmp14, 2)[:, :, None].to(tl.float32)
    tmp16 = tmp10 - tmp15
    tmp17 = libdevice.exp(tmp16)
    tmp18 = tl.broadcast_to(tmp17, [YBLOCK, XBLOCK, R0_BLOCK])
    tmp20 = tl.where(xmask & ymask, tmp18, 0)
    tmp21 = tl.sum(tmp20, 2)[:, :, None].to(tl.float32)
    tmp22 = tl.full([1, 1, 1], float("-inf"), tl.float32)
    tmp23 = tmp9 == tmp22
    tmp24 = tmp23 == 0
    tmp25 = tmp24.to(tl.int64)
    tmp26 = (tmp25 != 0)
    tmp27 = tl.broadcast_to(tmp26, [YBLOCK, XBLOCK, R0_BLOCK])
    tmp29 = tl.where(xmask & ymask, tmp27, False)
    tmp30 = triton_helpers.any(tmp29, 2)[:, :, None].to(tl.int1)
    tmp31 = tmp30 == 0
    tmp32 = tl.load(in_ptr4 + load_seed_offset)
    tmp33 = (r0_3 + 128*x2 + 16384*y4).to(tl.int32)
    tmp34 = tl.rand(tmp32, (tmp33).to(tl.uint32))
    tmp35 = tl.full([1, 1, 1], 0.1, tl.float32)
    tmp36 = tmp34 > tmp35
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tmp9 - tmp15
    tmp39 = libdevice.exp(tmp38)
    tmp40 = (tmp39 / tmp21)
    tmp41 = tl.full([1, 1, 1], 0.0, tl.float32)
    tmp42 = tl.where(tmp31, tmp41, tmp40)
    tmp43 = tmp37 * tmp42
    tmp44 = tl.full([1, 1, 1], 1.1111111111111112, tl.float32)
    tmp45 = tmp43 * tmp44
    tl.store(in_out_ptr0 + (x2 + 128*y4), tmp31, xmask & ymask)
    tl.store(out_ptr3 + (r0_3 + 128*x2 + 16384*y4), tmp36, xmask & ymask)
    tl.store(out_ptr4 + (r0_3 + 128*x2 + 16384*y4), tmp45, xmask & ymask)
    tl.store(out_ptr0 + (x2 + 128*y4), tmp15, xmask & ymask)
    tl.store(out_ptr1 + (x2 + 128*y4), tmp21, xmask & ymask)
