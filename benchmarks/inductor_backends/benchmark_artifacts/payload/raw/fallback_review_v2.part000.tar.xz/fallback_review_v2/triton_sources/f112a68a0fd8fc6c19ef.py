
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'y': 512, 'x': 128, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'r0_numel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_per_fused__to_copy_add_native_layer_norm_backward_slice_slice_backward_transpose_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'y': 102760448, 'x': 401408, 'r0_': 52183040}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy_add_native_layer_norm_backward_slice_slice_backward_transpose_view_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, ynumel, xnumel, r0_numel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 512
    xnumel = 98
    r0_numel = 256
    R0_BLOCK: tl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_3 = r0_index
    x2 = xindex
    y0 = (yindex % 128)
    y1 = yindex // 128
    y4 = yindex
    tmp18 = tl.load(in_ptr2 + (784*y0 + 100352*((r0_3 + 256*x2) // 784) + 3211264*y1 + (((r0_3 + 256*x2) % 784))), xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp20 = tl.load(in_ptr3 + (r0_3 + 256*x2 + 25088*y1), xmask & ymask, eviction_policy='evict_last', other=0.0)
    tmp22 = tl.load(in_ptr4 + (r0_3 + 256*x2 + 25088*y1), xmask & ymask, eviction_policy='evict_last', other=0.0)
    tmp0 = (1 + (((r0_3 + 256*x2) % 784))).to(tl.int64)
    tmp1 = (tmp0).to(tl.int64)
    tmp2 = tl.full([1, 1, 1], 1, tl.int64)
    tmp3 = tmp1 >= tmp2
    tmp4 = tmp3.to(tl.int1)
    tmp5 = tl.load(in_ptr0 + (128 + y0 + 128*(((r0_3 + 256*x2) % 784)) + 100480*((r0_3 + 256*x2) // 784) + 3215360*y1), tmp4 & xmask & ymask, eviction_policy='evict_last', other=0.0)
    tmp6 = tl.load(in_ptr1 + (784*y0 + 100352*((r0_3 + 256*x2) // 784) + 3211264*y1 + (((r0_3 + 256*x2) % 784))), tmp4 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 + tmp7
    tmp9 = tl.full(tmp8.shape, 0.0, tmp8.dtype)
    tmp10 = tl.where(tmp4, tmp8, tmp9)
    tmp11 = tl.full([1, 1, 1], 0.0, tl.float32)
    tmp12 = tl.where(tmp3, tmp10, tmp11)
    tmp13 = tmp1 < tmp2
    tmp14 = tmp13.to(tl.int1)
    tmp15 = tl.load(in_ptr0 + (y0 + 100480*((r0_3 + 256*x2) // 784) + 3215360*y1), tmp14 & xmask & ymask, eviction_policy='evict_first', other=0.0)
    tmp16 = tl.where(tmp13, tmp15, tmp11)
    tmp17 = tmp12 + tmp16
    tmp19 = tmp18.to(tl.float32)
    tmp21 = tmp19 - tmp20
    tmp23 = tmp21 * tmp22
    tmp24 = tmp17 * tmp23
    tmp25 = tl.broadcast_to(tmp24, [YBLOCK, XBLOCK, R0_BLOCK])
    tmp27 = tl.where(xmask & ymask, tmp25, 0)
    tmp28 = tl.sum(tmp27, 2)[:, :, None].to(tl.float32)
    tl.store(out_ptr0 + (x2 + 98*y4), tmp28, xmask & ymask)
