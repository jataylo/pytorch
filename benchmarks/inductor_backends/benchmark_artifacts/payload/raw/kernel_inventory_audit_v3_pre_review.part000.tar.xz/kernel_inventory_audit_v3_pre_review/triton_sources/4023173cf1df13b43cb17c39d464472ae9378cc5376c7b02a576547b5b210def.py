
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'y': 128, 'x': 128, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr0': '*bf16', 'out_ptr2': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'r0_numel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='hip', index=0, multi_processor_count=256, cc='gfx950', major=9, regs_per_multiprocessor=131072, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=64), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (1,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (2,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (3,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (4,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (5,): [['tt.divisibility', 16], ['tt.pointer_range', 32]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_per_fused__to_copy_add_clone_copy_mean_pow_rsqrt_select_transpose_view_0', 'mutated_arg_names': [], 'optimize_mem': False, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'y': 131072, 'x': 0, 'r0_': 20971520}, 'backend_hash': '91F91AEFD6F7BD46048D6DBCE934BD374C3A6814276F769E86ABCEBBDB2FD87D', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': False, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 32, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'is_hip': True}
)
@triton.jit
def triton_per_fused__to_copy_add_clone_copy_mean_pow_rsqrt_select_transpose_view_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, out_ptr2, ynumel, xnumel, r0_numel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 128
    xnumel = 128
    r0_numel = 128
    R0_BLOCK: tl.constexpr = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, None, :]
    roffset = r0_offset
    rindex = r0_index
    x2 = xindex // 64
    r0_3 = r0_index
    x1 = (xindex % 64)
    y0 = yindex
    x4 = xindex
    tmp3 = tl.load(in_ptr0 + (r0_3 + 128*x1 + 8192*y0), xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp4 = tl.load(in_ptr1 + (r0_3 + 128*x1 + 8192*y0), xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp8 = tl.load(in_ptr2 + (r0_3 + 128*x1 + 8192*y0), xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp9 = tl.load(in_ptr3 + (r0_3 + 128*x1 + 8192*y0), xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp0 = (x2).to(tl.int32)
    tmp1 = tl.full([1, 1, 1], 1, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp5 = tmp3 + tmp4
    tmp6 = tl.full([1, 1, 1], 0, tl.int32)
    tmp7 = tmp0 == tmp6
    tmp10 = tmp8 + tmp9
    tmp11 = tl.full([1, 1, 1], 0.0, tl.float32)
    tmp12 = tl.where(tmp7, tmp10, tmp11)
    tmp13 = tl.where(tmp2, tmp5, tmp12)
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tmp14 * tmp14
    tmp16 = tl.broadcast_to(tmp15, [YBLOCK, XBLOCK, R0_BLOCK])
    tmp18 = tl.where(xmask & ymask, tmp16, 0)
    tmp19 = tl.sum(tmp18, 2)[:, :, None].to(tl.float32)
    tmp20 = tl.full([1, 1, 1], 128.0, tl.float32)
    tmp21 = (tmp19 / tmp20)
    tmp22 = tl.full([1, 1, 1], 1e-05, tl.float32)
    tmp23 = tmp21 + tmp22
    tmp24 = tl.rsqrt(tmp23)
    tl.store(out_ptr0 + (r0_3 + 128*x4 + 16384*y0), tmp13, xmask & ymask)
    tl.store(out_ptr2 + (32*x4 + 4096*(y0 // 32) + ((y0 % 32))), tmp24, xmask & ymask)
